# SI Prefixes
**Prefix** Power Symbol
**yocto** 10[���] y
**zepto** 10[���] z
**atto** 10[���] a
**femto** 10[���] f
**pico** 10[���] p
**nano** 10[��] n
**micro** 10[��] 𝜇
**milli** 10[��] m
**centi** 10[��] c
**deci** 10[��] d
**deka** 10[�] da
**hecto** 10[�] h
**kilo** 10[�] k
**mega** 10[�] M
**giga** 10[�] G
**tera** 10[��] T
**peta** 10[��] P
**exa** 10[��] E
**zetta** 10[��] Z
**yotta** 10[��] Y

# Fundamental Masses

**Name** Mass (kg) Mass (u)

**Electron** 9.109 x 10[-31] 0.0005486
**Proton** 1.6726 x 10[-27] 1.007277
**Neutron** 1.6749 x 10[-27] 1.008665
**Muon** 1.8835 x 10[-28] 0.113429

# Some Conversion Factors
**_Length_**
1 m = 39.37 in = 3.21 ft = 1.094 yard
1 km = 0.6214 mi
1 mi = 5280 ft = 1.602 km
1 inch = 2.54 cm

**_Volume_**
1 L = 10[3] cm[3] = 10[-3] m[3] = 1.057 qt

**_Time_**
1 h = 3600 s
1 y = 3.156 x 10[7] s

**_Speed_**
1 km/h = 0.278 m/s = 0.9214 mi/h
1 ft/s = 0.3048 m/s = 0.6818 mi/h


# Important Physical Constants
**Name** Symbol Value
**Atomic mass unit** 𝑎𝑚𝑢 1 𝑢= 1.6605 𝑥10[���] 𝑘𝑔

**Avogadro’s number** 𝑁� 6.0221 𝑥10[��] [𝑝𝑎𝑟𝑡𝑖𝑐𝑙𝑒𝑠]

𝑚𝑜𝑙𝑒

1.3806 𝑥10[���]𝐽/𝐾

**Boltzmann constant** 𝑘= [𝑅]

𝑁� 8.6173 𝑥10[��] 𝑒𝑉/𝐾

1
**Coulomb Constant** 𝑘= 8.9875 𝑥10[�] 𝑁⋅𝑚[�]/𝐶[�]
4𝜋𝜖�

**Fundamental Charge** 𝑒 1.6022 𝑥10[���] 𝐶


**Gas Constant** 𝑅 8.3145 𝐽/(𝑚𝑜𝑙⋅𝐾)

**Universal**
𝐺 6.6738 𝑥10[���]𝑁⋅𝑚[�]/𝑘𝑔[�]
**Gravitational Constant**

**Permeability of Free**
**Space** 𝜇� 4𝜋𝑥10[��]𝑁/𝐴

**Permittivity of Free**
**Space** 𝜖� 8.8542 𝑥10[���]𝐶[�]/(𝑁⋅𝑚[�])


ℎ
**Planck’s Constant**
ℏ= ℎ/2𝜋


6.626 𝑥10[���]𝐽⋅𝑠 = 4.135 𝑥10[���]𝑒𝑉⋅𝑠
1.055 𝑥10[���]𝐽⋅𝑠 = 6.582 𝑥10[���]𝑒𝑉⋅𝑠


**Speed of light** 𝑐 2.9979 x 10[8] m/s[2]

**Stephan-Boltzmann**
𝜎 5.67037 x 10[-8] W/(m[2]K[4])
**constant**

# Terrestrial and Astronomical Data

Mass **Name** Symbol Value
(MeV/c[2]) **Gravitational Field Strength** g 9.81 N/kg =
0.5110 **at earth’s surface** 9.81 m/s[2]
938.27 **Radius of Earth** RE 6.38 x 10[6] m
939.57 **Mass of Earth** ME 5.98 x 10[24] kg
105.66 **Mass of Sun** MS 1.99 x 10[30] kg

**Mass of the moon** Mm 7.35 x 10[22] kg
**Earth-moon distance (mean)** 3.84 x 10[8] m
**Earth-sun distance (mean)** 1.50 x 10[11] m

|Stephan-Boltzmann constant|𝜎|5.67037 x 10-8 W/(m2K4)|
|---|---|---|

|Mass Name Mass (kg) Mass (u) (MeV/c2)|Col2|Col3|Col4|
|---|---|---|---|
|Electron 9.109 x 10-31 0.0005486 0.5110||||
|Proton 1.6726 x 10-27 1.007277 938.27||||
|Neutron 1.6749 x 10-27 1.008665 939.57||||
|Muon|1.8835 x 10-28|0.113429|105.66|

|Name Symbol Value|Col2|Col3|
|---|---|---|
|Gravitational Field Strength g 9.81 N/kg = at earth’s surface 9.81 m/s2|||
|Radius of Earth R 6.38 x 106 m E|||
|Mass of Earth M 5.98 x 1024 kg E|||
|Mass of Sun M 1.99 x 1030 kg S|||
|Mass of the moon M 7.35 x 1022 kg m|||
|Earth-moon distance (mean) 3.84 x 108 m|||
|Earth-sun distance (mean)||1.50 x 1011 m|

|Length 1 m = 39.37 in = 3.21 ft = 1.094 yard 1 km = 0.6214 mi 1 mi = 5280 ft = 1.602 km 1 inch = 2.54 cm Volume 1 L = 103 cm3 = 10-3 m3 = 1.057 qt Time 1 h = 3600 s 1 y = 3.156 x 107 s Speed 1 km/h = 0.278 m/s = 0.9214 mi/h 1 ft/s = 0.3048 m/s = 0.6818 mi/h|Angular Variables 1 rev = 2 rad = 360 degrees 1 rad = 57.30 degrees Mass 1 kg = 2.205 lb (at the surface of the earth) Energy 1 J = 107 erg 1 kWh = 3.6 MJ 1 cal = 4.186 J 1 eV = 1.602 x 10-19 J|
|---|---|


-----

-----

