### – Integration
## Appendix B


_Appendix B expands our discussion of calculus to the ideas of antiderivatives and integrals. The antiderivative is the_
_inverse process to the derivative introduced in Appendix A. In practice, antiderivatives and integrals represent the area_
_under the curve of a function in a given range. In physics, we will use these ideas to find mechanical work, as well as_
_expand the relationships between acceleration, velocity and acceleration._


##### The Bare Essentials

- Given a function, 𝑓(𝑡), the antiderivative of this function, 𝑔(𝑡)

is such that if one takes the derivative of 𝑔(𝑡), we get 𝑓(𝑡)
back:


�𝑓(𝑡)𝑑𝑡= 𝑔(𝑡)


��������
�⎯⎯⎯⎯�     𝑔[�](𝑡) = 𝑓(𝑡)



- The definite integral of a function is the antiderivative of that

function evaluated over a specific region.

- Graphically, the integral of a function between two points

represents the area under the curve of the function between
those two points.

- The Fundamental Theorem of Calculus defines how to get the

integral of a function between two known endpoints.



- Note that the antiderivative of a function (indefinite

integral) is only defined up to a constant (because the
derivative of a constant is zero). This constant, whatever
you call it, must be included in any indefinite integral. For
example

�𝑡[�]𝑑𝑡= [𝑡][�]

3 [+ 𝐶]

must include the +𝐶 term.

- Some important anti-derivatives to know. Below, 𝑡 is the

variable, and 𝑎 and 𝑛 represent constants:

�𝑎 𝑑𝑡= 𝑎𝑡+ 𝐶


**Fundamental Theorem of Calculus**

𝒃

�𝒇[�](𝒕)𝒅𝒕= 𝒇(𝒃) −𝒇(𝒂)

𝒂

**Description – The Fundamental Theorem states that the**

integral of a function, 𝑓’(𝑡), which is the known
derivative of another function 𝑓(𝑡), is equal to the
difference of the values of the 𝑓(𝑡) at the endpoints, 𝑡=
𝑏 and 𝑡= 𝑎 of the region of interest.
**Note: In practice, we must know the anti-derivative of the**

integrand in order to compute the integral from the
Fundamental Theorem.


�𝑡[�]𝑑𝑡= [𝑡][���]

𝑛+ 1 [+ 𝐶]

�sin(𝑎𝑡) 𝑑𝑡= − [1]

𝑎 [cos(𝑎𝑡) + 𝐶]


�cos(𝑎𝑡) 𝑑𝑡= [1]

𝑎 [sin(𝑎𝑡) + 𝐶]

�𝑒[��]𝑑𝑡= [1]

𝑎 [𝑒][��] [+ 𝐶]


-----

#### B.1 – Introduction to Integration

**Consider: What is integration?**

N INDEFINITE INTEGRAL, ALSO KNOWN AS AN antiderivative is the inverse process to the derivative
discussed in Appendix A. Whereas derivatives are concerned with rates of change and the slope of tangent lines,
integrals allow us to find the area under curves and net changes

# A

in a function. In Appendix A, we found that the average velocity of an
object is related to the object’s rate of change via

v�⃗��� = [∆x�⃗]∆t[.] (B-1)

We can rewrite this in order to find the _change in position (known as_
displacement) by solving this equation for ∆x�⃗, giving us

∆x�⃗= v�⃗���∆t. (B-2) **Figure B-1. Constant velocity versus time graph.**

Now, consider Figure B-1, which graphs a constant velocity over a
period of 10 seconds. Since the velocity in Figure B-1 is constant at 3 m/s, this is also the average velocity for the time
period. Therefore, we could find the displacement by multiplying this average velocity by the time over which we are
interested. For example, if the velocity is directed along the positive x-axis, the displacement over the first 5 seconds is

∆x�⃗= (3 𝑚𝑠⁄ )(5 s)x�= 15 𝑚x�, (B-3)

and the displacement over the full 10 seconds would be

∆x�⃗= (3 𝑚𝑠⁄ )(10 s)x�= 30 𝑚x�. (B-4)


In both of these cases, the area of the graph under the
velocity and between the times we care about is a
rectangle in Figure B-1, and in both cases (equations
B-3 and B-4) we used the length and width of the
rectangle to find the change in position (area under the
curve).
Notice that we have done here is the definition of
an inverse process. In equation B-1, we are finding
the velocity in terms of how position changes and in
equation B-2 we are finding how the position changes
in relation to the velocity! We also found in Appendix
A that a difference equation (such as equation B-1)

**Figure B-2. Area under the curve for** works well when the rate of change of position is
**a non-constant function.**

constant, but is only an approximation if the rate of
change changes. In the latter case, we had to use
derivatives. Similarly, the simple multiplication used in equations B-3 and B-4 work well for
constant velocities, but are only crude approximations when the velocity is changing.
Figure B-2 shows a situation where the function, 𝑓(𝑥) – similar to the velocity in our
example above – changes with respect to position. The area under the curve given by 𝑓(𝑥)
between points 𝑎 and 𝑏 is given by the shaded region. The problem is, how can we calculate
how large this area is?
Go back to equations B-3 and B-4. Equation B-3 tells us that the area under the velocity
curve between 𝑡= 0 and 𝑡= 5 is 15 m. We could also use similar reasoning to find that the
area under the velocity curve between 𝑡= 5 and 𝑡= 10 is also 15 m. One way in which we
could find the area under the full curve is the add these two pieces of the curve. By either
adding the pieces, or doing the full calculation (as in equation B-4), we find the total area is 30
m. Even when the function is not constant, we can go through a similar process. Figure B-3
shows the area under a 𝑓(𝑥) = √𝑥 curve between 𝑥= 0 and 𝑥= 1. The shaded region in the


**Figure B-3. Approximating**
**the area under a curve with**
**smaller and smaller**
**rectangles.**


-----

upper panel shows the actual area under this curve. The lower two panels approximate this area using rectangles of width
∆𝑥= 0.2 (middle panel) and ∆𝑥= 0.08 (lower panel). As you can see, the smaller the width of the rectangle, the closer the
approximation is to the actual area under the curve.
An integral does this job for us by taking each rectangle shown in figure B-3 an making the width infinitesimally small,
and then adding the area of all of the rectangles together. Since the approximation of the area gets better as the width of the
rectangles gets smaller, the estimated area tends towards the true area as the width tends towards being infinitely small. The
entire process of adding the large number of small rectangles is called a Riemann Sum. You will study the details of this in
Calculus if you have not done so already.
Symbolically, we write an integral as

�

�𝑓(𝑥)𝑑𝑥, (B-5)

�

where ∫ is the integral symbol, 𝑎 is the leftmost point of interest (starting point), 𝑏 is the rightmost point of interest (end
point) and 𝑑𝑥 represents an infinitesimally small piece of 𝑥 which essentially tells us which variable we are changing.

#### B.2 – Antiderivatives

**Consider: What form does an integral take?**

Section B.1 developed your sense for why we may care about integrals. However, we made no attempt to describe how you
would actually calculate one. The first step to determining the value of an integral is to be able to take the antiderivative or
**_indefinite integral of the function. The antiderivative of a function is the inverse process to the derivative and is such that if_**
we take the derivative of the antiderivative of a function, we must get the original function back:

��������

�𝑓(𝑡)𝑑𝑡= 𝑔(𝑡) �⎯⎯⎯⎯� 𝑔[�](𝑡) = 𝑓(𝑡). (B-6)

There are many techniques to find antiderivatives, some of which are very complicated and subtle. Just as with
derivatives, there are only a few classes of antiderivatives that you should be able to compute. These antiderivatives are
shown in Table B.1.

**Table B1. Table of antiderivatives (indefinite integrals) for Physics I.**


Type **Antiderivative** **Type** **Antiderivative**


�0 𝑑𝑡= 𝐶
**Zero**


�sin(𝑎𝑡) 𝑑𝑡= − [1]
**Sine** 𝑎 [cos(𝑎𝑡) + 𝐶]


�𝑎𝑑𝑡= 𝑎�𝑑𝑡= 𝑎𝑡+ 𝐶
**Constant**


�cos(𝑎𝑡) 𝑑𝑡= [1]
**Cosine** 𝑎 [sin(𝑎𝑡) + 𝐶]


�𝑡[�]𝑑𝑡= [𝑡][���]
**Polynomial** 𝑛+ 1 [+ 𝐶]


�𝑒[��]𝑑𝑡= [1]
**Exponential** 𝑎 [𝑒][��] [+ 𝐶]


Note that each of these antiderivatives includes a +𝐶, where 𝐶 is a constant.  This comes about because the derivative of a
constant is zero. Let me use a quick example to illustrate why this is important. First, remember that as inverse functions, if
we take a derivative and then an immediate antiderivative, we should get the initial function back. Consider the function

𝑓(𝑥) = 𝑥[�] + 4. (B-7)

We can take the derivative of this function to find

𝑓′(𝑥) = 3𝑥[�] + 0 = 3𝑥[�]. (B-8)

Now, we can take the antiderivative of this using the polynomial row of Table B1.


-----

�𝑓′(𝑥) 𝑑𝑥= 3 �𝑥[�]𝑑𝑥= 3 [𝑥][�] (B-9)

3 [+ 𝐶= 𝑥][�] [+ 𝐶.]

When we took the derivative of the function in equation B-8, we lost track of the constant from the original function
(+4). Thus, when we took the antiderivative in equation B-9, it is important to note that there _might be_ a constant in this
function. In practice, we need to know something about the initial conditions of the antiderivative to determine what that
constant is, but it is very important to include the +𝑪 in your solutions of an antiderivative.


Example B - 1 **A first antiderivative**

What is the antiderivative of 𝑥[�] + 𝑥[�] with respect to x, if we
know that the value of the antiderivative at 𝑥= 0 is 2?

**Solution:**

This problem asks us to calculate the antiderivative of a
function with a specific known value. To start this problem,
we must first determine the antiderivative. Just as with
derivatives, we can treat each of the two terms added together
separately and simply add the antiderivatives:

𝑔(𝑥) = �(𝑥[�] + 𝑥[�])𝑑𝑥= �𝑥[�]𝑑𝑥+ �𝑥[�]𝑑𝑥,

where I have called the antiderivative 𝑔(𝑥).

Following the polynomial antiderivative from Table B1, we
know that our new exponent in each case will be the old
exponent plus one and that we must divide each function by
the new exponent:


𝐶= 2.

Therefore, we have used the condition of the problem to
find the constant of integration, and we can fully write:

𝑔(𝑥) = [𝑥][�]

4 [+ 𝑥]3 [�] [+ 2.]


𝑔(𝑥) = �𝑥[�]𝑑𝑥+ �𝑥[�]𝑑𝑥= [𝑥][�]

4 [+ 𝑥]3 [�] [+ 𝐶.]

Please note, again, that we have included the +C term
since we have an indefinite integral.

The problem also tells us that the value of 𝑔(𝑥) at 𝑥 = 0
is 2, or 𝑔(0) = 2. We can use this to find


or


𝑔(0) = 2 = [0][�]

4 [+ 0]3 [�] [+ 𝐶,]


Example B - 2 **Mixed functions**

Find the indefinite integral of the function

𝑓(𝑡) = sin(3𝑡) −cos(2𝑡) + 𝑒[�].

**Solution:**

This problem asks us to practice taking antiderivatives with
mixed functions. First, we note that in order to find the
antiderivative of the entire function, we can take the
antiderivative of each added term and add them together as

𝑔(𝑡) = �sin(3𝑡) 𝑑𝑡−�cos(2𝑡) 𝑑𝑡+ �𝑒[�]𝑑𝑡,

where once again, we have called the antiderivative 𝑔(𝑡).

We can now use the right-hand column of Table B1 to find
the antiderivatives of each function. For ease of viewing, I
will do these separately and then recombine:


�sin(3𝑡) 𝑑𝑡= − [cos (3𝑡)] + 𝐷,

3

�cos(2𝑡) 𝑑𝑡= [sin (2𝑡)] + 𝐸,

2


and

�𝑒[�]𝑑𝑡= 𝑒[�] + 𝐹,

where 𝐷, 𝐸, and 𝐹 are all constants.

These functions can now be added together to give


𝑔(𝑡) = − [cos(3𝑡)] − [sin(2𝑡)] + 𝑒[�] + 𝐶.

3 2

Note that we only need one +C since the initial function
had all three terms in it.


-----

#### B.3 – Definite Integrals

**Consider: How do we calculate definite integrals?**

The Fundamental Theorem of Calculus allows us to combine the antiderivatives from the last section, along with the starting
and end point of an integral to find the area under a curve between those two points:

�

�𝑓[�](𝑡)𝑑𝑡= 𝑓(𝑡)|�� = 𝑓(𝑏) −𝑓(𝑎), (B-10)

�

where 𝑓(𝑡) represents the antiderivative of 𝑓′(𝑡), and the starting and end points are represented by 𝑎 and 𝑏, respectively. In
practical terms, what this tells us is that we can find the area under a curve given by a function 𝑓′(𝑡) using the antiderivative
𝑓(𝑡) evaluated at the end point, minus the antiderivative evaluated at the starting point.
For equation B-10, we say “the definite integral (or often just integral) of 𝑓′(𝑡)𝑑𝑡 is given by 𝑓(𝑏) −𝑓(𝑎).” This
defines how to find the full integral of a function between two points. Please note that when we compute a definite integral
(as opposed to an indefinite integral) we 𝑑𝑜 𝑛𝑜𝑡 have a +𝐶 remaining.


**Fundamental Theorem of Calculus**

𝒃

�𝒇[�](𝒕)𝒅𝒕= 𝒇(𝒃) −𝒇(𝒂)

𝒂

**Description – The Fundamental Theorem states that the**

integral of a function, 𝑓’(𝑡), which is the known
derivative of another function 𝑓(𝑡), is equal to the
difference of the values of the 𝑓(𝑡) at the endpoints, 𝑡=
𝑏 and 𝑡= 𝑎 of the region of interest.
**Note: In practice, we must know the antiderivative of the**

integrand in order to compute the integral from the
Fundamental Theorem.


Example B - 3 **Displacement**

Imaging that a car is initially moving along the positive x-axis
with a speed given by 𝑣(𝑡) = 6𝑡[�] −2𝑡[�]. What is the
displacement of the car between times 𝑡= 2 𝑠 and 𝑡= 5 𝑠?

**Solution:**

This problem asks us to use an integral to find the
displacement of a car between two known times, with a
known velocity function.

Setting up the problem as an integral, we find


�

∆𝑥= �(6𝑡[�] −2𝑡[�])𝑑𝑡

�


= �2𝑡[�] − [𝑡][�] �.

2 [�|][�]


Plugging in the endpoints using the Fundamental
Theorem of Calculus, we find

∆𝑥= �2(5[�]) − [5][�]

2 [�−�2(2][�][) −2]2 [�][�,]


�

∆𝑥= �𝑣(𝑡)𝑑𝑡

�


�

= �(6𝑡[�] −2𝑡[�])𝑑𝑡

�


We first must find the antiderivative of the argument of the
integral


which yields

∆𝑥= −70.5 𝑚.

Since the car was initially moving along the positive xaxis, the result tells us that the final displacement is
70.5 𝑚 from where it started in the direction of
decreasing 𝑥..


-----

Example B - 4 **Harmonic Oscillators**

The velocity of a simple harmonic oscillator as studied in
Physics I follows the general form

𝑣(𝑡) = 𝐴𝑐𝑜𝑠(𝜔𝑡),

where A is the amplitude of oscillation and 𝜔 is the angular
frequency (a measure of how many times per second the
object oscillates). Imagine that a particular oscillator has the
form

𝑣(𝑡) = 10 cos(20𝑡),

where 10 is in meters and 20 is in radians/second. Use
calculus to determine the displacement of the oscillator (in
meters) between 𝑡 = 2 and 𝑡 = 9 seconds.

**Solution:**

This problem asks us to use integration to find the change in
position of an oscillator given a velocity function.

In order to do this, we must first set up the integral equation
as

�

∆𝑥= �10 cos(20𝑡) 𝑑𝑡.

�


We can take the 10 out of the integral since it is a
constant, leaving

�

∆𝑥= 10 �cos(20𝑡) 𝑑𝑡.

�

We can then use the cosine integral from Table B1 to
evaluate this integral, leaving

∆𝑥= 10 � [1] �.

20 [sin(20𝑡)�|][�]


Evaluating the limits gives us

∆𝑥= [10]

20 [[sin(20 ∗9) −sin(20 ∗2)] = 10]20 [(−1.55).]


Simplifying, we get

∆𝑥= −0.78 𝑚.

Therefore, at the end of our 9 second interval the
oscillator is -0.78 meters from where it started.


-----

