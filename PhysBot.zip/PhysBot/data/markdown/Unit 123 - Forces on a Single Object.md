### – Forces on a Single Object
## 123


_Unit 123 begins our exploration of how to use Newton’s laws to determine the dynamics of a system. We will see that_
_Newton’s laws allow us to solve very similar problems to the conservation of energy; however, depending on the desired_
_quantities and system geometry, Newton’s laws are sometimes easier to use than the conservation laws._


##### The Bare Essentials

- The types of forces that can act on an object are directly

related to the interactions the object undergoes.

- When multiple forces are exerted on an object, we can

visualize these forces using a free-body diagram

- The net force on an object (𝐹[⃗]���) is given by the vector sum of

all the forces acting on the object.


**Torque Due to an Individual Force**

𝝉�⃗= 𝒓�⃗ 𝒙 𝑭[��⃗]

**Description – This equation relates the force on an object,**

𝐹[⃗], and the displacement of the force from an axis of
rotation, 𝑟⃗, to the torque produced by the force, 𝜏⃗.



- The torque on an object due to a single force is given by the

cross product of the displacement of the force from the axis of
rotation and the force itself.


**Net Force**

[��⃗]𝑭𝒏𝒆𝒕 = 𝑭[��⃗]𝟏 + 𝑭[��⃗]𝟐 + 𝑭[��⃗]𝟑 + ⋯

**Description – The equation defines the net (vector) force**

on an object as the vector sum of all the forces acting on
the object.
**Note: Each individual force in this equation (𝐹[⃗]� for**

example) should come from one force in a free body
diagram.



- Newton’s 2[nd] Law for rotation relates the net torque (sum of

the torques) on an object to the moment of inertial of the
object and the angular acceleration created by the net torque.



- Vector forces are related to acceleration by Newton’s 2[nd] Law


**Newton’s 2[nd] Law for Rotation**

𝝉�⃗𝒏𝒆𝒕 = 𝑰𝜶��⃗

**Description – Newton’s 2[nd] law for rotation relates the net**

torque on an object, 𝜏⃗���, to the moment of inertia, 𝐼,
and angular acceleration, 𝛼⃗, of the object.
**Note: Like Newton’s 2[nd] law, the 2[nd] law for rotation must**

be used for each object in a system individually.


**Newton’s Second Law**

[��⃗]𝑭𝒏𝒆𝒕 = 𝒎𝒂��⃗

**Description – The equation relates the net force (sum of the**

forces) on an object to the acceleration that the object
undergoes.
**Note: Newton’s second law equations must be done for**

each object in a system separately. This is in
comparison to conservation laws, where a single
equation represented the entire system.


𝐹[⃗] = [𝑑𝑝⃗]

𝑑𝑡 [   →  𝐹⃗= 𝑚𝑎⃗,]

and

𝜏⃗= [𝑑𝐿�⃗]

𝑑𝑡 [  →  𝜏⃗= 𝐼𝛼⃗,]

in the classical limit when mass (𝐹[⃗]) and moment of inertia (𝜏⃗)
are constant.



- As a reminder, note that


-----

#### 123.1 – Types of forces

**Consider: What are the types of forces that we will consider in Physics**
I and Physics II?

S PREVIOUSLY DISCUSSED, THE FORCES THAT ACT on an object are the result of interaction with other
objects. Therefore, it should not be surprising that each of the types of forces that we will consider in Physics I and
Physics II are the result of the interactions we discussed in Unit 102. Table 123-1 names the types of forces we will

# A

encounter, whether the force is a contact force or long-range force, the standard symbols we will use in this book and a short
description that will help you identify each type.

**Table 123-1. Types of common forces in Physics I and Physics II.**

**Interaction** **Contact or** **Standard** **Description**
**Long-range** **Symbol**

**Gravitational** Long-range 𝐹[⃗]� Attractive interaction between any two particles that have
mass. The gravitational interaction is both a fundamental
and mechanical interaction.
**Normal** Contact 𝐹[⃗]� Interaction when two solid objects are compressed against
each other. The normal interaction is always
perpendicular to the surface of the interacting objects.
**Friction** Contact 𝐹[⃗]�� Interaction when two solid objects are compressed against
each other. The friction interaction is always parallel to
the surface of the interacting objects.
**Tension** Contact 𝐹[⃗]� Interaction when two objects are connected but pulled
part or stretched (think of a rope between the objects).
Tension acts along the line of the connecting object.
**Elastic** Contact 𝐹[⃗]� Interaction between two objects connected by a spring or
an interaction that can be modeled as spring-like (atomic
bonds for example).
**Buoyancy** Contact 𝐹[⃗]� Interaction that tends to support a solid object immersed
in a fluid (liquid or gas). Buoyancy acts against the
gradient of pressure in the fluid (often, but not always
vertically).
**Drag and Lift** Contact 𝐹[⃗]�, 𝐹[⃗]� Interactions of a solid object moving in a fluid. Drag acts
opposite the direction of motion and the direction of lift is
perpendicular to the direction of motion.
**Electric** Long-range 𝐹[⃗]� Attraction or repulsion of two objects due to unbalanced
electric charge. We will study this extensively in Physics
II.
**Magnetic** Long-range 𝐹[⃗]� Attraction or repulsion of two objects due to the magnetic
force (generally due to moving electric charges). Studied
in Physics II.

The standard symbols in Table 123-1 are not set in stone – they are really suggestions. What is very important is that
you be consistent with your notation within a given problem. A good best-practice is to specifically describe in words each
force and set a symbol for it so that there is no confusion between yourself, your colleagues and your instructor(s).
Each force in a free body diagram will fall into one of the above categories. Keep in mind that a free body diagram may
have more than one force of a given type and certainly does not need to contain every type listed above.

#### 123.2 – Vector forces on one object

**Consider: How do we combine forces on one object?**

We are now prepared to discuss precisely how multiple forces acting on one object combine to form a **_net force, which is_**
also called a resultant force. All of the important pieces required to do this have already been introduced in this course; our
task now is to combine our knowledge of vectors with free body diagrams to find a vector form for the net force.
Mathematically, the net force is simply the vector sum of all of the forces acting on one object

𝐹[⃗]��� = 𝐹[⃗]� + 𝐹[⃗]� + 𝐹[⃗]� + ⋯. (123-1)

|Table 123-1. Types of common forces in Physics I and Physics II.|Col2|Col3|
|---|---|---|
|Interaction Contact or Standard Description Long-range Symbol|||
|Gravitational Long-range 𝐹⃗ Attractive interaction between any two particles that have ௚ mass. The gravitational interaction is both a fundamental and mechanical interaction.|||
|Normal Contact 𝐹⃗ Interaction when two solid objects are compressed against ே each other. The normal interaction is always perpendicular to the surface of the interacting objects.|||
|Friction Contact 𝐹⃗ Interaction when two solid objects are compressed against ி௥ each other. The friction interaction is always parallel to the surface of the interacting objects.|||
|Tension Contact 𝐹⃗ Interaction when two objects are connected but pulled ் part or stretched (think of a rope between the objects). Tension acts along the line of the connecting object.|||
|Elastic Contact 𝐹⃗ Interaction between two objects connected by a spring or ௦ an interaction that can be modeled as spring-like (atomic bonds for example).|||
|Buoyancy Contact 𝐹⃗ Interaction that tends to support a solid object immersed ஻ in a fluid (liquid or gas). Buoyancy acts against the gradient of pressure in the fluid (often, but not always vertically).|||
|Drag and Lift Contact 𝐹⃗ , 𝐹⃗ Interactions of a solid object moving in a fluid. Drag acts ஽ ௅ opposite the direction of motion and the direction of lift is perpendicular to the direction of motion.|||
|Electric Long-range 𝐹⃗ Attraction or repulsion of two objects due to unbalanced ா electric charge. We will study this extensively in Physics II.|||
|Magnetic Long-range|𝐹⃗ ஻|Attraction or repulsion of two objects due to the magnetic force (generally due to moving electric charges). Studied in Physics II.|


-----

Of course, since this is a vector equation, it can be written in terms of components as


𝐹��

�= �𝐹��

𝐹��


�. (123-2)

(123-3)


𝐹[⃗]��� = �


𝐹�
𝐹�
𝐹�


�+ �


𝐹��
𝐹��
𝐹��


�+ �


𝐹��
𝐹��
𝐹��


�+ ⋯= �


𝐹�� + 𝐹�� + 𝐹�� + ⋯
𝐹�� + 𝐹�� + 𝐹�� + ⋯

𝐹�� + 𝐹�� + 𝐹�� + ⋯


This is really three separate equations, one for each dimension,

𝐹� = 𝐹�� + 𝐹�� + 𝐹�� + ⋯
𝐹� = 𝐹�� + 𝐹�� + 𝐹�� + ⋯

𝐹� = 𝐹�� + 𝐹�� + 𝐹�� + ⋯

which combine to give us the vector net force.


**Net Force**

[��⃗]𝑭𝒏𝒆𝒕 = 𝑭[��⃗]𝟏 + 𝑭[��⃗]𝟐 + 𝑭[��⃗]𝟑 + ⋯

**Description – The equation defines the net (vector) force**

on an object as the vector sum of all the forces acting on
the object.
**Note: Each individual force in this equation (𝐹[⃗]� for**

example) should come from one force in a free body
diagram.


Consider a block of mass m sitting at rest on a table as shown in the free
body diagram in Figure 123-1. As you can see, two forces have been identified
as acting on this block – a normal force directed upwards and the gravitational
force downwards. We can then find the net force acting on the block using
Equation 123-2, taking to the right as +𝑥 and up as +𝑧 as


𝐹[⃗]��� = �


0
0
𝐹� −𝐹�


�. (123-4)


Note in the diagram that we placed the tail of each force where the force acts on
the block; the normal force acts at the interface between the block and the table
and the gravitational force acts on the center of the block. Although this is not **Figure 123-1. Free body diagram of a**

**block on a table.**

necessary when discussing forces for Newton’s 2[nd] law, we will see later in the
Unit that the location of each force is important when taking torque into account.

Next, consider Figure 123-2, which is the same block from Figure 123-1
except that it has an additional external force, labeled F, acting on it. If the angle
between the horizontal is 60°, we can write this force in vector notation as


𝐹[⃗] = �


𝐹cos 𝜃

0
𝐹sin 𝜃


�= �


𝐹cos 60°

0
𝐹sin 60°


�. (123-5)


**Figure 123-2. Free body diagram of a**
**block on a table pulled by an extra**
**force.**


With these three forces, the net vector force is

𝐹[⃗]��� = 𝐹[⃗]� + 𝐹[⃗]� + 𝐹[⃗]. (123-6)

If we are now very explicit about how to add these vectors, we get


-----

𝐹cos 𝜃

�= � 0

𝐹� −𝐹� + 𝐹sin 𝜃


𝐹[⃗]��� = �


0
0
𝐹�


�+ �


0
0
𝐹�


�+ �


𝐹cos 𝜃

0
𝐹sin 𝜃


�. (123-7)


Equations 123-4 and 123-7 show how to determine the net force on an object when forces lie entirely along coordinate axes
and when forces must be decomposed into components. No matter how many forces act on an object, using this technique
for each force individually and then producing the vector sum of all the forces will give you the correct net force.

#### 123.3 – Applying Newton’s second law

**Consider: How can the net force be used to determine how an object**
will move?

Now, that we have a strong understanding of how to find the net force on an object, Newton’s second law can be used to find
the acceleration of the object under that net force. In addition, we can then use our knowledge of kinematics to determine
how velocity and position will change under these conditions.


**Newton’s Second Law**

[��⃗]𝑭𝒏𝒆𝒕 = 𝒎𝒂��⃗

**Description – The equation relates the net force (sum of the**

forces) on an object to the acceleration that the object
undergoes.
**Note: Newton’s second law equations must be done for**

each object in a system separately. This is in
comparison to conservation laws, where a single
equation represented the entire system.


In order to see how Newton’s 2[nd] law leads to an understanding of motion, we will consider, again, the blocks in Figures
123-1 and 123-2. First, I will write down Newton’s 2[nd] law for the block in Figure 123-1, with the known net force from
Equation 123-4

0

𝐹[⃗]��� = � 0 �= 𝑚𝑎⃗. (123-8)

𝐹� −𝐹�

Since the acceleration is also a vector (as noted), this can be written


�


0
0
𝐹� −𝐹�


�= 𝑚�


𝑎�
𝑎��. (123-9)
𝑎�


We can immediately say that the acceleration of the block along the x- and y-axes is zero since there are no forces in those
dimensions. In order to interpret the z-component of this equation, however, we must have some knowledge of the system.
In the case of a block sitting on a standard table, we can say that we know from experience that the acceleration of the block
along this axis is zero. Therefore, the z-component of Newton’s 2[nd] law can be written

𝐹� −𝐹� = 𝑚𝑎� = 0 → 𝐹� = 𝐹�. (123-10)

We can interpret this result as the normal forces on the block is equal to the weight of the block. Please note that this
statement is a result of Newton’s 2[nd] law for this particular example, and is not a general result.
We can take the next step in using Newton’s 2[nd] law by considering the block in Figure 123-2, for which we found the
net force in Equation 123-7. Using this net force in Newton’s 2[nd] law we find


-----

𝐹[⃗]��� = �


𝐹cos 𝜃

0
𝐹� −𝐹� + 𝐹sin 𝜃


�= 𝑚𝑎⃗. (123-11)


As you can see, since this block has components of the net force along two dimensions, it is possible to also have
components of acceleration along two dimensions.


�


𝐹cos 𝜃

0
𝐹� −𝐹� + 𝐹sin 𝜃


�= 𝑚�


𝑎�
𝑎�
𝑎�


�. (123-12)


Again, we must know something about the system in order to interpret the accelerations. In the absence of friction (there is
no friction in the free body diagram), there is no way for the acceleration along the x-direction to be zero since we have an
unbalanced force. However, let’s assume that the block remains on the surface of the table so that the acceleration in the zdirection is zero. This gives us

𝐹cos 𝜃 𝑎�

� 0 �= 𝑚� 0 �. (123-13)

𝐹� −𝐹� + 𝐹sin 𝜃 0

The x-component of Equation 123-13 gives us the acceleration of the block,

𝑎� = [𝐹cos 𝜃]𝑚, (123-14)

and the z-component gives us a relationship for the normal
force **Connection: Normal force and weight**

You must be very careful with normal force and weight. The

𝐹� −𝐹� + 𝐹sin 𝜃= 0, (123-15) two forces are only equal to each other if the two vectors are

the only unopposed forces in the z-direction and the object is
on a horizontal surface **_and there is no acceleration in the z-_**

which gives us

direction. In all other cases, the normal force is not equal to
the weight!

𝐹� = 𝐹� −𝐹sin 𝜃. (123-16)

Please note that the addition of the force, 𝐹[⃗], has not only caused the block to accelerate, but it has also changed the normal
force so that it is no longer equal to the weight! See the connection box above for more information.


Example 123 - 1 **Elevators and apparent weight**

A 2.00-kg box sits on the floor of an elevator. If the
maximum acceleration of the elevator has a magnitude of 1.35
m/s[2], what are the maximum and minimum values of the
normal force of the floor of the elevator on the box?

**Solution:**

This problem is a direct application of Newton’s 2[nd] law. A
free body diagram of the box includes only the normal force
of the elevator on the box and the force of gravity as shown
below.


If we take up as the positive z-direction, Newton’s 2[nd]
law gives us

0 0

� 0 �= 𝑚�0�.

𝐹� −𝐹� 𝑎

Therefore, the normal force can be written

𝐹� = 𝐹� + 𝑚𝑎.

The acceleration of the elevator can be either positive or
negative, for example, when the elevator is accelerating
upward from rest and downward from rest, respectively.

We can then use our general equation for the
gravitational force and this relationship for max upward
and downward acceleration to write


-----

𝐹�,��� = 𝑚𝑔+ 𝑚𝑎= 𝑚(𝑔+ 𝑎), and
and

𝐹�,��� = 𝑚𝑔−𝑚𝑎= 𝑚(𝑔−𝑎), 𝐹�,��� = 2.00𝑘𝑔(9.8 0𝑁𝑘𝑔⁄ −1.35 𝑚𝑠⁄ [�]) = 16.9 𝑁,

respectively. respectively.

Using the values from the problem, we find When the elevators is not accelerating, the normal force

is 19.6 𝑁. Therefore, we see that the normal force does

𝐹�,��� = 2.00𝑘𝑔(9.8 0𝑁𝑘𝑔⁄ + 1.35 𝑚𝑠⁄ [�]) = 22.3 𝑁, depend on the acceleration of the elevator.

Extension:

The normal force acting on an object under acceleration (as in One of the great accomplishments of Newton (and later
the elevator above) is known as the apparent weight. This Einstein in more depth) is a relationship between
name comes from the fact that under acceleration, such as in acceleration and gravity known as the equivalence
an elevator, we feel like our weight is being adjusted by the **_principle. A detail look at this principle is beyond the_**
acceleration. Our actual weight (gravitational force) has not scope of this course; however, it is interesting to note that
changed, however. The change in the way we feel is due to accelerating objects always act as though they are being
this acceleration. acted on by a complicated form of gravity.

#### 123.4 – Torque and the 2[nd] law for rotations

**Consider: How does a force cause an object to rotate?**

Torque is the tendency for a force to change the rotational state of an object. In general, torque depends on three things

1) the force applied,
2) the distance between where the force is applied and the axis of rotation, known as the moment arm,
3) the angle between the force and the moment arm.

To put this in perspective, see Figure 123-3, which shows forces applied to a
wrench when trying to turn a bolt. Imagine you are trying to turn this bolt. Let’s
consider each of the above three points

1) **Moment arm. Do you feel it would be more effective if you were to**

apply the force at point A, or at point B? Point B would be more
effective, and it turns out this is generally true – the farther a force is
from the axis of rotation (O in figure 123-3) the greater the torque.

2) **Force. As you can imagine, the greater the force, the greater the** **Figure 123-3. Depictions of how forces**

tendency to rotate the bolt (greater torque). **lead to a torque on a wrench.**

3) **Angle. Finally, consider the angle. In Figure 123-3, both the forces are perpendicular to the moment arm (a vector**

that starts at the axis of rotation and goes to the point where the force acts). Imagine if instead of perpendicular to
the moment arm, you tried to push along the handle of the wrench (parallel to the moment arm). This would not be
very effective at all in terms of getting the wrench to rotate. The more perpendicular the moment arm and the force
is, the greater the torque.

It turns out the most effective was to combine these ideas together is via the cross product,

𝜏⃗= 𝑟⃗𝑥𝐹[⃗], (123-17)

with magnitude

|𝜏⃗| = |𝑟⃗|�𝐹[⃗]�sin 𝜃, (123-18)


-----

**Figure 123-4. Moment arm, force,**
**angle and torque.**


and a direction given by the right hand rule. The magnitude shown in Equation
123-18 fits all of the criteria we need – a larger moment arm or force leads to a
larger toque. Also, if the moment arm and force are perpendicular, we have a
maximum torque, whereas if they are parallel, we have zero torque. Angles in
between this value likewise have magnitudes between zero and the maximum.
Another way to view the relationship between moment arm, force,
angle and torque is shown in Figure 123-4. This figure shows a force at an angle
𝜃 relative to the moment arm, 𝑟. The figure shows how the component 𝐹sin 𝜃 is
perpendicular to r. That is, it is only the component of the force perpendicular to
the moment arm that leads to a torque. In addition, the figure shows how the
right hand rule applied to this system gives you a torque that is out of the page.


**Torque Due to an Individual Force**

𝝉�⃗= 𝒓�⃗ 𝒙 𝑭[��⃗]

**Description – This equation relates the force on an object,**

𝐹[⃗], and the displacement of the force from an axis of
rotation, 𝑟⃗, to the torque produced by the force, 𝜏⃗.


Example 123 - 2 **A bar and a force**

A rigid metal bar with length 0.79 meters is situated along
the x-axis of a coordinate system with one of its ends at the
origin. If a force of 2.22 N acts on the bar, what is the
torque on the bar due to the force if the force

a) is directed along the positive y-axis and is

imparted at the far end of the bar
b) is directed 30° from the positive x-axis towards the

positive y-axis and is imparted at the far end of the
bar
c) is directed 57° from the positive x-axis toward the

negative y-axis and is imparted at the midpoint of
the bar.

**Solution:**

This problem asks us to find the torque due to an individual
force for three situations

a) As shown to the right, for this
part, the force is perpendicular to
the moment arm (𝜃= 90°). This
suggests that it is easiest to find the
torque by the magnitude and right
hand rule. The magnitude is

|𝜏⃗| = |𝑟⃗|�𝐹[⃗]�sin 𝜃= (0.79𝑚)(2.22𝑁) sin 90°,

which gives us

|𝜏⃗| = 1.75 𝑁⋅𝑚.


The right hand rule gives the direction of the torque as out
of the page (positive-z). We could also do this using the
cross product:


𝚤̂ 𝚥̂ 𝑘[�]

𝜏⃗= 𝑟⃗𝑥𝐹[⃗] = �𝑟� 𝑟� 𝑟�

𝐹� 𝐹� 𝐹�


𝚤̂ 𝚥̂ 𝑘[�]

�= �0.79𝑚 0 0

0 2.22 𝑁 0


�,


which gives us the same answer of

𝜏⃗= (1.75 𝑁⋅𝑚 )𝑘[�].

b) The situation is again shown to
the right. Again, since we know
the magnitude of each vector and
the angle between them, it is
easiest to use the magnitude form
of the cross product with the right
hand rule.

|𝜏⃗| = |𝑟⃗|�𝐹[⃗]�sin 𝜃= (0.79𝑚)(2.22𝑁) sin 30°

leading to

|𝜏⃗| = 0.877 𝑁⋅𝑚.

The right hand rule, again, gives out of the page for the
direction.


-----

c) For this part, since the
force acts at the halfway point
of the bar, the moment arm is
half length of the bar. In
addition, we have to be
concerned about the direction
of the torque, since this force is trying to rotate the bar
clockwise, whereas the force in the last two sections was
trying to rotate the bar counter-clockwise. We first solve
this by using the magnitude formula,

|𝜏⃗| = |𝑟⃗|�𝐹[⃗]�sin 𝜃= [1]

2 [(0.79𝑚)(2.22𝑁) sin 57°,]

which gives us

|𝜏⃗| = 0.735 𝑁⋅𝑚.

In this case, however, the right hand rule suggests the
torque is into the page (negative z-direction).


We can confirm this result by finding the torque using the
cross product


In the above, note that the moment arm (half the length of
the bar) is 0.395 m, and we used sine and cosine to find the
components of the force is the x- and y-directions.

Computing the cross product, we find

𝜏⃗= −(0.735 𝑁⋅𝑚)𝑘[�],

as expected. Please note that it is often possible to use
either method (magnitude/right hand rule or cross product)
to find the torque due to a force; however, for a given
problem, one method is often easier than the other.
Spending time at the beginning of the problem deciding
how to attack it can save time in the long run.


𝜏⃗= 𝑟⃗𝑥𝐹[⃗] = �


𝚤̂ 𝚥̂ 𝑘[�]
0.395𝑚 0 0
2.22 cos 57°𝑁 −2.22 sin 57° 𝑁 0


�,


Example 123 - 3 **Parallel torques**

Describe what happens to the torque on an object due to a
single force that is

a) parallel to the moment arm,
b) on a line that passes through the axis.

**Solution:**

This problem asks us to describe the results of specific actions
of a force creating a torque on an object. The answer to both
parts a) and b) is that the torque is zero; however, we have
two different reasons:


a) In this case, the angle between the force and the
moment arm is 0° and sin 0° = 0, so

|𝜏⃗| = |𝑟⃗|�𝐹[⃗]�sin 0 = 0.

b) If the force acts along a line through the axis, then the
moment arm is zero (𝑟⃗= 0) in the magnitude equation,
leading to

|𝜏⃗| = �0[�⃗]��𝐹[⃗]�sin 𝜃= 0.

.


There is a version of Newton’s 2[nd] law that has been developed for rotational motion, known, unsurprisingly, as
**_Newton’s 2[nd] law for rotation. Just as the net force on an object is proportional to its linear acceleration, the net torque on an_**
object (vector sum of the torques) is proportional to its angular acceleration. For the linear relationship, the constant of
proportionality is the mass of the object (its inertia, or ability to resist changes in motion); therefore, by analogy, the constant
of proportionality for Newton’s 2[nd] law for rotations is the moment of inertia of the body (ability to resist changes in
rotational motion).


**Newton’s 2[nd] Law for Rotation**

𝝉�⃗𝒏𝒆𝒕 = 𝑰𝜶��⃗

**Description – Newton’s 2[nd] law for rotation relates the net**

torque on an object, 𝜏⃗���, to the moment of inertia, 𝐼,
and angular acceleration, 𝛼⃗, of the object.
**Note: Like Newton’s 2[nd] law, the 2[nd] law for rotation must**

be used for each object in a system individually.


-----

Example 123 - 4 **A single torque**

A single torque

𝜏⃗= (20 𝑁∙𝑚)𝚤̂

acts on a hollow ball of mass 1.28 kg and radius 20 cm. What
is the angular acceleration of the ball that results assuming no
other forces act on the ball?

**Solution:**

This problem asks us to use Newton’s 2[nd] law for rotations


to find an angular acceleration. Rearranging our vector
equation, we find

𝛼⃗= [1]

𝐼 [𝜏⃗][���][,]

where 𝐼= (2 3⁄ )𝑚𝑟[�] for a hollow sphere. Using values
from the problem, we find

1
𝛼⃗= ⁄ .
(2 3⁄ )(1.28𝑘𝑔)(0.20𝑚)[�] [(20 𝑁∙𝑚)𝚤̂ = 586 𝑟𝑎𝑑𝑠][�][ 𝚤̂]


Example 123 - 5 **A whole bunch of torques**

Imagine that the bar in Example 123-2 is acted upon by all
three forces (parts a-c) and that it has a mass of 5.25 kg. a)
What is the net torque on the bar? b) What is the angular
acceleration of the bar? c) What is the linear acceleration of a
point at the end of the bar? You may assume that the bar is
fixed at the origin and that no other forces act on the bar
except those from Example 123-2.

**Solution:**

This problem asks us to analyze a situation where many
forces cause a torque on an object.

a) We start by summarizing the torques we found in Example
123-4:

𝜏⃗� = (1.75 𝑁⋅𝑚 )𝑘[�],

𝜏⃗� = (0.877 𝑁⋅𝑚)𝑘[�],

𝜏⃗� = −(0.735 𝑁⋅𝑚)𝑘[�].

We then find the net torque through vector addition of these
three constituent torques, giving us

𝜏⃗��� = (1.75 𝑁⋅𝑚 )𝑘[�] + (0.877 𝑁⋅𝑚)𝑘[�] −(0.735 𝑁⋅𝑚)𝑘[�],

or

𝜏⃗��� = (1.89 𝑁⋅𝑚)𝑘[�]

b) The angular acceleration of the bar is then found using
Newton’s 2[nd] law for rotations solved for the angular
acceleration


𝛼⃗= [1]

𝐼 [𝜏⃗][���][.]

The moment of inertia for the bar can be found using
Table 109-2


𝐼��� = [1]3 [𝑚𝑙][�] [= 1]3 [(5.25 𝑘𝑔)(0.79𝑚)][�] [= 1.09 𝑘𝑔∙𝑚][�][.]

The angular acceleration is then

1
𝛼⃗= ⁄ 𝑘[�].
(1.09 𝑘𝑔∙𝑚[�]) [(1.89 𝑁⋅𝑚)𝑘�= 1.73 𝑟𝑎𝑑𝑠][�]

Note that the net torque and the angular acceleration are
in the same direction as they should be by Newton’s 2[nd]
law for rotations.

c) The magnitude of the linear acceleration is found using

𝑎= 𝛼𝑟,

where 𝑟 is the distance from the axis (length of the bar in
this case). Therefore the linear acceleration is

𝑎= (1.73 𝑟𝑎𝑑𝑠⁄ [�])(0.79𝑚) = 1.37 𝑚𝑠⁄ [�]

Since the angular acceleration is working to rotate the bar
counter-clockwise, the linear acceleration of the particle
as shown in the figures for Example 123-2 must be up the
page (along the positive y-axis).


-----

-----

