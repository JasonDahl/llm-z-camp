### – Chemical and Nuclear Energy
## 112


_There is hidden energy stored inside of chemical bonds as well as the nuclei of atoms. The human body runs on energy_
_stored in the bonds of biomolecules found in each of our cells. In unit 112 we will first explore how cellular structure_
_and chemistry lead to this energy storage and release and how this relates to production of mechanical work and long-_
_term energy storage in the body. Following this, we will explore how large amounts of energy are stored hidden away in_
_the nucleus of almost all atoms._

##### Integration of Ideas

    - The ideas of fundamental electromagnetic and nuclear interactions from unit 101.
    - The ideas of potential energy and energy diagrams from units 106 and 107


##### The Bare Essentials

- Two commonly used units for heat are the calorie and

**_kilocalorie (Calorie), where_**

1 𝑐𝑎𝑙= 4.184 𝐽

1 𝑘𝑐𝑎𝑙= 1 𝐶𝑎𝑙= 4,184 𝐽

- All biological processes harness “hidden” energy stored in

the bonds of specific biomolecules. The most important
biomolecule for the conversion of chemical energy to
mechanical energy is Adenosine Triphosphate (ATP) with
energy storage of

𝐸��� = 29 𝑘𝐽/𝑘𝑔.

- ATP is produced in the mitochondria of your cells, one of

the many cellular structures known as organelles. There are
typically 1,000 – 2,000 mitochondria per cell.

- Energy balance in the human body at a basic level is a

measure of energy in versus energy out. Excess energy is
stored as adipose tissue (fat).

∆𝐸������ = 𝐸���� −𝐸��������

- Your Basal Metabolic Rate (BMR) or Resting Energy

Expenditure (REE) is a measure of how much energy your
body requires at minimum effort. REE can be estimated by
gender, height, weight and age using either the Harris**_Benedict Formula or the Mifflin Formula._**

- One pound of adipose tissue (fat) stores 3500 Calories

(kcal) of energy.


**Binding Energy per Nucleon**

𝚫𝑬
𝚫𝐞=
𝒏𝒑 + 𝒏𝒏

**Description – This equation defines the binding energy per**

nucleon, ∆e, as the binding energy of a nucleus, ∆𝐸,
divided by the total number nucleons (protons and
neutrons), 𝑛� + 𝑛�
**Note: The binding energy per nucleon peaks at iron-56,**

meaning that iron-56 is the most stable of the nuclei
currently known.



- When protons and neutrons combine to form a nucleus, the

mass of the nucleus is less than the mass of the parts that make
it up. This mass deficit is directly related to the nuclear
**_binding energy of the nucleus by Einstein’s famous equation._**


**Nuclear Binding Energy**

𝚫𝑬= 𝚫𝒎𝒄[𝟐]

**Description – The equation defines the nuclear binding**

energy, ∆𝐸, resulting from a mass deficit, ∆𝑚. c is the
speed of light in vacuum.
**Note: The mass deficit is found as the difference between**

the mass of the constituent particles and the mass of the
nucleus as a whole: ∆𝑚= 𝑚����� −𝑚�������,.



- Often, the nuclear binding energy is discussed as the binding

energy per nucleon


-----

#### 112.1 – Measuring energy stored in molecules: the calorie

**Consider: What is a Calorie when I look at nutrition information?**

HE ENERGY REQUIRED TO RAISE one gram of water one degree Celsius at standard pressure is called the calorie.
In the 19[th] Century, it wasn’t clear that mechanical energy and heat are as intimately related as we know the today, so
the calorie was defined to be the heat equivalent of energy. Although the Joule is the international standard unit for

# T

energy, the calorie and its derivatives continue to be very common in calorimetry, food science and exercise science.
Today, we know that heat is one of the main forms of energy transfers, so scientists feel comfortable moving between
calories and Joules in most settings. The conversion factor for Joules and calories is

1 𝑐𝑎𝑙𝑜𝑟𝑖𝑒(𝑐𝑎𝑙) = 4.184 𝐽𝑜𝑢𝑙𝑒𝑠(𝐽). (112-1)

When you read the nutrition information on the side of any registered food product in the U.S., the Calories listed are actually
kilocalories, 1000 calories. This second standard unit, the Calorie (Cal, note the capital C) is most often seen in food and
exercise science, whereas the calorie (little c) is still used in basic science. You must be very careful which unit you are
dealing with, as the factor of 1000 can change the result of a problem dramatically. Since most of the application we will
explore in this unit will use the kilocalorie (Calorie), it is important to note the conversion factor for this unit as well

1 𝐶𝑎𝑙𝑜𝑟𝑖𝑒(𝐶𝑎𝑙) = 1000 𝑐𝑎𝑙= 1 𝑘𝑖𝑙𝑜𝑐𝑎𝑙(𝑘𝑐𝑎𝑙) = 4,184 𝐽𝑜𝑢𝑙𝑒𝑠(𝐽). (112-2)

We will see Calories in the next couple of sections while exploring energy and the human body. However, in the second half
of the unit, when we deal with nuclear energy, we will have to re-introduce another alternate energy unit, the electron-volt.

#### 112.2 – Life: Harnessing energy from chemical bonds

**Consider: How is energy stored and released in a human?**

Energy plays a role in every single biological process that occurs in your body. Many of the energy interactions occur across
the cell membrane of your cells. Figure 112-1 gives a view of many of the features of a typical cell membrane. The most
basic structure of the cell membrane is the phospholipid bilayer – a double layer of molecules which each have a hydrophilic
(water-loving) head and hydrophobic (water-hating) set of tails. All other features of the membrane are somehow attached to
the cell membrane. Interestingly enough, when phosopholipids are place in water, they will inherently form into bilayer
spheres resembling basic cells due to the molecules water attracting and repelling sides.

**Figure 112-1. A typical cell membrane. The phospholipid bilayer forms the backbone for other important molecules including**
**proteins, lipids and cholesterol.**


-----

All of the various structures added to the bilayer membrane have specific purposes. Cholesterol (which generally gets a bad
rap) is integrated into the membrane to adjust the fluidity of membrane structures. When there is more cholesterol in the
membrane, membrane structures are not as free to flow (think of object flowing in water – cholesterol makes the membrane
more viscous). Many peripheral and integral proteins are important for binding molecules and transporting them into or out
of the cell or signaling another process in the cell.
A specific series of integral membrane proteins are called ion channels and pumps. These proteins are responsible for
shuttling ions such as calcium, potassium and sodium into and out of the cell. In general, these pumps act to maintain
different concentrations of ions between the outside and inside of the cell (known as a concentration gradient). This
concentration gradient creates an electrostatic potential difference between the inside and outside of each cell. One of the
most important biological processes including energy if is for the channels and pumps to sense a ‘trigger’ causing them to
rapidly change the ion gradient by moving ions across the membrane. This is the process by which electrical signals are sent

by nerve cells throughout your body.
This is also the process by which a nerve
cell can initiate a muscle contraction, as
the signal sent down a nerve cell reaches
a muscle cell causing a similar rapid
change in ion gradient.
The science behind cell signaling
and electric transport through nerve and
muscle cells is fascinating and far more
complex than we let on here. However,
this is the level we need to understand
cell structure to begin to explore muscle
contraction and the connection between
internal chemical energy and external
mechanical energy. If you find this
interesting, I would encourage you to
explore more on your own.
Figure 112-2 shows the basic
structure of an animal cell. As you can
see, the entire structure is surrounded by

**Figure 112-2. Structure of a typical animal cell. The structures inside the cell**

the phospholipid (plasma) membrane we

**are called organelles and each have has specific functions.**

just discussed. Some of the important
features you will find in the cell are

   - The Nucleus where your DNA is stored,

   - **_Ribosomes where proteins are synthesized,_**

   - **_Golgi Vesicles where proteins are packaged for secretion,_**

   - **_Lysosomes which contain digestive enzymes,_**

   - **_Endoplasmic Reticulum which protein synthesis occur in conjunction with ribosomes,_**

   - **_Mitochondria where food from energy is packaged into Adenosine Triphosphate._**

For our purpose, we will focus on the mitochondria at this point. A typical cell will have between 1000 and 2000
mitochondria. In a process known as cellular respiration,
mitochondria take sugars obtained from food and produce
**_Adenosine Triphosphate (ATP). The chemical structure_**
of ATP is shown in Figure 112-3. ATP is the main energy
storage molecule of the cells in your body. Note on the
left side of Figure 112-3, there are three phosphate groups
(P’s with O’s around them). A relatively large amount of
energy is stored in each of these phosphate bonds. One of
the ways to liberate energy from ATP is for a muscle cell
to break one of the phosphate bonds using water in a
process known as **_hydrolysis. This process leaves a_**
molecule similar to Figure 112-3, but with only two
phosphate groups. This product is called Adenosine
Diphosphate (ADP). **Figure 112-3. The chemical structure of ATP.**


-----

The hydrolysis of ATP to ADP can be written as

𝐴𝑇𝑃[��] + 𝐻�𝑂→ 𝐴𝐷𝑃[��] + 𝐻𝑃𝑂��� + 𝐻�, (112-3)

where 𝐻𝑃𝑂��� represents the cleaved phosphate group and 𝐻� is a positively charged hydrogen ion. This process releases

7.3 𝑘𝑐𝑎𝑙 of energy per mole (29 kJ/mole). Another process, the conversion of ATP to Adenosine Monophosphate (AMP –
consider Figure 112-3 with only one phosphate group) releases 10.9

**Table 112-1. ATP Hydrolysis information.**

kcal/mole (43 kJ/mole). In normal physiologic conditions, equation 112-3

**Description** Value Units

requires an enzyme to catalyze the reactions; otherwise, any ATP present

**ATP Molar Mass** 507.18 g/mole

in water would be immediately converted to ADP and its use as an energy

**Energy released** 7.3 kcal/mole

storage mechanism would be depleted. Important quantities for ATP

29 kJ/mole

hydrolysis are shown in Table 112-1.

Example 112 - 1 **Example Problem**

How many ATP molecules must be hydrolyzed to ADP in that each mole contains Avogadro’s number of
order to release 1 Joule? molecules. So

**Solution:** 29 𝑘𝐽𝑚𝑜𝑙𝑒⁄

1𝐽= 𝑁 .
6.022𝑥10[��] 𝑚𝑜𝑙𝑚𝑜𝑙𝑒⁄

This problem is essentially a conversion factor to relate
chemical energy to the scale of everyday energy. Solving for N, we find

We know that each hydrolysis provides 29 kJ/mole and 𝑁= 2.08 𝑥10[��] 𝑚𝑜𝑙𝑒𝑐𝑢𝑙𝑒𝑠.

#### 112.3 – Energy stored in food and tissue


**Consider: How much energy is stored in food and in the body?**

So, now we know a little bit about how energy is stored and released in our cells, **Table 112-2. Energy content of various**
but what are some practical consequences of this information? Much of the food **food sources**
we eat can be broken into one of three categories – fat, protein and carbohydrates. **Food source** Value
Each of these food sources contains different energy capacity, as shown in Table (kcal/g)
112.2. **Fats** 9
Much of the excess energy you eat is stored as adipose tissue (fat) in your **Carbohydrates** 4
body. The basic equation is energy in – energy out = stored fat. Storing energy **Protein** 4
in body fat is historically very important for humans. When food was plentiful,
storing energy allowed for survival during times of less food. Today, of course, we have to be very careful as our modern
lifestyles and ease of access to food (at least here in the U.S.) have put us in a situation where it is quite easy for us to overeat

and store far more fat than our bodies need. One pound of fat

**Connection: Minimum body fat**

**_stores 3500 Calories (3500 kcal) of energy._**
Your bodies need energy just to survive. Each type of

Having some body fat is extremely important for health, both

tissue must maintain itself as well as repair damage that

in terms of regulating physiological processes and buffering

happens due to injury and general wear-and-tear. The amount

organs in your body. In general, essential fat percentage for
men is 2%-5% of body weight and 10%-13% for women. of energy each type of tissue needs is different based on their
Obesity is considered >25% for men and >32% for women. physiological activity. Table 112-3 gives general guidance for
These guideline percentages increase with age, but are good how much energy some types of tissue require for basic
guidelines for young, healthy adults. survival.

AS you **Table 112-3. Resting energy use of various tissue**

**types.**

might imagine, your overall body make-up then has a direct impact on your

**Tissue type** Energy per Day

daily energy needs, especially when you consider how much higher the

(kJ/kg)   (kcal/kg)

energy requirements of muscle are when compared to other tissue types. In

**Skeletal muscle** 54.4 13.0

the next section we will explore a couple of models to estimate your daily

**Adipose tissue (fat)** 18.8 4.5

required energy intake. Generally though, a 2,000 – 2,200 Calorie diet is

**Bone** 9.6 2.3

**_used as a standard._**


-----

Of course, we get our energy from food. Again, I remind you that we are not
concerning ourselves with the detail of nutritional standards for healthy living, but
only considering the important energy factor: energy in – energy out = stored
energy (fat). Each food we eat contains a certain amount of energy (Calories).
Given Table 112-2 showing how much energy each type of food source contains
per gram, it is not surprising that foods high in fats are generally high in calories.
In addition, keep in mind that diets high in fat also tend to lack some of the other
important factors to keep your body running at an optimal level. Table 112-4
gives a Calorie or Calorie ranges for some typical or surprising foods.


**Table 112-4. Calories for some foods**

**Food** Value

(Cal)
**Cereal (3/4 cup)** 120 - 200
**McDonald’s Big Mac** 540
**Restaurant Salad** 1300+
**Milk (1 cup)** 110
**Energy bar (typical)** 200
**Caramel Frappuccino** 2,000
**Bagel** 300
**Doughnut** 200 – 300
**Fresh fish (service)** 150-200
**BK Triple whopper meal** 2,100


#### 112.4 – The Harris-Benedict / Mifflin equations and caloric needs

**Consider: Can I estimate how many Calories per day I need?**

In 1919, James Arthur Harris and Francis Gano Benedict published a report estimating the caloric requirements for men and
women based on their gender, weight, height and age. Their formula was revised in 1984 by Roza and Shizgal. Such energy
requirements are called either basal metabolic rates (BMR) or resting energy requirements (REE). Although the HarrisBenedict equations remained the hallmark of energy prediction for nearly a century, researchers became concerned that
modern lifestyle, including modern medical care on one side and the rising prevalence of obesity on the other, required a
revised equation for predicting energy requirements. As such, in 1990, Miflin, et.al. released a revised set of equations for
calculating REE.
Table 112-5 presents the Harris-Benedict (H-B) equations and Mifflin equations for both men and women. Although the
Mifflin equations were designed to take into account modern lifestyles as noted above, I believe that the classic HarrisBenedict equation may be better suited to young, active individuals such as cadets at the Coast Guard Academy, which is
why both are presented in this text.

**Table 112-5. Harris-Benedict and Mifflin Formulas for Men and Women.**
**Model** **BMR Equation**


**H-B Men** REE = 88.362 + (13.397 x weight in kg) + (4.799 x height in cm) - (5.677 x age in years)


**H-B Women** REE = 447.593 + (9.247 x weight in kg) + (3.098 x height in cm) - (4.330 x age in years)


**Mifflin Men** REE = 5 + (10 x weight in kg) + (6.25 x height in cm) – (5 x age in years)


**Mifflin Women** REE = -161 + (10 x weight in kg) + (6.25 x height in cm) – (5 x age in years)


The 95% confidence interval for the Harris-Benedict formula is ±210.5 𝑘𝑐𝑎𝑙/𝑑𝑎𝑦 for men and ±201.0 𝑘𝑐𝑎𝑙/𝑑𝑎𝑦 for
women, meaning that 95% of people will have a basal metabolic rate between the values listed of the energy requirements
given by the H-B formula. This is; however, a spread of over 400 𝑘𝑐𝑎𝑙/𝑑𝑎𝑦 for any person. The H-B formula is by no
means perfect, but it does give you a base to understand your body’s energy requirements. Each of these equations was
found via regression analysis – a method where researchers take a large pool of data and find trends along many axes. This

**Table 112-6. REE activity factor multipliers.**

|Table 112-6. REE activity factor multipliers.|Col2|
|---|---|
|Catagory Description Activity Factor||
|Sedentary very little exercise/activity 1.2||
|Lightly active light exercise/sports 1-3 day/week 1.375||
|Moderately active moderate exercise/sports 3-5 days/week 1.5||
|Very active hard exercise/sports 6-7 days/week 1.725||
|Extra active very hard exercise/sports or 2x training|1.9|


-----

is the same process as finding the best-fit line for a set of data, except this best fit “line” is done in a large number of
dimensions.
Although the H-B and Mifflin equations give good estimates for REE, it is also important to include average level of
activity when determining caloric needs. Table 112-6 shows “Multipliers” called **_activity factors to be used in conjunction_**
with REE equations to determine just how many Calories should be ingested per day.

To find the caloric intake needed, you would find your REE and multiply it by the activity factor. For example, if your
REE is found to be 1790, and your consider yourself moderately active, you would get

𝐹𝑜𝑜𝑑𝑟𝑒𝑞𝑢𝑖𝑟𝑒𝑑= 1790 𝐶𝑎𝑙𝑑𝑎𝑦⁄ ∗1.5 = 2685 𝐶𝑎𝑙𝑑𝑎𝑦.⁄ (112-4)


Example 112 - 2 **How much a cadet should eat**

What are the (approximate) daily energy requirements of a
very active 5’5”, 158 lb. female cadet on her 20[th] birthday?
What is the error associated with this requirement?

**Solution:**

This problem asks us to use the Harris-Benedict and/or
Mifflin formulas, along with an activity factor, to find daily
caloric needs.  In order to do this, we must first convert
height and weight to SI units:

5′5" = 165.1 𝑐𝑚;    138 𝑙𝑏𝑠. = 68.2 𝑘𝑔.

We can now directly use the H-B and Mifflin equations from
Table 112-1:

Harris-Benedict (H-B):

𝑅𝐸𝐸��� = 447.593 + 9.247(68.2 𝑘𝑔) + 3.098(165.1𝑐𝑚)

−4.330(20𝑦)

𝑅𝐸𝐸= 1503 𝐶𝑎𝑙/𝑑𝑎𝑦


Mifflin:

𝑅𝐸𝐸� = −161 + 10(68.2 𝑘𝑔)

+ 6.25(165.1𝑐𝑚)– 5(20𝑦)

𝑅𝐸𝐸= 1453 𝐶𝑎𝑙/𝑑𝑎𝑦

As you can see, the H-B and Mifflin equations differ by a
factor of about 5%, which was noted in Mifflin’s original
paper.

We can now use the activity factor for very active (1.725)
from Table 112-2 to estimate daily caloric needs:

H-B: 1.725(1503 𝐶𝑎𝑙/𝑑𝑎𝑦) = 2638 𝐶𝑎𝑙/𝑑𝑎𝑦
Mifflin: 1.725(1453 𝐶𝑎𝑙/𝑑𝑎𝑦) = 2506 𝐶𝑎𝑙/𝑑𝑎𝑦

The 95% confidence interval for the H-B equation for
women is ±201.0 𝐶𝑎𝑙/𝑑𝑎𝑦, suggesting that we can say
with 95% confidence that our cadet needs between 2437
and 2838 Calories per day. Please note that the Mifflin
result is well within this range for the H-B values.


#### 112.5 – Exercise: The basis for the activity factor

**Consider: How does exercise affect energy balance in humans?**

Every move you make beyond those that just keep you alive use energy that goes beyond the REE. Thus, exercise is the
background basis for the activity factor used in the last section. There are two things we need to consider:

1) How much energy does our body output to do certain activities;
2) How much energy needs to go into performing those activities?

In a perfect world, the answer to 1) and 2) above would be the same, meaning that the human body would be perfectly
**_efficient. Unfortunately, this is not the case. Just as with all mechanical devices, some energy is “lost” in the process of_**
converting between chemical energy and mechanical energy. You may have noticed that when you exercise, you get hot.
Similar to friction in mechanical systems, this thermal energy is directly related to the loss of energy in the transition from
stored chemical energy to mechanical energy.
We define the efficiency of a system (biological system in this case) as the percentage of energy that comes out of a
system, relative to the energy that goes in:


-----

𝐸𝑓𝑓𝑖𝑐𝑖𝑒𝑛𝑐𝑦(%) = [𝑀𝑒𝑐ℎ𝑎𝑛𝑖𝑐𝑎𝑙𝐸𝑛𝑒𝑟𝑔𝑦𝑂𝑢𝑡] 𝑥100. (112-5)

𝐶ℎ𝑒𝑚𝑖𝑐𝑎𝑙𝐸𝑛𝑒𝑟𝑔𝑦𝐼𝑛

The efficiency of the human body depends on the type of activity being performed. The body tends to be most efficient when
performing sustained effort against consistent, constant loads, such as a bicycling on a flat surface. In this case, the body’s
efficiency can be as high as 20% – 25%. However, for activities that have broken motions, such as swimming at the surface
of a wavy ocean, or striking a nail with a hammer, human efficiency can be as low as 2% - 3%. The situations is even more
complicated because my efficiency on any task will necessarily be different than your efficiency, so we can only talk here in
terms of generality. Efficiencies can be very well measured by finding the output energy of a task and measuring various
physiological factors related to the input energy (such as O2 uptake and CO2 release, heart rate and breathing rate
measurements, etc.), however, these go beyond the scope of this course.
In Physics, we will give you the efficiency of a certain activity, or give you enough information to find the efficiency.
As an example, let’s say I ask you to calculate the energy required to bench press a 90-kg (200-lb) mass. One way to do this
is to find the increase in gravitational potential energy of the mass as it increases in height about 0.5 meters (a typical
distance in a bench press). Doing this, you would find

∆𝑈� = 𝑚𝑔∆ℎ= (90 𝑘𝑔)(9.81 𝑁𝑘𝑔⁄ )(0.5 𝑚) = 440 𝐽. (112-6)

Knowing that 1 𝐶𝑎𝑙= 4184 𝐽, this is the same as 0.10 Calories. However, if **Table 112-7. Energy expenditure of some**
your muscles are only 20% efficient for this motion, equation 112-5 tells us **exercises for a 155 lb person.**
you will use **Description** Energy

(Cal/hr)
**Leisure biking** 281

𝐶ℎ𝑒𝑚𝑖𝑐𝑎𝑙𝐸𝑛𝑒𝑟𝑔𝑦= [440 𝐽] (112-7) **Bicycle racing** 1100

0.20 [= 2200 𝐽= 0.53 𝐶𝑎𝑙.]

**Running (6 mph)** 704
**Running (10 mph)** 1126

Now, remember that this motion was **_just lifting the bar up one time. If we_**

**Golf** 317

then do three sets of ten reps (30 total repetitions), the total internal energy

**Tennis** 495

expenditure is 66,000 J (16 Cal) for 13,200 J of mechanical work. You might

**Volleyball** 510

be asking right now: 16 Calories?? That’s really all that is burned while doing

**Carrying 20 lbs up stairs** 422

thirty bench presses? Well, it’s close. In reality, you will also burn some **Walking (3 mph)** 232
extra calories from this exercise because your heart rate will increase for a **Swimming laps, fast** 701
certain amount of time following the completion of the exercise. However, **Taking out the trash** 211
these extra Calories do not add tremendously to the total in this case.


Example 112 - 3 **A more precise model of lifting**

While lifting one afternoon, a cadet does three sets of ten reps
on a shoulder press with a total of 150 lbs. between the bar
and weights (referred to as the bar for the rest of this
problem). (a) How much does the gravitational potential
energy of the bar change during the lifting session? (b) How
much mechanical work goes into lifting the bar one time if it
is lifted a distance of 1.5 feet? (c) Since the human body is
_non-conservative, both the upward motion and downward_
motion will require energy to be transferred from the body to
the bar. Assume that 100% of the mechanical work is used
while lifting the bar and that 25% is also used while lowering
the bar to calculate how much non-conservative mechanical
energy is used during the 10 reps. Finally, assume an
efficiency of 5% to determine how much chemical energy is
used by the body during this process.

**Solution:**

(a) Since the starting point and ending point of the bar are at
the same point, there is no change in gravitational potential
energy of the bar. The rest of the problem helps explain why


you get tired even with no change in potential energy.

(b) The mechanical work needed to lift the bar is

𝑊� = 𝑚𝑔ℎ= (68 𝑘𝑔)(9.8 𝑁𝑘𝑔)(0.46 𝑚),⁄

where I have converted English units to metric units.
This gives a mechanical work for one lift of

𝑊� = 307 𝐽.

(c) We know we have to lift and lower the bar 30 times
each. Given that we assume 100% for each lift and 25%
for each lowering, the total mechanical work required is

𝑊��� = 30(307 𝐽) + [1]4 [(30)(307 𝐽) = 1.15 𝑥 10][�][ 𝐽.]

Finally, we need to use the fact that the body is only 5%
efficient for this process (remember, efficiencies are
different person-to-person, which is why this value


-----

differs from the example in the text). Using a 5% efficiency,
the total chemical energy used in the entire session is

𝑊��� = 0.05 [𝑊] [= 1.15 𝑥 10]0.05 [�][ 𝐽] = 2.3 𝑥 10[�]𝐽.


2.3 𝑥10[�]𝐽 [1 𝐶𝑎𝑙]

4186 𝐽 [= 55 𝐶𝑎𝑙.]

Note that this is still only 55 Calories. Although lifting
can help increase muscle efficiency and strength, it is not
an effective way to burn stored energy.


Finally, to compare this to our daily caloric need, we can
convert this value to Calories:


Example 112 - 4 **Example Problem**

A bicyclist must exert an average forward force of 30 N to
maintain a constant velocity of 10 m/s speed east. Assuming
an efficiency of 15%, how much energy will this bicyclist
release during a 30-minute ride?

**Solution:**

This problem asks us to relate force, speed, time and
efficiency to determine how much energy a bicyclist will use
in completing a 30-minute trip.
The first step is to determine the distance over which the
bicyclist travels during the trip. Since 30 minutes is
equivalent to 1800 seconds, we can find the distance of the
trip as

𝑑= 𝑣∆𝑡= (10 𝑚𝑠)(1800 𝑠) = 18 000 𝑚.⁄

We can then find the energy used during this trip using the
equation for mechanical work (with 𝐹[⃗] parallel to 𝑑[⃗])

𝑊���� = 𝐹[⃗] ∙𝑑[⃗] = (30 𝑁)(18 000 𝑚) cos 0°


𝑊���� = 5.4 𝑥 10[�]𝐽.

Now, if we use the 15% efficiency, the chemical energy
used in the body for this process is

𝑊���� = [𝑊]0.15 [����] [= 5.4 𝑥 10]0.15 [�][𝐽] = 3.6 𝑥 10[�]𝐽.


Finally, we can convert this to Calories to find

𝑊���� = 3.6 𝑥 10[�]𝐽 4186 𝐽[1 𝐶𝑎𝑙] [= 860 𝐶𝑎𝑙.]

As you can see, bicycling in this fashion consumes a
number of Calories. Keep in mind, however, that the
average speed of the bicycle in this problem is 22 mph
for 30 minutes – not a leisurely ride.

**_Note: In the next unit, we will find a different way to_**
solve this same problem.


The activity factor from section 112.4 is a result of all the added energy expenditure a person does in a typical day. Keep
in mind that this energy expenditure is anything over complete rest: going to the bathroom, eating lunch, talking, etc. Even
the tiniest thing we can do on a regular basis will add up. Table 112-7 gives a summary of just a few activities and the
(chemical) Caloric expenditure of each. Tables such as these can be found on the internet if you would like to compare
something not listed here.

#### 112.6 – Nuclear potential energy

**Consider: How is energy stored in atomic nuclei?**

In Section 103.2, it was noted that the potential energy of a system is stored as an increase or decrease in the mass of the
system. This change in mass is all but undetectable for most types of potential energy, including gravitational, elastic and
chemical. When it comes to nuclear potential energy, on the other hand, the change in mass due to the stored energy can be
an appreciable percentage of the mass of the system.
As an example, let’s take Iron-56, a nucleus which contains 26 protons and 30 neutrons. The mass of the iron nucleus
and its constituents separately are (masses of protons and neutrons can be found in the important information table):

𝑚���� = 52,103.06 𝑀𝑒𝑉𝑐⁄ [�] (112-7)

26 𝑚� = 26(938.272046 𝑀𝑒𝑉𝑐⁄ [�]) = 24,395.0732 𝑀𝑒𝑉𝑐⁄ [�] (112-8)

30 𝑚� = 30(939.565378 𝑀𝑒𝑉𝑐⁄ [�]) = 28,186.96 𝑀𝑒𝑉𝑐⁄ [�] (112-9)


-----

Now, if we add up the constituent protons and neutrons, the nucleus should have a mass of 52,582.03 𝑀𝑒𝑉𝑐⁄ [�].  So, we
can see that there is a mass deficit of

∆𝑚= 𝑚����� −𝑚������� = 52,585.03 𝑀𝑒𝑉𝑐⁄ [�] −52103.06 𝑀𝑒𝑉𝑐⁄ [�], (112-10)
or
∆𝑚= 481.97 𝑀𝑒𝑉𝑐⁄ [�]. (112-11)

This mass deficit is nearly 1% of the mass of the initial particles!! This is huge when you consider that the mass deficit for
gravitational potential energy is often less than 10[���] of the initial mass of the system.
Since we know that rest-mass energy and mass are related by Einstein’s famous equation, 𝐸= 𝑚𝑐[�], we can also find the
difference in energy that results from the interactions of the protons and neutrons to form the nucleus. This is the nuclear
**_binding energy and is defined as_**
𝛥𝐸= 𝛥𝑚𝑐[�], (112-12)

where ∆m is the mass deficit we found above.


**Nuclear Binding Energy**

𝚫𝑬= 𝚫𝒎𝒄[𝟐]

**Description – The equation defines the nuclear binding**

energy, ∆𝐸, resulting from a mass deficit, ∆𝑚. c is the
speed of light in vacuum.
**Note: The mass deficit is found as the difference between**

the mass of the constituent particles and the mass of the
nucleus as a whole: ∆𝑚= 𝑚����� −𝑚�������,.


In order to compare how tightly nuclei are bound together by the strong nuclear interaction, binding energies are reported as
binding energy per nucleon, which is the total binding energy of the nucleus divided by the total number of protons and
neutrons that make up the nucleus:
∆𝐸
∆e = . (112-12)
𝑛� + 𝑛�


**Binding Energy per Nucleon**


𝚫𝑬
𝚫𝐞=
𝒏𝒑 + 𝒏𝒏


= [𝚫𝒎𝒄][𝟐]

𝒏𝒑 + 𝒏𝒏


**Description – This equation defines the binding energy per**

nucleon, ∆e, as the binding energy of a nucleus, ∆𝐸,
divided by the total number nucleons (protons and
neutrons), 𝑛� + 𝑛�
**Note: The binding energy per nucleon peaks at iron-56,**

meaning that iron-56 is the most stable of the nuclei
currently known.


**Figure 112-4. Plot of average binding energy per**
**nucleon for most known values of nucleon number.**


The binding energy per nucleon is an important factor because it measures the stability of the nucleus. Nuclei with
higher binding energy per nucleon are more tightly bound and therefore harder to separate. The nickel-62 nucleon has the
highest binding energy per nucleon of any known nucleus. Since nature is always searching for the most stable states, nuclei
which are less stable can undergo transformations to make them more stable. For nuclei with less than 56 nucleons this tends
to be combing nuclei – a process known as nuclear fusion. For nuclei with more than 56 nucleons, this tends to be dividing –
a process known as nuclear fission. In unit 229, we will study these processes.


-----

Figure 112-4 gives a graph of binding energy per nucleon versus nucleon number.
As expected, iron-56 is located at the peak of the graph. Another interesting point is
helium-4, which spikes above other nuclei in its vicinity. This means that the helium-4
nucleus is quite stable, and is why it is not uncommon for helium nuclei, as an alpha
particle, to escape a nucleus in radioactive beta-decay (see unit 228).
There is one other interesting fact about nuclear binding energy to discuss at this
point. Many stable, small nuclei have the same number of protons and neutrons. At a
basic level, this can be explained by suggesting that the neutrons are mixed into the
nucleus with the protons to buffer the protons as they try to repel each other. Since
protons have the same electric charge, they are constantly trying to push each other
away out of the nucleus. With neutrons mixed into
the nucleus, the protons are, on average, farther
away from each other, creating less electrostatic
repulsion and making it easier for the strong nuclear
interaction to keep the nucleus together.

**Figure 112-5. Energy-filling**

As fermions (with half-integer spin), protons

**diagram for oxygen-16 with 8**

and neutrons must follow the **_Pauli Exclusion_**

**protons and 8 neutrons.**

**_Principle, which states that no two particles can_**
have the exact same properties in a given system. As we build up the protons in a
nucleus, the first two protons will go in at the lowest possible energy level. The reason
two protons can be in the nucleus at one energy level is that one can have a positive spin
and one can have a negative spin, so they are not in the exact same state. Now, if we try
to add another proton to the system it must have more energy. A third can be at this
energy, but must have the opposite spin, and so on and so on. The exact same is true for
each neutron we try to put in the system. This process is illustrated in Figure 112-5,

which shows a stable oxygen-16 nucleus. Each row of **Figure 112-6. Energy-filling**
particles in this diagram represent particles at a given **diagram for carbon-16 with 6**
energy. Particles higher up in the figure have more **protons and 10 neutrons.**
energy.
If we were to try and fill the nucleus with a different number of protons and neutrons,
as in Figure 112-6, we would wind up with an unstable nucleus. The reason is that if one of
the neutrons could transition itself to a proton, it could then drop down to a lower energy
level, making the nucleus more stable. This is the idea of nuclear radiation and the weak
nuclear interaction. We will study this effect in detail in Physics II.
Finally, larger stable nuclei tend to have more neutrons than protons, such as iron-56,
with its 26 protons and 30 neutrons (remember, iron-56 is actually the most stable of all
known nuclei). Our nuclear filling model can explain this as well! For large nuclei, the
electrostatic interactions of the protons must be taken into account. This creates an electric
potential energy for protons that lifts all protons filling levels. However, since neutrons are

**Figure 112-7. Energy-filling** electrically neutral, they do not feel this effect. As can be seen in Figure 112-7, when the
**diagram for iron-56 with** proton levels are lifted enough to cross over a neutron level, we will have more neutrons in
**the proton levels lifted by** the nucleus that protons for it to be stable. As noted above, we will study this entire process
**electrostatic repulsion (Er).** more in Physics II.

Example 112 - 4 **Example Problem**

What is the binding energy per nucleon of Helium-4? ∆𝑚= 2(1.00728 𝑢) + 2(1.00867 𝑢) − 4.00151 𝑢,
The mass of a Helium-4 nucleus is 4.00151 u.

or

**Solution:** ∆𝑚= 0.030374 𝑢

We must first find the mass deficit The binding energy per nucleon is then given by


⁄
= [(0.030374 𝑢)(931.494 𝑀𝑒𝑉𝑐][�][)𝑐][�].
2 + 2

∆e = 7.0733 MeV.


∆𝑚= 𝑚������ −𝑚����� = 2𝑚� + 2𝑚� −𝑚�����,

since the helium nucleus has two protons and two neutrons.
Therefore,


∆e = [∆𝑚𝑐][�]

𝑛� + 𝑛�

or


-----

