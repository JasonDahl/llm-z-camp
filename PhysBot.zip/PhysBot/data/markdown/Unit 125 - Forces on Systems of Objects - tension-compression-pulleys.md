### – Forces on Systems of Objects I
## 125


_When objects interact via direct contact or when tied together with strings, we can use Newton’s 3[rd] law to relate pairs_
_of forces on the two objects. In this unit we begin to consider systems which have interacting objects that are either_
_touching directly have a stretched string between them. Along the way we will also explore the effects of both real and_
_ideal pulleys._

##### The Bare Essentials

- When objects interact via direct contact (normal forces) or via

tension, Newton’s 3[rd] law can be used to relate forces on
different objects thereby reducing the number of unknown
forces in the system.

- Normal forces are always perpendicular to the surfaces of

interaction, and can therefore be in any direction. Only when
the surfaces of two objects are horizontal are the normal forces
vertical.

- Tension forces act along the line of the string (or similar

object) between two objects. Tension forces are always
directed away from the objects to which they are attached.

- Pulleys are used to redirect a string (or similar). Pulleys can be

treated in two different ways

1) **_Ideal Pulley. An ideal pulley has no mass or friction at_**

the pin. The tension of the string (or similar) on each
side of an ideal pulley is of the same magnitude and is
directed along the line of the string.

2) **_Real Pulley. A real pulley has mass and therefore_**

rotational inertia. Do to this rotational inertia, the
tension of each side of the pulley is not the same and a
torque equation is often used to relate the two tensions.


-----

#### 125.1 – When objects push on each other (Normal forces)

**Consider: How do we include the normal forces of two blocks pushing**
on each other?

NIT 125 BEGINS OUR EXPLORATION OF HOW to use Newton’s laws when objects in a system directly interact.
In this unit we will explore what happens when objects directly push on each other (compression/normal forces) or
pull on each other via wires and strings (tension). In either case, Newton’s 3[rd] law will be important since for each

# U

force of one object on the second, there will be an equal and opposite
force of the same type on the first.
Consider Figure 125-1, which shows two blocks on a horizontal
plane, with the leftmost block being push by a force with magnitude, 𝐹.
When the force is applied to m1, it will in turn push on m2. Newton’s 3[rd]
law tells us that m2 must then push back on m1 with the same force. The
other forces on each block will be the normal force due to the floor and
the gravitational force on each block. Using all of these ideas, the free

**Figure 125-1. Two blocks on a frictionless**

body diagrams for this system are shown in Figure 125-2. Please note

**horizontal surface being pushed by a force.**

that F12 and F21 are a compression (normal) force between the two
blocks related by Newton’s 3[rd] law. The way the subscripts are
reversed for the two forces are meant to show the 3[rd] law relationship.
Applying Newton’s 1[st] law to m1 gives us


𝐹−𝐹��

𝐹���.� = � 0

𝐹�� −𝐹��


𝑎�

�= 𝑚� � 0

0


�, (125-1)


where I have taken to the right and up as the positive x and z directions
respectively. We can write a similar equation for m2 as


𝐹��

𝐹���.� = � 0

𝐹�� −𝐹��


𝑎�

�= 𝑚� � 0

0


�, (125-2)


**Figure 125-2. Free body diagrams to accompany**
**the blocks in Figure 125-1. Please note that 𝑭𝟏𝟐**
**and 𝑭𝟐𝟏 are horizontal normal forces which are**
**related by Newton’s 3[rd] law.**


Here are a few important notes on this set of Newton’s 2[nd] law:

1) Each object has its own FBD and Newton’s 2[nd] law equation
2) The mass used on the right side of Newton’s 2[nd] law is the mass of the object in the related FBD.
3) We have set 𝑎� = 0 meaning that we assume the blocks will remain on the flat surface.
4) The normal and gravitational force on each block is labeled with a subscript labeling not only the type of force, but

also which block the force is associated with. This is important since we will use Newton’s 3[rd] law to relate forces
between the two blocks.
5) The acceleration, 𝑎�, in each 2[nd] law equation must be the same in this situation since the blocks are in contact with

each other (they will also have the same change in position and velocity for this reason as well).


Example 125 - 1 **Two blocks and a force**

In the situation described in Figure 125-1, imagine that 𝐹=
25 𝑁, 𝑚� = 5.1 𝑘𝑔 and 𝑚� = 8.2 𝑘𝑔. What is the
acceleration of the system?

**Solution:**

This is a Newton’s 2[nd] law problem with two objects. The
process of drawing the free body diagrams and writing a
Newton’s 2[nd] law equation for each object has already been
taken care of (see Figure 125-2 and Equations 125-1 and 1252). We first note that due to Newton’s 3[rd] law, the magnitudes


of the forces between the blocks must be equal to each
other as

𝐹�� = 𝐹��.

With this, the x-components of Equations 125-1 and 1252 can be written

𝐹−𝐹�� = 𝑚�𝑎�    and    𝐹�� = 𝐹�� = 𝑚�𝑎�,

respectively. Adding these two equations, we find


-----

𝐹= 𝑚�𝑎� + 𝑚�𝑎� = (𝑚� + 𝑚�)𝑎�,

which can be solved for the acceleration as


25 𝑁
𝑎� = 5.1 𝑘𝑔+ 8.2 𝑘𝑔 [= 1.9] 𝑠[𝑚][�][.]

Note that we could have found this acceleration by
treating both blocks as one single large block with mass
5.1 + 8.2 = 13.3 kg. The acceleration would then be
found using newton’s 2[nd] law for a single object.


𝐹
𝑎� = 𝑚� + 𝑚�


.


Using the values given in the problem, we find


Extension:

What is the magnitude of the forces between the two boxes?

**Solution:**

We know from above that 𝐹�� = 𝐹��, so if we find the
magnitude of one of the forces, we automatically know the
magnitude of the other force. We can find the magnitude


of these forces using the x-component of Equation 125-2:

𝐹�� = 𝑚�𝑎� = (8.2 𝑘𝑔)(1.8 𝑚𝑠⁄ [�]) = 15 𝑁.

It does make sense that the force required to accelerate
the 8.2 kg block is less than it takes to accelerate the
entire 13.3 kg system at 1.8 m/s[2].


#### 125.2 – Tension

**Consider: What is tension and how is it included in Newton’s 2[nd] law?**

Tension forces are considered in much the same way that
compression forces are when considering Newton’s 2[nd] law. A tension
force will connect two objects via a string or similar object. An **_ideal_**
**_string in one which has such a small mass in relationship to the other_**
masses in the system that we can consider it essentially massless. In this
course, we will only consider ideal strings, although you must be careful **Figure 125-3. Two blocks on a horizontal surface**
because some conclusions for a given system can change if the mass of a **with friction including tension.**
string is taken into account.
Consider Figure 125-3, which shows two blocks of the same mass
connected by a light ideal string, which the block on the right pulled
with a force of magnitude, 𝐹. In this case, we will include friction on
the surface, which will add further complexity. Figure 125-4 shows
free body diagrams for the two masses in Figure 125-3. For this
example, we will take to the right as the positive x direction and up as
the positive z direction. Following the free body diagrams, Newton’s
2[nd] law for the left box becomes **Figure 125-4. Free body diagrams to accompany**

**the blocks in Figure 125-3.**

𝐹�� −𝐹�� 𝑎�

𝐹���.� = � 0 �= 𝑚� � 0 �, (125-3)

𝐹�� −𝐹�� 0

and for the box on the right, we get

𝐹−𝐹�� −𝐹�� 𝑎�

𝐹���.� = � 0 �= 𝑚� � 0 �, (125-4)

𝐹�� −𝐹�� 0


Similar to the compression forces between the boxes in the Equations 125-1 and 125-2 above, we must note that the tension
forces in Equations 125-3 and 125-4 are related by Newton’s 3[rd] law, and will therefore have the same magnitude.
The z-components of Equations 125-3 and 125-4 can be used to find the vertical normal forces acting on each block,

𝐹�� −𝐹�� = 0 → 𝐹�� = 𝐹�� = 𝑚�𝑔. (125-5)
𝐹�� −𝐹�� = 0 → 𝐹�� = 𝐹�� = 𝑚�𝑔.


-----

We are now left with the task of solving the x-components for each block

𝐹�� −𝐹�� = 𝑚�𝑎� → 𝐹�� −𝜇𝑚�𝑔= 𝑚�𝑎�, (125-6)
𝐹−𝐹�� −𝐹�� = 𝑚�𝑎� → 𝐹−𝐹�� −𝜇𝑚�𝑔= 𝑚�𝑎�,

where I have used the face that for the force of friction 𝐹� = 𝜇𝐹� for each block, and 𝐹�� = 𝐹�� by Newton’s 3[rd] law.
The equations in 125-6 can then be solved for the acceleration of the system as a function of the applied force as


𝑎� = [𝐹−𝜇𝑔(𝑚]𝑚� + 𝑚[�] [+ 𝑚]� [�][)]


. (125-7)


Once the acceleration is known, the tension can be found using either of equations 125-6. Please note that I have left the
coefficient of friction as a general 𝜇, since we have not stated whether it is static or kinetic friction. Once known, we could
substitute the correct coefficient in the equation. Interestingly, if we plug in the coefficient of static friction and find a
negative value, this tells us that the blocks are, in fact, not moving and we must use the coefficient of static friction. Also,
note that this solution does assume that both blocks are made of the same material so that 𝜇 will be the same for each block.


Example 125 - 2 **Tension between two blocks.**

Imagine two blocks are connected by a light string as shown
in Figure 125-3. If the coefficient of static friction is 𝜇� =
0.55 and the coefficient of kinetic friction is 𝜇� = 0.35,
determine the tension in the string.  For this problem, 𝑚� =
2.2 𝑘𝑔, 𝑚� = 3.2 𝑘𝑔 and 𝐹= 42 𝑁. You may assume that
both blocks are made of the same material.

**Solution:**

This is a Newton’s 2[nd] law problem with tension involved.
The tension between the blocks will depend on the
acceleration, so it is first important to determine if the system
moves under the given force.

Along the horizontal direction, Equations 125-6 can be
combined to

𝐹−𝜇𝑚�𝑔−𝜇𝑚�𝑔= (𝑚� + 𝑚�)𝑎�.

This suggests that for the system to accelerate

𝐹≥𝜇�𝑚�𝑔−𝜇�𝑚�𝑔= 𝜇�𝑔(𝑚� + 𝑚�),


Using information from the problem, we find

2.2 𝑘𝑔
𝐹� = (42 𝑁) 2.2 𝑘𝑔+ 3.2 𝑘𝑔 [= 17 𝑁.]


which in words says that the applied force must be
greater than the net static friction force on the system.

Solving for the right side of the equation, we get

𝐹≥(0.55)(9.8 𝑁𝑘𝑔⁄ )(3.2 𝑘𝑔+ 2.2 𝑘𝑔) = 29.1 𝑁.

Since, the applied force is greater than this, the system
will accelerate

Now that we know the system accelerates, we can solve
Equations 125-6 for the Tension (either 𝐹�� or 𝐹�� since
we know they must have the same magnitude by
Newton’s 3[rd] law). This can be done by using the
acceleration in one equation to eliminate it from the other
equation, given us


𝑚�
𝐹� = 𝐹 𝑚� + 𝑚�


.


Extension:

Although the problem does not ask for the acceleration, it is
instructive to find it in this case. Using Equation 125-7 with
kinetic friction,


This is solved to give us

𝑎� = 4.35 𝑚𝑠⁄ [�].

If you inspect the equation for the acceleration, it says
nothing about the tension. In this problem, the tension
couples the two blocks so that they act like one large
block with a mass equal to the combined mass of the two
blocks. If the blocks had different coefficients of friction,
it would be a bit more complicated, but still conceptually
the same as just described.


,


we find


𝑎� = [𝐹−𝜇]𝑚[�][𝑔(𝑚]� + 𝑚[�] [+ 𝑚]� [�][)]


⁄ )(3.2 𝑘𝑔+ 2.2 𝑘𝑔)
𝑎� = [42 𝑁−(0.35)(9.8 𝑁𝑘𝑔](3.2 𝑘𝑔+ 2.2 𝑘𝑔) .


-----

#### 125.3 – Ideal pulleys

**Consider: How are pulleys used to redirect tension forces?**

A pulley is a wheel on some form of axis which is designed to have a rope, cable,
string or similar wrapped around it and support its movement around the pulley or
change the direction of the string. In general, we will use a string as the object
wrapped around the pulley for this course. One of the classic physics uses of a
pulley is shown in the Atwood’s machine of Figure 125-5.
In this section, we will explore ideal pulleys, which are pulleys that have
essentially no mass or friction at the axle. Since an ideal pulley has no mass, it also
has no rotational inertia. Consider the free body diagram of such a pulley in Figure
125-6. If we apply a torque equation to this pulley we find

𝜏��� = 𝑟�𝑇� sin 90° −𝑟�𝑇� sin 90° = 𝐼������𝛼, (125-8)

where I have taken counterclockwise as the positive direction for the torque. Since
the moment of inertial of the pulley is zero, and the radius of the pulley is the same
at both the positions of 𝑇� and 𝑇�, equation 125-8 reduces to


**Figure 125-5. An Atwood machine**
**use to describe a pulley.**


𝑇� = 𝑇�. (125-9)

Therefore, the magnitude of the tension of each side of an ideal pulley must be the same. Note
that since we used torque to determine this relationship, the actual directions of the tensions do
not matter in this case, only that they are attached at the same radius and that the tensions must
each be trying to create rotations in the opposite

**Figure 125-6. Text box** direction of each other.
**used for figures.** Using this relationship, let’s once again

consider the Atwood’s machine from Figure
125-5. Assume that the mass on the right of the figure has more mass than the
mass on the left, our intuition would suggest that the mass on the right will
accelerate down, while the mass on the left will accelerate up. This is
important when describing the coordinate system for each mass – please note
**your coordinate system for each mass need not be the same, but it is** **Figure 125-7. Free body diagrams of the**
**helpful to have them be consistent! As can be seen in Figure 125-7, this** **masses in Figure 125-5.**
suggests that we should choose positive-z for the mass on the left as up, which
positive-z for the mass on the right is down. This will ensure that positive motion of one block will be positive motion of the
other block, and negative motion for one block will likewise be negative motion of the other block.
Figure 125-7 also shows the free body diagrams of each block in the system. Note that in these diagrams, the weight of
each block is written in terms of its mass and the gravitational field strength to emphasize the point that the naming of each
force is not important, only that we be consistent. Since all of the forces in the free body diagram are parallel to the z-axis,
we can write Newton’s 2[nd] law for this system using just the z-components. This leads to

Left mass: 𝑇−𝑚𝑔= 𝑚𝑎 (125-10)
and

Right mass: 𝑀𝑔−𝑇= 𝑀𝑎 (125-11)

Equations 125-10 and 125-11 can be solved for the acceleration of the system by directly adding the equations and solving
for 𝑎 as

𝑎= [𝑀−𝑚] (125-12)

𝑀+ 𝑚 [𝑔.]

Further, we can also find the tension in the string by using the acceleration in either of Equations 125-10 or 125-11 as


𝑇= [2𝑚𝑀𝑔] (125-13)

𝑀+ 𝑚[.]


-----

As with all Newton’s law problems, what we have really done is to identify the system, write free body diagrams, relate
any forces we can (tensions in this case) and then write down Newton’s 2[nd] law and solve. Equations 125-10 through 125-13
show a very general solution to only the ideal Atwood’s machine problem, so be very careful about applying this solution to
other situations.


Example 125 - 3 **What is the acceleration?**

For an ideal Atwood’s machine with masses of 𝑚� = 3.75 𝑘𝑔
and 𝑚� = 4.50 𝑘𝑔, what is the acceleration of the system and
the tension in the string supporting the masses?

**Solution:**

This problem asks us to solve the ideal Atwood’s machine
problem for specific values of masses. Using a process
similar to that used in the text above, Newton’s 2[nd] law in the
z-direction gives us

𝑇−𝑚�𝑔= 𝑚�𝑎,
and

𝑚�𝑔−𝑇= 𝑚�𝑎,

For 𝑚� and 𝑚�, respectively. Solving these equations give


Using values from the problem, we find

𝑎= [4.50 𝑘𝑔−3.75 𝑘𝑔] ⁄ ) = 0.891 𝑚𝑠⁄ [�],

4.50 𝑘𝑔+ 3.75 𝑘𝑔 [(9.80 𝑁𝑘𝑔]

and

⁄ )
𝑇= [2(3.75 𝑘𝑔)(4.50 𝑘𝑔)(9.8 𝑁𝑘𝑔] = 40.1 𝑁.
4.50 𝑘𝑔+ 3.75 𝑘𝑔

Note that this tension is different than the tension
required to hold each mass at rest separately:

𝑇�� = (3.75 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ) = 36.8 𝑁,

𝑇�� = (4.50 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ) = 44.1 𝑁.

The acceleration definitely changes the tension in the
string, so be careful to include this effect!


𝑎= [𝑚][�] [−𝑚][�]

𝑚� + 𝑚�


𝑔 and 𝑇= [2𝑚][�][𝑚][�][𝑔]

𝑚� + 𝑚�


.


Example 125 - 4 **A block on a table with pulley**

Consider the figure below with one block sitting on a
frictionless table connected by a pulley to a block with the
same mass hanging vertically. Determine the acceleration of
the system and the tension in the cord.

**Solution:**

This is a pulley problem with one mass on the table and one
mass hanging over the edge. Since we have an ideal pulley,
we know that the tension on each side of the pulley is the
same. Newton’s 2[nd] law for the mass on the table is


The vertical component of the mass on the table tells us
that, in this case, the normal force is equal to the weight
of the block. As for the z-components, we can now insert
that we know the masses are the same, and write these as

𝑇= 𝑚𝑎   and   𝑚𝑔−𝑇= 𝑚𝑎.

We can find the acceleration of the system by substituting
the first equation into the second equation and solving,
giving us

𝑚𝑔−𝑚𝑎= 𝑚𝑎  →   𝑎= [𝑔]

2[.]

The tension can then be found by substituting in this
acceleration into the first equation, giving us

𝑇= [𝑚𝑔]

2 [.]

Please note that these equation are specific to the
situation where the masses of the two blocks are the
same.


𝐹���,� = �


0
0
𝑀𝑔−𝑇


�= 𝑀�


0
0
𝑎


�.


𝐹���,� = �


𝑁−𝑚𝑔

0
𝑇


�= 𝑚�


0
0
𝑎


�,


And Newton’s 2[nd] law for the hanging mass is


-----

Extension:

If the masses of the blocks are not the same, the acceleration
and tension can be found to be


where 𝑚� is the mass on the table and 𝑚� is the hanging
mass. Keep in mind that this result is still only when
there is no friction and we have an ideal pulley. Any
deviation from this situation and you will need to find all
results specifically.


𝑚�
𝑎=
𝑚� + 𝑚�


𝑚�𝑚�
𝑔 and 𝑇=
𝑚� + 𝑚�


𝑔,


#### 125.4 – Pulleys with mass and friction

**Consider: What is different about real pulleys with mass and friction?**

In Section 125.3, we assumed that all pulleys were massless and frictionless at their axle, which made the tension on each
side of the pulley have the same magnitude. If we now include the mass, and therefore rotational inertia of the pulley, the
torque equation (see Figure 125-6 and Equation 125-8) becomes


0

�+ � 0

𝑟�


0
𝑟�𝑇� −𝑟�𝑇�

0


𝜏⃗��� = 𝜏⃗� + 𝜏⃗� = �


0
0
−𝑟�


𝑇�

�𝑥� 0

0


�𝑥�


𝑇�

0 �= �
0


�= 𝐼������𝛼⃗. (125-14)


Realizing that this equation is all along the y-axis, we can write this as a one-dimensional equation as

𝑟�𝑇� −𝑟�𝑇� = 𝐼������𝛼. (125-15)

If the pulley rotates such that the string does not slip, we can use the relationship 𝑎= 𝛼𝑟 so write


𝑟�𝑇� −𝑟�𝑇� = 𝐼������


𝑎
𝑟������


. (125-16)


Equation 125-16 allows for strings to be attached at different radii of the pulley, which need not be the same as the radius of
the pulley itself. In the specific case (such as Figure 125-6) where a single string is attached at the radius, Equation 125-16
can be reduced to


𝑇� −𝑇� = 𝐼������


𝑎
(125-17)
𝑟[�][.]


Now, let us consider again the Atwood’s machine shown in Figure 125-5, except that we now allow the pulley to have mass.
The free body diagrams of the two masses and the pulley as shown in Figure
125-8. Using Newton’s 2[nd] law and Newton’s 2[nd] law for rotation, we can
write three equations, one for each object as

𝑇� −𝑚𝑔= 𝑚𝑎


𝑀𝑔−𝑇� = 𝑀𝑎

𝑎

𝑇� −𝑇� = 𝐼������ 𝑟[�]


(125-18)


In the ideal pulley situation of Section 125-3, we had a set of two equation and
two unknowns (𝑎 and 𝑇). In this case, we have a set of three equations and
three unknowns (𝑎, 𝑇� and 𝑇�). Please note that in the torque equation of 12517, the order of 𝑇� and 𝑇� is switched relative to our description above. This is
because 𝑇� is trying to rotate the pulley in the direction of the presumed
acceleration. Therefore, we took clockwise as positive for the torque in this
case.
Solving equations 125-18 for acceleration gives


**Figure 125-7. Free body diagrams of the**
**masses in Figure 125-5 including the**
**pulley.**


-----

𝑀−𝑚
𝑎= 𝑔. (125-19)
𝑀+ 𝑚+ 𝐼������⁄𝑟[�]

We leave the solutions for the tensions for the example below.
A few notes about this solution

1) The acceleration with a massive pulley is similar to the acceleration in the ideal pulley situation, with the addition of

a rotational inertia term in the denominator
2) In the limit where the moment of inertia of the pulley goes to zero, the acceleration we just find is the same as in the

ideal pulley situation.
3) If the masses are equal, there is no acceleration (which is the same in the ideal pulley situation as well).
4) In the limit that one of the masses becomes very large

**Connection: Pulleys and tension**

compared to the other mass and the mass of the
pulley, the magnitude of the acceleration of the

Pulley problems are a perfect example of where you must be

system tends towards 𝑔.

careful with tension and weight. We’ve seen before that the
normal force on a block is not necessarily equal to its weight.

Just as with our discussion of the ideal pulley system, we used Same with pulley problems; there are a limited number of
a one-dimensional example to illustrate how to solve pulley situations where the tension in a pulley problem is equal to
problems. Follow the general steps for Newton’s 2[nd] law to the weight of one of the blocks – for example where the
solve pulley problems using this general framework for more acceleration of the system is equal to zero. Be careful!
complicated systems.


Example 125 - 5 **Tensions in the real case**

In this problem, we return to the Atwood’s machine of
Example 125-3, with 𝑚� = 3.75 𝑘𝑔 and 𝑚� = 4.50 𝑘𝑔.
However, we will now take the pulley to have a mass of
𝑚� = 2.50 𝑘𝑔 and radius, 𝑟= 0.25 𝑚. Find the acceleration
of the system and the tensions on both sides of the pulley.

**Solution:**

This problem is an Atwood’s machine problem with a real
pulley. Using figure 125-7 with 𝑚� = 𝑚 and 𝑚� = 𝑀, the
Newton’s 2[nd] law equations for m1, m2 and the pulley are,
respectively,

𝑇� −𝑚�𝑔= 𝑚�𝑎,

𝑚�𝑔−𝑇� = 𝑚�𝑎,

𝑎

𝑇� −𝑇� = 𝐼������ 𝑟[�][.]

Most pulleys can either be modeled as a disk or a hoop (with
light spindles). Since the pulley in Figure 125-7 resembles a
disk, we will use the moment of inertia of a disk,

𝐼������ = [1]2 [𝑚][�][𝑟][�][.]

Substituting this into the torque equation, we get


𝑇� −𝑚�𝑔= 𝑚�𝑎,

𝑚�𝑔−𝑇� = 𝑚�𝑎,

𝑇� −𝑇� = [�]�[𝑚][�][𝑎.]

Solving these equations for acceleration, we get

2𝑔(𝑚� −𝑚�) ⁄ )(4.50 𝑘𝑔−3.75 𝑘𝑔)
𝑎=
𝑚� + 2(𝑚� + 𝑚�) [= 2(9.8 𝑁𝑘𝑔]2.50 𝑘𝑔+ 2(3.75 𝑘𝑔+ 4.50 𝑘𝑔)

or

𝑎= 0.77 𝑚𝑠⁄ [�].

For 𝑇�, we find


𝑇� −𝑇� = 𝐼������


𝑎
𝑟[�] [= 1]2 [𝑚][�][𝑟][�] [�𝑎]𝑟[�][�= 1]2 [𝑚][�][𝑎.]


We now have three equations for our three unknowns, a, T1
and T2:


𝑇� = [𝑔𝑚][�][�𝑚][�] [+ 4𝑚][�][�]

𝑚𝑝 + 2(𝑚1 + 𝑚2) [= 39.4 𝑁,]

And for 𝑇� we get

𝑇� = [𝑔𝑚][�][�𝑚][�] [+ 4𝑚][�][�]

𝑚𝑝 + 2(𝑚1 + 𝑚2) [= 38.7 𝑁.]

You may notice that since we have a small acceleration
and a small pulley, the difference between the tensions is
not too great; however, it is still quite measurable.

Also, please note that if the mass of the pulley goes to
zero, each of the above equations (125-12 and 125013)
reduces to those we found earlier in the ideal pulley
model.


-----

