### – Systems and Interactions
## 102


_In Physics, it is important to identify objects of particular interest for a given situation. In this process you are defining_
_the system. Once we know our system, we can determine whether the entire system interacts with external objects or_
_whether the system is itself isolated; meaning all interactions take place within the system and not with external objects._
_In this unit, we first explore how to define systems, and then categorize the interactions that occur between the objects in_
_the system or between the system and the external environment._

##### Integration of Ideas

      - The definition of fundamental interactions from Unit 101.

##### The Bare Essentials

- The nucleus of an atom is described by the total number of

protons and neutrons contained within it.  - Macroscopic interactions describe the results of the

fundamental interactions that we see in everyday life.
Except for the macroscopic gravitational interaction, all

**Nuclear Symbols** macroscopic interactions are a result of the fundamental

electromagnetic interaction

𝑨𝒁𝑨𝑿

                              - By definition a system is a part of the universe being

**Description – The nuclear symbol for an atom with** studied:

chemical symbol X is described by its number of
protons (Z), the total number of nucleons (A).    - An isolated system is a system of objects that we
**Note 1: The chemical symbol (X) and the number of** can consider to undergo no interactions with objects

protons are redundant; however, in physics, both are outside of the system.
often expressed for ease of use.    - The environment is the area outside of the system
**Note 2: The number of neutrons in a nuclei is given by** which is ignored except for specific interactions

the neutron number, 𝑁𝑁 = 𝐴𝐴– 𝑍𝑍. with the system.

                              - In Physics, a model is a set of rules and assumptions used

- The radius of a nucleus is extremely small and is related to its to define a problem. Two important models used in this
mass number. course are classical mechanics and special relativity.

                              - Interactions come in three forms:

**Nuclear Radius**            - **Fundamental interactions: The four fundamental**

interactions described in unit 101.

𝒓𝒓 = 𝒓𝒓𝟎𝟎𝑨𝟏�𝟏 𝟑                     - **Mechanical interactions: Interactions that lead to a**

change in motion.

**Description – This equation describes the radius of a**   - **Microscopic interactions: Interactions that lead to**

nucleus, 𝑟𝑟, with nuclear number, 𝐴𝐴. a non-mechanical, macroscopic change (change in
**Note:** 𝑟0𝑟 = 1.25 𝑓𝑓𝑓𝑓. temperature, phase, shape, etc.).

- An electrically neutral atom has the same number of electrons
as protons with the electrons in shells around the nucleus of the
atom.

- An ion is an atom or molecule where the number of electrons
does not match the number of protons


-----

#### 102-1. Nuclei, atoms and molecules – the stuff of our world.

**Consider: What are the basic building blocks of matter?**

N UNIT 101, WE DESCRIBED HOW protons and neutrons are composed of quarks which are held together by gluons.
At a fundamental level, these fermions and bosons represent the components of matter; so how does this relate to what we
see in our everyday lives? The scale of quarks and gluons is so small that we cannot ‘see’ them. In fact, even full atoms,

# I

which are 20,000 to 100,000 times the size of their nuclei cannot be “seen” with powerful microscopes.
The strong nuclear force is not only responsible for holding quarks together inside of protons and neutrons, but it is also
responsible for holding protons and neutrons together within the nuclei. Although it is a very crude model, you can visualize
the nucleus of an atom as a closely packed set of spheres, where each sphere represents a proton or neutron. Figure 102-1
shows this sphere-packing model of an atomic nucleus. As noted in the last unit, the strong nuclear force only has a range of
a few femtometers, which is about the size of the nucleus. This is why we only see the effects of the force on the scale of
nuclei and not on the human scale.
The nucleus of an atom is composed of protons and neutrons.


1) The **_proton number,_** 𝑍𝑍, is the number of protons contained in the nucleus. This number determines the
identity of the nucleus, due to the fact that protons add to the nuclei’s electric charge. For example, all nuclei
with one proton are some form of hydrogen; all nuclei with six protons are some form of carbon, etc.
2) The neutron number, 𝑁𝑁, determines the isotope of the nuclei.
3) The **_mass number,_** 𝐴𝐴, is the total number of nucleons (protons and
neutrons) inside the nucleus; 𝐴𝐴= 𝑍𝑍+ 𝑁𝑁.

There is a compact notation that can be used to write down a specific nucleus, known
as a nuclear symbol:
𝐴𝐴𝑍𝑍𝑋𝑋, 101-1

where A is the mass number, Z is the proton number, and X is the chemical symbol
(from the periodic table) that corresponds to the proton number. The use of Z and X in
a nuclear symbol is redundant and Z is often removed in chemical symbols; however, **Figure 102-1. Schematic diagram**

**of a nucleus as a collection of**

since the number of protons is often an important value to have on hand in nuclear

**protons (red) and neutrons (blue).**

physics, physicists tend to leave it in the symbol. Note that although the neutron
number is not explicitly stated in the nuclear symbol, it can easily be found as 𝑁𝑁 = 𝐴𝐴 – 𝑍𝑍.


**Nuclear Symbols**

𝑨𝒁𝑨𝑿

**Description – The nuclear symbol for an atom with**

chemical symbol X is described by its number of
protons (Z), the total number of nucleons (A).
**Note 1: The chemical symbol (X) and the number of**

protons are redundant; however, in physics, both are
often expressed for ease of use.
**Note 2: The number of neutrons in a nuclei is given by**


the neutron number, 𝑁𝑁 = 𝐴𝐴– 𝑍𝑍.

Nuclei are very interesting on their own, and we will discuss many of their properties in unit 228 of Volume II of this book.
For now, it is sufficient for us to know the basic structure of the nucleus and how it relates to building matter.
Nuclei are very small. The nucleus of hydrogen is 1.25 𝑥𝑥 10[−15]𝑚𝑚= 1.25 𝑓𝑓𝑓𝑓 in radius. As you might imagine, nuclei
get larger with each nucleon added. If we use the very crude model of the nucleus shown in figure 102-1 and treat each
nucleon as a hard, three dimensional ball, then A can be written as

𝑟𝑟= 𝑟𝑟0𝐴𝐴1 3�, 101-2


-----

where 𝑟𝑟0 is the radius the hydrogen nucleus noted above, 1.25 𝑓𝑓𝑓𝑓. To understand this equation we know that the total
volume the nucleus is the number of nucleons, A, times the volume of a hydrogen atom (1 nucleon). Since the volume of the
sphere is proportional to the radius of the sphere cubed, the radius of the nucleus must be radius of the hydrogen nucleus, 𝑟𝑟𝑜𝑜,
multiplied by the cube root of 𝐴𝐴.


**Nuclear Radius**

𝒓𝒓 = 𝒓𝒓𝟎𝟎𝑨𝟏�𝟏 𝟑

**Description – This equation describes the radius of a**


nucleus, 𝑟𝑟, with nuclear number, 𝐴𝐴.
**Note:** 𝑟0𝑟 = 1.25 𝑓𝑓𝑓𝑓.

It is important to note that this model for the nuclear radius is only an approximation. Nuclear physics is very complex and
our most precise models still have a 20% uncertainty for 𝑟0𝑟 in equation 101-2. However, this model is heavily used to help
understand the average size of atomic nuclei.


Example 102 - 1 **Basic nuclear calculations**

For each of the following nuclei, write down the nuclear
symbol and find the approximate radius of the nucleus.

a) A nucleus with 8 protons and 8 neutrons
b) A nucleus with a mass number of 238 and a neutron

number of 146.

**Solution:**

For each of the parts, we will use what we know about
nuclear symbols and nuclear radii to solve the problem.

a) Using a periodic table, we can find that oxygen (with
chemical symbol 𝑂𝑂) has eight protons. We can also calculate
the mass number, 𝐴𝐴, of oxygen with eight neutrons as 𝐴𝐴 =
𝑁𝑁 + 𝑍𝑍 = 8 + 8 = 16. Therefore the nuclear symbol is
written

168 .𝑂

We can then find the approximate radius of the oxygen
nucleus using the nuclear radii equation


𝑟𝑟 = 𝑟0𝑟 𝐴1 3� = (1.25 𝑓𝑓𝑓𝑓)(16)1 3� = 3.15 𝑓𝑓𝑓𝑓.

b) We know 𝐴𝐴 = 238 and 𝑁𝑁 = 146. Using the
relationship between atomic number, neutron number and
mass number, we find 𝑍𝑍 = 𝐴𝐴 −𝑁𝑁 = 238 −146 = 92.
Again, using a periodic table, we find the element
corresponding to 𝑍𝑍 = 92 to be uranium (U). The
chemical symbol is then

23892𝑈 .

We can then find the nuclear radius by the same method
as in part a:

𝑟𝑟 = 𝑟0𝑟 𝐴1 3� = (1.25 𝑓𝑓𝑓𝑓)(238)1 3� = 7.75 𝑓𝑓𝑓𝑓.

Again, note that these are extremely small radii – even
for uranium, which is one of the largest naturally
occurring elements on earth.


Example 102 - 2 **Finding the nucleus**

A nucleus is found to have a radius of 3.80 fm. Determine the
mass number of the nucleus and suggest the most likely
element represented by this nucleus, and write the nuclear
symbol.

**Solution:**

This is an application of the nuclear radius equation, although
we much first rearrange and solve for the mass number,


Therefore, the mass number of this nucleus is 28. For
relatively small nuclei, the number of protons is
approximately equal to the number of neutrons,
suggesting that we should have 14 of each in this nucleus.

Consulting a periodic table gives silicon for Z = 14. In
fact, 92% of naturally occurring silicon has a mass
number of 28. The nuclear symbol for silicon-28 is

2814𝑆𝑆𝑆.

Please note, this analysis can be quite difficult for larger
nuclei where 𝑍𝑍 ≠𝑁𝑁.


= �[3.80 𝑓][𝑓][𝑓]

1.25 𝑓𝑓𝑓𝑓[�]


= 28.


𝐴𝐴 = � [𝑟]

𝑟0𝑟


3

�


3


-----

The nucleus of an atom has a positive electric charge due to each of the
protons in the nucleus (since the neutrons are electrically neutral, they do not
contribute to the overall electric charge). An atom is composed of his positively
charged nucleus which is surrounded by a negatively charged electron cloud.
When there are the same number of electrons and protons, the atom is
considered neutral. Since an electron has an electric charge with the same
magnitude but opposite sign as a proton, having the same number of protons as
electrons makes an atom electrically neutral. A neutral atom does not interact
very well with its surroundings. Atoms which do not have the same number of
electrons as protons are known as ions. Atomic ions do tend to interact strongly
with their surroundings, especially with other ions.
The electrons surround the nucleus of an atom in an **_electron cloud, as_**

**Figure 102-2. Diagram of the electron**

depicted in Figure 102-2. In the model of physics known as **_quantum_**

**cloud of a helium nucleus. The inset**

**_mechanics, all particles, including electrons, can act as both a particle and a_** **shows the packed-ball model of the**
wave; a property known as **_wave-particle duality. Our best understanding of_** **helium nucleus.**
electrons in atoms is that they are smeared out as a wave with a certain
probability of being found at specific locations. Then, when located by experiment, the electrons then act as particles. In
Figure 102-2, the probability of finding an electron at a certain location is represented by the darkness of the shading – areas
where the electron is likely to be found are dark and areas where the electron is less likely to be found are lighter. Note the
size scale in Figure 102-2; the atom is on the order of 100,000 𝑓𝑓𝑓𝑓 (a scale known as the angstrom, Å), or around to 80,000
times the size of the nucleus.

**Connection: The stuff of life**

Individual atoms can interact via the electrostatic
interaction to create chemical bonds that hold the atoms

Molecules are also the stuff of life. Deoxyribonucleic acid

together.  Chemical bonds come in many types, including the

(DNA) is a long molecule found in each of our cells that
contains the genetic information that makes you you. Proteins interaction and/or sharing of electrons between atoms
are long strings of atoms that act as molecular machines and (covalent and ionic bonds) and the interaction of electrons with
signal messengers to make your body work. Without other nuclei. Atoms which are chemically bonded together are
molecules, our bodies would not be able to function. called **_molecules. Molecules vary from just two atoms to_**

thousands or even millions of atoms in size.

#### 102-2. Solids, liquids and gasses.

**Consider: What are the basic phases of matter?**


**Figure 102-3. Molecular representations**
**of the three basic phases of matter: solid,**
**liquids and gasses.**


In the last section, we described the structure of atomic nuclei and how they
combine to form atoms and molecules. It turns out that molecules interact with
each other as well, and strength of this interaction is directly related to the type
of matter we see.
When atoms and molecules strongly interact with each other, they tend to
lock themselves into lattices where the atoms and molecules are not free to
move relative to each other. This is the basic premise of a **_solid. Since the_**
particles cannot move relative to each other, any object formed of these particles
will have a well-defined shape and size. A liquid is formed when atoms and
molecules are spaced farther apart while still interacting with each other. In a
liquid this interaction allows them to move relative to one another. Since the
particles can slide by each other, the overall material does not have a welldefined shape and will therefore take the form of whatever container is holding
the liquid. Finally, if the particles are spaced far apart, they tend to interact very
weakly and can easily more around relative to each other. This is the defining
characteristic of a gas. Gasses not only fill their container like liquids, but since
the particles are much farther apart when compared to liquids, gasses tend to be
compressible if pushed by an external force.


-----

**Figure 102-4. Basic phases of matter and their**
**transformations.**


The state of matter for a substance is known as its **_phase, and_**
when a substance changes from one state to another, it is known as a
**_phase change. Generally, the speed at which molecules are moving_**
increase as we move from solids to liquids to gasses. Since solids
are locked into lattices they will not move relative to each other;
however, they will vibrate. The particles in liquids will move
relative to each other, and the particles in a gas will move quite fast.
In fact, at room temperature, gas particles move, on average,
hundreds of meters per second! Figure 102-4 shows the relationship
between the phases just described and the names given to the phase
change between each phase, using water as an example. We will
explore phase changes in more detail in Unit 108.

There are two other things that should be noted about phases
before we move on:


1) There is a forth common state of matter known as a plasma. When enough energy is imparted
on a gas, the energy of the electrons can become high enough that they are no longer bound to
their nuclei – which is the defining characteristic of a plasma. The nuclei and electrons then
swim around in a kind of soup. Plasmas can be found in neon lights, fluorescent lights, plasma
balls and lightning, just to name a few. In general, we will not deal with plasmas in this
course.

2) Almost all chemical bonds, including both bonds that hold atoms together into molecules and
bonds that hold molecules together into solids, can be modeled as particles held together by
springs. As noted above, particles in a solid will vibrate even though they cannot move
relative to each other. This vibration can be thought of as a mass moving back and forth when
attached to a spring. We will explore this model later in the text – it is a good model for many
chemical bonds, although it certainly does not hold for all.

#### 102-3. Open and closed systems.

**Consider: What is meant by a system?**

In physics, a **_system is simply a portion of the universe being studied. What constitutes a system is completely_**
dependent on the individual question you are trying to answer. In fact, there may even be multiple choices of a
system to answer a given question.
Consider the classic problem of Newton and the apple. There is a myth in physics that Isaac Newton came up
with his ideas about gravity after being hit on the head by a falling apple. So let’s look at this myth. If we want to
describe the motion of the apple as it falls, there are two possible systems that we could consider:

1) The apple. In this system, we consider only the apple, and say that it is acted on by an outside
interaction – the gravitational interaction between the apple and the earth. In this case, we only
need to know that the apple exists in our system and something about how the system is
affected by the gravity. You will see later in this text that this is the model often used when
discussing forces.

2) The apple and the earth. In this system, we consider both objects of interest, the apple and the
earth, and we examine the gravitational interaction within the system between the two objects.
In this case, we have no interactions between the system and the rest of the universe. This is
the model of systems most used when talking about energy and momentum.

Although the two systems noted above are for a specific example, we can take the ideas and generalize them to
two basic types of systems – ones which interact with the outside universe, known as open systems, and ones that do
not interact with the outside universe, known as closed or isolated systems. To summarize:


-----

     - An **_open system is a system of one or more particles that may interact with the outside_**
universe. In this case we must know something about external interactions, but not necessarily
the exact object with which the system interacts. Particles within an open system may also
interact with each other.

     - A **_closed or isolated system is a system of particles that does not interact with the outside_**
universe; however, the particles inside the system may interact with each other.

The idea of a system and specifically the two types of systems just listed may not seem important at this point;
however, as we move through the course, you will see that it is often important to know whether a system is closed
or open and that will help you decide what type of principle to use to attack the problem.

#### 102-4. Interactions are measured as a change in….something.

**Consider: What is an interaction in physics?**

_Every interaction can be put into one of the four fundamental forms. In the modern world, we do see the effects of each of_
these interactions, although some are more apparent than others in our everyday life. For example, as described in unit 101,
all contact interactions are fundamentally electromagnetic in nature, however, we need to be more specific. Gravitational
interactions are also fundamental, but we see them in our everyday lives. The rest of Physics I will be about describing these
two fundamental interactions and exploring how they manifest themselves as mechanical forces and energies. In Physics II
we will look at the electromagnetic interaction more directly in terms of electric and magnetic forces. Even the nuclear
interactions are important in our everyday lives, although they are less directly noticeable. The energy we get from nuclear
power plants is mediated by the strong interaction (which we’ll discuss in unit 228). We are also bombarded every second by
nuclear radiation (don’t worry, a certain amount is expected as background radiation), which is a result of the weak nuclear
interaction.
The title of this section suggests that each of these interactions changes some aspect of the objects that interact. Table
102-1 relates how each of the fundamental interactions changes something about the interacting bodies.

**Table 102-1. Detecting the fundamental interactions as a change.**

**Interaction** **Description of interaction** **Measurable change**
**Strong nuclear** Quarks are held together by      - Change in mass of quark-containing objects.
gluons; change could be the                 - Change in motion of interacting objects.
combining or splitting of quarkcontaining matter.

**Weak nuclear** Changes in identity of quarks and      - Permutation of protons to neutrons and vice versa.
leptons lead to radioactivity and                  - Production of neutrinos.
high energy release of particles.                  - Change in motion of interacting objects.

**Electromagnetic** Interaction of all particles      - Change in motion due to electric and/or magnetic
containing electric charge. All attraction and repulsion.
contact interactions are                  - Change in motion due to static electric forces noted as
fundamentally electromagnetic mechanical (contact interaction).
due to electron interaction.                  - Change in the physical appearance of an object due to

density, phase changes or identity.
**Gravitational** All particles with mass are      - Change in motion due to gravitational attraction.
attracted to each other.

**Note: Weak nuclear, electromagnetic and gravitational interactions are also each accompanied by a small change in the**
mass of interacting objects due to the storage of energy between the objects (potential energy). This change in mass is
usually small enough that it cannot be directly detected for these interactions.

Take a look again at the electromagnetic interaction in Table 102-1. We will spend a great deal of time looking at how
electric and magnetic forces change motion in Physics II. For now, we will focus in on how the electromagnetic interaction
changes an object in ways that don’t immediately seem electromagnetic – through contact forces and changes in appearance.
Consider the following two definitions:

      - **_Mechanical Interaction: An interaction that, on its own, is directly related to the change in_**
motion or physical shape of an object. Mechanical interactions can fundamentally be either
electromagnetic or gravitational.

|Interaction Description of interaction|Measurable change|
|---|---|
|Strong nuclear Quarks are held together by gluons; change could be the combining or splitting of quark- containing matter.|• Change in mass of quark-containing objects. • Change in motion of interacting objects.|
|Weak nuclear Changes in identity of quarks and leptons lead to radioactivity and high energy release of particles.|• Permutation of protons to neutrons and vice versa. • Production of neutrinos. • Change in motion of interacting objects.|
|Electromagnetic Interaction of all particles containing electric charge. All contact interactions are fundamentally electromagnetic due to electron interaction.|• Change in motion due to electric and/or magnetic attraction and repulsion. • Change in motion due to static electric forces noted as mechanical (contact interaction). • Change in the physical appearance of an object due to density, phase changes or identity.|
|Gravitational All particles with mass are attracted to each other.|• Change in motion due to gravitational attraction.|


-----

      - **_Microscopic Interaction: An interaction that changes the physical appearance of an object in_**
terms of density, temperature, phase (solid, liquid, gas, etc.), color or even identity.

Mechanical and microscopic interactions can each take on different forms. Table 102-2 and 102-3 give lists of
mechanical and microscopic interactions we will use in this course.

**Table 102-2. List of mechanical interactions with descriptions.**

**Interaction** **Contact or** **Description**
**Long-range**

**Gravitational** Long-range Attractive interaction between any two particles that have mass. The
gravitational interaction is both a fundamental and mechanical
interaction.
**Normal** Contact Interaction when two solid objects are compressed against each other.
The normal interaction is always perpendicular to the surface of the
interacting objects.
**Friction** Contact Interaction when two solid objects are compressed against each other.
The friction interaction is always parallel to the surface of the
interacting objects.
**Tension** Contact Interaction when two objects are connected but pulled part or stretched
(think of a rope between the objects). Tension acts along the line of the
connecting object.
**Elastic** Contact Interaction between two objects connected by a spring or an interaction
that can be modeled as spring-like (atomic bonds for example).
**Buoyancy** Contact Interaction that tends to support a solid object immersed in a fluid
(liquid or gas). Buoyancy acts against the gradient of pressure in the
fluid (often, but not always vertically).
**Drag and Lift** Contact Interactions of a solid object moving in a fluid. Drag acts opposite the
direction of motion and the direction of lift depends on the shape of the
object and the direction of motion relative to the fluid.
**Electric** Long-range Attraction or repulsion of two objects due to unbalanced electric charge.
We will study this extensively in Physics II.
**Magnetic** Long-range Attraction or repulsion of two objects due to the magnetic force
(generally due to moving electric charges). Studied in Physics II.

**Table 102-3. List of microscopic properties and the interactions which change them.**

**Measured change** **Description of interaction**
**Temperature** Temperature is the average kinetic energy of the atoms and molecules
that make up a substance. A change in temperature is therefore noted
when interactions of the atoms and molecules in a substance change the
overall motion of those particles.
**Phase** The phase of an object is a measure of how strongly the atoms and
molecules in the substance interact with each other. The phase change
occurs when an external interaction changes how strongly the particles
interact with each other.
**Density** The density of a material is a measure of how much mass there is per
unit volume. The density of an object can change if an external
interaction causes the average spacing between particles to change.
**Identity** The identity of a substance is its nuclear, atomic and/or molecular
composition. A change in identity comes about by chemical reactions or
the weak nuclear interaction (nuclear decay).

The examples below show how we can categorize interactions seen in everyday life in terms of both its fundamental
interaction and either the mechanical or microscopic interaction that results. It is very important to note that every interaction
has a fundamental interaction associated with it. Then for interactions seen in everyday life, each can also be categorized as
mechanical or microscopic.

|Interaction Contact or Long-range|Description|
|---|---|
|Gravitational Long-range|Attractive interaction between any two particles that have mass. The gravitational interaction is both a fundamental and mechanical interaction.|
|Normal Contact|Interaction when two solid objects are compressed against each other. The normal interaction is always perpendicular to the surface of the interacting objects.|
|Friction Contact|Interaction when two solid objects are compressed against each other. The friction interaction is always parallel to the surface of the interacting objects.|
|Tension Contact|Interaction when two objects are connected but pulled part or stretched (think of a rope between the objects). Tension acts along the line of the connecting object.|
|Elastic Contact|Interaction between two objects connected by a spring or an interaction that can be modeled as spring-like (atomic bonds for example).|
|Buoyancy Contact|Interaction that tends to support a solid object immersed in a fluid (liquid or gas). Buoyancy acts against the gradient of pressure in the fluid (often, but not always vertically).|
|Drag and Lift Contact|Interactions of a solid object moving in a fluid. Drag acts opposite the direction of motion and the direction of lift depends on the shape of the object and the direction of motion relative to the fluid.|
|Electric Long-range|Attraction or repulsion of two objects due to unbalanced electric charge. We will study this extensively in Physics II.|
|Magnetic Long-range|Attraction or repulsion of two objects due to the magnetic force (generally due to moving electric charges). Studied in Physics II.|


Example 102 - 1 **Interacting coffee**

A cup of coffee cools as its sits on a table in an open mug.
The coffee inside the mug undergoes two vertical mechanical


interactions and one microscopic interaction. Describe
these interactions.


-----

**Solution:**

The coffee in the mug is in contact with the mug and since it
has mass, it also interacts with the earth gravitationally. So,
the two offsetting vertical interactions are a contact
interaction (normal interaction) with the mug and a


gravitational interaction with the earth. The fact that the
coffee is cooling down is evidence that it is undergoing a
microscopic interaction (temperature change), which is
due to the contact interaction with the air around the mug
at a different temperature than the coffee itself.


Example 102 - 2 **Example Problem**

A block slides down a rough incline and slows down. As the
block slows, the surface in contact with the incline warms up
slightly. Describe the three mechanical interactions that the
block undergoes in this situation. Also, explain why,
although the surface of the block increases in temperature, it
is not undergoing a microscopic interaction.

**Solution:**

Since the block has mass, it undergoes a gravitational


interactions with the earth. The block also undergoes two
contact interactions with the incline – a normal
interaction and a friction interaction (note that the normal
interaction is perpendicular to the surface of the incline
and the friction interaction is parallel to the surface of the
incline). The friction interaction is responsible for the
increase in temperature of the block’s surface, which is
why it is part of a mechanical interaction and not a
microscopic interaction.


#### 102.5. String Theory, Dark Energy and the Things We Don’t Know. (Optional)

**Consider: What is string theory, and why does it exist if we understand**
_the universe so well?_

The revolutions brought about by the discoveries of quantum mechanics and special relativity in the early parts of the 20[th]
century helped describe the world around us in remarkable detail. The standard model of particle physics describes the
particulate makeup of the matter, from how quarks form together to create nuclei and how three of the four fundamental
forces interact. There are still some lingering questions that go beyond the standard model that physicists cannot answer right
now; here are just a few:

1) **The standard model does not include gravity.  This makes it incomplete. Although the graviton is one of the**
important gauge bosons of the standard model, it has not been detected, and even if it were, the standard model is
incompatible with some of the more important observations of extreme gravity – black holes for one.

2) **Galaxies have too much mass. When astronomers measure the rate at which galaxies orbit each other, the speeds**
they measure do not match the amount of mass they see in the galaxies. As we will see in this course, in order for
galaxies to orbit each other, there must be a force that pulls them together – the force of gravity. Unfortunately, no
measure of the amount of ‘stuff’ in galaxies comes close to creating the gravitational forces needed to pull the
galaxies together. Scientists now call this missing stuff “dark matter” since it cannot be seen. The standard model
has no mechanism to theoretically account for dark matter.

3) **The universe is accelerating outward. On the largest scales, gravity is the most important of the known forces,**
and, as far as we know, is always attractive. This means gravity should always pull objects toward each other.
There is one problem – observations made by astronomers over the last couple of decades has proven that the
universe is accelerating outward as if something is pushing everything apart – anti-gravity if you will. Scientists call
the stuff pushing the universe apart “dark energy,” and the standard model has no way of accounting for it. Dark
energy may represent a paradigm shift for physics and astronomy because these observations were completely
unexpected and no previous theories can account for this anomalous acceleration.

Gravity is a problem. If you read over the three points above, you will notice that gravity plays an important role in
each. From the beginning of the development of the standard model, physicists knew that gravity was not being fully
considered; however, early attempts to include gravity caused the theory to fall apart. As an aside, Albert Einstein spent most


-----

of the second half of his career working on a “theory of everything” that would combine the known forces with gravity, but
even the greatest mind of the 20[th] century was not able to pull the pieces together.
Modern physicists continue to work on theories of everything, now known as Grand Unified Theories (GUTs). Two
promising such theories are string theory and its even more complex cousin, brane theory. The standard model treats the
fundamental particles as geometric points, zero dimensional objects. Although the math is far beyond the scope of this text,
the problem comes into play when a physicist needs to divide by the size of a particle. Since the size of a point particle is
zero, this creates a singularity. We all learn early on that dividing by zero is not a good idea, and so zero-dimensional point
particles create a significant challenge.  The situation is actually far more complicated than I just let on, but the _model I_
described should give you an idea for why the problem exists.
String theory takes the point-like nature of the fundamental particles and stretches them into tiny little vibrating strings,
on the order of 10[-35] meters in length. Most people can’t intuitively understand how small this is. An atom is on the order of
10[-10] meters, and the nucleus of an atom is 100,000 times smaller; on the order
of 10[-15] meters. To get to 10[-35] meters we have to divide that nucleus into a
hundredth of a billionth of a billionth of its original size. You probably still
don’t have a feel for that size and quite frankly, it’s too small for me to fathom
as well. So, with string theory, particles have size, and the problem is solved.
Various ways to ‘view’ an object – a diamond in this case – are shown in Figure
102-4.
What’s really fascinating is that string theory states that all of the particles
of the standard model, such as quarks and leptons, are different _modes of_
vibration of a string, or a small number of strings (depending on the exact
model). This is very similar to playing different notes on a guitar by placing
your finger in the middle of the string or 1/3 the way down the string while it is
vibrating; those notes represent different vibrational modes of the guitar string,
just as different modes of a fundamental string represent different particles.
This is where it starts to get crazy. It turns out that there are still problems
with our one-dimensional strings; if just a couple of types of strings are
responsible for all of the known particles, how is it that some particles interact
strongly with each other in one way and interact weakly in others? As an
example, consider how strongly quarks are held together inside of a nucleus by
the strong force versus how weakly gravity holds those same particles together.
To solve this, physicists next tried to generalize strings to two dimensions,
forming _membranes, and then later to even higher dimensions, which they_
called p-branes. Yes, p-brane is said “pee-brane”! All joking aside, p is set to
be the number of dimensions of this “brane;” a 0-brane is a point particle, a 1brane is a string, a 2-brane is a membrane and so on. The crazy thing is that this
seemed to work – as long as they allowed for eleven dimensions. _Eleven_
_dimensions!! Four of these dimensions are what we are accustomed to in our_
everyday life, three spatial dimensions and time. The other seven dimensions,
known as higher-order dimensions, are **_compactified, which is to say they are_**
spatial dimensions that have wrapped around on themselves so tightly that they

**Figure 102-5. A diamond at different**

are essentially non-existent to the macroscopic world. Difference in the strength

**scales. 1. Macroscopic scale. 2. Mol-**

of nuclear forces and gravitational forces can then be viewed as how strings **ecular scale. 3. Atomic scale. 4. Electron**
connect to p-branes – strings connecting to a low dimensional brane represent **scale. 5. Quark scale. 6. String scale.**
the strong nuclear force, whereas a string connecting to a higher-dimensional,
compactified brane represents the weak gravitational force, since more of this force ‘lives’ in the higher dimension.
Unfortunately, M-theory, as it is now called, is beyond what we can do in detail in this course, but this fascinating model is
considered by many physicists to be a major step towards incorporating gravity into the standard model. On the flip side,
physicists expect to be able to test these theories within your lifetimes using some of the largest particle accelerators in the
world. The idea is that they will smash particles together with enough energy that they _decompactify (expand) the next_
higher dimension for a split second and test whether the fundamental forces behave as they do now or as they are predicted to
in brane theory.


-----

-----

