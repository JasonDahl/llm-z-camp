### – What is Physics?
## 101


_What is physics? In this first unit, we will strive to give you a straightforward definition of physics and a sense of_
_just how interesting and complex the field is today. Physics is not just friction, electricity and magnetism, it is also_
_the field that tries to define where and when the universe began and how it will all evolve in the future. We begin_
_our journey in Unit 1 by describing the most fundamental building blocks of matter and energy. Then, in the next_
_few units we will build up how the world around us rises from these pieces._

##### Integration of Ideas

    - None. This unit begins our exploration of Physics.


##### The Bare Essentials

- Physics is defined as the study of matter, energy and their

**_interactions._**

- Physicists describe the universe with four fundamental
interactions, each of which have different relative strengths


**Four Fundamental Interactions**

**Strong Nuclear Interaction – Short-range interaction**

between quarks and gluons responsible for keeping
quarks together in nucleons, and nucleons together in
nuclei.
**Weak Nuclear Interaction – Short-range interaction**

responsible for nuclear radioactivity
**Gravitational Interaction – Long-range, attractive**

interaction between massive particles
**Electromagnetic Interaction – Long-range interaction**


between electrically charged particles.

- The Standard Model is currently the most widely accepted
fundamental model for our universe. In the Standard Model,
the universe is composed of three basic types of particles, in
two categories

**_Fermions – subatomic particles with half-integer spin_**

   - **_Quarks – particles which experience call fundamental_**
interactions and combine to form massive particles such
as protons and neutrons.

   - **_Leptons – particles which do not experience the strong_**
interaction. Leptons are often products of nuclear
reactions mediated by the weak interaction.

**_Bosons – subatomic particles with integer spin. Bosons_**
carry information about interactions between interacting
particles:



- Each fundamental interaction has at least one boson:

  - **_Photons – electromagnetic interaction_**

  - **_Gluons_** **– strong nuclear interaction**

  - **_W and Z bosons_** – weak nuclear interaction

  - **_Graviton – gravity (theoretical – never measured)_**

- There are problems with the standard model which lead to
extension to the model including string theory and
attempts to explain dark matter and dark energy

- Significant figures are used to determine the precision with
which a measurement or calculation is made. Although we
will generally use two or three significant figures in
Physics I and II, it is important to understand how to
determine an appropriate number of sig figs.

- Fundamental quantities in physics include

 - Energy (J or eV)
 - Mass (kg, amu or eV/c[2])
 - Length (m)
 - Time (s)

- When measuring quantities in physics, large variations in
scale are seen.  The scale of each quantity can be
succinctly described using the SI prefixes


-----

#### 101.1 From the Big Bang to the Standard Model to Newton and Einstein

**Consider: What is Physics?**

s far as we know, the Universe dates back to 13.7 billion years ago when a cataclysmic event known as the big bang
created the universe we know today. It is easy to try and think of the big bang as an explosion that started a chain
reaction, creating the universe; however, this isn’t really true. Explosions as we see them on earth occur because

# A

material with stored energy (which we’ll later call potential energy) suddenly releases that energy, allowing material to fly
away at high speed (later called kinetic energy) into the surrounding space. This cannot be the case for the big bang. Before
the “explosion” there was no space for the material to expand into, in fact, there wasn’t even time for the material to expand
into, so there was no “explosion” in the traditional sense. This is a hard concept to grasp, but before the big bang there was
no space and there was no time – at least not as we now know it.
The earliest microseconds of the universe did not resemble our current universe made of galaxies, stars and planets. This
universe was a hot, dense mess; the fundamental pieces of matter (as we know it today) were not well defined, and swam in a
soup called a quark-gluon plasma. As we’ll explore shortly, quarks are subatomic particles that form together in threes to
make up protons and neutrons (among other things). Gluons are a separate class of subatomic particles responsible for
holding quarks together as protons and neutrons. In this early quark-gluon plasma, there was simply too much energy density
for the gluons to do their job and create these quark triplets. It is near impossible to describe what the universe was really
like at this time, because everything is different from what we
experience today – matter wasn’t yet matter, time didn’t flow the way **Connection: Quark-gluon plasmas today**
we perceive today, and all of the interactions and forces we use to
describe the universe today, from the smallest to largest scales, were The universe went without quark-gluon plasmas for

about 13 billion years, until humans once again

combined into one indistinguishable superforce. Luckily, as space

recreated the conditions of the early universe - on

and time literally and figuratively expanded into nothingness, it

Long Island. Physicists at the Relativistic Heavy Ion

settled down, allowing quarks to form together into nucleons and then

Collider (RHIC) at the Brookhaven National

nuclei; allowing electrons to bind to these nuclei forming atoms and Laboratory first produced evidence of QG plasmas in
then for light to propagate as the newly formed matter spread out. 2005, although it wasn’t confirmed until 2010.
Today, the highly organized way the universe works at its Today, both RHIC and the Large Hadron Collider
fundamental level is called the standard model of particle physics and (LHC) near Geneva, Switzerland, routinely reproduce
you’ll explore some of it in this unit. these hot-dense conditions which allows them to
This is **_all physics. Physicists study the universe from its_** study the first millionths of a second of the universe.
creation to its demise. We study the smallest wiggles of space and
time and the gigantic interactions of galactic superclusters. Physicists study the beginnings of life and the evolution of
technology, and we hope to use this knowledge to improve lives and mitigate the unforeseen consequences of our
technological advances. And yes, physics can teach why a ball will fly through the air when you throw it – although that
problem has been solved for quite some time now.
Ask a random person on the street for one word that describes physics and most likely you’ll hear responses related to
mechanics. You might hear terms such as force, energy, projectiles, work, etc. The fact of the matter is that this list of ideas
is over three-hundred years old, and does not represent what the breadth of physics today. Even some of the more advanced
topics that might be covered in high school physics courses, such as electric charges and magnets, were well developed
before the beginning of the 20[th] century. Physics has come a long way since these topics were discovered and cataloged.
Today, physicists talk of string theory, dark energy, quantum dynamics and the multiverse; however, even with these
seemingly exotic ideas, the down-and-dirty definition of physics has not changed and still holds true for quark-gluon plasmas
and projectile motion alike:

**Physics: The study of matter, energy and their interaction.**

So, where do we start? Traditionally, introductory physics courses use a rather historical treatment of the field. After a
brief introduction to the math needed in the course, you would jump right into the ideas of basic motion, some of which were
known to the ancient Greeks. Following this, the course would move into the 17[th] century work of Isaac Newton, one of the
greatest physics minds the world has ever known. Finally, the ideas of energy and momentum would be introduced; topics
that are, in reality, far more fundamental than those studied earlier in the sequence. Along the way, you might even learn a
little about Albert Einstein and his theories on relativity from the beginning of the 20[th] century – even this is more than a
hundred years old!
This course will focus on introducing physics from a much more fundamental viewpoint. First, we study just a little of
what physics is today; that is, what we know about the nuts and bolts of the universe and how these basics give rise to the
everyday world around us. In fact, it turns out that everything we know about how physics works can be broken down to just
**_four basic interactions and two fundamental principles. This is where we start out journey._**


**Physics: The study of matter, energy and their interaction.**


-----

#### 101.2 The Four Fundamental Interactions

**Consider: How do objects interact on a basic level?**

In unit 102, we will take an in depth look at systems and interactions. However, in order to discuss how quarks and gluons
can form the basic building blocks of the current universe, we must discuss a little bit about how they interact. At a
fundamental level, there are only four ways in which matter interacts in the universe. These interactions are known as the
**_four fundamental interactions:_**

**_Gravitational Interaction – an interaction between any matter that possesses mass; a fundamental property_**
of inertia, or the ability to resist changes in motion. The gravitational interaction is by far the weakest
of the four interactions. The current “state-of-the-art” theory in understanding this interaction is
Einstein’s theory of general relativity.

**_Electromagnetic Interaction – an interaction between electrically charged particles. Electric charge, like_**
mass, is a fundamental property of a particle. The current “state-of-the-art” theory of
electromagnetism is quantum electrodynamics

**_Strong Nuclear Interaction – an interaction between certain sub-atomic particles that is responsible for_**
holding atomic nuclei together. The current “state-of-the-art” theory of the strong interaction is
quantum chromodynamics.

**_Weak Nuclear Interaction – an interaction between certain sub-atomic particles that is responsible for_**
some types of nuclear radiation. The current “state-of-the-art” theory of the weak interaction is known
as electroweak theory.

Throughout the course of the year, we will explore each of these fundamental interactions. As far as we know, all
measureable interactions fall under one of the four interactions above. This brings up an important question: where in the
fundamental interactions do all of the pushes and pulls of our everyday life fit (later we’ll call these mechanical forces)? It
turns out that all mechanical interactions – e.g. the ground holding you up or the force when you push on a box – are
electromagnetic on a fundamental level. Here are two important things to note: All atoms have negatively charged electrons
in orbitals around the atomic nuclei (see section 102-1); particles with the same electric charge repel each other and particles
with unlike electric charge attract each other. On a fundamental level, all of the mechanical forces (except for gravity) are
due to these electromagnetic interactions. We will discuss this more in unit 102.
The four fundamental interactions vary in strength. In order to understand this, we first have to discuss the range of each
interaction. We don’t tend to notice the nuclear interactions in our everyday lives. Nuclear interactions are responsible for
holding nuclei together, so we would certainly not exist without them; we
don’t notice them because their effective range is quite short when compared **Table 101-1. The fundamental interactions**

**with their relative strength and range.**

to our macroscopic scale, therefore we don’t notice the forces due to these

**Description** Relative Range

interactions. The range of the strong nuclear force is only about 10[−15]

Strength

meters and the range of the weak nuclear force is only about 10[−18] meters. **Gravitational** 1 ∞
On the other hand, the ranges of the electromagnetic and gravitational

**Weak nuclear** 10[25] 10[−18] 𝑚𝑚

interactions are infinite. The strength of the interactions does decrease with

**Electromagnetic** 10[36] ∞

distance, but does not completely disappear.  Table 101-1 summarizes some **Strong nuclear** 10[38] 10[−15] 𝑚𝑚
of the important features of the four fundamental interactions.


#### 101.3 The Standard Model of Particle Physics

**Consider: What is the current state of Physics?**

The Standard Model of particle physics (or just the Standard Model) is one of the most widely accepted models organizing
three of the four fundamental interactions. Gravity has proven very hard to incorporate within this model; however, the
standard model has very successfully described how the electromagnetic, weak nuclear and strong nuclear interactions fit
together to define the universe.
The Standard Model categorizes three distinct subatomic particles: quarks, leptons, and bosons; in two main categories:
fermions (quarks and leptons) and bosons. Particles in the Standard Model each have three characteristics that uniquely
identify each type of particle – mass, electric charge, and spin. Each of these is a fundamental property, meaning that they


-----

**Figure 101-1. The seventeen particles of the Standard Model with the name, mass (in**
**eV/c[2]), electric charge (relative to a proton) and spin (relative to Planck’s constant) of**
**each. Please see section 101-5 for a description of mass in eV/c[2]. First generation**
**fermions are in the first column, second generation fermions in the second column and**
**third generation fermions in the third column.**

are so hardwired into the fabric of the universe that it is hard to describe them beyond their measureable properties. For now,
you should consider the following definitions:

**_Mass – a measure of a particle’s inertia (resistance to change in motion) and of how particles interact_**
gravitationally; There is no apparent reason that these properties of mass should be the same, but in reality,
they seem to be – a principle now known as the Einstein equivalence principle.
**_Electric charge – a measure of how particles interact via the electromagnetic interaction; for subatomic particles the_**
electric charge is often measured relative to the magnitude of the charge on an electron (e). Electric charge
comes in two forms, positive (+) and negative (-). Objects with like electric charge repel and objects with
unlike electric charge attract under the electromagnetic interaction.
**_Spin – a measure of a particle’s angular momentum – a classical analogy would be how fast a child’s top spins,_**
although this analogy is weak. Spin is often measured relative to Planck’s constant, h, a fundamental constant.

Figure 101-1 shows the 17 fundamental particles considered part of the standard model. In this figure, the first three columns
represent fermions (quarks and leptons) and the last two columns represent bosons. Each column of fermion represents a
**_generation_** (First column is 1[st] generation, 2[nd] column is 2[nd] generation, etc). If you read a row horizontally across
generations, the higher generation particles are just higher mass versions of the lower generation particle. For example, the
charmed quark is a higher mass up quark and a muon is a higher mass electron.
Each of these classes of particles is described below. Please note that almost all particles we interact with on a daily
basis are in the first generation of fermions (the left-most column), and all of the bosons.

**_Fermions are particles which have a half-integer spin (relative to Planck’s constant). Fermions must obey the_** _Pauli_
_Exclusion Principle (no two particles may be in the exact same state). Fermions come in two types: quarks and leptons:_


-----

**_Quarks_** – Quarks are fermions that experience all four of the fundamental interactions. Quarks have
fractional electric charge (when compared to the electron). Although particles are not allowed to exist
independently with fractional electric charge, quarks can form together into stable particles with
integer charge (such as the proton and the neutron). There are six known types (flavors) of quarks –
up, down, charmed, strange, truth (aka top) and beauty (aka bottom). Most ‘normal’ matter is
composed of up and down quarks.

**_Leptons – Fermions that do not experience the strong nuclear interaction. Leptons include the electron and_**
its more massive cousins the muon and tau particle. In addition, each of these leptons has an
associated electrically neutral neutrino – a lepton itself that does not interact via the electromagnetic
interaction because of its neutral charge.

**_Bosons are particles with an integer spin that do not obey the Pauli Exclusion Principle. Gauge bosons are the “force_**
carriers” of the fundamental interactions, meaning that each interaction has an associated boson which carries
information about the interaction between other subatomic particles:

**_Photon – electromagnetic interaction_**
**_Gluon – strong nuclear interaction_**
**_W and Z bosons – weak nuclear interaction_**
**_Graviton – gravitational interaction (theoretical – never observed)_**

In addition, the recently discovered **_Higgs Boson is responsible for the mass of some_**
subatomic particles, although this is a different type of boson from the gauge bosons
noted above.

Now, note that the fermions in Figure 101-1 are grouped into three generations.
That is, the up quark, down quark, electron and electron neutrino make the _first_
_generation, the charm quark, strange quark muon and muon neutrino make a_ _second_
_generation, etc. Almost all normal matter is made up of first generation fermions! The_
second and third generation material observed has mostly been made in particle
accelerators, except for muons, which are created by cosmic ray collisions high in the
atmosphere. There are also horizontal connections in Figure 101-1. As an example, the
charmed quark is very similar to an up quark, just with more mass. Similarly, the bottom

**Figure 101-2. Gluons (squiggly**

quark is very similar to the strange and down quarks except that it has more mass. **lines) interacting with quarks to**
We noted before that quarks can form into stable matter if the electric charge of the **form a proton (𝒖𝒖𝒖𝒖𝒖𝒖).**
composite particle is an integer of the charge of the electron. Consider a particle made
up of three quarks, two up quarks and one down quark. Since each up quark contributes a
charge of +(2/3)e (where e is the magnitude of the charge on an electron) and the down quark contributed (-1/3)e, the net
charge of this particle would be +1. This is the proton. Likewise, the particle made of one up quark and two down quarks
(with net charge of zero) is the neutron.
Figure 101-2 depicts how gluons (the mediators of the strong nuclear interaction) interact with a two up quarks and a
down quark to form a proton. Note that the squiggly lines represent the gluons holding the quarks together (similar to springs
in this example).


Example 101 - 1 **Comparing quark masses**

What is the quark makeup of a proton-like particle with the
next most mass than the proton itself?

**Solution:**

The proton is made of two up and one down quark, noted uud.
In order to make a more massive proton, we would need to
replace one of the up quarks with a charmed quark or a down


quark with a strange quark. Since the strange quark is
less massive than the charmed quark, the lowest possible
correction is the down to a strange – uus.

This particle is known as the Sigma[+] particle, and can
created in particle accelerators. Once created, however,
the Sigma[+] only lasts 8 𝑥𝑥 10[−11] seconds before decaying
into a proton or neutron and some other crazy particles.


-----

Example 101 - 2 **Using the 2[nd] generation**

What is the quark makeup and electric charge of a neutron- The neutron is composed of one up (charge +2/3) and
like particle made entirely of 2[nd] generation quarks? two down quarks (each with charge −1/3). Looking at

Figure 101-1, we can see that the 2[nd] generation

**Solution:** equivalents of the up and down quarks are the charmed

and strange quarks, respectively. Therefore, our neutron
This problem asks us to compare what we know about the like, 2[nd] generation particle will be composed on one
neutron to what we know about second generation particles. charmed and two strange quarks. The electric charge of

this particle would be zero, just like the neutron.

We could spend the entire course discussing the properties and consequences of the Standard Model. As an example,
consider a Helium nucleus made of two protons and two neutrons. Each of these four particles are trying to attract each other
via the gravitational force (very weak). However, the two protons are repelling each other with a much stronger force than
that which the gravitational force could hold it together. So, why doesn’t the nucleus just fly apart? Well, the answer is the
strong nuclear force – Some of the quarks in one proton are close enough to quarks in the other proton or the neutron to be
attracted by the strong nuclear force. However, the strong nuclear force almost shuts off at 10[−15] meters, so if one of the
particles were to separate just far enough away from the others, they could be separated (we will explore this more in Physics
II).

A couple of other notes:

**_Antiparticle – an antiparticle of a particle has all the same properties as the original particle except that it has opposite_**
electric charge. As an example, the positron is the antiparticle of the electron – it is an electron with a positive
charge. Antiparticles are often noted with a bar over the symbol: An anti-up quark (𝑢𝑢�) is an up quark (𝑢𝑢) with a
charge of –(2/3)e.
**_Color charge – quarks and gluons have a property known as color charge. In a quark triplet (such as the proton or_**
neutron) each quark in the triplet must be one of three colors (red, green or blue). Each gluon is then described by
the two colors it acts between (red-blue gluon for a gluon that acts between a red and blue quark). Note that the
name color here only refers to a property, and not real color – the name was given because red, green and blue
pigments are often used to make the colors of the rainbow.


Example 101 - 3 **Anti-quark triplet**

A certain three-quark particle is found to be made of a blue
anti-up quark, a green anti-up quark and an anti-down quark.
(a) What is the electric charge of this particle? (b) Does this
particle resemble any of standard particles discussed in this
unit? (c) What is the color of the anti-down quark?

**Solution:**

This problem asks us to explore what we know about the
makeup of three-quark particles including antiparticles and
color charge.

(a) Each anti-up quark has an electric charge of -2/3 since

they have the same magnitude of an up quark (+2/3) but
with the opposite sign. Similarly, the anti-down quark
has an electric charge of +1/3. So, the total charge is


2 �− [2]

3[�+ 1]3 [= −1.]


(b) Since this particle is made entirely of 1[st] generation

quarks and has an electric charge of −1, this is the
antiparticle of the proton, known as the anti-proton.
Although the anti-proton has the opposite electric
charge of the proton, it will have the same mass as
the proton.

(c) Three-quark particles must have one each of red,

green, and blue quarks. Since the anti-up quarks
carried blue and green color charges, the anti-down
quark must have a red color charge.


-----

#### 101.5 – Significant Figures, Scientific Notation and SI Prefixes.

**Consider: How can I represent big and small numbers?**

**Table 101-3. SI Prefixes**

Throughout the course we will solve problems in two fundamentally different ways.

**Prefix** Factor Symbol First, we will develop your ability to work with the fundamental principles of
yocto- 10[−24] y physics to algebraically solve problems so that we can find, in symbols, how system
zepto- 10[−21] z act. Although these analytic solutions are very important for understanding the
atto- 10[−18] a

general way in which systems move, we also want to use specific real-world

**femto-** 𝟏𝟏𝟏𝟏[−𝟏𝟏𝟏𝟏] **f**

situations to test and understand physics – which means using numbers. In this

**pico-** 𝟏𝟏𝟏𝟏[−𝟏𝟏𝟏𝟏] **p**

course we will see some very small numbers such as

**nano-** 𝟏𝟏𝟏𝟏[−𝟗𝟗] **n**
**micro-** 𝟏𝟏𝟏𝟏[−𝟔𝟔] µ
**milli-** 𝟏𝟏𝟏𝟏[−𝟑𝟑] **m** 𝑟𝑟= 0.000 000 000 000 00125 𝑚𝑚,
**centi-** 𝟏𝟏𝟏𝟏[−𝟐𝟐] **c**
deci- 10[−1] d which is the approximate size of the hydrogen nucleus, and
deka- 10[1] da
hecto- 10[2] h 𝑡𝑡= 435 000 000 000 000 000 𝑠𝑠;
**kilo-** 𝟏𝟏𝟏𝟏[𝟑𝟑] **k**
**mega-** 𝟏𝟏𝟏𝟏[𝟔𝟔] **M** the approximate age of the universe.
**giga-** 𝟏𝟏𝟏𝟏[𝟗𝟗] **G** Such number are either so small or so large that it is impossible to look at them
**tera-** 𝟏𝟏𝟏𝟏[𝟏𝟏𝟏𝟏] **T** and immediately interpret their significance. Luckily, mathematicians and scientists
**peta-** 𝟏𝟏𝟏𝟏[𝟏𝟏𝟏𝟏] **P** have developed a notation, known as scientific notation, which allows us to write all
exa- 10[18] E numbers in a succinct form. The basic promise is that a number in the form
zetta- 10[21] Z
yotto- 10[24] Y 𝑎𝑎 𝑥𝑥 10[𝑏𝑏] (101-1)

is the same as the number 𝑎𝑎 followed by 𝑏𝑏 zeroes. For example

4 𝑥𝑥 10[5] = 400 000, (101-2)

or a 4 with 5 zeroes after it. Most numbers will have more than one digit, such as 2 345. In this case, we write the number
with one digit to the left of a decimal point and the rest to the right of the decimal point and then the exponent is the number
of places we need to move the decimal place. For 2 345 we would write 2.345 as the number and since we moved the
decimal place by three places, the exponent is three:
2 345 = 2.345 𝑥𝑥 10[3]. (101-3)


Example 101 - 4 **Practicing scientific notation**

Write the following numbers if scientific notation

(a) 2 322
(b) 0.00055
(c) 272.4 x 10[2]
(d) 0.0033 𝑥𝑥 10[−2]

**Solution:**

Each of these ask us to work with the definition of scientific
notation.

(a) In this basic case, we need to move the decimal point

three place to the left, so we add three to the exponent
(which starts at zero):

2 322 = 2.322 𝑥𝑥 10[3]


(b) In this case, we need to move the decimal place four

places to the left, so the exponent becomes -4:

0.00055 = 5.5 𝑥𝑥 10[−4]

(c) In this part, we have to move the decimal place two

places to the left, so we add two to the exponent

272.4 x 10[2] = 2.724 𝑥𝑥 10[4]

(d) In this case, we need to move the decimal place three

places to the right, so we subtract three from the
exponent

0.0033 𝑥𝑥 10[−2] = 3.3 x 10[−5]


Another convenient shortcut for small and large numbers is to use SI prefixes. You are already familiar with this concept. If
you have ever described something as being a few centimeters or kilometers, you have used the SI prefixes centi- (for 1/100)


-----

and kilo- (for 1 000). There are SI prefixes for every multiple of 10[3], as well as a couple of other non-standard intervals. All
of the SI prefixes are summarized in Table 101-3. The prefixes you should be very familiar with are bolded in this table.
Scientific notation and SI prefixes go together very well. For example, 3.2 km can also be written as 3.2 𝑥𝑥 10[3] m.
Something like 27 mm can easily be converted to scientific notation by first converting the prefix to an exponent and then
making sure that there is one leading digit in front of the decimal place:

27 𝑚𝑚𝑚𝑚= 27 𝑥𝑥 10[−3] 𝑚𝑚= 2.7 𝑥𝑥 10[−2] 𝑚𝑚. (101-4)

It can take some time to become familiar with both of these notations; however, once you master them, they can make
writing and analyzing numbers much easier.


Example 101 - 5 **Including SI prefixes**

Write the following quantities in scientific notion using the
unit described

(a) 4.2 km in m
(b) 58 s in Ms
(c) 30.2 pg in kg

**Solution:**

This problem asks us to use our knowledge of SI prefixes and
scientific notation to rewrite numbers.

(a) This is a straightforward conversion:


4.2 𝑘𝑘𝑘𝑘 = 4.2 𝑥𝑥 10[3] 𝑚𝑚

(b) In this case, we must note that 1 𝑀𝑀𝑀𝑀 = 10[6]𝑠𝑠 or 1 𝑠𝑠 =

10[−6] 𝑀𝑀𝑀𝑀, therefore

58 𝑠𝑠 = 58 𝑥𝑥 10[−6] 𝑀𝑀𝑀𝑀 = 5.8 𝑥𝑥 10[−5] 𝑀𝑀𝑀𝑀.

(c) For this part, we must note that 1 𝑝𝑝𝑝 𝑝 = 10[−12] 𝑔𝑔 and

1 𝑘𝑘𝑘𝑘 = 10[3]𝑔𝑔, so we must move the decimal place by
12 places:

30.2 𝑝𝑝𝑝 𝑝 = 30.2 𝑥𝑥 10[−15] 𝑘𝑘𝑘𝑘 = 3.02 𝑥𝑥 10[−14] 𝑘𝑘𝑘𝑘


Finally, there is always the question of significant figures. We only report answers to numerical problems to the same
number of digits as the smallest (non-exact) number in the problem. If you are unsure of the number of significant digits that
a number contains, they best way to determine this is to write the number in scientific notation. When you do this, you must
keep any zeroes at the end of a number if they are after the decimal places. More details on significant figures can be found
in the appendix of this text. Note: It is always a good idea to keep one or two extra significant figures in the middle of a
**_complex calculation!_**


Example 101 - 6 **Significant figures**

Perform the below calculations and report the answers in the
correct number of significant figures.

(a) 1.322 m + 1.45 m
(b) 7.89 m / 1.22876 s

**Solution:**

This problem asks us to perform arithmetic steps and then
report the answer in terms of the correct significant figures.


(a) We first do the required calculation and then note that
the smallest number of significant figures is three:

1.322 m + 1.45 m = 2.772m →2.77 m.

(b) We first do the required calculation and then note that
the smallest number of significant figures is three:

7.89 𝑚𝑚⁄1.22876 𝑠 = 6.421107𝑠𝑠 →6.42 𝑠𝑠.


#### 101.5 – Measuring basic quantities.

**Consider: What are the basic quantities and units in Physics?**

In this section, we will define some of the important fundamental quantities used in Physics I. Along the way, we will also
define the important units that go with each. A unit is a unique name we give to a specific quantity of something so that we
can talk about it in relationship to something else. Physicists have worked hard to make the fundamental units for various
quantities fit with basic properties of the universe. We will see that many of the standard units in the international system of
**_units (often abbreviated SI units from the French translation, also known as the_** _metric system) are based on light_
(electromagnetic waves).


-----

In 1971, the base units of the SI system were set and have not changed **Table 101-4. The seven base units in the SI**
since that time. Table 101-4 gives these quantities along with their standard **System.**
unit and unit abbreviation. In Physics I we will make use of the meter, **Description** Unit Symbol
kilogram, second, kelvin and mole. We will not see the units ampere and **Length** meter m
candela until Physics II. **Mass** kilogram kg
As a note, the symbols for units named after a person are capitalized **Time** second s

**Electric current** ampere A

(e.g. A for ampere and K for kelvin in Table 101.4); however the name of

**Temperature** kelvin K

the unit is not capitalized. For units that are not named after a person, both

**Substance amount** mole mole

the units name and symbol are lowercase.

**Luminous Intensity** candela cd

**_The speed of light_**

It turns out that the speed of light in a vacuum is one of the most fundamental values in all of physics. One of the pillars of
Einstein’s special theory of relativity is that the speed of light in vacuum is the same for all observers in all inertial reference
frames and it is therefore one of the universal physical constants. The standard symbol for the speed of light is c, and its
value is exactly
𝒄𝒄= 𝟐𝟐𝟐𝟐𝟐𝟐, 𝟕𝟕𝟕𝟕𝟕𝟕, 𝟒𝟒𝟒𝟒𝟒𝟒 𝒎𝒎/𝒔𝒔, (101-5)

where the unit 𝑚𝑚/𝑠𝑠 represents meters/second, or rather distance over time. This is a derived SI unit using the base units of 𝑚𝑚
and 𝑠𝑠.

**_Energy_**

Energy is a fundamental concept that objects and systems possess in up to three forms – kinetic energy (energy of motion),
potential energy (stored energy) and internal energy (energy associated with individual atoms and molecules). Energy is very
hard to define because of its fundamental nature, but you can picture it as the ability to measure or change the motion of
objects in a system (including the individual atoms and molecules).
Although the concept of energy is fundamental, it does not have a base SI unit, only derived units. The most commonly
used units for energy are the Joule (𝑱𝑱), and electron-volt (𝒆𝒆𝒆𝒆). Joules tend to work well for systems that are approximately
our size or larger and electron volts are often used for very small systems, since the unit is defined as the energy gained by an
electron if accelerated through one volt of potential difference (described in Physics II). eVs and Joules are related by

1 𝑒𝑒𝑒 𝑒 = 1.6 𝑥𝑥 10[−19] 𝐽𝐽, (101-6)

Table 101-5 gives some representative values for energy.

**Table 101-5. Some typical values for energy.**

**Description** Energy (J) Energy (eV)
**Estimated mass-energy of the universe** 4.0 𝑥𝑥 10[69] -**World energy consumption (2010)** 5 𝑥𝑥 10[20] -**One food Calorie** 4.2 𝑥𝑥 10[3] -**Energy to lift a hamburger to mouth** ~1 6.3 𝑥𝑥 10[18]
**Energy of small apple dropped 1 meter** ~1 6.3 𝑥𝑥 10[18]
**Energy from fission of one U-235 nucleus** 3.4 𝑥𝑥 10[−11] 2.1 𝑥𝑥 10[8]
**Visible photon (particle of light)** 4 𝑥𝑥 10[−19] 2.5
**AM radio photon (radio wave)** 6.6 𝑥𝑥 10[−28] 4 𝑥𝑥 10[−9]
Notes: -- = it does not make sense to report value in 𝑒𝑒𝑒𝑒.

**_Mass_**

The SI unit for mass is the kilogram (kg). The kilogram is defined by a cylindrical mass of platinum-iridium, known as the
“international prototype kilogram,” that is kept at the International Bureau of Weights and Measures in Paris France. The
kilogram is the only standard unit still defined by an artifact (a thing). Although there are discussions underway to change
the definition, for now we are stuck with a metal cylinder kept under two evacuated bell jars (see Figure 101-3). The mass of
all other objects is defined relative to this standard mass.
There are two other important mass units that are used for very small quantities. The first is the atomic mass unit (u),
which is defined as one-twelfth the mass of a carbon-12 atom (a carbon atom with 6 protons, 6 neutrons and 6 electrons):


-----

1 𝑢𝑢= 1.66053886 𝑥𝑥 10[−27] 𝑘𝑘𝑘𝑘. (104-7)

The third important mass unit is based on Einstein’s famous equation, 𝐸𝐸= 𝑚𝑚𝑐𝑐[2]. This
equation can be solved for mass, leaving it in units of 𝐸𝐸𝑐𝑐⁄ [2]. The energy that is typically
used in this case is the energy an electron gains if it moves through a 1-volt potential
difference, called the electron-volt (eV) (we will define this later in the course). Thus, the
unit of mass becomes 𝑒𝑒𝑒𝑒/𝑐𝑐[2], with

1 𝑒𝑒𝑒𝑒/𝑐𝑐[2] = 1.78266184 × 10[−36] 𝑘𝑘𝑘𝑘. (104-8)

The vast majority of the time, we will use the unit kg for mass; however, when dealing with
the very small (atoms and nuclei), the atomic mass unit and 𝑒𝑒𝑒𝑒/𝑐𝑐[2] will occasionally come
up. This is the unit of mass used in Figure 101-1 for the mass of the fundamental particles.
Table 101-6 gives some representational values for mass.


**Figure 101-3. The**
**standard kilogram.**


**Table 101-6. Some typical values for mass.**
**Description** Mass (kg) Mass (eV units)
**Mass of the sun** 2.0 𝑥𝑥10[30] 1.1 𝑥𝑥10[66] 𝑒𝑒𝑒 𝑒/𝑐𝑐[2]
**Mass of the earth** 6.0 𝑥𝑥 10[24] 3.4 𝑥𝑥 10[60]𝑒𝑒𝑒𝑒/𝑐𝑐[2]
**Blue whale** 1.5 𝑥𝑥 10[5] 8.4 𝑥𝑥 10[40] 𝑒𝑒𝑒𝑒/𝑐𝑐[2]
**Human** 70 3.9 𝑥𝑥 10[37] 𝑒𝑒𝑒 𝑒/𝑐𝑐[2]
**Dust particle** 10[−14] 5.6 𝑥𝑥 10[21] 𝑒𝑒𝑒 𝑒/𝑐𝑐[2]
**Proton** 1.7 𝑥𝑥 10[−27] 953 𝑀𝑀𝑀𝑀𝑀 𝑀/𝑐𝑐[2]
**Electron** 9.1 𝑥𝑥 10[−31] 511 𝑘𝑘𝑘 𝑘𝑘 𝑘/𝑐𝑐[2]
Note: 𝑀𝑀𝑀𝑀𝑀𝑀/𝑐𝑐[2] is Mega-eV/c[2], 𝑘𝑘𝑘𝑘𝑘𝑘/𝑐𝑐[2] is kilo-eV/c[2]. eV/c[2] tends to be used for
only very small objects.

**_Time_**

Time is a concept we have all used extensively in our lives. In reality, time is far more complicated than most people realize.
Another one of the results of Einstein’s special theory of relativity is that different observers experience different rates at
which time passes. For most of us, these differences are so small that they are nearly unmeasureable so that we can go on our
merry way without even thinking about it (for more, see Unit 131 – The Curious Case of Time).
As an everyday measurement tool, time is ‘how long it take something to happen.’ Therefore, anything that repeats itself
could give us a standard measure of time. It turns out that light of a specific color is an electromagnetic wave that oscillates
up and down a specific number of times a second (frequency). Since we know from above that light travels at an exact speed
in a vacuum, this allows us to precisely define a time period. Using all this, the standard unit of time is the second (s) and is
defined as follows:

_The second is the time it takes for a specific color of light emanating from cesium-133 to oscillate_
_9,192,631,770 times._

These “atomic” cesium clocks are so precise that it would take more than 6,000 years for two of them to be out of sync by 1
second. Table 101-7 gives some representational values for time.

**Table 101-7. Some typical values for time.**

**Description** Time (s)
**Age of the universe** 4.3 𝑥𝑥 10[17]
**Age of earth** 1.7 𝑥𝑥 10[17]
**One year** 3.2 𝑥𝑥 10[7]
**One Physics I session** 6 600
**Record for 100m sprint** 9.7
**Time for light to pass one mile** 5.3 𝑥𝑥 10[−6]
**Time for light to cross one atom** 4 𝑥𝑥 10[−19]


-----

**_Length_**

For literally hundreds of years, the standard measure of length, the meter, was defined by the distance between two scratch
marks on a metal bar in Paris, France (at the same International Bureau of Weights and Measures described in the section on
the kg). As you can imagine, the precision to which these scratch marks defined the meter was not very good. Today, the
meter is very precisely defined by the speed of light and the second:

_The meter is exactly the distance that light travels in a vacuum in 1/299,792,458 seconds._

One meter is 3.28 feet, or 1.09 yards. You are probably more familiar with these Imperial or English measurement units;
however, such units are only used in Liberia, Myanmar and the United States – the rest of the world uses the metric system.
Table 101-8 gives some representational values for length.

**Table 101-8. Some typical values for length.**

**Description** Length (m)
**Size of the universe** 8.6 𝑥𝑥 10[26]
**Radius of the sun** 7.0 𝑥𝑥 10[8]
**Radius of the earth** 6.4 𝑥𝑥 10[6]
**Empire State building** 443
**Typical human** 1.75
**Diameter of a hydrogen atom** 1.1 𝑥𝑥 10[−10]
**Size of a proton** ~10[−15]


-----

-----

