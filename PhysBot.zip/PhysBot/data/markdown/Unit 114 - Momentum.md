### – Momentum
## 114


_Momentum, the combination of an object’s mass and velocity, is one of the few fundamental quantities in physics. In this_
_unit we study the basics of momentum and its relationship to force. In the next couple of units, we will explore how_
_momentum is conserved in all isolated systems and the consequences of this idea._

##### The Bare Essentials

- The center of mass of an extended object is found by adding

small pieces of the object relative to each piece’s position. **Impulse-Momentum Relationship**

𝑱[⃗] = 𝚫𝒑��⃗

**Center of Mass**

**Description – This equation relates the impulse imparted to an**

object, 𝐽[⃗], to the object’s change in momentum, ∆𝑝⃗.

𝒓�⃗𝒄𝒎 = [𝟏] **Note 1: Impulse is defined as the integral of force with respect to**

𝑴 [�𝒎][𝒊][𝒓�⃗][𝒊]

time or the average force multiplied by time: 𝐽[⃗] ≡∫𝐹[⃗]𝑑𝑡≈

**Description – This equation describes how to find the center of** 𝐹[⃗]���∆𝑡

mass, 𝑟⃗��, of an extended object of total mass 𝑀. 𝑚� and 𝑟� **Note 2: In practice, we often use the definition of impulse to**
represent the mass and position of small parts of the mass.

directly relate to change in momentum as 𝐹[⃗]���∆𝑡= ∆𝑝⃗.



- For linear motion, you can treat an extended object as if it

were a point particle with all of its mass concentrated at its
center of mass.

- The momentum of an object is defined by its mass and its

velocity.


**Force-Momentum Relationship**

𝐅[⃗]𝐧𝐞𝐭 = [𝒅𝒑��⃗]𝒅𝒕

**Description – The force-momentum relationship (Newton’s 2[nd]**

law) tells us that the net force on an object, F[�⃗], is equal to the
rate of change of momentum with respect to time 𝑑𝑝⃗𝑑𝑡⁄ .
**Note: This equation can also be used to find the change in**

momentum that would be caused by an individual force in the
absence of other forces.



- The force on a particle at an instant of time is the time rate of

change of momentum of the particle.


**Momentum of a Particle**

𝒑��⃗= 𝜸𝒎𝒗��⃗

**Description – This equation defines the momentum, 𝑝⃗, of a**

particle in terms of the Lorentz factor, 𝛾, and the particle’s
mass, 𝑚, and velocity, 𝑣⃗.
**Note 1: In the classical limit the momentum of a particle is 𝑝⃗=**

𝑚𝑣⃗
**Note 2: The SI units of momentum is 𝑘𝑔∙𝑚𝑠⁄ .**



- The conservation of momentum states that the total

momentum of an isolated system does not change.



- The impulse-momentum relationship states that the impulse on

an object is equal to its change in momentum.


**Conservation of Momentum**

𝚫𝒑��⃗𝒔𝒚𝒔 = 𝟎

**Description – This equation states that the total momentum of an**

isolated system does not change.
**Note: If the system is not isolated, the total change in momentum**

is related to the external force and the time over which it acts
by the impulse-momentum relationship, ∆𝑝⃗��� = 𝐹[⃗]���∆𝑡.


-----

#### 114.1 – Momentum is fundamental

**Consider: Why do we care about momentum?**

IKE ENERGY, MOMENTUM IS A FUNDAMENTAL quantity in all of physics. To the best of our knowledge,
momentum is conserved in all isolated systems across the universe. In the last many units, we discussed the many
types of energy, including potential energy, kinetic energy and a host of different potential energies. We also had to

# L

discuss two important types of energy transfer – heat and work. There is only one type of momentum. In a sense, this makes
our task simpler – we don’t have to worry about what types of momentum go into a system like we did with energy because
each object will only possess its own momentum. On the flip side, momentum is a vector where energy is a scalar. This
means we have to go back to using vector notation and take care to carry over components in a correct fashion.
In a traditional introductory physics course, momentum is introduced after a long discussion of forces and then changes
in momentum are directly related to how a force acts on an object over time. This treatment doesn’t give momentum the
credit it deserves. It cannot be overstated that momentum is one of the basic features of physics as we know it – tiny
quantum particles and huge galactic clusters follow the principle of momentum. In fact, the conservation of momentum (the
fact that the total momentum of an isolated system must remain constant) is the result of a basic underlying symmetry in the
universe known as **_translational symmetry, which states that the laws of physics do not change if you move an object_**
(translate it) to a different place. If you look deeply into this statement, the conservation of momentum falls out – meaning it
must be true everywhere. Physicists look for beauty in physics by finding such symmetries, which is why the conservation of
momentum holds such an important place in the hearts of professional physicists.

#### 114.2 – Center of mass of an extended object

**Consider: How do I find the balance point of an object?**

Pick up a pen, pencil, marker or something similar and try to balance it on
your finger. If your object is relatively symmetric, your finger should be
approximately under the center of it to get it to balance. Now, if you were to
try this with a baseball bat or an umbrella, you would find that the position to
need to place your finger is not under the center of the object, but rather
under its center of mass, a position which takes the relative position of each **Figure 114-1. Three masses situated on the x-**
bit of mass in the object into account. **axis used to discuss the center of mass.**
Consider the set of three masses shown in Figure 114-1. If these masses
were evenly distributed, we would expect the center of mass to be directly in
the middle of the setup as described above. However, since there is some asymmetry to the way the masses are arranged, the
center of mass must be calculated directly. In order to do this, we will add the product of mass and position for each particle
and then divide by the total mass of the system as
𝑥�� = [𝑥][�][𝑚]𝑚[�] �[+ 𝑥]+ 𝑚[�][𝑚]�[�]+ 𝑚[+ 𝑥]�[�][𝑚][�]. (114-1)

This equation can be expanded to any number of particles such that the numerator becomes a sum over all of the particles
which make up the object. This gives us a general, one-dimensional center of mass equation

𝑥�� = [1], (114-2)

𝑀 [�𝑚][�][𝑥][�]

�

where I have also denoted the total mass of the system as 𝑀= 𝑚� + 𝑚� + ⋯.
Finally, we could use the same process to find the center of mass of objects in multiple dimensions by finding the y- and
z-components of the center of mass as well, which gives us

𝑥�� = [1], 𝑦�� = [1], 𝑧�� = [1] . (114-3)

𝑀 [�𝑚][�][𝑥][�] 𝑀 [�𝑚][�][𝑦][�] 𝑀 [�𝑚][�][𝑧][�]

� � �

In practice, we will find each of these possible components separately; however, they can be written concisely using vector
notation:


-----

𝑟⃗�� = 𝑀[1] [�𝑚][�][𝑟⃗][�][.] (114-4)


where

respectively.


𝑟⃗�� = �


𝑥��
𝑦��
𝑧��


�      and      𝑟⃗� = �


𝑥�
𝑦��,
𝑧�


**Center of Mass**

𝒓�⃗𝒄𝒎 = 𝑴[𝟏] [�𝒎][𝒊][𝒓�⃗][𝒊]

**Description – This equation describes how to find the**

center of mass, 𝑟⃗��, of an extended object of total mass
𝑀. 𝑚� and 𝑟� represent the mass and position of small
parts of the mass.


A couple of notes on the center of mass:

1) Since the center of mass is a weighted average, more massive particles will have a greater influence. This is seen in

two-particle systems where the center of mass is closer to the more massive particle.
2) There does not need to actually be mass at the center of mass. For example, the center of mass of a Hula-Hoop is at

the center of the hoop and the center of mass of a bar stool will be under the seat of the stool.
3) Symmetric objects have a center of mass at the physical center. Non-symmetric objects will often have a center of

mass that is different from the physical center.
4) For linear motion, you can treat an extended object as if it is a point particle with all of its mass concentrated at its

center of mass. This is not true when considering rotational motion as in Units 117 and 118.


Example 114 - 1 **2D center of mass**

Two small spheres of mass 𝑚� and 2𝑚� are separated by 3.0
meters. Where is the center of mass located relative to the
smaller sphere?

**Solution:**

This problem asks us to use the definition of the center of
mass to describe where the center of mass of a two object
system is located.

The problem only contains two objects, 𝑚� with mass m and
𝑚� with mass 2m. We will orient our coordinate system such
that the small mass is located at the origin and the larger mass
is located along the positive x-axis (at 𝑥= 2𝑚).

We can now write the equation for center of mass of the
system as

𝑟⃗�� = 𝑀[1] [�𝑚][�][𝑟⃗][�][,]

which can be simplified to


𝑟��,� = 2 𝑚.

Note that the center of mass of the system is closer to the
larger mass than the smaller mass. In addition, we did
not need to know the _actual masses in this case; since_
they are multiples of each other, the 𝑚� drops out of the
equation. As a reminder, if you feel like you don’t have
all the necessary information, still try to problem because
the information you feel you need may not wind up being
important (such as numerical values for masses in this
case).


1
𝑟��,� = 𝑚� + 𝑚�


(𝑚�𝑥� + 𝑚�𝑥�),


since we have defined the coordinate system such that all of the
mass is on the x-axis. Using values from the problem, we find


1
𝑟��,� = 𝑚� + 2𝑚�

which simplifies to



[𝑚�(0) + 2𝑚�(3.0 𝑚)],


-----

Example 114 - 2 **Equilateral triangle**

Where is the center of mass of three identical masses, which
form an equilateral triangle with sides of 2.5 m?

**Solution:**

This problem asks us to use the definition of the center of
mass to find the center of mass of a multi-dimensional
system.

In order to solve this problem, we must first set up a
coordinate system. In this case, I will put one of the masses at
the origin of our coordinate system and have one side of the
triangle oriented along the positive-y axis. In addition, I will
place the triangle in the xy-plane as shown below.

Note that in this coordinate system, all z-components will be
zero.  We can now use the definition of center of mass to find


Note that this center of mass lies where there is no actual
mass – a common trait of open structures.


𝑟⃗�� = 𝑀[1] [�𝑚][�][𝑟⃗][�]

In this case, we do need to use the full vector form of the center
of mass. The total mass of the system is 𝑀= 3𝑚, where m is
the mass at any one of the three points. One mass is at the
origin (0,0,0) m, and one mass is at (2.5,0,0) m.

In order to find the position of the final mass, we note that the
mass in the xy-plane is located directly above the midpoint of
the mass on the x-axis (see the dotted line in the diagram).
Since each angle of an equilateral triangle is 60°, we can use
trig to find the x- and y-components of this position. Putting
this all together, we find


0
0
0


�


𝑥��
𝑦��
𝑧��


�= [1]

3𝑚 [��]


0�+ �


2.5𝑚

0
0


�+ �


2.5 cos 60° 𝑚

2.5 sin 60° 𝑚

0


��.


Again, each term contains the mass, which will cancel with the
mass in the fraction out front. Simplifying, we find


𝑥��

𝑟⃗�� = �𝑦��

𝑧��


�= �


1.25
0.72

0


� 𝑚𝑒𝑡𝑒𝑟𝑠.


#### 114.3 – Linear momentum

**Consider: What is momentum?**

Consider the center of mass of a two particle system which interacts under the gravitational interaction. I will call the two
particles particle 1 and particle 2, with masses 𝑚� and 𝑚�, respectively. Let’s also assume that both particles are on an x-axis
with positions 𝑥� and 𝑥�. The center of mass of this system is
𝑥�� = [𝑥][�][𝑚]𝑚[�]� [+ 𝑥]+ 𝑚[�]�[𝑚][�] = [𝑥][�][𝑚][�] 𝑀[+ 𝑥][�][𝑚][�]. (114-5)

For reasons that will become clear in a bit, I also want to rewrite this equation with quantities related to the entire system (𝑀
and 𝑥��) on one side of the equation and all terms related to individual particles on the other side of the equation:

𝑀𝑥�� = 𝑥�𝑚� + 𝑥�𝑚�. (114-6)

The gravitational interaction between the two bodies will cause the bodies to move towards each other (unless there is
another interaction to stop this). We can find a relationship between the motion of the center of mass of the system and the
motion of each particle by taking the derivative with respect to time of Equation 114-6, giving us

𝑀 [𝑑𝑥]𝑑𝑡[��] = 𝑚� 𝑑𝑥𝑑𝑡� [+ 𝑚][�] 𝑑𝑥𝑑𝑡�[.] (114-7)

Since 𝑑𝑥𝑑𝑡⁄ is a velocity (in one-dimension) we can replace each derivative in this equation with velocities, leading to

𝑀𝑣�� = 𝑚�𝑣� + 𝑚�𝑣�. (114-8)


-----

Over time, each of these velocities would change (just as a ball speeds up towards the earth when you drop it); therefore, we
can assign initial and final velocities to each of the terms

𝑀𝑣��,� = 𝑚�𝑣�� + 𝑚�𝑣��,

(114-9)

𝑀𝑣��,� = 𝑚�𝑣�� + 𝑚�𝑣��,

and we can find the differences between two times by subtracting the initial equation from the final equation:

𝑀(𝑣��,� −𝑣��,�) = 𝑚��𝑣�� −𝑣���+ 𝑚��𝑣�� −𝑣���. (114-10)

Simplifying, we get
𝑀∆𝑣�� = 𝑚�∆𝑣� + 𝑚�∆𝑣�. (114-11)

Ok, we’ve done some mathematical manipulation starting with the equation for the center of mass to get to Equation 114-11,
but let’s remember the situation: we have two bodies interacting via gravity and this interaction changes their motion.
However, since this integration is only between the two bodies, the _system of the two bodies does not interact with the_
environment. Remembering that a system can be treated as if it is entirely at its center of mass, this means that if there is not
external interaction with the system there should be no change in motion of the system, i.e., ∆𝑣�� = 0. This allows us to
simplify Equation 114-11 to
0 = 𝑚�∆𝑣� + 𝑚�∆𝑣�. (114-12)

Equation 114-12 brings up two important points:

1) The quantity 𝑚∆𝑣 is very important when discussing changes in motion.
2) The sum of this quantity is conserved, meaning that for an isolated system, it does not change.

In classical mechanics, we define the quantity 𝑚𝑣 as momentum and give it the symbol 𝑝. For simplicity, the description
above was done along a straight line on the x-axis. However, the same argument could be made for vector velocities, as
opposed to velocities on an axis. Therefore, the momentum of a particle is a vector, which is defined as

𝑝⃗= 𝑚𝑣⃗. (114-13)

The above discussion is for classical momentum. In reality, the momentum of a particle increases faster than Equation 11412 as its speed increases. Just as with kinetic energy in Unit 103, we must add the Lorentz factor to make this fit with the
special theory of relativity,
𝑝⃗= 𝛾𝑚𝑣⃗. (114-14)

Unfortunately, a discussion of the derivation of the relativistic momentum formula is beyond the scope of this course.
However, I will say that it has been tested to very high accuracy in high-energy particle accelerators.


**Momentum of a Particle**

𝒑��⃗= 𝜸𝒎𝒗��⃗

**Description – This equation defines the momentum, 𝑝⃗, of a**

particle in terms of the Lorentz factor, 𝛾, and the particle’s
mass, 𝑚, and velocity, 𝑣⃗.
**Note 1: In the classical limit the momentum of a particle is 𝑝⃗=**

𝑚𝑣⃗
**Note 2: The SI units of momentum is 𝑘𝑔∙𝑚𝑠⁄ .**


The second important idea that arises from Equation 114-12 is that there is no change in the total momentum of the
system, which is to say that the change in momentum of all particles adds to zero. This can more easily be seen if we rewrite
Equation 114-12 in terms of momentum:
0 = ∆𝑝� + ∆𝑝�. (114-15)


-----

Again, we can extend this argument to any dimension, making it a vector relationship.
Since the change in momentum of the system is zero, we say the momentum is conserved, which is written
mathcmatically as

∆𝑝⃗��� = 0, (114-16)

where ∆𝑝⃗��� = ∆𝑝⃗� + ∆𝑝⃗� + ⋯.


**Conservation of Momentum**

𝚫𝒑��⃗𝒔𝒚𝒔 = 𝟎

**Description – This equation states that the total momentum of an**

isolated system does not change.
**Note: If the system is not isolated, the total change in momentum**

is related to the external force and the time over which it acts
by the impulse-momentum relationship, ∆𝑝⃗��� = 𝐹[⃗]���∆𝑡.


Although we are now prepared to look at the conservation of momentum for simple systems, Units 115 and 116 are dedicated
to collisions and explosions where the conservation of momentum is key.


Example 114 - 3 **Classical (vector) momentum**

What is the magnitude of the momentum of a 112-kg cart
moving with a velocity 𝑣⃗= [24,0,12] 𝑚𝑠⁄ .

**Solution:**

We can find the (classical vector) momentum of the cart using
the definition


We can then find the magnitude using the Pythagorean
theorem as

|𝑝⃗| = �(2688)[�] + (0)[�] + (1344)[�] 𝑘𝑔∙𝑚𝑠⁄ .

Simplifying this expression, we find

|𝑝⃗| = 3000 𝑘𝑔∙𝑚𝑠⁄ .


2688

0
1344


� 𝑘𝑔∙𝑚𝑠⁄ .


𝑝⃗= 𝑚𝑣⃗= (112 𝑘𝑔) �


24

0
12


� 𝑚𝑠⁄ = �


Example 114 - 4 **Relativistic momentum**

What is the magnitude of the momentum of a 12,200-kg
spaceship traveling at 92% the speed of light?

**Solution:**

We can assume that the spaceship is moving along one axis
(call it the x-axis), then, this problem asks us to calculate the
relativistic momentum along that axis. Starting with the
general equation for momentum, we find


𝑝� = (2.55)(12,200 𝑘𝑔)(0.92𝑐).

We could report this result in terms of the speed of light,
c, or use the value of c to find a direct answer. In each
case, we get

𝑝� = 2.9𝑥10[�]𝑐 𝑘𝑔∙𝑚𝑠⁄

or

𝑝� = 8.6𝑥10[��] 𝑘𝑔∙𝑚𝑠⁄ .

Note that, unlike velocity, the relativistic momentum
does not have a limit since it includes the rest mass of the
object in question.


𝑝� = 𝛾𝑚𝑣� =

which reduces to


1
⎛ ⎞(12,200 𝑘𝑔)(0.92𝑐),

�1 − [(0.92𝑐)][�]�

⎝ 𝑐[�]⎠


-----

#### 114.3 – Impulse, force and momentum

**Consider: What is an impulse and how does it change motion?**

Mechanical interactions change momentum. Consider a force (remember, a force is a result on one side of an interaction)
acting over a period of time on an object – say you push on box on very slick ice. The more you push on the box, the faster
the box will go. Another way to say this is as the longer a force acts on an object, the greater its change in momentum will
be. Mathematically, keeping in mind that force is a vector, this can be written

𝐽[⃗] ≡𝐹[⃗]���∆𝑡, (114-17)

where 𝐽[⃗] is called the impulse on the system. Note that the impulse technically measures the effect of a single force on an object over time,
and not the net effect of a number of forces. Equation 114-17 is written in terms of an average force, however, we can generalize this to
any force by thinking about the how a force (even a time varying force) will add to the impulse of a system in very small increments of
time, i.e., as an integral:

𝐽[⃗] ≡�𝐹[⃗]𝑑𝑡. (114-18)

We can find the units of impulse by looking at the units of force and time that make compose it as

�𝐽[⃗]�= [𝐹][𝑡] = 𝑁𝑠= �𝑘𝑔 [𝑚] (114-19)

𝑠[�][�(𝑠) = 𝑘𝑔𝑚]𝑠 [.]

Note that the units are the same units as momentum! In fact, this is a very important point because

**impulse is a measure of a single force’s impact on the change in momentum of an object, and**

**the net impulse on an object is equal to the change in momentum of the object.**

The net impulse on an object is the vector sum of all of the impulses acting on an object. We can put these ideas together
into a single mathematical expression, which allows us to both find the impulse due to a force and relate it to the change in
momentum of the object (due to that single force) as

𝐽[⃗] ≡�𝐹[⃗]𝑑𝑡= ∆𝑝⃗. (114-20)

This is known as the impulse-momentum relationship.


**Impulse-Momentum Relationship**

𝑱[⃗] = 𝚫𝒑��⃗

**Description – This equation relates the impulse imparted to an**

object, 𝐽[⃗], to the object’s change in momentum, ∆𝑝⃗.
**Note 1: Impulse is defined as the integral of force with respect to**

time or the average force multiplied by time: 𝐽[⃗] ≡∫𝐹[⃗]𝑑𝑡=
𝐹[⃗]���∆𝑡
**Note 2: In practice, we often use the definition of impulse to**

directly relate to change in momentum as 𝐹[⃗]���∆𝑡= ∆𝑝⃗.


There is quite a bit of physics wrapped up in the impulse-momentum relationship. We will see how it allows us to determine
the change of momentum of a system when the entire system has an external force, and, below, how it is directly related to
Newton’s 2[nd] Law.


-----

Example 114 - 5 **Impulse and change in velocity**

An average force of 20.0 N acts on a 9.8-kg block for 2.2
seconds. What are (a) the impulse imparted to the block
during this time, (b) the change in momentum of the block
during this time and (c) the magnitude of the change in
velocity of the object during this time?

**Solution:**

This problem asks us to use the impulse-momentum
relationship and what we know about momentum to find
impulse, change in momentum and change in velocity.

(a) We know that if an average force acts on an object for a
given time, the relationship is

𝐽[⃗] ≈𝐹[⃗]���∆𝑡.


Since we have a single force, we can assume that all quantities
in this problem act along the line of that force and neglect the
vector form. So, this gives us an impulse of

𝐽= 𝐹���∆𝑡= (20.0 𝑁)(2.2 𝑠) = 44 𝑁.

(b) The impulse-momentum relationship tells us that the
impulse imparted to an object is equal to its change in
momentum, therefore

∆𝑝= 𝐽= 𝐹���∆𝑡= 44 𝑁.

(c) For this part, we use the relationship between
momentum and velocity to find

∆𝑣= [∆𝑝] [44 𝑁]

𝑚 [=] 9.8 𝑘𝑔 [= 4.5 𝑚]𝑠 [.]


Equation 114-20 shows how a large number of small impulses on an object leads to the change in momentum of the
object. We can also consider what happens for only one of the small pieces of impuse, 𝐹[⃗]𝑑𝑡. In this case, the impulse will not be
related to the overall change in momentum of the object, but just a small change in momentum, d𝑝⃗,

𝐹[⃗]𝑑𝑡= d𝑝⃗. (114-21)

Rearranging this equation to solve for the force, we get

𝐹[⃗] = [d𝑝⃗] (114-22)

𝑑𝑡 [.]

Equation 114-22 is known as the force-momentum relationship, which also happens to be Newton’s 2[nd] law!! We can find
the more familiar form of Newton’s 2[nd] law by considering what happens if the mass of an object is constant. In this case, the
mass can be removed from the derivative

𝐹[⃗] = [d𝑝⃗] = 𝑚 [d𝑣⃗] (114-22)

𝑑𝑡 [= d(𝑚𝑣⃗)]𝑑𝑡 𝑑𝑡 [= 𝑚𝑎⃗,]

where I have used the fact that the time rate of change of velocity is acceleration. We use explore the use of Newton’s 2[nd]
law in this form in Units 119-129.


**Force-Momentum Relationship**

𝐅[⃗]𝐧𝐞𝐭 = [𝒅𝒑��⃗]𝒅𝒕

**Description – The force-momentum relationship (Newton’s 2[nd]**

law) tells us that the net force on an object, F[�⃗], is equal to the
rate of change of momentum with respect to time 𝑑𝑝⃗𝑑𝑡⁄ .
**Note: This equation can also be used to find the change in**

momentum that would be caused by an individual force in the
absence of other forces.


-----

Example 114 - 6 **Force from change in momentum**

A 1.9-kg object’s velocity changes from 1.2 m/s north to 2.5
m/s east in 1.9 seconds. What is the average net force that
acted on the object during this time?

**Solution:**

This problem asks us to find the net force on an object given a
change in velocity (change in momentum).

First, we can use the vector form to find the change in
velocity assuming east is along the x-axis and north is along
the y-axis


1 4.75 𝑁

F[�⃗]��� = [𝑑𝑝⃗]𝑑𝑡 [≈∆𝑝⃗]∆𝑡 [=] 1.9 𝑠 [�]−2.28 𝑁 �.

0


∆𝑝= 𝑚∆𝑣= (1.9 𝑘𝑔) �


2.5 𝑘𝑔∙𝑚𝑠⁄
−1.2 𝑘𝑔∙𝑚𝑠⁄
0


�,


or


∆𝑝= �


4.75 𝑘𝑔∙𝑚𝑠⁄
−2.28 𝑘𝑔∙𝑚𝑠⁄
0


�.


The average net force is then


2.5 𝑁
1.9 𝑁

0


Simplifying, we find


∆𝑣= 𝑣� −𝑣� = �


2.5 𝑚𝑠⁄
0
0


�−�


0
1.2 𝑚𝑠⁄
0


�= �


2.5 𝑚𝑠⁄
−1.2 𝑚𝑠⁄
0


�


This gives us a change in momentum of


F[�⃗]��� = �


�.


-----

-----

