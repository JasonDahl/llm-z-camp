### – Elasticity
## 130


_Early in the course, we described how interactions change something about objects in a system. We have explored how_
_interactions can change momentum, temperature and relative positions. In this Unit, we explore one way in which_
_interactions can change the shape of an object. The term elasticity is used as a measure of how deformable an object is_
_under stress. This Unit is important background for our discussion of earthquakes in Physics II._


##### The Bare Essentials

- **_Stress is a measure of force per unit area placed on a solid_**

object.

- **_Strain (while under stress) is the ratio of deformation to initial_**

length, ∆𝐿/𝐿�.

- When real solid objects are placed under stress, they deform

or change their shape.

- Tensile or compressive stresses change the length of materials.

For small deformations, these stresses obey Hooke’s law.


**Description – This equation relates the initial length of an object,**

𝐿�, to the change in position of one end of the object relative to
the other, ∆𝑥, perpendicular to the length, while under a shear
force, 𝐹 (which is perpendicular to the length as well). 𝐴 is the
cross-sectional area of the object parallel to the force, and 𝐺 is
the shear modulus of the material.



- **_Shear stresses change the shape of the material by bending_**

them. The shear modulus (𝐺) is the ratio of shear stress to
shear strain


**Shear Deformation**


𝚫𝒙= [𝟏]

𝑮


𝑭
𝑨 [𝑳][𝟎]


**Effective Hooke’s Law**
**(Tension/Compression)**

�𝑭[��⃗]𝑻�= 𝒌𝒆𝚫𝑳

**Description – Hooke’s law for tension and compression relates**

the magnitude of a force place on an object to the change in
length of the object. 𝑘� is the effective spring constant.



- The bulk modulus (𝐾) measures a substances resistance to

uniform compression. It is the ratio of volume stress to
volume strain (change in volume).



- **_Tensile stresses change the length of an object along one axis._**

**_Young’s modulus (𝑌) is the ratio of tensile strength to tensile_**
strain along this axis for a given material.


**Bulk (Volume) Deformation**


𝚫𝑽= [𝟏]

𝑲


𝑭
𝑨 [𝑽][𝟎]


**Tensile and Compression Deformation**


**Description – This equation relates the change in volume, ∆𝑉, to**

the initial volume of an object, 𝑉�, while under a force per unit
area 𝐹𝐴⁄, acting on the object from all sides. 𝐾 is the bulk
modulus of the material.


𝚫𝑳= [𝟏]

𝒀


𝑭
𝑨 [𝑳][𝟎]


**Description – This equation relates the change in length along one**

axis of an object, ∆𝐿, to the objects unstressed length, 𝐿�, the
force on the object, 𝐹, and the cross-sectional area of the
object, 𝐴 and the Young’s modulus of the material, 𝑌.
**Note: The effective spring constant for tensile stress is 𝑘�** =

𝑌𝐴/𝐿�.


-----

#### 130.1 – Mechanical Stress, Pressure and Strain

**Consider: How do forces change the shape of objects?**

N OUR STUDY OF FORCES SO FAR, we have focused on how forces can
affect a change in motion of an object or set of objects.  We haven’t yet
considered what happens to a real object when a set of offsetting forces act it,

# I

but its motion does not changes. Sure, we studied such statics problems in Unit
127, but only in the guise of what forces and torques are needed to keep the object
stationary without translation or rotation.
Consider a small, squishy ball, like the stress ball shown in Figure 130-1.
When you grab a stress ball and squeeze it, but keep your arm stationary, the force
you apply while squeezing the ball does not change its motion, but rather, you
change its _shape. Such a change in shape due to outside forces is called_
**_deformation. The deformation that occurs in the stress ball is extremely_** **Figure 130-1. A stress ball.**
complicated because the force you apply to ball varies across its surface leading to
vary non-symmetric change in shape. In this unit, we will describe how forces can change the shape of an object in more
straightforward ways – by changing an objects length, bending the object, or symmetrically changing an object’s volume.
However, before we get into these details, we first need to provide a few definitions.

Figure 130-2 shows what happens if two stress balls, like the one in Figure 130-1,
are pushed together slightly. The area over which the two balls are in contact with each
other will form a flat circle between them, which is shows in the Figure. The large
arrow represents the force that the bottom ball exerts on the top ball.
However, this force is actually spread, almost evenly over the surface contact area
of the balls. The stress is the force divided by the area of over which the force acts,


**Figure 130-2. Definition of**
**stress between two stress balls.**


𝑇[�⃗] = [𝐹⃗] (130-1)

𝐴[,]

where 𝑇[�⃗] is the stress, 𝐹[⃗] is the force between the surface and A is the area of contact
between the surfaces. I should note that I’m making a rather bad simplification here.
Technically, stress is a tensor quantity, that is a geometric quantity that can relate two
vectors in a more complicated way than we have considered so far in Physics. Writing
stress as a vector as in Equation 130-1, although not technically correct, will allow us to
explore its basic properties at the introductory level. I should also note that in writing
Equation 130-1, I have assumed that the stress over the entire area is constant. In
reality, we should define the stress at each point separately and write


𝑇[�⃗] = [𝑑𝐹⃗] (130-2)

𝑑𝐴[,]

The units of stress are Newtons per square meter (𝑁𝑚⁄ [�]). This unit is also called the **_Pascal (Pa) after scientist and_**
mathematician Blaise Pascal. As we will later see, because of its magnitude, stress is often reported in gigapascals (GPa):

1 𝑃𝑎= 1 𝑁𝑚⁄ [�] 1𝐺𝑃𝑎= 10[�]𝑃𝑎.

Consider again Figure 130-2, and note that the force (and therefore stress) acts at an angle relative to the surface between
the balls. We can decompose the stress into two components; the normal stress (compression or tension) is the component
perpendicular to the surface, where the shear stress is the component parallel to the surface. We will consider each of these
stresses in tern in the Sections ahead.

Pressure

**_Pressure in physics and engineering is a quantity closely related to stress. Pressure is actually a special case of stress – it_**
is defined as the magnitude of the normal force divided by the area over which the force acts,

𝑃= [𝑑�𝐹⃗][�][�] (130-3)

𝑑𝐴 [,]


-----

where P is the pressure, 𝑑�𝐹[⃗]�� is the magnitude of a tiny piece of the normal force acting over a tiny area, 𝑑𝐴. If we assume
the pressure is constant over an area, this can be written as simply 𝑃= 𝐹�/𝐴. Pressure is used in numerous ways in physics,
including

1) The pressure a gas exerts on the container in which it is contained,
2) The pressure exerted by a normal force between two surfaces
3) Pressure differences in fluids leading the fluid to move.

We will explore pressure a bit more in Physics II when we discuss fluids. For now, it is important to note that pressure (as a
special case of stress) has the same units of stress, Pa, and that pressure is often used in a macroscopic sense, where stress is
used when discussing the deformations.

Strain

When an object is placed under stress, the deformation is often measured in terms of strain, which is the ratio of change of
shape to the original shape. This change can be either linear (tensile or shear stress) or volumetric (bulk stress). Therefore,
strain, 𝜖,can be written


𝜖= [∆𝐿]

𝐿�


𝑜𝑟        𝜖= [∆𝑉]

𝑉�


,


where the first strain is the ratio of a change in length, ∆𝐿 to original length, 𝐿� and the second strain is the ratio of the change
in volume ∆𝑉 to the original volume, 𝑉�. Note that as a ratio of similar quantities, strain is unitless.

Stress-Strain Relationships

Our goal in the rest of this Unit is to find relationships between stress and strain for three changes in shape: linear changes in
length, bending, and changes in volume. Each of these will take on the general form

𝑠𝑡𝑟𝑒𝑠𝑠= 𝜂× 𝑠𝑡𝑟𝑎𝑖𝑛,

where 𝜂 is a material-dependent proportionality constant known as a modulus. Based on our three changes in shape, we will
find three types of moduli: Young’s modulus (changes in length), shear modulus (bending) and bulk modulus (changes in
volume). Representative values of all moduli can be found in Table 130-1 at the end of the Unit.


Example 130 - 1 **A quick pressure problem**

A cubic box with sides 1.3 m on each side has a mass of 24.2
kg. What is the pressure that the box exerts on the ground
assuming it is sitting stationary on a flat, horizontal surface?

**Solution:**

This problem is a direct application of pressure.  In order to
find the pressure, we first need the normal force between the


bottom of the box and the ground. Since we have a flat
horizontal surface with only the normal force and the
gravitational force, this is the situation where 𝐹� = 𝐹�.
Therefore, the normal force is 𝐹� = 𝑚𝑔= 237 𝑁. Using
the definition of pressure, we find

𝑃= [𝐹][�] [237 𝑁]

𝐴 [=] (1.3 𝑚)[�] [= 140 𝑃𝑎.]


#### 130.2 – Normal stress

**Consider: What does it take to stretch metal?**

In Unit 129, we used Hooke’s law to relate the force on a spring to the extension of the spring. In reality, Hooke’s law is
valid over a region in which the spring can be compressed of stretched, but yet will still return to its original shape when the
external force is removed. In addition, in Unit 107 we spent some time on how atomic bonds behave similar to springs in
many ways. Now, consider a metal bar with length 𝑙. Imagine placing one end of the bar up against a wall or similar
immovable object. If we were to then push on the other end of the bar with some force, that force would act on all the atomic
bonds in the bar, causing each to compress. In this way, the entire bar will shorten, and if we remove the external force, the


-----

bar will return to its initial length. Since this process exactly resembles what happens with springs, we can define a Hooke’s
law for this compress (or similar extension) effects

�𝐹[⃗]��= 𝑘�∆𝐿, (130-4)

where 𝐹[⃗]� is a tensile (extension) or compression force, 𝑘� is an effective spring constant for the effect and ∆𝐿 is the change in
length of the object.


**Effective Hooke’s Law**
**(Tension/Compression)**

�𝑭[��⃗]𝑻�= 𝒌𝒆𝚫𝑳

**Description – Hooke’s law for tension and compression**

relates the magnitude of a force place on an object to the
change in length of the object. 𝑘� is the effective spring
constant.


Figure 130-2 shows a **_stress-strain diagram for a typical (metallic) material._**
Note that on the left side of this graph, there is a linear section that rises from the
origin up until a curved region. This linear region is the region over which our
generalize Hooke’s law works well when approximating how materials respond to
normal stress. This region is called the elastic region.
Above the elastic region is a curved region where the response of a material to
stress is much more complicated, and can even have a negative slope for some
materials.  This is called the plastic region. The point at the end of the plot is the
**_point of fracture and represents where the material would split it two or more_**
pieces (fracture) under stress.
For linear tension and compression forces, the modulus relating stress and
strain is known as Young’s modulus, 𝑌. Young’s modulus is the slope of the
elastic portion of a stress-strain diagram. Noting that tension and compression tend
to change the length of material along one axis, we can write the general stressstrain relationship (in the elastic region) as

𝐹
𝑠𝑡𝑟𝑒𝑠𝑠= 𝑌× 𝑠𝑡𝑟𝑎𝑖𝑛 →
𝐴 [= 𝑌∆L]L�

which can be rewritten in terms of the change in length as


**Figure 130-3. Generic stress-strain**
**diagram.**

, (130-5)


∆𝐿= [1]

𝑌


𝐹
(130-6)
𝐴 [𝐿][�][.]


Materials with a large Young’s modulus are said to have a large tensile strength. Materials with a large tensile strength tend
to deform less when placed under normal forces (tension or compression). Please note that this equation deals with the
magnitudes of forces and lengths; you must know how the force is acting on the object to determine in the change in length is
a compression or extension. Figure 130-4 depicts how a normal force can change the length of an object.

**Figure 130-4. Change in length due to normal stress.**


-----

**Tensile and Compression Deformation**


𝚫𝑳= [𝟏]

𝒀


𝑭
𝑨 [𝑳][𝟎]


**Description – This equation relates the change in length**

along one axis of an object, ∆𝐿, to the objects unstressed
length, 𝐿�, the force on the object, 𝐹, and the crosssectional area of the object, 𝐴 and the Young’s modulus
of the material, 𝑌.
**Note: The effective spring constant for tensile stress is 𝑘�** =

𝑌𝐴/𝐿�.


Example 130 - 2 **Steel cable**

A steel cable spans the a 129 m gap between two buildings.
The maximum tension that the cable can support is 2.99 ×
10[�] 𝑁. What is the maximum length that this cable can
stretch before snapping? The radius of the cable is 0.054 m.

**Solution:**

This problem is a direct application of tensile strength. We
can first calculate the cross-sectional area of the cable as

𝐴= 𝜋𝑟[�] = 𝜋(0.054𝑚)[�] = 0.00916 𝑚[�].

We can now use own known values (including Young’s


which gives us

∆𝐿= 0.200 𝑚.

Therefore, the cable can only stretch 20 cm before
snapping, which makes sense because this is not a very
long span and it is made of steel.


modulus for steel) to find


∆𝐿= [1]

𝑌


𝐹 1
𝐴 [𝐿][�] [= �]

210𝑥10[�] [𝑁]

𝑚[�]


��[2.99 × 10][�][ 𝑁]

0.00916 𝑚[�] [�(129𝑚).]


#### 130.3 – Shear stress

**Consider: What does it take to bend steel like Superman?**

Figure 130-5 depicts a **_shear stress acting on a object of length_** 𝐿�. Note
that the force causing the shear stress acts perpendicular to the length of a
object and causes a deformation, ∆𝑥, which is also perpendicular to the
length of the object. In this case, our general stress-strain relationship
becomes

𝐹
𝑠𝑡𝑟𝑒𝑠𝑠= 𝐺× 𝑠𝑡𝑟𝑎𝑖𝑛 →, (130-7)
𝐴 [= 𝐺∆x]L�

where 𝐺 is the shear modulus. Rewriting this in terms of the deformation,
∆𝑥, we find


∆𝑥= [1]

𝐺


𝐹
(130-8)
𝐴 [𝐿][�][.]


**Figure 130-5. Change in shape due to shear**
**stress.**

Shear stresses are very important in the human body. For example,
bones do not tend to break under normal stress. Yes, bones do shorten and lengthen slightly based on the tensile and
compressive forces placed on them; however, the fracture point for these stresses is very high. In comparison, the fracture
point for shear stresses are much lower, meaning that our bones have much less resistance to the bending motion created by
shearing stress. The same effect also causes back pain in obese people and pregnant women – increased weight in the front
of the body causes people to push their shoulders back to maintain balance, thereby putting shear stresses on the spine. With
a very low shear modulus, the spine bends and winds up out of alignment with the rest of the body.


-----

**Shear Deformation**


𝚫𝒙= [𝟏]

𝑮


𝑭
𝑨 [𝑳][𝟎]


**Description – This equation relates the initial length of an object,**

𝐿�, to the change in position of one end of the object relative to
the other, ∆𝑥, perpendicular to the length, while under a shear
force, 𝐹 (which is perpendicular to the length as well). 𝐴 is the
cross-sectional area of the object parallel to the force, and 𝐺 is
the shear modulus of the material.


Example 130 - 3 **Hanging a picture on a nail**

Imagine that a steel nail with body diameter of 1.25 mm is
hammered into a wall so that the head extends 4 mm from the
wall. By how much will the nail bend downward if a 7.7 kg
picture is hung from the end?

**Solution:**

This is a direct application of shear stress and strain.


The weight of the picture, which is the force
perpendicular to the length of the nail coming from the
wall, is

𝐹� = 𝑚𝑔= (7.7 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ) = 75.5 𝑁.

We can now use all this information, along with the shear
modulus of steel from Table 130-1 to find


𝐹

∆𝑥= [1]

𝐺 𝐴 [𝐿][�][.]


∆𝑥= [1]

𝐺


𝐹 1
𝐴 [𝐿][�] [=] 80𝑥10[�]𝑃𝑎


75.5 𝑁
1.23𝑥10[��]𝑚 [0.004𝑚,]


Therefore, in order to find the deformation perpendicular to
the length of the nail, we need to find the weight of the picture
and the cross-sectional area of the nail.

We can first find the cross-sectional area of the nail as


which simplifies to

∆𝑥= 3.07𝑥10[��] 𝑚.

Note that this is an extremely small deflection, which is
why a steel nail of this size would be ideal to hang the
proposed picture.


= 𝜋�[0.00125𝑚]�

2


𝐴= 𝜋𝑟[�] = 𝜋�[𝑑]

2[�]


�


�


= 1.23𝑥10[��]𝑚


#### 130.4 – Volume stress

**Consider: Can we change the volume of a hunk of metal?**

Finally, Figure 130-6 shows the contraction of a volume when a
normal stress impinges evenly from all directions. Please note that this
is a very symmetric contraction and occurs from all sides. As we will
see in Physics II, this type of deformation will occur when an object is
placed in a fluid with a given pressure because that pressure will be
exerted inward from all sides on the body.
For this situation, we must use the volume strain as opposed to the
linear strain used in the last two sections. Using analogies to what we
have seen before, the stress-strain relationship can be written


𝐹
𝑠𝑡𝑟𝑒𝑠𝑠= 𝐾× 𝑠𝑡𝑟𝑎𝑖𝑛 →, (130-9)
𝐴 [= 𝐾∆V]V�


where 𝐾 is the **_bulk modulus. Rewriting this in terms of the_**
deformation, ∆𝑉, we find


**Figure 130-6. Change in volume due to**
**symmetric normal stresses.**


-----

∆𝑉= [1]

𝐾


𝐹
(130-10)
𝐴 [𝑉][�][.]


**Bulk (Volume) Deformation**


𝚫𝑽= [𝟏]

𝑲


𝑭
𝑨 [𝑽][𝟎]


**Description – This equation relates the change in volume, ∆𝑉, to**

the initial volume of an object, 𝑉�, while under a force per unit
area 𝐹𝐴⁄, acting on the object from all sides. 𝐾 is the bulk
modulus of the material.


Example 130 - 4 **Compressing metal**

How much will a cube of aluminum with sides 0.54 m
compress if a force of 3.4𝑥10[�] 𝑁 is applied evenly to all
sides?

**Solution:**

This is a direct application of the volume deformation
relationships


∆𝑉= [𝐹𝑙]

𝐾 [=]


equation can be reduced to

∆𝑉= [1]

𝐾


𝐹
𝑙[�] [𝑙][�] [= 𝐹𝑙]𝐾 [,]


which gives us


(3.4𝑥10[�] 𝑁)(0.54𝑚)

= 2.45𝑥10[��]𝑚[�],
75𝑥10[�] 𝑃𝑎


∆𝑉= [1]

𝐾


𝐹
𝐴 [𝑉][�]


Knowing that the area of a side of a cube is given by 𝑙[�] and
the volume of the cube can be written as 𝑙[�], our


which is the same as 2.9 cm on a side. This may seem
like a large deformation, but keep in mind that we have a
very large force.


**Table 130-1. Young’s modulus, shear modulus and bulk modulus for some materials.**
**All moduli are given in GPa (10[9] N/m[2])**

|Table 130-1. Young’s modulus, shear modulus and bulk modulus for some materials.  All moduli are given in GPa (109 N/m2)|Col2|Col3|
|---|---|---|
|Young’s Shear Bulk Material Modulus (Y) Modulus (G) Modulus (K)|||
|Aluminum 70 25 75|||
|Bone – tension 16 80 8|||
|Bone - compression 9 -- --|||
|Brass 90 35 75|||
|Brick 15 -- --|||
|Concrete 20 -- --|||
|Glass 70 20 30|||
|Granite 45 20 45|||
|Human hair 10 -- --|||
|Iron 100 40 90|||
|Lead 16 5 50|||
|Silk 6 -- --|||
|Steel 210 80 130|||
|Acetone -- -- 0.7|||
|Mercury -- -- 25|||
|Water --|--|2.2|


-----

-----

