## – The two (three) main principles
# 104


_Unit 104 gives an overview of the two major principles developed in this book as well as a glimpse at the ‘Laws’ that_
_come about as a result of these principles. The three ideas presented in this unit are so pervasive that they give us a_
_roadmap for much of physics. This unit is very much about introducing terminology that will be important throughout_
_the semester. You must become familiar with the definitions (both words and equations) described in this unit._

#### Integration of Ideas

      - The concept of interactions from Unit 102.

#### The Bare Essentials

- **_Energy is a fundamental quantity that particles can possess._**

The energy of a particle can be made up of three types of **Conservation of Momentum (Isolated System)**
energy, rest-mass energy, kinetic energy, and potential
**_energy. The total energy of a particle is the sum of each of_** 𝚫𝒑��⃗= 𝟎
these energies. Note: equation boxes for rest-mass, kinetic
_and total energy are presented in the text, but not in the Bare_ **Description – The conservation of momentum states that**
_Essentials._ the total momentum contained in an isolated system

does not change.

- For an isolated system, the total energy of the system (the sum **Note: An isolated system is defined as a system that does**

of the energies of all the particles in the system) does not not interact with its surroundings.
change.


**Conservation of Energy (Isolated System)**

𝚫𝑬= 𝟎

**Description – The conservation of energy states that the**

total energy contained in an isolated system does not
change.
**Note: An isolated system is defined as a system that does**

not interact with its surroundings.



- **_Newton’s Laws, built on the above fundamental principles,_**

gives us valuable techniques to solve physics problems

 - **_Newton’s 1[st] Law states that the velocity of a particle does_**
not change when it is not undergoing any interactions.
 - **_Newton’s 2[nd] Law states that the net force on an object (due_**
to all its interactions) is equal to the rate of change of its
momentum
 - **_Newton’s 3[rd] Law states that a single force on an object_**
(object 1) is due to its interaction with another object
(object 2), the force on object 2 is equal in magnitude and
in the opposite direction to the force on object 1.



- The transfer of energy into or out of a system can take

multiple forms:

- **Heat – transfer of energy due to differences in temperature**
- **Thermodynamic work – transfer of energy due to**
mechanical and microscopic interactions (but not
temperature differences).
- **Mechanical work – transfer of energy related to mechanical**
interactions. (Subset of thermodynamic work)

- The momentum of an individual particle is given by 𝑝⃗=

𝛾𝑚𝑣⃗, where 𝛾 is the Lorentz factor, 𝑚 is the mass of the
particle and 𝑣⃗ is the velocity of the particle.

- For an isolated system the total momentum of the system does

not change.


**Note: The conservation laws for energy and momentum deal**
with entire systems, where Newton’s laws hold for individual
particles!


**Newton’s Second Law**

𝐅[⃗]𝐧𝐞𝐭 = [𝒅𝒑��⃗]𝒅𝒕

**Description – The equation relates the net force on an**

object, F[�⃗]���, to the rate of change of the object’s
momentum, 𝑑𝑝⃗𝑑𝑡⁄ .
**Note: When the mass of an object moving at non-relativistic**

speeds is constant, 𝑑𝑝⃗𝑑𝑡⁄ reduces to 𝑚𝑎⃗.


-----

### 104-1. The major principles

**Consider: What are the major principles we will explore in this**
course?

For many students who have studied physics in the past, physics means forces and Newton’s laws. Although there are many
situations where forces are used to describe interactions, it is important to understand that forces are the result of changes in
more fundamental quantities – namely energy and momentum. Momentum and energy are very powerful notions because
they adhere to conservation laws. That is to say, for any object where we can define a system that includes any other objects
it interacts with, the total amount of energy and momentum in the system do not change. The energy and momentum may be
transferred between objects in our system, but the total remains constant.
Unfortunately, it is hard to precisely define energy and momentum because they are so fundamental. In a sense, they just
_are. In the next two subsections, I will try to give an overall flavor for these concepts._
For professional physicists, there is beauty in the three principles and laws that we will discuss in this unit. Just about
every problem and idea presented in the remainder of this book (including Volume II) can be categorized into one of the
ideas presented below. It can be very difficult for students first learning physics to see the simplicity that lies with all of
classical physics being reduced to just a few fundamental ideas. Uniquely, in this book, I confront this issue by introducing
these three principles together at the beginning of the text. I ask that you keep this in mind as we progress through the rest of
the year and that you work to place each concept and problem into one of the categories presented below. This will help you
develop a more sophisticated conceptual view of physics.

### 104-2. The conservation of energy

**Consider: What is the conservation of energy?**

Energy comes in three basic forms:

1) **_Rest-mass energy – energy contained in a mass_**
2) **_Kinetic energy – energy of motion,_**
3) **_Potential energy – energy of position – also called stored energy._**

**Rest-mass energy**

Mass is one way to store energy within an object. This principle was proposed by Albert Einstein when developing the
special theory of relativity in the early 20[th] century. He used what is probably the most famous equation in all of physics:

𝐸� = 𝑚𝑐[�], (104-1)

where 𝐸� is the rest-mass energy, 𝑚 is the mass of the object and 𝑐 is the speed of light in a vacuum (𝑐= 3.00 𝑥 10[�] 𝑚/𝑠).
This equation relates the energy stored within an object to its mass.


**Rest-energy of an Object**

𝐸� = 𝑚𝑐[�]

**Description – This equation describes the energy, 𝐸�, contained in an**

object with mass, 𝑚. 𝑐 is the speed of light in a vacuum.
**Note 1: 𝑐= 3 𝑥 10[�] 𝑚/𝑠.**
**Note 2: The SI unit for energy is the Joule (𝐽) [1 𝐽= 1 𝑘𝑔⋅𝑚[�]⁄𝑠[�]].**
**Note 3: Another important unit of energy is the electron-volt, where**

1 𝑒𝑉= 1.6 𝑥10[���] 𝐽.


-----

Example 104 - 1 **What energy?**

What rest-mass energy is stored in a 1-kg steel ball?

**Solution:**

This problem is a direct application of the rest-mass energy
equation. In order to solve this, we directly substitute our
known mass into the rest-mass energy equation:

𝐸� = 𝑚𝑐[�] = (1 𝑘𝑔)(3𝑥10[�] 𝑚𝑠⁄ )[�],


which gives us

𝐸� = 9 𝑥 10[��] 𝐽.

Note that even at 1-kg (2.2 lbs) this is an immense
amount of energy compared to everyday values. We will
see below that in classical mechanics, we can often
neglect rest-mass energy because it is so large.


**Kinetic energy**

Kinetic energy is the energy of motion. It can be described in terms of the mass of an object and how fast it is moving. The
exact equation for kinetic energy, 𝐾, of an object of mass, 𝑚, and speed, 𝑣, is given by

1
𝐾= � −1�𝑚𝑐[�], (104-2)

�1 −(𝑣[�]⁄𝑐[�])

where c is, again, the speed of light in vacuum. Note how similar this equation is to the equation for the rest energy of an
object. The first term in parentheses in equation 104-2 is called the Lorentz factor and is often abbreviated as 𝛾 (the Greek
letter gamma). This allows the kinetic energy equation to be written

𝐾= (𝛾−1)𝑚𝑐[�]. (104-3)


**Kinetic Energy of an Object**

𝐾= (𝛾−1)𝑚𝑐[�]

**Description – This equation describes the kinetic energy, 𝐾, of an**

object with mass, 𝑚, and speed, 𝑣. 𝑐 is the speed of light in a
vacuum and 𝛾 is the Lorentz factor.
**Note: 𝛾= 1 �1 −𝑣⁄** [�]⁄𝑐[�].


This most general equation for kinetic energy can be simplified if the
object is moving slow when compared to the speed of light. In this case
(called the classical limit or non-relativistic limit), the kinetic energy of an
object can be written

𝐾= [1] (104-4)

2 [𝑚𝑣][�][.]

The optional section at the end of this unit shows how the two equations
(104-3) and (104-4) are related. In practice, the classical equation for
kinetic energy (104-4) can be used as long as the object is moving slower
than about 3 𝑥 10[�] 𝑚/𝑠 (about 1/100[th] the speed of light), although there
is no real hard cut-off for this approximation.
Figure 104-1 compares the relativistic kinetic energy (equation 104-3) **Figure 104-1. A comparison of the classical**
to its classical counterpart (104-4). Note that at low speeds relative to the **kinetic energy equation (solid line) with the**
speed of light, the classical kinetic energy and relativistic kinetic energy **relativistic kinetic energy (dashed lines) for**
equations agree very well. In this case, the classical approximation can be **various speeds.**
used and is generally much easier to calculate. However, as an object
approaches a reasonable fraction of the speed of light, the two equations differ greatly, and the relativistic kinetic energy
equation must be used.


-----

**Total energy of an isolated object**

The total energy of an isolated object can be written in a relatively straightforward way by adding the rest-mass energy
and kinetic energy:

𝐸� = 𝐸�� + 𝐾� = 𝑚�𝑐[�] + (𝛾−1)𝑚�𝑐[�], (104-5)

which simplifies to

𝐸� = 𝛾𝑚�𝑐[�]. (104-6)


**Total Energy of an Isolated Massive Object**

𝐸= 𝛾𝑚𝑐[�]

**Description – This equation describes the total energy, 𝐸, of an object**

with mass, 𝑚. 𝑐 is the speed of light in a vacuum and 𝛾 is the
Lorentz factor.
**Note: 𝛾= 1 �1 −𝑣⁄** [�]⁄𝑐[�].


**Potential energy**

Potential energies are energies related to the interaction of two objects, which tends to store energy in the interaction itself.
In general, a potential energy is an energy of interaction and only depends on the relative position of the interacting objects.
Put another way, the position of two interacting bodies relative to each other can store energy that can later be converted to
kinetic energy (or another type of potential energy). There are many types of potential energy, including, but not limited to:

     - Gravitational potential energy �𝑈��

     - Electric potential energy (𝑈�)

     - Magnetic potential energy (𝑈�)

     - Chemical potential energy (𝑈�)

     - Elastic potential energy (𝑈�)

     - Nuclear potential energy (𝑈�)

This list is not meant to be exhaustive, but rather just lists some of the important types of potential energy we will explore in
this course. We will use a capital 𝑈 for potential energy and include a subscript with the 𝑈 to denote which type of potential
energy we use. For example, we might write 𝑈�� for the gravitational potential energy of objects 1 and 2, and 𝑈��� for the
nuclear potential energy of objects 1 and 3. We will explore some important potential energies in units 106 and 107.

**Total energy of a system**

The total energy of a system of objects is given by the sum of all the possible energies noted above. For example, we would
say the total energy of two objects which interact with potential energy 𝑈�� is

𝐸��� = (𝐸�� + 𝐾�) + (𝐸�� + 𝐾�) + 𝑈��, (104-7)

where 𝐸�� and 𝐸�� are rest-mass energies and 𝐾� and 𝐾� are the kinetic energies of object 1 and 2, respectively.
When two objects interact, any potential energy is stored as an increase or decrease in mass of the system. For most of
the potential energies, the difference in mass of the system due to the potential energy relative to the rest mass of the objects
in the system is often so small it cannot be measured. Nuclear potential energy, on the other hand, can change the mass of
the system by an appreciable fraction of the original mass. We can see how potential energy is stored in the mass of the
system by rearranging Eq. 104-4 as
𝐸��� = (𝐸�� + 𝐸�� + 𝑈��) + 𝐾� + 𝐾�. (104-8)


-----

Remember that the total energy of an object is defined as the rest-mass energy plus the kinetic energy, so for this system, the
kinetic energy is simply the sum of the kinetic energies of the two particles; however, the rest-mass energy of the system is
given by
𝐸���� = 𝐸�� + 𝐸�� + 𝑈��, (104-9)

which may be larger or smaller than the sum of the individual rest-mass energies depending on the sign of 𝑈��. Thus, the
potential energy of the system has been included in the rest-mass energy!! Although this was written for just two interacting
particles, it is relatively easy to expand it to any number of interacting particles with any number of potential energies.

**The conservation of energy**

The total energy of a system is given by the sum of the total energy of all of the objects in the system:

𝐸��� = 𝐸�� + 𝐸�� + ⋯+ 𝐾� + 𝐾� + ⋯+ 𝑈�� + 𝑈�� + ⋯ (104-10)

As you can imagine, writing the equation for the total energy of a system can contain many, many terms. One of the goals of
this course is to help you develop a sense for which of the terms are important in a problem and which can be ignored.
The **_conservation of energy states that the total energy of a system that does not interact with its environment must_**
remain constant, but that energy can be moved around within the system itself. Specifically, we can state:

**_In an isolated system, energy can neither be created nor destroyed, only transferred between objects in_**
**_the system and between types of energy._**

This means that the change in total energy of an isolated system is zero:

∆𝐸��� = 0. (104-11)

Our goal in the energy units of this book will be to build up an inventory of potential energies to combine with kinetic energy
and rest-mass energy to solve many types of problems. We will do this starting with simple systems of one or two types of
potential energy and build up to more complicated regimes. In the end, remember that conservation of energy really comes
down to equation 104-6, and you just need to know the types of potential energy involved.

Some final notes:

1) In the classical limit, the rest-mass energies of each object is so much larger than all kinetic and potential energies in

the system that the rest-mass energies can be neglected when concerned with changes in energy. Therefore, we
write the total energy of a system as the sum of all the kinetic energies and potential energies, 𝐸��� = 𝐾� + 𝐾� +
⋯+ 𝑈�� + 𝑈�� + ⋯.
2) In practice, ∆𝐸��� = 0 can also be written as 𝐸� = 𝐸�, where 𝐸� is the total initial energy of the system and 𝐸� is the

final total energy of the system.
3) Be very careful to not neglect important energies. Many physics students immediately run to "𝑚𝑔ℎ= (1 2⁄ )𝑚𝑣[�]",
which is too non-specific and almost never the correct equation. Even when this equation happens to be correct, you
must be careful to state which object the equation is written for and which side of the equation is the initial state and
which side is the final state. In general, you must state all your assumptions.

Units 105-113 will deal directly with the conservation of energy.

### 104-3. The conservation of momentum

**Consider: What is the conservation of momentum?**

The linear momentum of an object, 𝑝⃗�, is defined as

𝑝⃗� = 𝛾𝑚𝑣⃗�, (104-12)

where 𝛾, 𝑚 and 𝑣⃗ are as defined above. The little arrows of the 𝑝⃗ and 𝑣⃗ denote that they are vectors, meaning that we have to
be very careful taking their direction into account. (We will explore much more on vectors in subsequent units). Although


-----

there is only one type of momentum for an object, the fact that it is a vector and we have to be careful about the directions,
will make it more complicated. There are, however, many techniques for dealing with vectors as we will see.
Similar to our discussion of the conservation of energy above, the **_conservation of momentum states that the total_**
momentum of an isolated system does not change. If a system is composed of many objects, the total momentum of the
system can be written
𝑝⃗= 𝑝⃗� + 𝑝⃗� + 𝑝⃗� + ⋯, (104-13)

and therefore the conservation of momentum is written

∆𝑝⃗= 𝑝⃗� −𝑝⃗� = 0. (104-14)

A couple of important notes:

1) In the classical limit, the momentum of an object is written as

𝑝⃗� = 𝑚𝑣⃗�, since 𝛾~1at slow speeds.
2) In practice, the conservation of momentum for an isolated system

can be written as the total initial momentum (𝑝⃗�) equals the total
final momentum (𝑝⃗� ), since ∆𝑝⃗= 𝑝⃗� −𝑝⃗� = 0.
3) The conservation of momentum also has a rotational counterpart

known as the conservation of angular momentum.
4) The SI unit for momentum is 𝑘𝑔∙𝑚/𝑠.

To support #1 above, Figure 104-2 compares relativistic momentum to
classical momentum from rest up to the speed to light. Please note that at
low speeds, the two equations for momentum agree to a very large extent,
so we can use the easier, classical equation in this case. Just as with the

**Figure 104-2. A comparison of the classical**

equations for kinetic energy, the classical equation can be used to high

**momentum equation (solid line) with relativistic**

certainty if the speed of an object is less than about 3 𝑥 10[�] 𝑚/𝑠.

**momentum (dashed lines) for various speeds.**

Units 114-118 are focused on the conservation of momentum.

### 104-4. Newton’s Laws of Motion

**Consider: What are Newton’s three laws of motion?**

Although Newton’s laws are extremely powerful for exploring and calculating classical systems, they are _not fundamental_
relationships. First, Newton’s laws only work in the classical limit, and second, each of the laws are direct consequences of
more fundamental principles or relationships. Regardless, these laws are so important in the classical limit, we will spend a
considerable amount of time exploring how to use the laws and so we put them on the same pedestal as the two conservation
laws described above.

Newton’s 1[st] Law

My definition:

**_N1[st]: In an inertial reference frame, an object remains at rest or continues to move at_**
**_constant velocity (speed and direction) unless acted on by an outside force._**

Newton’s definition:

_Law I: Every body persists in its state of being at rest or of moving uniformly straight_
_forward, except insofar as it is compelled to change its state by force impressed._

The first law sets up the definition of an inertial reference frame. Such frames are any two frames that are not accelerating
relative to each other – that is to say that the two reference frames are either at rest relative to each other, or moving relatively
at a constant speed and direction. In this case, an isolated object moves at a constant velocity (speed and direction).


-----

Newton’s 2[nd] Law

My definition:

**_N2[nd]: The vector sum of forces on an object is equal to the rate of change of_**
**_momentum of the object. In the case where the mass of the object remains the same,_**
**_the vector sum of forces is equal to the mass of the object multiplied by the acceleration_**
**_(rate of change of velocity) of the object._**

Newton’s definition:

_Law II: The alteration of motion is ever proportional to the motive force impress'd; and_
_is made in the direction of the right line in which that force is impress'd_

The second law gives us the means to calculate the net force on an object and its subsequent change in motion. Although the
equation 𝐹[⃗] = 𝑚𝑎⃗ is very common, we must be very careful – it is absolutely true in the case where the mass of the object is
constant; the more general form 𝐹[⃗] = 𝑑𝑝⃗𝑑𝑡⁄ must be used if we aren’t sure the mass is constant. In order to use the second
law, the mass of the system must remain constant, however, mass can flow between different objects in the system (as in
rockets where exhaust leaves the back of the rocket but remains in the system).


**Newton’s Second Law**

[��⃗]𝑭𝒏𝒆𝒕 = [𝒅𝒑��⃗]𝒅𝒕 [  (= 𝒎𝒂��⃗)]

**Description – The equation relates the net force on an**

object, F[�⃗]���, to the rate of change of the object’s
momentum, 𝑑𝑝⃗𝑑𝑡⁄ .
**Note 1: When the mass of an object moving at non-**

relativistic speeds is constant, 𝑑𝑝⃗𝑑𝑡⁄ reduces to 𝑚𝑎⃗.
**Note 2: The SI unit for force is the Newton (N), where**

1𝑁= 1 𝑘𝑔∙𝑚/𝑠[�]


Newton’s 3[rd] Law

My definition:

**_N3[rd]: When two objects interact, the force exerted on the first object by the second_**
**_object is equal in magnitude and opposite in direction to the force on the second object_**
**_by the first object._**

Newton’s definition:

_Law III: To every action there is always opposed an equal reaction: or the mutual actions_
_of two bodies upon each other are always equal, and directed to contrary parts._

The third law seems easy, but it often proves conceptually very hard for physics students. Third-law pairs, as the two forces
referenced in the third law are called, must be the same type of force (since they are each part of a single interaction), but it is
easy to forget this. As an example, consider you sitting in a chair. What is the third-law pair of the earth pulling down on
you gravitationally? Many students answer that it is the normal force of the chair pushing up on you. However, these two
forces are from completely different interactions – the gravitational force is, well, gravitational and acts between you and the
earth, whereas the normal force is a contact force that acts between you and the chair. Since these are different types of
forces, they can’t possibly be third-law pairs. The correct answer is that the reaction force to the gravitational force of the
earth pulling down on you is a gravitational force of you pulling up on the earth – and yes, they have the same magnitude.
See unit 119 for how this is possible.

Units 119-130 give an introduction to Newton’s laws and their applications.


-----

### 104-5. Derivation of Kinetic Energy Equation at Low Speeds (Optional)

**Consider: Where does K = ½mv[2] come from?**

For those of you exposed previously to physics, you were almost certainly introduced to kinetic energy in its classical
form,
𝐾= [1] (104-4)

2 [𝑚𝑣][�][.]


As noted above, this equation an approximation that is valid only at low speeds (compared to the speed of light). In this
section, we present a derivation of this classical limit from the more-correct relativistic form.
In order to show where the classical kinetic energy equation comes from, we must first start with the full relativistic
equation, given by
1
𝐾= � −1�𝑚𝑐[�]. (104-2)

�1 −(𝑣[�]⁄𝑐[�])

When 𝑣 is small compared to 𝑐, the square-root in the denominator, �1 −(𝑣[�]⁄𝑐[�]), is very close to one, since the 𝑣[�]⁄𝑐[�] term
is close to zero. In this case, we can use the binomial approximation to explore the properties of this equation. The general
form of the binomial approximation is
(1 ± 𝑥)[�] ≈1 ± 𝛼𝑥, (104-15)

which is valid when 𝑥 is much smaller than 1. In the general form for kinetic energy (104-2), 𝑥 is 𝑣[�]⁄𝑐[�] and 𝛼 is -1/2, since

�[�]��

1

= �1 −(𝑣[�]⁄𝑐[�])� . (104-16)

�1 −(𝑣[�]⁄𝑐[�])


Therefore, applying the binomial approximation gives us

1

≈1 −�− [1]

�1 −(𝑣[�]⁄𝑐[�]) 2


𝑣[�]

𝑐[�][�= 1 + 1]2


𝑣[�]

(104-17)
𝑐[�] [.]


This approximation can then be substituted back into our equation for kinetic energy giving us

1 𝑣[�]
𝐾= � −1�𝑚𝑐[�] ≈�1 + [1] (104-18)

�1 −(𝑣[�]⁄𝑐[�]) 2 𝑐[�] [−1�𝑚𝑐][�] [= 1]2 [𝑚𝑣][�][,]

as expected. For the vast majority of this course, we will use the classical limit for both kinetic energy and momentum;
however, it is important to remember that these are approximations at low speed. We will be very explicit when a full
relativistic treatment must be used.


-----

