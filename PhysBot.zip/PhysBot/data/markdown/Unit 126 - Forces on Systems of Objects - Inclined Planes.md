### – Forces on Systems of Objects II
## 126


_In our study of forces so far, we have considered systems which have horizontal and vertical components of motion. In_
_this unit, we will expand our abilities to deal with Newton’s 2[nd] law to inclined planes; systems in which the motion of an_
_object tends to not be along the line or perpendicular to gravity. Like pulley problems, this provides us with another_
_situation to use a non-standard coordinate system._

##### The Bare Essentials

- Objects constrained to move along an inclined plane tend to

have forces that are parallel and perpendicular to the line of the
plane, not horizontal and vertical.

- For inclined planes, it often makes sense to define the

coordinate system such that one axis is parallel to the plane and
one axis is perpendicular. This often allows normal, friction
and pushing/pulling forces to lie along one of the axes;
however, the force of gravity will have components along both
axes.

- The acceleration of a block on a frictionless inclined plane is

given by

𝑎= 𝑔sin 𝜃

where 𝜃 is the angle of inclination.


-----

#### 126-1 – Inclined planes and geometry

**Consider: What coordinate systems make inclined planes**
mathematically easier to deal with?

ONSIDER THE BOX SITTING ON AN inclined plane as shown in Figure
126-1. At first glance, we could approach this system in the same way we
have for other single-object free body diagrams – simply decompose the

# C

normal force into vertical and horizontal components and then apply Newton’s 2[nd]
law. However, when we try to include the acceleration of the block, an interesting
thing happens: since the block will move along the incline, this means that it will
have both horizontal and vertical components of the acceleration as well as forces!
If we then want to find the total acceleration of the block, we will have to use the
Pythagorean Theorem to find the magnitude and then use 𝜃 as the direction.
Fortunately, there is a change in coordinate system that will eliminate this **Figure 126-1. A box on a**

**frictionless inclined plan with a free**

problem and place the motion all along one

**body diagram superimposed.**

axis. As shown in Figure 126-2, we can
choose one of the coordinate axes (the x-axis in this figure) along the plane and
chose another axis (z-axis) as perpendicular to the plane. In this system, the normal
force lies entirely along the z-axis; however, we now have to decompose the
gravitational force into components which are parallel and perpendicular to the
plane. Please note that the x-axis can be chosen either up or down the plane
depending on the situation.
The decomposition of the gravitational force can also be seen in Figure 126-2.
As the incline angle increases from 0° to 𝜃, the component of the gravitational force

**Figure 126-2. Coordinate system**
**parallel and perpendicular to the** parallel to the normal force also rotates from the vertical by the same angle. Since
**inclined plane with the decomp-** this component of the gravitational force is adjacent to the angle, we will use the
**osition of the gravitational force.** cos 𝜃 to find this component, which is along the –z-axis. The compoenent of the

gravitational force that is parallel to the plane will be opposite the angle and will
therefore use sin 𝜃. Putting this all together, the net force on the block in Figure 126-2 is written


𝐹[⃗]��� = �


𝑚𝑔sin 𝜃

0
𝑁−𝑚𝑔cos 𝜃


�. (126-1)


Again, it is important to remember that this coordinate system is not horizontal and vertical as we have often used before.
However, this system is completely consistent and, as we will see shortly, also incorporates friction and any pushes or pulls
up or down the plane very well.

#### 126-2 – Inclined planes and Newton’s 2[nd] law

**Consider: How does Newton’s 2[nd] law work with inclined planes?**

Assuming the box in Figure 126-2 only moves along the plane, which is to say along the x-direction, Newton’s 2[nd] law for
this block becomes


𝐹[⃗]��� = 𝑚𝑎⃗ → �

The z-component of this equation gives us


𝑚𝑔sin 𝜃

0
𝑁−𝑚𝑔cos 𝜃


�= 𝑚�


𝑎
0
0


�. (126-2)


𝑁−𝑚𝑔cos 𝜃= 0 → 𝑁= 𝑚𝑔cos 𝜃. (126-3)

Note that this is another situation in which the normal force on a block is not equal to the weight of the block. Visually, this
is expected since the normal force is not parallel to the gravitational force in this case, and in fact, we can see this relationship
directly in Equation 126-3. We can also test the Equation 126-3 by considering its extreme values. When 𝜃= 0, meaning
when there is no incline, the normal force is equal to the weight of the block, as expected. When 𝜃= 90°, the normal force


-----

goes to zero. This is a situation where the inclined plane essentially becomes a
vertical wall. Since the plane is no longer supporting the block at all, we would
expect the normal force to go to zero.
The x-component of Newton’s second law only has one force, which means the
block must accelerate, with an acceleration given by

𝑚𝑔sin 𝜃= 𝑚𝑎 → 𝑎= 𝑔sin 𝜃. (126-4)

Therefore, the acceleration of the block depends on the angle of the incline, which

**Figure 126-3. A block on an**

makes sense – at small angles, we have a small acceleration, and at large angles, the

**inclined plane with friction.**

acceleration approaches the acceleration due to gravity.
Now, let us continue our exploration of inclined planes by including friction, as shown in Figure 126-3. In this figure,
the block is either at rest, so that the friction is static friction, or moving down the plane so that the friction is kinetic friction.
Please note that if the block were moving up the plane, the kinetic friction force would be in the opposite direction of Figure
126-3.
An interesting thing to notice is that the force of friction is also along the plane, meaning that it also fits very well with
our inclined coordinate system, also shown in Figure 126-3. Putting this all together, Newton’s 2[nd] law for the box on an
inclined plane including friction is


𝐹[⃗]��� = 𝑚𝑎⃗ → �


𝑚𝑔sin 𝜃−𝑓

0
𝑁−𝑚𝑔cos 𝜃


�= 𝑚�


𝑎
0
0


�. (126-5)


As with all Newton’s law problems including friction, these equations are coupled because the friction force depends on the
normal force. As before, the normal force is 𝑁= 𝑚𝑔cos 𝜃, which gives us a general x-component equation of

𝑚𝑔sin 𝜃−𝜇𝑚𝑔cos 𝜃= 𝑚𝑎, (126-6)

where 𝜇 could be the coefficient of static friction or the coefficient of kinetic friction depending on the situation.


Example 126 - 1 **Acceleration along plane**

A 2.54-kg block of wet ice is placed on an inclined plane
made of ice at 41°. What is the acceleration of the 2.54-kg
piece of ice?

**Solution:**

Using the geometry for inclined planes along with Newton’s
2[nd] law, we found that the acceleration without friction along


an inclined plane is given by

𝑎= 𝑔sin 𝜃.

Therefore, the acceleration in this situation is

𝑎= (9.8 𝑁𝑘𝑔⁄ ) sin 41° = 6.43 𝑚𝑠⁄ [�].


Example 126 - 2 **The coefficients of friction**

A block is sitting on an inclined plane whose angle is slowly
increased. If the block starts to move just when the angle is
27°, what is the coefficient of static friction between the block
and the plane? If the coefficient of kinetic friction is 80% the
coefficient of static friction, what is the acceleration of the
block after it starts moving if the angle is maintained?

**Solution:**

This is an inclined plane problem including friction. As
shown above the x-component of an inclined plane with
friction is given by

𝑚𝑔sin 𝜃−𝜇𝑚𝑔cos 𝜃= 𝑚𝑎.


When the block is not moving, we must use the
coefficient of static friction and we also know that the
acceleration is zero. This leads to

𝑚𝑔sin 𝜃−𝜇�𝑚𝑔cos 𝜃= 0.

This equation can be solved for the coefficient of friction
as a function of angle by factoring out and canceling the
mass and solving for 𝜇� as

𝜇� = tan 𝜃.

Since we know that the block started to move at 27°, this


-----

suggests that the coefficient of static friction is

𝜇� = tan 27° = 0.510.

Once the block starts to move, we can return to our equation
of motion in the x-direction; however in this case, we must
use the coefficient of kinetic friction, and keep the
acceleration term, giving us

𝑚𝑔sin 𝜃−𝜇�𝑚𝑔cos 𝜃= 𝑚𝑎,

which gives us an acceleration equation

𝑎= 𝑔(sin 𝜃−𝜇� cos 𝜃).


The problem tells us that the coefficient of kinetic friction
is 80% the coefficient of static friction. Therefore, we
find

𝜇� = (0.8)(0.510) = 0.408.

Using this and the angle given, the acceleration of the
block after it starts moving is

𝑎= (9.8 𝑁𝑘𝑔⁄ ) (sin 27° −0.408 cos 27°),

which gives us

𝑎= 0.887 𝑚𝑠⁄ [�].


Example 126 - 3 **Slowing a block on an inclined plane**

Imagine that a 10.4-kg block is initially moving up a 12.2°
inclined plane at 2.00 m/s. a) How far up the plane will the
block move if the coefficient of kinetic friction is 0.20? b) If
the coefficient of static friction is 0.66, will the block remain
stopped or come back down the incline once it reaches its
peak?

**Solution:**

a) This is an inclined plane problem with friction, which
requires Newton’s 2[nd] law to solve. Since the block is moving
up the inclined plane, the free body diagram resembles that of
Figure 126-3, except that the friction force is directed down
the plane (in the opposite direction of the motion of the block
relative to the plane). This leads to a Newton’s 2[nd] law
equation


𝑎= (9.8 𝑁𝑘𝑔⁄ ) (sin 12.2° + 0.20 cos 12.2°),

or

𝑎= 3.99 𝑚𝑠⁄ [�].

Now that we know the acceleration, we can use one of
the constant acceleration kinematics equations to
determine how far the block will move before coming to
rest. Since we do not care about time and know the
initial velocity, final velocity and acceleration, we can
use

𝑣[�](𝑡) = 𝑣�� + 2𝑎(𝑥(𝑡) −𝑥�).

We know that the final velocity will be zero, and we only
care about the change in position �𝑥= 𝑥(𝑡) −𝑥�.
Therefore, the change in position can be written


(−2.00 𝑚𝑠⁄ )[�]

2(3.99 𝑚𝑠⁄ [�]) [= 0.50 𝑚.]


�

�𝑥= [𝑣][�]

2𝑎 [=]


�


𝑚𝑔sin 𝜃+ 𝑓�

0
𝑁−𝑚𝑔cos 𝜃


�= 𝑚�


𝑎
0
0


�.


Please note that since the initial velocity is up the plane, and
we chose down the plane as the positive x-direction, the initial
velocity is −2.00 𝑚/𝑠 𝑥�.

The z-component tells us the normal force is given by

𝑁= 𝑚𝑔cos 𝜃.

This can then be used in the x-component equation to find

𝑚𝑔sin 𝜃+ 𝜇𝑚𝑔cos 𝜃= 𝑚𝑎,

or

𝑎= 𝑔(sin 𝜃+ 𝜇cos 𝜃).

Using values from the problem, the acceleration is


Therefore, the block will slide 0.50 m up the inclined
plane before coming to rest.

b) At the top of the incline, the block will momentarily
stop before it starts to move _down the plane (if it moves_
down at all). Since it now wants to move down the plane,
the direction of the frictional force is now up the plane
and has a maximum value of

𝑓� = 𝜇𝑚𝑔cos 𝜃= 65.7 𝑁,

compared to the component of the force of gravity down
the plane:

𝑚𝑔sin 𝜃= 21.5 𝑁.

Since the maximum coefficient of static friction is larger
than the force pulling on the box, it will remain at rest at
the top.


-----

#### 126-3 – Inclined plane problems with pulleys

**Consider: How can inclined planes be combined with pulleys to create**
more complicated situations?

As a final application of tension and inclined planes, consider the inclined
Atwood’s machine as shown in Figure 126-4. We will take the surface of
the inclined plane to be frictionless and consider the pulley as ideal. You
could extend the problem to include friction and real pulleys as we have
shown in previous sections.
Figure 126-4 has free body diagrams for both 𝑚� and 𝑚�
superimposed on the figure itself. As we have for other multi-object
systems, we must consider each object separately.
Mass 𝑚� is a mass on an inclined plane without friction. Note that in
Figure 126-4, we have reversed the direction of the x-axis and placed it up
the ramp. Following our general procedures for inclined planes, Newton’s
2[nd] law for this block becomes


𝐹[⃗]���,� = 𝑚�𝑎⃗ → �


𝑇−𝑚�𝑔sin 𝜃

0
𝑁−𝑚�𝑔cos 𝜃


�= 𝑚� �


**Figure 126-4. Atwood’s machine with one**
**block on an incline.**


𝑎
0
0


�. (126-7)


If the block on the inclined plane moves up the plane, then 𝑚� would move vertically downward. Therefore, to be
consistent, since up the plane is the positive-x direction for 𝑚�, I will call vertically down the positive-x direction for 𝑚�.
Using this coordinate system, we find for 𝑚�


𝐹[⃗]���,� = 𝑚�𝑎⃗ → �


𝑚�𝑔−𝑇

0
0


�= 𝑚� �


𝑎
0
0


�. (126-8)


The z-component of the equation for 𝑚� gives us the normal force. In order to find the acceleration of the system and the
tension in the string, we must simultaneously solve the x-component equations for 𝑚� and 𝑚�,

𝑇−𝑚�𝑔sin 𝜃= 𝑚�𝑎 and 𝑚�𝑔−𝑇= 𝑚�𝑎. (126-9)

Solving Equations 126-9, we find


𝑎=


(𝑚� −𝑚� sin 𝜃)𝑔

𝑚� + 𝑚�


, (126-10)


and


𝑇= [𝑚][�][𝑚][�][𝑔(1 + sin 𝜃)]. (126-11)

𝑚� + 𝑚�

Please note that the results for both the acceleration and the tension resemble what we have previously found for Atwood’s
machine problems, but include angles related to the angle of inclination of the plane. In the limit as 𝜃 goes to zero, these
results are the same as the problem we did where one block is on a flat table and one is hanging, and as 𝜃 goes to 90°, the
results approach those for the standard Atwood’s machine problem. Since these extreme values fit for this inclined plane
problem, this suggest that our solutions work for all values of theta.
This section really just showed how we can combine the ideas of inclined planes with the ideas of pulley from the last
Unit. As always, what we have done is to set up free body diagrams for the system, write Newton’s 2[nd] law equations from
these free body diagrams and solve those equations for the relevant values. Following this plan will help you with all
Newton’s law problems, no matter how complex.


-----

Example 126 - 4 **When the masses are the same.**

Imagine that the two blocks in figure 126-4 are each 2.54 kg,
and that the angle of incline of the ramp is 30°. Determine the
acceleration of the blocks and the tension in the string.

**Solution:**

This is a pulley problem with an inclined plane. Knowing
that the masses are the same, we can immediately simplify the
equations for the acceleration and tension to


Using the values from our problem, we find


𝑎=


(9.8 𝑁𝑘𝑔⁄ )(1 −sin 30°)

= 2.45 𝑚𝑠⁄ [�],
2


and

𝑇=


(2.54 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )(1 + sin 30°)
= 18.7 𝑁.
2


𝑎=


(𝑚−𝑚sin 𝜃)𝑔

= [𝑔(1 −sin 𝜃)]
𝑚+ 𝑚 2


and


𝑇= [𝑚𝑚𝑔(1 + sin 𝜃)] = [𝑚𝑔(1 + sin 𝜃)].

𝑚+ 𝑚 2


Note that the acceleration in this case is independent of
the mass; however, the tension in the string is not. Of
course, this problem could be made more difficult by
including friction on the surface or allowing the pulley to
have mass. We have explored previously how to include
these situations into Newton’s 2[nd] law problems.


-----

