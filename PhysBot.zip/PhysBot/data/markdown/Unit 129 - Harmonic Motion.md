### – Harmonic Motion
## 129


_In unit 107, we studied how springs and atomic bonds can store energy as elastic potential energy. As with all types of_
_energy, there is the ability to convert this potential energy into kinetic energy as long as the total energy is conserved. In_
_Unit 129 we now explore how the release of elastic potential energy may lead to vibrational motion. Along the way,_
_we’ll see how gravitational potential energy can have a similar effect on pendulums and the role that friction plays in_
_these processes._


##### The Bare Essentials

- Hooke’s law relates the displacement of a spring from

equilibrium to the restoring force of the spring.


**Hooke’s Law**

𝑭[��⃗] = −𝒌(𝒙��⃗−𝒙��⃗𝟎)

**Description – The equation describes the force of an object on a**

spring with stiffness, 𝑘, and displacement from equilibrium,
(𝑥⃗−𝑥⃗�).



- **_Damped oscillations are grouped into one of three categories,_**

which are determined by the damping ratio.

   - **_Overdamped: The system does not oscillate because_**

friction only allows it to return to equilibrium via
exponential decay.
   - **_Critically damped: The system exactly returns to_**

equilibrium as quickly as possible while not oscillating.
   - **_Underdamped: The system oscillates; however, the_**

amplitude decreases with time and the frequency of
oscillation is slightly off from the un-damped frequency.



- In simple harmonic motion, a restoring force creates

oscillatory motion for block-spring systems and pendulums.


**Block-Spring Oscillation**

𝒙(𝒕) = 𝑨 𝒄𝒐𝒔 (𝝎𝟎𝒕−𝝓)

**Description – This equation describes the position as a function of**

time of a linear oscillator with amplitude, 𝐴, angular
frequency, 𝜔�, and initial phase, 𝜙, at time 𝑡.
**Note: For an object with mass 𝑚 on a spring with stiffness 𝑘, the**

angular frequency is given by 𝜔� = �𝑘𝑚⁄ .


**Damping Ratio**

𝒃
𝝌=

𝟐√𝒎𝒌

**Description – The equation describes the damping ratio, 𝜒, of a**

damped mass-spring oscillator in terms of the damping
coefficient, 𝑏, the mass of the oscillator, 𝑚, and the spring
constant, 𝑘.
**Note 1: Overdamped: 𝜒> 1; critically damped, : 𝜒= 1;**

underdamped, : 𝜒< 1.
**Note 2: 𝜔�** = 𝜔��1 −𝜒[�]


**Pendulum (small angles)**

𝜽(𝒕) = 𝜽𝟎 𝒄𝒐𝒔 (𝝎𝟎𝒕− 𝝓)

**Description – This equation describes the angular position of a**

function of time of a pendulum with amplitude, 𝜃�, angular
frequency, 𝜔�, and initial phase, 𝜙, at time 𝑡.
**Note 1: For a pendulum with length 𝑙 in gravitational field strength**

𝑔, 𝜔� = �𝑔𝑙⁄ .
**Note 2: This equation only holds for small oscillations.**



- **_Forced-damped motion occurs when a sinusoidal forcing_**

function acts on a damped oscillator. Such systems exhibit
**_resonance when the driving frequency matches the natural_**
frequency.


**Forced-Damped Motion**

𝒙(𝒕) = 𝑨𝒇𝒄𝒐𝒔(𝝎𝒇𝒕−𝝓)

**Description – The equation describes the steady state solution of a**

forced-damped harmonic oscillator with forcing function
𝐹� sin(𝜔�𝑡).
**Note 1: 𝜔� is the angular frequency of the driving force.**

**Note 2: 𝐴�** = ��⁄�� �

����[�]����� ���[�] [�] ���



- When friction is included in an oscillator, the oscillations

become damped, meaning that their amplitude decreases with
time.


-----

#### 129-1 – Oscillating mass on a spring

**Consider: Why do masses on springs oscillate?**

ONSIDER FIGUER 129-1, WHICH shows a mass connected to a
spring, which in turn is attached to a wall. The mass is situated on a
frictionless surface, so that there are no non-conservative forces acting

# C

on the mass.  In Sections 107-2 and 107-3, we used a very similar setup to
show that the elastic potential energy of such a system is given by


𝑈�(𝑥) = [1]2 [𝑘][�][(𝑥−𝑥][�][)][�][,] (129-1) **Figure 129-1. A mass connected to a**

**spring.**

and that the force on the mass due to the extension or compression of the spring
is given by Hooke’s Law,

𝐹[⃗]� = −𝑘�(𝑥⃗−𝑥⃗�). (129-2)


**Hooke’s Law**

𝑭[��⃗] = −𝒌(𝒙��⃗−𝒙��⃗𝟎)

**Description – The equation describes the force of an object on a**

spring with stiffness, 𝑘, and displacement from equilibrium,
(𝑥⃗−𝑥⃗�).


In Unit 107, we focused on how energy stored in the spring can be converted to other
forms of energy. We now consider the dynamics of this same setup using Newton’s
laws.
To make our analysis a bit simpler at this point, we will first assume that the
motion of the mass will only be along the x-direction and we will call the equilibrium
position of the spring, 𝑥� = 0, so that

𝐹� = −𝑘𝑥. (129-3)

As shown in Figure 129-2, Equation 129-3 suggests that the force on the mass will
always be in the opposite direction as the displacement of the mass from equilibrium.

**Figure 129-2. Relationship**
**between displacement and force** Another way to say this is that the force on the mass is always pushing it back towards
**on a mass-spring system.** its equilibrium position. Because the force is always working to restore the mass to this

equilibrium position, it is called a **_restoring force.  Any linear restoring force can be_**
treated in the same way we are going to treat the mass-spring system below.

Again assuming no friction, the only force acting on the block in the x-direction is the force from Hooke’s law. Given
this, Newton’s 2[nd] law for the mass-spring system is


𝐹[⃗]��� = �


−𝑘𝑥

0
𝐹� −𝐹�


�= 𝑚�


𝑎
0�. (129-4)
0


The z-component of Equation 129-4 tells us that, in this case, the normal force is equal to the weight of the mass, which can
be important if friction is included. For now, we will focus in on the x-component of the force law. Be definition,
acceleration is the second derivative of the position function with respect to time. Given this, the x-component of newton’s
2[nd] law can be written

−𝑘𝑥= 𝑚 [𝑑][�][𝑥] (129-5)

𝑑𝑡[�] [.]

Equation 129-5 is a second-order linear differential equation. Although the general solution method for this type of problem
is beyond the scope of this course, we can use what we know about calculus and our intuition to find a solution. First, I will
solve this equation so that the derivative is alone on one side, be dividing both sides of the equation by the mass,


-----

𝑑[�]𝑥

(129-6)

𝑑𝑡[�] [= −𝑘]𝑚 [𝑥.]

Equation 129-6 says that we need a function such that if we take its second derivative, we have the negative of the same
function with some multiplied constants. We do know such functions, sin 𝜃 and cos 𝜃. Here are a couple of other
considerations for the solution

1) It makes sense that if we pull the mass a given displacement and then release it, the mass will start to oscillate. This

suggests that at time 𝑡= 0, we want the function to be non-zero, so I will choose cos 𝜃.
2) We want the solution to be a function of time, so I will say that the angle in the cosine function is 𝜃= 𝜔�𝑡, where

𝜔� is the natural angular frequency or sometimes just angular frequency.
3) Because we have a second derivative, we can have up to two constants of integration that relate the displacement

term to the acceleration term.

Given these considerations, I will assume a solution of the form

𝑥(𝑡) = 𝐴cos(𝜔�𝑡+ 𝜙), (129-7)

where our two constants of integration are the amplitude, 𝐴, and the phase constant, 𝜙. In order to relate this solution to our
Newton’s 2[nd] law equation, we must find the related velocity and acceleration terms as


𝑥[�](𝑡) = [𝑑𝑥]

𝑑𝑡 [= −𝐴𝜔][�] [sin(𝜔][�][𝑡+ 𝜙),]

𝑥[��](𝑡) = [𝑑]𝑑𝑡[�][𝑥][�] [= −𝐴𝜔][�]� cos(𝜔�𝑡+ 𝜙).


(129-8)


As you can see, the acceleration is, indeed, the same function as the displacement with a multiplicative constant, 𝜔��. To

determine how our constant 𝜔� relates to the constants in Newton’s 2[nd] law, we substitute equations 129-7 and 129-8 into
Equation 129-6

−𝐴𝜔�� cos(𝜔�𝑡+ 𝜙) = − 𝑚[𝑘] [(𝐴cos(𝜔][�][𝑡+ 𝜙)).] (129-9)


Since the cosine terms and amplitudes can be canceled from this equation, it simplifies to

𝜔� = [�𝑘]𝑚[.] (129-10)

Therefore, Equation 129-7 is a solution to Newton’s 2[nd] law as long as Equation 129-10 holds true. 𝜔� is called the natural
**_angular frequency or just angular frequency_** and has the units of rad/sec. The number of times per second an oscillation
cycles is called the frequency, 𝑓 and is given by 𝜔2𝜋⁄ . The standard units of frequency are 𝑠[��] = 1 𝐻𝑒𝑟𝑡𝑧= 1𝐻𝑧.


**Block-Spring Oscillation**

𝒙(𝒕) = 𝑨 𝒄𝒐𝒔 (𝝎𝟎𝒕−𝝓)

**Description – This equation describes the position as a**

function of time of a linear oscillator with amplitude, 𝐴,
angular frequency, 𝜔�, and initial phase, 𝜙, at time 𝑡.
**Note: For an object with mass 𝑚 on a spring with stiffness**

𝑘, the angular frequency is given by 𝜔� = �𝑘𝑚⁄ .


-----

Any oscillation given by a linear restoring force alone which leads to the solution above is called simple harmonic motion
(SHM). Figure 129-3 shows a plot of an object undergoing SHM. As can be seen, the amplitude, 𝐴 represents the maximum
displacement from equilibrium (both positive and negative). In addition, we can define the period, 𝑇, of motion as time it
takes to complete one full cycle of motion.
We can find the period in terms of the angular frequency by noting that as the time increases by T, the angle must
increase by 2𝜋 to add one complete cycle. Therefore

𝜔�(𝑡+ 𝑇) = 𝜔�𝑡−2𝜋. (129-11)

This relationship can be simplified by subtracting 𝜔𝑡 from both sides and
solving for the period


𝑇= [2𝜋]

𝜔�


. (129-12)


**Figure 129-3. Plot of simple harmonic**
**motion defining the Amplitude, 𝑨, and**
**period, 𝑻.**


Finally, note that the plot in Figure 129-3 is not a perfect cos 𝜔𝑡 graph,
since it does not start at its maximum value at 𝑡= 0. This is where the
**_phase constant,_** 𝜙, comes into play. Consider the **_phase,_** 𝜔𝑡+ 𝜙, in the
equation for the position in SHM. The phase constant allows the phase to
have a non-zero value even at 𝑡= 0. The phase constant therefore serves
two purposes


1) It allows the position function to start anywhere, especially not at the maximum or minimum value at 𝑡= 0.

2) It gives the motion an initial velocity since the velocity is given by the sine function (see Equation 129-8) and the

phase for the velocity will not necessarily be zero at 𝑡= 0.

In practice, if you need to solve for the phase, it will be one of the unknowns in a given problem. You can use equations 1297, 129-8, 129-10 and 129-12 to solve SHM problems readily. The following summarizes some important information about
SHM of a block-mass system:


Angular frequency: 𝜔� = �


�

�


Period of motion: 𝑇=


�� �

�� [= 2𝜋�]�


�

� [=]


�

�� [�]


�

�


Frequency: 𝑓=


��
�� [=]


Example 129 - 1 **A mass-spring oscillation**

A 2.00-kg mass is attached to a spring with a stiffness of 5.49
N/kg. If the system is set in motion, what will be the angular
frequency, frequency and period of motion?

**Solution:**

This is a direct application of the mass-spring system of
simple harmonic motion. We can first find the angular
frequency using

⁄

𝜔= [�𝑘] = 1.66 𝑟𝑎𝑑𝑠⁄ .

𝑚 [= �5.49 𝑁𝑚]2.00 𝑘𝑔


1

𝑇= [1]

𝑓 [=] 0.264 𝐻𝑧 [= 3.79 𝑠.]

Please note that we have a number of small relationships
between the quantities for simple harmonic oscillation. It
is important to keep each straight and to be familiar with
each of the small relationships.


We can then find the frequency as

⁄

𝑓= [𝜔] = 0.264 𝐻𝑧.

2𝜋 [= 1.66 𝑟𝑎𝑑𝑠]2𝜋

Finally, we can find the period


-----

Example 129 - 2 **Equations of motion**

Imagine that a 1.95-kg mass is set to oscillate while attached
to a spring with stiffness 10.2 N/m. If the initial position of
the mass, relative to the spring’s equilibrium position is
+0.250 m and it has an initial speed of +1.45 m/s. What are
the amplitude and initial phase of this motion?

**Solution:**

This problem is an application of the equations of simple
harmonic motion for a mass-spring system. We start with the
general equations for the position and speed of a mass-spring
system:

𝑥(𝑡) = 𝐴cos(𝜔�𝑡−𝜙),
and

𝑥[�](𝑡) = −𝐴𝜔� sin(𝜔�𝑡−𝜙).

Since we are given the initial position and velocity (𝑡= 0), it
turns out that we do not need the angular frequency of
oscillation in this problem. Substituting what we know into
our two equations, we get

0.250𝑚= 𝐴cos(−𝜙) = 𝐴cos 𝜙
and

1.45 𝑚𝑠⁄ = −𝐴𝜔�sin(−𝜙) = 𝐴𝜔� sin 𝜙

We now have a set of two equations with two unknowns.


We can then use this phase angle in either of the two
equations to find

𝐴= 0.679 𝑚.

We can use this information to write the position
equation as a function of time. In order to do this, we do
need

⁄

𝜔� = [�𝑘]𝑚 [= �10.2 𝑁𝑚]1.95 𝑘𝑔 = 2.29 𝑟𝑎𝑑𝑠.⁄

Therefore, the equation of motion is

𝑥(𝑡) = 0.679𝑚cos(2.29𝑡−1.20 𝑟𝑎𝑑).


We can solve for the phase by dividing the velocity
equation by the position equation to get

𝐴𝜔�sin 𝜙

𝐴cos 𝜙 = 𝜔� tan 𝜙= 0.250[1.45] [,]


which gives us

1.45
𝜙= tan[��]
0.250𝜔�


= 1.20 𝑟𝑎𝑑.


#### 129-2 – The simple pendulum

**Consider: How does a pendulum work?**

A **_simple pendulum is a massive object suspended by a light string or wire. If the_**
**_pendulum bob (the mass) is pulled to one side while maintaining no slack in the string,_**
and then released, the mass will swing back and forth in an oscillatory motion. Figure
126-4 shows a pendulum, including the forces of tension and gravity acting on the bob.
In this figure, the bob is pulled to an angle 𝜃, and the force of gravity is decomposed into
components parallel and perpendicular to the direction of motion at that point (tangential
and radial to the circle traced out by the pendulum at that point).
If we call the direction of motion the x-axis and that perpendicular to this the z-axis,
Newton’s 2[nd] law can be written


𝐹��� = �


−𝑚𝑔sin 𝜃

0
𝐹� −𝑚𝑔cos 𝜃


�= 𝑚�


𝑎
0
0


�, (129-13)


where we have set the acceleration in the z-direction equal to zero because this would
represent a change along the length of the string. The x-component equation mixes an
angular variable (𝜃) on the left side and a linear variable (a) on the right side. In order to
relate these variables, we can use the general relationship between linear and angular
variables. First, we note that if the length of the string is 𝑙, then this is also the radius of

**Figure 129-4. A simple**

the circle that would be traced out by the bob. Therefore, the arclength and angle are

**pendulum including forces.**

related by

𝑑[�]𝑠
𝑠= 𝑙𝜃 → (129-14)
𝑑𝑡[�] [= 𝑙𝑑]𝑑𝑡[�][𝜃][�] [,]


-----

where the 𝑙 is a constant and is therefore not changed in the derivative. Since the pendulum bob would follow the arclength
as it moves, the second derivative of the arclength is the linear acceleration of the bob. Therefore, the x-component of
Newton’s 2[nd] law becomes

𝑑[�]𝜃

𝑔sin 𝜃= −𝑙 [𝑑][�][𝜃] → (129-15)

𝑑𝑡[�] 𝑑𝑡[�] [= −𝑔]𝑙 [sin 𝜃.]

There is no closed form solution to Equation 129-15. This equation does closely resemble Equation 129-6 for the massspring system, with the variable replaced with 𝜃; however, the fact that the right side of the equation is sin 𝜃 and not simply 𝜃
makes the equation unsolvable.
Luckily, there is an approximation that gives us the ability to solve this problem. For small angles, sin 𝜃≈𝜃. For the
sake of this course, we will take “small angle” to mean any angle less than approximately 30°. Regardless, if we use this
relationship, Equation 129-15 reduces to

𝑑[�]𝜃

(129-16)

𝑑𝑡[�] [= −𝑔]𝑙 [𝜃,]

which has solution

𝜃(𝑡) = 𝜃� 𝑐𝑜𝑠(𝜔�𝑡+ 𝜙). (129-17)

In Equation 129-17, 𝜃� is the amplitude of oscillation in terms of angle and

𝜔� = �[𝑔]𝑙 [.] (129-18)

Many of the properties of SHM we discussed for the mass-spring system hold true for simple pendulums. Here are a couple
of notes specific to this system

1) The angular frequency for pendulums does not depend on amplitude or mass,
2) The motion of a pendulum without using the small angle approximation still resembles SHM, however, the

frequency of oscillation is different than predicted above.


**Pendulum (small angles)**

𝜽(𝒕) = 𝜽𝟎 𝒄𝒐𝒔 (𝝎𝟎𝒕− 𝝓)

**Description – This equation describes the angular position of a**

function of time of a pendulum with amplitude, 𝜃�, angular
frequency, 𝜔�, and initial phase, 𝜙, at time 𝑡.
**Note 1: For a pendulum with length 𝑙 in gravitational field strength**

𝑔, 𝜔� = �𝑔𝑙⁄ .
**Note 2: This equation only holds for small oscillations.**


Example 129 - 3 **The seconds pendulum**

A standard grandfather clock works by using a pendulum
designed to swing with a period of one second. How long and
with what mass must such a pendulum be built?

**Solution:**

This is a direct application of our simple pendulum
discussion. In this case, we know that the period should be
one second, so

𝑇= [2𝜋]

𝜔 [= 2𝜋�𝑙]𝑔[.]


Since mass does not come into our equations for period,
it does not matter with what mass we build the pendulum.

**Be careful with this!** Many physics students feel the
period should depend on length and forget that it does
not!


Solving this equation for the length gives


𝑔= �[1 𝑠]

2𝜋[�]


𝑙= � [𝑇]

2𝜋[�]


�


�


(9.8 𝑁𝑘𝑔⁄ ) = 0.25 𝑚.


-----

#### 129-3 – Damped oscillations

**Consider: Why do oscillations get smaller in real life?**

Simple harmonic motion is actually quite rare in real life. A child on a swing will slowly come to a stop without pumping
her legs or being pushed. The vibrations of one point on a piano string will come to rest after some time, even if the key is
left pressed. In each case, some form of friction or drag comes into play and causes the amplitude of motion to decrease over
time. In order to see how this works, we must again go back to Newton’s 2[nd] law for a mass-spring system (Equation 129-6)
and include a linear drag term

𝑚𝑎= −𝑘𝑥−𝑏𝑣. (129-19)

This equation can be written in terms of displacement as


𝑑[�]𝑥

𝑚 [𝑑][�][𝑥] →

𝑑𝑡[�] [= −𝑘𝑥−𝑏𝑑𝑥]𝑑𝑡 𝑑𝑡[�] [= −𝑘]𝑚 [𝑥−𝑏]𝑚


𝑑𝑥

(129-20)
𝑑𝑡 [.]


This differential equation requires more detail to solve than what we saw for SHM above. To solve it analytically, we choose
a test function
𝑥(𝑡) = 𝑒 [��], (129-21)

and substitute this into the differential equation. If we do this, we find

𝑚𝜆[�] + 𝑏𝜆+ 𝑘= 0, (129-22)

which is a quadratic equation with solutions

𝜆= [−𝑏± √𝑏][�] [−4𝑚𝑘]. (129-23)

2𝑚

Therefore, a general equation for the solution to this equation is


±[�]�[�]����

�� �. (129-24)


𝑥(𝑡) = 𝑒


��±[�]�[�]����

� � [�]
�� = 𝑒 ��[�]𝑒


Here’s what really interesting - if the argument of the square root in the second
term is less than one, that term actually represents an oscillation! The math to
show how this works is a bit beyond what I want to go into at this point, but
the crux of the matter is that if the argument of square root is less than one, we
have an oscillation whose amplitude decreases over time. If the argument of
the square root is zero, we have an exponential decay, and if the argument of
the square root is greater than zero, we have an exponential decay that is less

**Figure 129-5. Underdamped oscillation.** steep than if it is zero. We describe each of these motions be defining a

**_damping ratio, 𝜒= 𝑏2√𝑚𝑘⁄_** . The damping ratio is unitless.

There are three possible results for 𝜒:

1) If 𝜒< 1, the system is **_underdamped and undergoes oscillation with an exponentially decreasing amplitude over_**

time,
2) If 𝜒= 1, the system is critically damped and undergoes exponential decay (does not oscillate),
3) If 𝜒> 1, the system is overdamped, and undergoes less steep exponential decay than 𝜒= 1.

Figure 129-5 shows an underdamped oscillation. It should also be noted that for an underdamped system, the angular
frequency of oscillation is given by 𝜔� = 𝜔��1 −𝜒[�].


-----

**Damping Ratio**

𝒃
𝝌=

𝟐√𝒎𝒌

**Description – The equation describes the damping ratio, 𝜒,**

of a damped mass-spring oscillator in terms of the
damping coefficient, 𝑏, the mass of the oscillator, 𝑚,
and the spring constant, 𝑘.
**Note 1: Overdamped: 𝜒> 1; critically damped, : 𝜒= 1;**

underdamped, : 𝜒< 1.
**Note 2: 𝜔�** = 𝜔��1 −𝜒[�]


Example 129 - 4 **Springs in water**

A 76.5-kg diving bell in water is attached to a spring with
stiffness 54.6 N/m. For this shape in water, 𝑏= 29.5 kg/s. If
the bell is pulled such that the spring is stretched and then
released, describe the subsequent motion.

**Solution:**

This problem is an application of damped harmonic
oscillation. In order to determine the type of behavior of this
system, we must find the damping ratio


which gives us

𝜒= 0.229.

Since the damping ratio is less than one, we know that
this motion is underdamped and will therefore undergo
oscillation with an exponentially decreasing amplitude.

The frequency of oscillation for underdamped systems is
given by

𝜔� = 𝜔��1 −𝜒[�],

with 𝜔� = �𝑘𝑚⁄ for mass-spring systems. Therefore

⁄
𝜔� = �[54.6 𝑁𝑚]76.5 𝑘𝑔 [�1 −0.229][�] [= 0.82 𝑟𝑎𝑑]𝑠 [.]


𝑏
𝜒=

2√𝑚𝑘


.


Using values from the problem, we find

29.5 kg/s
𝜒=

2�(76.5 𝑘𝑔)(54.6 𝑁/𝑚)


,


#### 129-4 – Forced, damped oscillations

**Consider: Why does pumping your feet on a swing make you go**
higher?

Imagine you hold a spring in your hand with a mass hanging from the end. If you move your hand up and down with the
objective of getting the mass to move up and down, something interesting happens – at certain frequencies, no energy is
transferred to the mass, at some frequencies the mass moves a little and at one frequency the mass almost jumps off the
spring holding it! The same thing happens when a child is swinging on a swing set – if the child pumps her legs at the correct
rate (frequency), she goes higher. If she does not pump her legs efficiently, she may only go to a low height, or her motion
may continue to die out as damped motion.
The situations described above are examples of forced, damped harmonic oscillations – that is, they are real systems with
damping that are forced with a specific frequency. Mathematically, we can write this as

𝑚 [𝑑][�][𝑥]

𝑑𝑡[�] [+ 𝑘𝑥+ 𝑏𝑑𝑥]𝑑𝑡 [= 𝐹][�] [cos�𝜔][�][𝑡�][.] (129-26)


-----

The general solution to this equation is quite complicated because it includes both a transient initial solution which depends
on the initial position and velocity of the oscillation, and a steady state, long-term solution. If we consider just the steady
state solution, we find

𝑥(𝑡) = 𝐴�𝑐𝑜𝑠(𝜔�𝑡−𝜙) (129-27)

where


𝐹�⁄𝑚
𝐴� =

��𝜔�� −𝜔���� + �𝑚𝑏 [�]


�


𝜔��


,
(129-28)


is a frequency-dependent amplitude, and 𝜔� is the frequency of the forcing function. We will not worry about the phase
shift, 𝜙 in Physics I.


**Forced-Damped Motion**

𝒙(𝒕) = 𝑨𝒇𝒄𝒐𝒔(𝝎𝒇𝒕)

**Description – The equation describes the steady state**

solution of a forced-damped harmonic oscillator with
forcing function 𝐹� sin(𝜔�𝑡).
**Note 1: 𝜔� is the angular frequency of the driving force.**

**Note 2: 𝐴�** = ��⁄�� �

����[�]����� ���[�] [�] ���


The amplitude in Equation 129-26 can be maximized by minimizing
the denominator. This happens when the forcing frequency is equal to
the natural frequency of oscillation of the system. When this condition
is met, the system is said to be in resonance.
Systems which are in resonance can have very large amplitudes of
oscillation, especially if the system damping is small. One great
example of this is the Tacoma Narrows Bridge collapse, shown in
Figure 129-6. On November 7[th], 1940 winds through the Narrows
reached approximately 40 mph, which set up a resonant condition with
the deck of the bridge. As described above, the amplitude of
oscillation continued to grow until it reached an untenable level for the
bridge, which then collapsed. To be fair, it should be noted that the
type of vibration the bridge endured, now called aeroelastic fluttering,
had never been seen before. In this fluttering effect, not only did the
wind effectively transfer energy to the bridge, but also caused a motion **Figure 129-6. Collapse of the Tacoma Narrows**
that dropped damping in the bridge to near zero. In Physics II, you will **Bridge.**
learn about modes of vibration. The Tacoma Narrows bridge went
through a torsional vibrational oscillation where the middle of the bridge did not move (called a second harmonic), but where
positions at ¼ and ¾ along the bridge moved with devastating effects.


-----

Example 129 - 5 **How big an oscillation**

A 18.5-kg mass is to oscillate while attached to a spring with
a stiffness of 52.2 N/m. If the system is forced by a drive
with a maximum force of 200 N at 1.92 rad/s, what is the
amplitude of oscillation of the system? You may assume that
the system is essentially frictionless.

**Solution:**

This problem is a direct application of a forced, damped
harmonic oscillator. In this case, we know that the damping
is essentially zero, so the equation for the amplitude of the
system reduces to


⁄

𝜔� = [�𝑘]𝑚 [= �52.2 𝑁𝑚]18.5 𝑘𝑔 = 1.68 𝑟𝑎𝑑𝑠.⁄

We can now use information from the problem directly in
the equation for amplitude


𝐴� =


(200 𝑁) (18.5 𝑘𝑔)⁄

�(1.68[�] −1.92[�])[�] [,]


𝐹�⁄𝑚
𝐴� =

��𝜔�� −𝜔����


.


In order to determine this amplitude, we need to know the
natural angular frequency of the system


which gives

𝐴� = 12.5 𝑚.

Now, with no damping, the maximum possible amplitude
is extremely large (technically undefined at resonance).
Even so, 12.5 m is a large amplitude for many
applications.


-----

