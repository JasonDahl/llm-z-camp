### – Potential Energy Diagrams and
## 107

### Elastic Potential Energy


_In this unit, we will first describe ways to visualize the potential energy stored in an object as a function of position,_
_known as a potential energy diagram. Conceptually, you can view this as how much gravitational potential energy does_
_an object have as it moves up and down hills on a landscape – however, this reasoning works for all types of potential_
_energy. The second half of this unit is dedicated to a new type of potential energy that occurs when springs are stretched_
_or compressed – an type of stored energy called elastic potential energy._


##### The Bare Essentials

- **_Potential energy diagrams allow you to visualize how the_**

potential energy of an object changes with position.

- If the total energy of an object is included on a potential energy
diagram, we can determine where the object is allowed to be in
space as well as how its speed to change at different placed.
This comes about from the knowing the total energy, potential
energy and conservation of energy:

𝐾𝐾(𝑥𝑥) = 𝐸𝐸−𝑈𝑈(𝑥𝑥).

- **_Elastic potential energy is stored whenever a spring (or_**
anything else stretchy for that matter) if displaced from
equilibrium.



- In equations related to the elastic potential energy, 𝒌𝒌𝒔𝒔 is

known as the stiffness or spring constant and has units of
either 𝑱𝑱/𝒎𝒎[𝟐𝟐] or 𝑵𝑵/𝒎𝒎.

- Bonds between atoms act like springs around their
equilibrium positions, which leads to stored energy
resembling that of a spring.

- We can now solve conservation of energy problems
including
  - Kinetic energy
  - Gravitational potential energy
  - Elastic potential energy


**Elastic Potential Energy**

𝑼𝒔𝑼 𝒔 = [𝟏]
𝟐𝟐 [𝒌][𝒌][𝒔][𝒔][|𝒙][��⃗−𝒙][𝒙] [��⃗][𝒙][𝟎][𝟎][|][𝟐][𝟐]

**Description – This equation describes the elastic potential**

energy of a system, 𝑈𝑠𝑈 𝑠, in terms of the stiffness (spring
constant), 𝑘𝑘𝑠𝑠, and the displacement from equilibrium,
𝑥𝑥 −𝑥0𝑥 .
**Note 1: This equation holds for any system storing energy**

according to the linear version of Hooke’s law.
**Note 2: We often try to set up a coordinate system so that**

𝑥0𝑥 = 0.




-----

#### 107.1 – Potential Energy Diagrams

**Consider: How can we visualize potential energies that vary in space?**

RAVITATIONAL POTENTIAL ENERGY, as introduced in unit 106, is the first of many types of potential energy
that we will introduce – it is also one of the easiest to understand since we are immersed in gravity all of the time.
For most objects that we directly interact with in our everyday lives, the 𝑈𝑈𝑔𝑔 = 𝑚𝑚𝑚𝑚𝑚𝑚 approximate works very well.

# G

Imagine going on a long walk on a hilly terrain – as you walk up a
hill, your gravitational potential energy increases, and when you walk
down a hill, your gravitational potential energy decreases.
When you walk up and down a hill, there is quite a bit more
going on than just changes in gravitational potential energy and
kinetic energy; there is also chemical energy conversion in your
body, friction, etc., all of which makes the system complicated. So,
now let’s just consider a ball rolling up and down in a near circular
depression, such as shown in figure 107-1.
In figure 107-1, the line labeled U(x) represents the potential
energy as a function of position (along the x-axis in this case). One
of the great things about gravitational potential energy is that you can
visualize the potential energy of a system as hills, and think about
how an object would react to that potential energy as what a ball **Figure 107-1. A potential energy diagram**
would do if placed on the hill. **representing a near circular depression between**

**two flat areas. E represents the total energy of the**

Let’s now assume that we place a ball at position 𝑥𝑥1. If we just **system, U(x) is the gravitational potential energy.**
place the ball there, so that its kinetic energy is zero, then the total
energy of the ball is

𝐸𝐸= 𝐾𝐾+ 𝑈𝑈= 0 + 𝑈𝑈= 𝑈𝑈. (107-1)

When the ball is released, we would expect it to roll down the hill to the bottom. At the bottom of the hill, it doesn’t just stop
though, since it has some speed there, it will continue on and move up the hill on the right side. Since the total energy of the
system does not change, what is happening throughout this process is that potential energy is converted to kinetic energy as
the ball rolls down the hill. Again look at figure 107-1. At the bottom of the trough, the potential energy is still not zero;
however, its it is at its lowest point, the kinetic energy will be at its maximum, meaning that this is where the ball will be
moving the fastest.
Since the ball has kinetic energy at the very bottom, it will continue passed the maximum point and start to roll back up
the other side. Assuming that no energy is lost from the system, the ball will make it all the way up to the same height that it
was when it was released (noted by 𝑥𝑥2 in figure 107-1). Analyzing a system with the use of a potential energy diagram as we
just did can be a very powerful way to understand the dynamics of a system.
We will now take a deeper look at some of the features of potential energy (PE) diagrams. All PE diagrams have
potential energy on the y-axis and position on the x-axis, as can be seen in Figure 107-1. The potential energy of the system,
𝑈𝑈(𝑥𝑥), is then plotted across the graph. The total energy, 𝐸𝐸, of a particle is often written as a straight line across the diagram,
since the total energy will not change. The kinetic energy will also be a function of position, and although it is not directly
plotted on the diagram, we can determine the kinetic energy from the conservation of energy as

𝐾𝐾(𝑥𝑥) = 𝐸𝐸−𝑈𝑈(𝑥𝑥). (107-2)

Now, consider the Region I, to the left of 𝑥𝑥1, and Region III, to the right of 𝑥𝑥2 in Figure 107-1. For a particle to be
present in these regions, its potential energy would be larger than its total energy. In this case, equation 107-2 tells us that the
kinetic energy would be negative – which is impossible. Therefore regions like this, where the potential energy is larger than
the total energy are called forbidden zones; we will never find a particle at these positions. All other regions, such as Region
II in Figure 107-1 are known as allowed zones and represent areas where the particle can be found with kinetic energy given
by equation 107-2. Points x1 and x2 are called turning points, because if a particle were approaching these positions, they
would turn around as to not enter a forbidden zone.
Places where the total energy line, E, and the potential energy function, U(x), intersect are called turning points, because
these are places where the kinetic energy is zero, and the particle will turn around. In our gravitational potential energy
analogy (a ball on a hill), the turning points are where a ball rolling up a hill will come to a stop and start rolling back down
the hill in the other direction.


-----

Potential energy diagrams can be used both to qualitatively understand the way a system will progress as well as
quantitatively to calculate kinetic, potential and total energies (and related quantities). The examples below show how this
works.


Example 107 - 1 **Example Problem**

Consider the potential energy diagram shown below.

If the total energy, 𝐸𝐸, of a particle is directly in the middle of
the energy range shown by 𝐸𝑏𝐸 𝑏, are positions x A, xB and xC
each in an allowed region, forbidden region, or on the border
between the two?


**Solution:**

In a potential energy diagram, the allowed regions are
where the kinetic energy will be positive as given by

𝐾𝐾(𝑥𝑥) = 𝐸𝐸 −𝑈𝑈(𝑥𝑥).

In other words, allowed regions are where the total
energy is larger than the potential energy.

x A: At this point, the total energy is greater than the
potential energy so this is an allowed point.

xB: At this point, the total energy is less than the potential
energy so this is a forbidden point.

xC: at this point, the total energy is greater than the
potential energy so this is an allowed point.


Extension

Note: Even though points x A and xC are allowed, a particle
would not be able to transverse between them since it would
need to go through a forbidden region.


Example 107 - 2 **Example Problem**

Consider, again, the potential energy diagram from example
107-1:

In this problem, the top of range 𝐸𝑏𝐸 𝑏 is 15 J and the bottom of
the range is 7 J. Points x A, xB and xC are at 0.50, 1.00 and
1.20 meters, respectively. If a particle with a mass of 11 kg
has a total energy of 11 J, what is its potential energy, kinetic
energy and speed at point x A? How will its speed change if it
moves away from point x A ?


**Solution:**

We know that at point xA, the particle has 7 J of potential
energy since the potential curve is at the lower range of
𝐸𝑏𝐸 𝑏 at this point. We can then find the kinetic energy of
the particle using

𝐾𝐾(𝑥𝑥) = 𝐸𝐸 −𝑈𝑈(𝑥𝑥) = 11 𝐽𝐽 −7 𝐽𝐽 = 4 𝐽𝐽.

Therfore, the particle has 4 J of kinetic energy at this
point. We can now use the classical equation for kinetic
energy to find the speed of the particle at this point

𝐾𝐾 = [1] ⁄ .
2 [𝑚][𝑚][𝑣][𝑣][2][  →  𝑣][𝑣] [= ][�2𝐾]𝑚𝑚 [= ][�2(4 𝐽]11 𝑘𝑘𝑘[𝐽][)]𝑘 [= 0.85 𝑚][𝑚] [𝑠]

Finally, if the particle were to move in either direction
from x A, its potential energy would increase (until it
reaches xB) and since its total energy is constant its
kinetic energy, and therefore speed, would decrease
according to Equation 107.2.


-----

#### 107.2 – Hooke’s law

**Consider: How does a spring work?**

The second type of potential energy that we will look at in-depth is elastic potential energy,
which is energy stored in a system when one or more objects are deformed. The classic
system to think of elastic potential is a mass on a spring as shown in Figure 107-2, although
elastic energy has applications for atomic and molecule bonds, earthquakes and a host of
other systems.
What happens when you stretch a mass on a spring? As can be seen in Figure 107-2,
the mass is pulled back towards its resting position by the spring. Similarly, if we were to

**Figure 107-2. A mass on a**

compress the spring, the spring would push the mass back towards it resting position. Such

**spring to demonstrate**

a pull/push system is known as a restoring force, because the spring is always pushing the

**Hooke’s law.**

mass back towards its resting position, which is more precisely known as its **_equilibrium_**
**_position, 𝑥𝑥0._**
We can represent our restoring force with Hooke’s law, named after 17[th] century physicist Robert Hooke:

(107-3)
𝐹𝐹[⃗]𝑠𝑠 = −𝑘𝑘𝑠𝑠(𝑥𝑥⃗−𝑥𝑥⃗0).

In equation 107-3, 𝐹𝐹[⃗] is the elastic force (the s here stands for spring), 𝑥𝑥⃗ is the position of the particle, 𝑥𝑥⃗0 is the equilibrium
position of the particle, and 𝑘𝑘𝑠𝑠 is the stiffness of the system (the spring in our example). 𝑘𝑘𝑠𝑠 is often called the **_spring_**
**_constant, and has units of either_** 𝐽𝐽/𝑚𝑚[2] or 𝑁𝑁/𝑚𝑚. The minus sign in Equation
107-3 represents how the direction of the force is always opposite the direction
of displacement from equilibrium, i.e. that the force is always directed towards
the equilibrium position.
A couple of notes about Hooke’s law:


1) Often, we attempt to set up our coordinate system so that the
equilibrium position of the system is at 𝑥𝑥⃗0 = 0, so that Hooke’s law
can be written
(107-4)
𝐹𝐹[⃗]𝑠𝑠 = −𝑘𝑘𝑠𝑠𝑥𝑥⃗.

2) The linear version of Hooke’s law presented is very useful, but is
actually an approximation of a generalized Hooke’s law, which can be
written (for one dimension)

𝐹𝐹𝑠𝑠 = −𝑘𝑘1𝑥𝑥−𝑘𝑘2𝑥𝑥[2] −𝑘𝑘3𝑥𝑥[3] + ⋯. (107-5)

3) Hooke’s law is only applicable over a certain range of values for the
displacement, 𝑥𝑥⃗. At extreme deformations, a spring will no longer
return to its original shape and Hooke’s law does not hold. Similarly,
when generalizing this law to other systems, large deformations
change the system, such as the ionization of molecules when
discussing atomic bonds, or earthquakes when discussing elastic
energy in the earth. Unfortunately, there is no set way to know where
this limit is – it depends completely on the specific situation. This
situation is shown in Figure 107-3.


**Figure 107-3. The force required to**
**maintain a given compression or extension**
**of a spring. Note the non-linear nature far**
**from equilibrium.**


Example 107 - 3 **Spring constants**

What is the spring constant, 𝑘𝑘𝑠𝑠 of a spring that is extended
0.41 meters when pushed by a force of 9.1 N?

**Solution:**

This problem is a one-dimensional direct application of
Hooke’s law, so we start with the equation 107-4:


𝐹𝑠𝐹 𝑠 = −𝑘𝑘𝑠𝑠𝑥𝑥 → 𝑘𝑘𝑠𝑠 = − [𝐹] ⁄ .

𝑥𝑥 [= −9.1 𝑁]0.41 𝑚𝑚 [= −22 𝑁][𝑁] [𝑚]

Note that the negative just states that the direction of the
force attempting to restore the spring to equilibrium is in
the opposite direction to the displacement of the spring.


-----

We will explore Hooke’s law in detail in unit 129. We will also show how this can be generalized to stresses and strains
in solids in unit 130. However, this physical picture that Hooke’s law gives us for elastic potential energy is important to
visualize for the remainder of the units, which is why it was introduced now. Whether it be a mass on a spring, an atomic
bond, or stored energy leading to earthquakes, this energy is all about how far from equilibrium a system reaches.

#### 107.3 – Elastic Potential Energy

**Consider: How much energy can a spring store?**

When a force acts through a distance some energy must be transferred from one object to another within the system or even
into or out of the system itself. In unit 110, we will call this energy transfer mechanical work, 𝑊𝑊. If all of the energy stays
within the system, the energy transferred can be stored in the system as potential energy, and can be found as


𝑥𝑥

𝑈𝑈(𝑥𝑥) = −𝑊𝑊= −�𝐹𝐹[⃗](𝑥𝑥⃗) ⋅𝑑𝑑𝑥𝑥⃗

𝑥𝑥0


(107-6)
.


Although we will explore the details of this later in the book, we will now use this definition to see how Hooke’s law leads to
energy storage as elastic potential energy.
In order to understand the process as its basic level, we will do the calculation in one dimension. Keep in mind that if
you have more than one dimension, the contributions of each dimension just add to each other (since an integral is really just
a summation over many small parts). In one dimension, Hooke’s law and the equation for potential energy from force
(equation 107-4) are
𝐹𝐹𝑠𝑠 = −𝑘𝑘𝑠𝑠(𝑥𝑥−𝑥𝑥0)   and   𝑈𝑈(𝑥𝑥) = −∫𝐹𝐹(𝑥𝑥) 𝑑𝑑𝑑𝑑. (107-7)

Substituting Hooke’s law into the potential energy equation, gives us

𝑥𝑥

𝑈𝑈𝑠𝑠(𝑥𝑥) = −�−𝑘𝑘𝑠𝑠(𝑥𝑥−𝑥𝑥0)𝑑𝑑𝑑𝑑. (107-8)

𝑥𝑥0


In order to solve this, we must do a u-substitution with 𝑢𝑢= 𝑥𝑥−𝑥𝑥0 and 𝑑𝑑𝑑𝑑=
𝑑𝑑𝑑𝑑 First taking the antiderivative gives us

𝑈𝑈𝑠𝑠(𝑥𝑥) = −�−𝑘𝑘𝑠𝑠𝑢𝑢𝑢𝑢𝑢𝑢= [1] (107-9)

2 [𝑘𝑘][𝑠𝑠][(𝑢𝑢)][2][.]

We can now rewrite this equation in terms of x, and insert the limits from our
original integral, giving us

(107-10)

𝑈𝑈𝑠𝑠(𝑥𝑥) = [1]

2 [𝑘][𝑘][𝑠][𝑠][(𝑥][𝑥] [−𝑥][0][𝑥] [)][2][.]


**Figure 107-4. Elastic potential energy curve**
**for a spring with ks = 1 N/kg.**


**Elastic Potential Energy**

𝑼𝒔𝑼 𝒔 = [𝟏]
𝟐𝟐 [𝒌][𝒌][𝒔][𝒔][|𝒙][��⃗−𝒙][𝒙] [��⃗][𝒙][𝟎][𝟎][|][𝟐][𝟐]

**Description – This equation describes the elastic potential**

energy of a system, 𝑈𝑠𝑈 𝑠, in terms of the stiffness (spring
constant), 𝑘𝑘𝑠𝑠, and the displacement from equilibrium,
𝑥𝑥 −𝑥0𝑥 .
**Note 1: This equation holds for any system storing energy**

according to the linear version of Hooke’s law.
**Note 2: We often try to set up a coordinate system so that**

𝑥0𝑥 = 0.


-----

Example 107 - 4 **Compressing a spring**

Imagine a spring with stiffness 35 𝐽𝐽/𝑚𝑚[2] and a resting length
of 5.6 cm. If it is compressed to half its resting length, how
much elastic potential energy is stored by the spring?

**Solution:**

This is a direct application of the equation for elastic potential
energy with 𝑘𝑘𝑠𝑠 = 35 𝐽𝐽/𝑚𝑚[2], 𝑥𝑥(0) = 0 (call the zero point of
potential the equilibrium position), and 𝑥𝑥 = 0.028 𝑚𝑚.


Therefore

𝑈𝑠𝑈 𝑠 = [1] [𝐽]
2 [𝑘][𝑘][𝑠][𝑠][(𝑥][⃗−𝑥][𝑥] [⃗][0][𝑥] [)][2][ = 1]2 [�35] 𝑚𝑚[2][�(0.028 𝑚][𝑚][)][2][,]

which gives us a stored energy of

𝑈𝑠𝑈 𝑠 = 0.013 𝐽𝐽.


Now that we know the mathematical form for elastic potential energy, we are ready to solve conservation of energy problems
including kinetic energy, gravitational potential energy and elastic potential energy. Carefully examine the following
examples as they help to illustrate some possible shortcuts in solving such problems. Again, keep in mind, as always, that we
need terms representing gravitational and elastic potential energy between any possible pairs of objects as well as kinetic
energy terms for each object in the system. Be careful to not miss terms!


Example 107 - 6 **Example Problem**

Imagine that a 2.05-kg block is sliding across a horizontal,
frictionless surface at 9.12 m/s, The block strikes a spring
with stiffness 91.0 N/m. What is the maximum compression
of the spring?

**Solution:**

This is a direct application of the conservation of energy
including elastic potential and kinetic energy. Since there is
no change in height, we do not have to consider gravitational
potential energy. Therefore

Δ𝐸𝐸 = Δ𝐾𝑏𝐾 𝑏 + Δ𝑈𝑠𝑈 𝑠 = 0.

In this initial situation, the block has kinetic energy (𝐾𝑏𝐾 𝑏,𝑖𝑖);
however, the spring in uncompressed (𝑈𝑠𝑈 𝑠,𝑖𝑖 = 0). In the final
situation, the spring is compressed to its maximum (𝑈𝑠𝑈 𝑠,𝑓𝑓),
meaning that the block will be at rest (𝐾𝑏𝐾 𝑏,𝑓𝑓). So,


Δ𝐸𝐸 = 𝐾𝑏𝐾 𝑏,𝑓𝑓 −𝐾𝑏𝐾 𝑏,𝑖𝑖 + 𝑈𝑠𝑈 𝑠,𝑓𝑓 −𝑈𝑠𝑈 𝑠,𝑖𝑖 = −𝐾𝑏𝐾 𝑏,𝑖𝑖 + 𝑈𝑠𝑈 𝑠,𝑓𝑓 = 0.

We can now substitute in terms for kinetic and potential
energy and solve for the final compression:

− [1] 2 + [1] 2 = 0  →  𝑥𝑓𝑥 𝑓 = �[𝑚]
2 [𝑚][𝑚][𝑣][𝑖][𝑣] 2 [𝑘][𝑘][𝑥][𝑓][𝑥] 𝑘𝑘 [𝑣][𝑖][𝑣] [𝑖][.]

Using numbers from the problem, this gives us

𝑥𝑓𝑥 𝑓 = �91.0 𝑁[2.05 𝑘]𝑁⁄[𝑘][𝑘]𝑚 (9.12 𝑚𝑚⁄ ) = 1.37 𝑚𝑠 𝑚.

Please note that 1.37 m seems like a large compression
for a spring; however, no scale was given in this problem.


Example 107 - 7 **Example Problem**

In an unusual physics experiment, a 1200-kg car is placed
such that it compresses a spring with stiffness 2.12 𝑥𝑥 10[5] 𝑁𝑁/
𝑚𝑚, 2.5 meters from its resting position. If released how far
(vertically) could this car travel up a hill before coming to
rest?

**Solution:**

Similar to the previous problem, this example is an
application of the conservation of energy including elastic
potential energy and gravitational potential energy. At both
the initial and final positions, the car is not moving, so kinetic
energy can be neglected. Therefore,


Δ𝐸𝐸 = Δ𝑈𝑔𝑈 𝑔 + Δ𝑈𝑠𝑈 𝑠 = 0.

In this case, we can set the zero-point of energy at the
bottom of this hill such that the initial potential energy is
zero. In the final situation, the elastic energy is zero, so

𝑚𝑚𝑚𝑚ℎ𝑓𝑓 − [1]2[𝑘][𝑘][𝑥][𝑖][𝑥]2 = 0  →  ℎ𝑓𝑓 = 2𝑚𝑘 𝑚𝑚𝑚 [𝑥][𝑖][𝑥]2.

Using values from the problem, we find

2.12𝑥𝑥10[5] 𝑁𝑁⁄𝑚
ℎ𝑓𝑓 = 2(1200 𝑘𝑘𝑘𝑘)(9.8 𝑁𝑁⁄𝑘𝑘𝑘𝑘) (2.5 𝑚𝑚)[2] = 56 𝑚𝑚.


-----

#### 107.4 – Atomic Bonds and Solids as Springs

**Consider: How do springs relate to atomic bonds?**

When atoms are locked together in a solid (see Unit 108), the interaction
of the atoms with each other can be modeled as a set of masses (atoms)
connected by springs (atomic bonds). Although this model may seem
crude at first, it gives surprisingly good results related to how solids react
to temperature changes, and external pressures. Just as masses on
springs will vibrate if they are pulled from equilibrium and released, so
do the atoms inside a solid – and since they are locked into the solid
lattice, the “springs” even stay within the safe zone that can be modeled
as a linear, Hooke’s law spring.
This model, shown in Figure 107-5, is called an Einstein solid. Each
atom in the solid is connected to others by a specific number of atomic
bonds, represented as that same number of springs. The number depends
on the crystal structure of the solid. Figure 107-5 shows a cubic
structure; however, this is only one of many possible arrangements.  In **Figure 107-5. An Einstein solid model showing**
an Einstein solid, it is assumed that all atoms and springs are the same, **atomic bonds as springs.**
leading to the same spring constant and frequency of vibration for all
particles.
Although the Einstein solid is the easiest mass-spring atomic model to visualize, similar models are used for other
molecule systems. Take, for example, diatomic molecules, such as oxygen or carbon monoxide. Each of the two atoms in a
molecule can be modeled as a mass connected by a single spring, representing the molecular bond. A very simplistic
interpretation of such a system might have a harmonic potential energy curve, such as shown in Figure 107-4. In reality, the
potential energy curve of the molecule is more complicated, and not symmetric. Figure 107-6 shows the Morse Potential,
one of the leading potential energy curves used to analyze diatomic molecules. In this figure, both a pure harmonic potential
and the more complicated Morse potential are shown. The r value shown in Figure 107-5 represents the distance of
separation of the centers of mass of the two atoms in the molecule, and the specific value of re is the equilibrium distance.
Due to quantum-mechanical effects, the two atoms are never at rest relative to each other, but rather vibrate with a
characteristic frequency that depends on the
strength of the molecular bond, just as the
reaction of masses on springs is based on the
strength of the spring connecting the mass
(the spring constant). Comparing the
harmonic potential and Morse potential in
Figure 107-6, you can see that the Morse
potential more closely resembles a harmonic
potential when the atoms are close to each
other. However, at larger separations, the
two potentials deviate; this can be related to
overstretching of a spring leading to its
deformation. In the case of the Morse
potential, this happens as the two atoms
approach a separation which allows them to
be liberated from each other – which
happens at an energy called the dissociation
**_energy._**
The key here is that we can apply
everything we know about potential energy
curves to the Morse potential. Areas where
the potential energy is low, such as near the
equilibrium separation, are where the atoms
are moving at the greatest speeds relative to
each other. Areas where the potential energy
are high are where the atoms are moving **Figure 107-6. The Morse potential and how it deviates from a simple elastic**
slow and will tend to change their directions **(harmonic) potential energy system.**
(turning points).


-----

A final interesting thing to note about Figure 107-6 is the specific energy levels shown on both the harmonic and Morse
potentials. In quantum mechanics, the energies which can be physically maintained within bound systems is quantized,
meaning that the energies must be at discrete levels (labeled as 𝜈𝜈= 1, 𝜈𝜈= 2, and so on in the diagram) and not just any
value. In classical mechanics, we treat the energy as a continuum and allow it to take on any value it wants. So, in the
quantum mechanical model of diatomic molecules, the vibrational energy of the atoms must be one of a specific set of values
and changing the energies, known as spectral changes, must be done in packets. This is why atomic and molecule spectra
you may have seen in chemistry come in discrete lines and not smeared out over a large range of values.
We will study more of quantum mechanics in Physics II, but for now, this should give a quick introduction and
comparison to the classical elastic potential energy studied in this unit.


-----

