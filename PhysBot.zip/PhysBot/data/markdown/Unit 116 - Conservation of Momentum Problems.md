### – Conservation of Momentum
## 116

###  Problems


_In Unit 115, we discussed how the conservation of momentum can be used to solve many types of collision problems. In_
_Unit 116, we extend this discussion to multiple dimensions. Since momentum is a vector, the extension to many_
_dimensions turns a scalar collision equation into a vector equation. In addition, we will explore the effects of collisions_
_on the human body as well as how rockets can increase their momentum in space where there is nothing to ‘push’_
_against._


##### The Bare Essentials

- The conservation of momentum for collisions can be utilized

using the vector nature of momentum.



- Rockets use the conservation of momentum to increase the

forward motion of a rocket by offsetting the motion of fuel
exhaust in the opposite direction.


∆𝑝⃗= �


∆𝑝�
∆𝑝�
∆𝑝�


�= �


0
0
0


�



- When humans undergo a collision, the effects depend on both

the strength of the collision, the time of the collision and the
orientation of the body relative to the collision.

- Human effects related to collisions (and acceleration in

general) are measured using g-forces or g’s, where

𝑔[�]𝑠= [𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛 𝑖𝑛 𝑐𝑜𝑙𝑙𝑖𝑠𝑖𝑜𝑛]

9.8 𝑚𝑠⁄ [�]


**Rocket Equation**

𝑴
𝚫𝒗= 𝒗𝒆 𝐥𝐧�𝑴−𝒎𝒆�


**Description – This equation describes the change in**

speed of a rocket, ∆𝑣, as a mass, 𝑚�, of fuel is ejected.
M is the original mass of the rocket/fuel system.
**Note: This equation only works for non-relativistic**

speeds.


-----

#### 116.1 – Collisions in multiple dimensions

**Consider: How do you solve collision problems in multiple**
dimensions?

LTHOUGH WE DEFINED THE CONSERVATION of momentum for collisions in Unit 115 as terms of a vector
equation, all of our examples only considered one-dimensional interactions. Our first goal in Unit 116 is extend this
discussion to multiple dimensions. Explicitly, we can write the conservation of momentum equation for collisions,

# A

∆𝑝⃗= 0, (116-1)

in column vector form as

∆𝑝� 0

∆𝑝⃗= �∆𝑝��= �0�. (116-2)

∆𝑝� 0


In general, the collision of more than two objects can be inherently three-dimensional. However, the collision between
two objects can always be written in just two dimensions since two vectors, 𝐴[⃗] and 𝐵[�⃗] define a plane with a normal unit vector,
𝑛�⃗, given by

𝑛�⃗= [𝐴⃗𝑥𝐵�⃗] . (116-3)

�𝐴[⃗] 𝑥𝐵[�⃗]�

Remember, that the cross product of any two vectors is always perpendicular to both vectors; therefore, equation 116-3
defines a vector that is perpendicular to both A and B, which is how we define the normal vector of a plane (perpendicular to
the surface of the plane). With this in mind, we can always write the conservation of momentum equation for two colliding
objects with one of the ∆𝑝′𝑠 equal to zero.
As a quick example, imagine we want to write the momentum of a 1.2-kg object traveling at 5.8 m/s with a direction 22°
north of east. We can start out with the vector equation for momentum and write it out in terms of components as


∆𝑣�

�= 𝑚�∆𝑣�

∆𝑣�


∆𝑝⃗= �


∆𝑝�
∆𝑝�
∆𝑝�


�= �


m∆𝑣�
m∆𝑣�
m∆𝑣�


�. (116-4)


If we now set east as the positive x-axis and north as the positive y-axis, we can fill in this momentum as


∆𝑝⃗= 1.2 𝑘𝑔�


(5.8 𝑚𝑠⁄ ) cos 22°
(5.8 𝑚𝑠⁄ ) sin 22°

0


�= �


6.5
2.6

0


�𝑘𝑔∙𝑚𝑠⁄ . (116-5)


This vector form of the momentum could then be combined with the momentum of other objects in the conservation of
momentum equation. The following examples will help to elucidate how this process is done.


Example 116 - 1 **Orthogonal two dimensional collision**

Imagine that two identical, 1500-kg cars collide at a city
intersection where the traffic light malfunctioned. One of the
cars was traveling 20 m/s north and the other was traveling 15
m/s east. If the cars stick together, what is the final velocity
of the tangled mess just after the collision?

**Solution:**

This problem asks us to use the conservation of momentum to
solve for the final velocity of a collision. For a _completely_
_inelastic collision, we can use equation 115-5 (in vector form)_
to write


𝑣⃗� = [1]2 [�]


�= �


m�v�⃗�,� + 𝑚�𝑣⃗�,� = (𝑚� + 𝑚�)𝑣⃗�.

Using our known values, we get


15 𝑚𝑠⁄

1500𝑘𝑔� 0

0


�+ 1500𝑘𝑔�


0
20 𝑚𝑠⁄
0


�= (3000 𝑘𝑔)𝑣⃗�.


The 1500 kg can be factored out of each term on the left
side, which allows us to find


15 𝑚𝑠⁄
20 𝑚𝑠⁄
0


7.5 𝑚𝑠⁄
10 𝑚𝑠⁄
0


�.


-----

Extension:

Although the answer given above is a perfectly valid way to
represent a final velocity, we can also find this in magnitude
angle form. The magnitude of the velocity (speed) is

𝑣= �(7.5)[�] + (10)[�] 𝑚𝑠= 12.5 𝑚𝑠⁄ ⁄ .

The angle can be found using the inverse tangent function


𝜃�→� = tan[��] 7.5 [10] [= 53°.]

Therefore, the mass of two cars leaves the collision at
12.5 𝑚/𝑠, 53° north of east. Again, remember that either
of these forms is a perfectly valid way to represent the
final velocity.


Example 116 - 2 **2-D Collision**

A 2.3-kg particle moving 36 m/s at an angle 30° north of east
collides with an 8.1-kg particle moving 23 m/s at an angle 23°
north of west. If the 2.3-kg particle has a final velocity of 45
m/s directly north, what is the final velocity of the 8.1-kg
particle?

**Solution:**

This problem asks use to the use the conservation of
momentum in multiple dimensions to find the final velocity of
a particle. In order to do this, let’s first find the initial and
final momentum of the particles we know.


where the units of all brackets are 𝑘𝑔∙𝑚𝑠⁄ . Solving for
𝑝⃗��, we get

−99.8

𝑝⃗�� = � 10.7 �𝑘𝑔∙𝑚𝑠⁄ .

0

Finally, we can find the velocity as


∆𝑝⃗� + ∆𝑝⃗� = 0,

which gives us


0

��103.5

0


−171.5

��+ �𝑝⃗�� −� 72.8

0


�−�


71.7
41.4

0


��= 0,


71.7

�𝑚𝑠⁄ = �41.4

0


𝑝⃗�� = 2.3𝑘𝑔�


36 cos 30°

36 sin 30°

0


�𝑘𝑔∙𝑚𝑠⁄,


0
103.5

0


𝑣⃗�� = [𝑝⃗]𝑚[��]�


−12.3

1.32

0


�𝑚𝑠⁄ .


𝑝⃗�� = 2.3𝑘𝑔�


0
45�𝑚𝑠⁄ = �

0


�𝑘𝑔∙𝑚𝑠,⁄


= �


Again, this is a perfectly fine way to report a vector;
however, in magnitude/angle form the final velocity is
12.3 m/s at an angle of 6.1° north of west.


𝑝⃗�� = 8.1𝑘𝑔�


−23 cos 23° −171.5

23 sin 23° �𝑚𝑠⁄ = � 72.8

0 0


�𝑘𝑔∙𝑚𝑠⁄ .


We can now use the conservation of momentum to find the
final momentum of the second particle as


**Connection: Gravitational slingshot**

Spacecraft passing close to a planet can use the
gravitational interaction with the planet to gain speed in
a process known as a gravitational slingshot. In reality,
this process is an elastic, multidimensional collision
between the spacecraft and the planet mediated by the
gravitational force. The process is show in the figure to
the right. As the spacecraft comes close to the planet,
the interaction drags the spacecraft in the direction of
motion of the planet increasing the component of
velocity in the direction of the planet’s motion, leading
to a (possibly) large increase in speed. Conservation of
momentum says that the planet should slow down due to
this interaction – however, since it is tremendously
larger than the spacecraft, the change in speed of the
planet is negligible.


-----

The conservation of momentum and the conservation of energy can also be combined to solve certain problems as shown
below.

Example 116 - 3 **Ballistic pendulum**

A ballistic pendulum (shown below) can be used to determine The conservation of energy for this system can be
the initial speed of a projectile when the projectile is fired into written
a block attached to a pendulum. Imagine that you are trying to
investigate the properties of a new handgun, which fires bullets ∆𝐾� + ∆𝐾� + ∆𝑈� = 0,
with mass 9.2 g. If the mass of the ballistic pendulum is 1.2
kg, and the pendulum rises to a height 5.2 cm above where it Where ∆𝐾� and ∆𝐾� are the change in kinetic energy of
starts after the bullet collides with it, what is the speed of the the pendulum and earth, respectively, and ∆𝑈� is the
bullet before the collision?

change in gravitational potential energy of the
pendulum-earth system. Because the earth is much
larger than the pendulum, we can neglect the change in
kinetic energy of the earth, and use the gravitational
potential energy equation near a large gravitating body.
Therefore, we can write the conservation of energy for
this system as

1
2 [𝑚𝑣][�]� − [1]2 [𝑚𝑣][�]� + 𝑚𝑔ℎ� −𝑚𝑔ℎ� = 0.

**Solution:**

We know that the final speed of the pendulum is zero

This problem asks use to use the conservation of energy for the (since it comes to rest at its peak) and we can call the
ballistic pendulum, along with the conservation of momentum initial height zero. In addition, each term in the
of the bullet-pendulum system to determine the initial speed of equation contains the mass of the bullet-pendulum
the bullet. system, so we can factor and cancel the mass. This

gives us a conservation of energy equation

The collision of the bullet with the pendulum represents a onedimensional perfectly inelastic collision since the objects stick �

𝑣� = 2𝑔ℎ� →   𝑣� = �2𝑔ℎ�.

together. Therefore, we can use

𝑚�𝑣� + 𝑚�𝑣�� = �𝑚� + 𝑚��𝑣�, We can now substitute this value for 𝑣� into our

conservation of momentum equation, yielding

where 𝑚� is the mass of the bullet, 𝑚� is the mass of the
pendulum, speed of the pendulum and 𝑣� is the initial speed of the bullet, 𝑣� is the speed of the combined 𝑣�� is the initial 𝑣� = [�𝑚][�]𝑚[+ 𝑚]� [�][�] �2𝑔ℎ�.
bullet-pendulum system after the collision. Since the
pendulum is at rest before the collision, 𝑣�� = 0. We know each of the values on the right side of this

equation. Substituting in these values leads to the
solution

Following the collision, we can use the conservation of energy
to relate the speed of the bullet-pendulum system immediately
after the collision to the height which the pendulum rises. 𝑣� = 133 𝑚/𝑠.

#### 116.2 – Effects of collisions on the human body

**Consider: What are the effects of various collisions on the human**
body?

The human body is in some ways very resilient and in other ways it is very fragile. Collisions, whether they be between a
running back and a linebacker during a football game, or between a car passenger’s head and the dashboard during a car
crash, all provide physical shock to the human body. Traditionally, this shock is measured in g-forces, or g’s, meaning that
they are measured as the effective acceleration on the human body relative to the normal acceleration due to gravity,
9.8 𝑚𝑠⁄ [�].  The conversion fact is therefore


-----

𝑔[�]𝑠= [𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛𝑖𝑛𝑐𝑜𝑙𝑙𝑖𝑠𝑖𝑜𝑛]. (116-6)

9.8 𝑚𝑠⁄ [�]

Some typical values for g-forces are shown in Table 116-1. **Table 116-1. Some typical values for g-forces.**
There are two factors that tremendously affect the overall **Collision or action** g’s
response of the human body to g-forces: **Free fall** ~0

**Standing on the surface of the moon** 0.17

1) **_Time – The duration over which a collision or acceleration_** **Standing on earth at sea level** 1

occurs has a tremendous effect on the human body. For very **Typical braking in a car** 0.1 −0.8

**High-g roller coasters** 3 −6

short bursts, humans can survive g-forces up to about 100

**Max turn in alpine skiing** 9 – 12

g’s in general, although lower and higher levels have been

**Typical pilot ‘blackout’ for positive g’s** 10 – 12

reported. For longer term accelerations, human survival

**Death or serious injury (>400 ms)** ~25

tends to be limited to about 25 g’s. **Parachute opening during skydive** 33

**Limit of typical human survival in crash** 100

2) **_Orientation – The main reason that g-forces affect humans_** **Highest recorded human survival** 214

is that our organs and blood will tend to be pushed in the
opposite direction to the direction of the acceleration due to inertia. For example, in a car crash, when a passengers head
strikes the steering wheel or dashboard, the dashboard pushes the head back with tremendous force, however, the brain
and blood will continue to move forward as much as possible until they strike the inside of the person’s skull. The
interaction of brain and skull with the increased pressure of accumulated blood is what really does the damage. In a
longer-term interaction, blood is the main problem. For example, when a pilot undergoes a high acceleration upwards,
blood tends to pool in the feet and legs and be pulled away from the brain – this lack of blood in the brain can cause
blackout and loss of consciousness. Consider how the body reacts to g-forces in different directions:

               - **_Positive g’s – when undergoing positive g’s (upward force), humans can withstand up_**
to 10-12 g’s before blacking out. High-g suits which are designed to help offset these pressure
difference can help jet pilots. Also, training can help increase the general level of g-force that a
person can withstand without blackout and loss of consciousness.

               - **_Negative g’s – when undergoing negative g’s (downward force), humans can only_**
withstand about 2-3 g’s before losing consciousness. This is because blood will be pushed into
the brain under negative g’s and the brain does not have a mechanism for dealing with increased
pressure. This condition is sometimes called red-out because the excess blood in the head can
caused reddened vision before loss of consciousness.


**Figure 116-1. Col. John**
**Stapp during a 421 mph**
**sled ride in 1954.**



  - **_Horizontal g’s – Humans are much better at dealing with horizontal accelerations;_**
however, time is a factor. Typically, humans can resist 20 g’s for about 10 seconds, 10 g’s for 1
minute and 6 g’s for 10 minutes for any horizontal direction.

Figure 116-1 depicts a classic picture of Col. John P Stapp while on a rocket sled during an
experiment called Sonic Wind 1 in 1954. Stapp took part in a series of experiments exploring
the effects of acceleration on the human body by using a sled accelerated by rocket propulsion.
The top speed of this particular experiment was 421 mph. Stapp’s experiments were vital for
the development of military jet fighters as he showed that with proper protection, even jet pilots
could survive plane crashes if their harnesses were rated up to 32 g’s.


#### 116.3 – Rocket propulsion

**Consider: How can a rocket accelerate in space where there is no air to**
push against?

Rockets do not accelerate by pushing against their launch pads or the air around them – they simply use the conservation of
momentum. Modern spacecraft have two main forms of propulsion:


-----

1) Chemical engines use highly exothermic chemical reactions to produce semi-controled explosions and the exhaust

gases are expelled at high velocity out the back of the rocket.
2) Ion thrusters use the electromagnetic force to accelerate ions out the back of the spacecraft.

In each case, it is the reaction of the spacecraft to the expulsion of exhaust from the back of the spacecraft that allows for the
increased momentum of the spacecraft itself. This is a conservation of momentum problem – the exhaust gets momentum in
one direction so the spacecraft gets momentum in the other direction – with one additional problem: The mass of rocket fuel
can be a significant percentage of the overall original mass of the spacecraft. This means that the mass of the rocket or
spacecraft will change significantly throughout the process.
For this problem, I will assume the rocket is completely isolated (no external forces, even gravity!) and write the
conservation of momentum in terms of the initial momentum of the system and the final momentum of the system. We can
do this because

0 = �𝑝⃗�,� −𝑝⃗�,��+ �𝑝⃗�,� −𝑝⃗�,�� → 𝑝⃗�,� + 𝑝⃗�,� = 𝑝⃗�,� + 𝑝⃗�,� (116-7)

Imagine that a rocket system starts with a rocket mass of 𝑚� and the mass of the fuel is 𝑚�. If a portion of the fuel given by
m� is expelled, we can write the conservation of momentum as

�𝑚� + 𝑚��𝑣� = �𝑚� + 𝑚� −m��𝑣� + (m�)𝑣�, (116-8)

where 𝑣� is the initial velocity of the rocket and fuel, 𝑣� is the final speed of the rocket and 𝑣� is the final velocity of the
exhaust relative to an observer watching the system. We can simplify this equation some by calling the initial mass of the
system M, where 𝑀= 𝑚� + 𝑚�. We also expect the rocket itself to increase its speed in the direction of its original motion
and for the exhaust to leave the rocket opposite to its initial velocity. Therefore, we can say

𝑣� = 𝑣� + ∆𝑣 𝑎𝑛𝑑 𝑣� = 𝑣� −𝑣�, (116-9)

where ∆𝑣 is the change in speed of the rocket and 𝑣� is the speed of the exhaust relative to the rocket (which is also the speed
that the exhaust would leave the rocket if the rocket is at rest).
With these simplifications, the momentum equation for the rocket can be written

𝑀𝑣� = (𝑀−m�)(𝑣� + ∆𝑣) + (m�)(𝑣� −𝑣�). (116-10)

Simplifying this equation, we find

𝑀∆𝑣= 𝑚�𝑣� + 𝑚�∆𝑣 → (𝑀−𝑚�)∆𝑣= 𝑚�𝑣�. (116-11)

Remembering that 𝑀= 𝑚� + 𝑚�, we can further simplify this equation to

𝑚�∆𝑣= 𝑚�𝑣�. (116-12)

If we look at what happens over a very short period of time, the change in speed of the rocket will be very small (∆𝑣→𝑑𝑣)
and the mass ejected as exhaust will also be very small (𝑚� →𝑑𝑚�). Using this, we can write the rocket equation in terms of
differentials as
𝑚�𝑑𝑣= 𝑣�𝑑𝑚� → 𝑑𝑣= 𝑚[𝑣][�]� 𝑑𝑚�. (116-13)

As the mass of the fuel ejected increases, it comes from the overall mass in the rocket, so 𝑑𝑚� = −𝑑𝑚� and we can write
𝑑𝑣= − 𝑚[𝑣][�]� 𝑑𝑚�. (116-14)


We can now integrate this equation to get

���� 𝑑𝑚�

∆𝑣= −𝑣� �� 𝑚�


𝑀
= 𝑣� ln �𝑀−𝑚�


�, (116-15)


-----

where, again, 𝑀 is the mass of the rocket/fuel system at the beginning
and 𝑚� is the mass of fuel exhausted.
Rocket engines are not perfectly efficient. As such, the above
equation only has limited usage in real-world applications; however, it
is a very good example of how to expand the conservation of
momentum to more complicated systems. Aerospace engineers
working on rockets use an efficiency parameter called the **_specific_**
**_impulse of the rocket along with the weight ratios of the payload and_**
fuel to determine the maximum speed that can be reached by a given
rocket. Although using specific impulse can lead to more precise
results, we will use the model derived for equation 116-15 in Physics I.


**Rocket Equation**

𝑴
𝚫𝒗= 𝒗𝒆 𝐥𝐧�𝑴−𝒎𝒆


�


**Description – This equation describes the change in speed of a rocket,**

∆𝑣, as a mass, 𝑚�, of fuel is ejected. M is the original mass of the
rocket/fuel system.
**Note: This equation only works for non-relativistic speeds.**


The relativistic version of the rocket equation is found in a similar fashion to the classical version above (equation 116-15).
However, the gamma factor adds more complication to the mathematics that must be used. Without derivation, the related
equation for this increase in rocket speed at relativistic speeds is

𝑀

∆𝑣��� = 𝑐tanh �[𝑣]𝑐[�] [ln] 𝑀−𝑚��, (116-16)

where tanh is the hyperbolic tangent function and 𝑐 is the speed of light in a vacuum.


Example 116 - 4 **Rocket speed**

What is the ratio of a rockets maximum achievable (classical)
speed to the exhaust speed of its fuel if the fuel accounts for
90% of the total initial rocket mass? You may assume the
rocket starts from rest.

**Solution:**

This problem asks us to use the rocket equation to find the
ratio of ∆𝑣/𝑣� for a rocket. We can start by rearranging
equation 116-15 for the ratio we need to find:


∆𝑣

𝑣�


𝑀
𝑀−𝑚�


𝑀
=
𝑀−0.9(𝑀) [= 10.]


Therefore, the ratio we desire is given by 𝑙𝑛 (10) = 2.3.
Assuming the rocket starts at rest, the maximum speed
the rocket can reach is 2.3 times the exhaust speed of its
fuel:


= ln(10) = 2.3.


∆𝑣

𝑣�


𝑀
= ln �
𝑀−𝑚�


�


Since the mass of the fuel is 90% of the total mass, we can
write


It may seem initially strange that the rocket can reach a
faster speed than the exhaust speed; however, keep in
mind that the mass of the exhaust is much larger than the
mass of the rocket structure!


-----

-----

