### – Scalars and Vectors
## 103


_This unit introduces the valuable mathematical idea of a vector. Vectors are quantities that require both a magnitude_
_(number) and direction to describe them completely. In this unit, we will differentiate between vectors and scalars, a_
_numerical value. We will also learn how to use mathematics to report important quantities related to vectors._

##### Integration of Ideas

    - This unit is independent of the previous units. It is needed for most of the units moving forward.


##### The Bare Essentials

- Scalars are quantities that only require only a number to

describe them fully.

- Vectors are quantities that require both a magnitude and

direction to be fully described

- A vector can be described in terms of its components relative

to a set of axes.


**Magnitude/Angle Notation**

|𝑎⃗| = �𝑎�[�] + 𝑎�[�]       𝜃�→� = tan[��] [𝑎]𝑎[�]�

**Description – These equations define the magnitude, |𝑎⃗|, and**

angle, 𝜃�→�, of a vector, 𝑎⃗, with components, 𝑎� and 𝑎�.
**Note 1: The angle, 𝜃�→�, is measured from the positive x-axis**

towards the positive y-axis.
**Note 2: These equations are extensible to any plane. For example,**

the angle of a vector in the y-z plane, measured from the y-axis
towards the z-axis is 𝜃�→� = tan[��] 𝑎�⁄𝑎�.



- A vector can also be written in terms of its magnitude (length)

and direction relative to a given axis.


**Vector Notation**

�= �𝑎�, 𝑎�, 𝑎��= 𝑎�𝚤̂ + 𝑎�𝚥̂ + 𝑎�𝑘[�].


𝑎⃗= �


𝑎�
𝑎�
𝑎�


**Description – This equation defines the vector notation for a**

vector 𝑎⃗ with components, 𝑎�, 𝑎� and 𝑎� along the x-, y-, and
z-axes, respectively.
**Note: The choice of 𝚤̂, 𝚥̂ and 𝑘[�] for the unit-vector notation is**

arbitrary; however, these most often correspond to the x-, yand z-axes, respectively.



- Vectors can similarly be written in three dimensions; however,

the math can become a bit more complicated for magnitude/
angle notation.



- The components of these vectors can be found relative to

given axes using trigonometry


**Description of Vectors (3-D)**

𝑎⃗= �𝑎�, 𝑎�, 𝑎��= 𝑎�𝚤̂ + 𝑎�𝚥̂ + 𝑎�𝑘[�].


**Vector Components**

𝑎� = |𝑎⃗| cos 𝜃�→� 𝑎� = |𝑎⃗| sin 𝜃�→�

**Description – These equations define the components, 𝑎� and 𝑎�**

of a vector, 𝑎⃗, which has makes angle 𝜃�→� from the positive
x-axis towards the positive y-axis.
**Note 1: |𝑎⃗| is the magnitude of vector 𝑎⃗.**
**Note** **2: These equations are extensible to any plane, For example,**

in the y-z plane with angle measured off of y-axis, 𝑎� =
|𝑎⃗| cos 𝜃�→�, 𝑎� = |𝑎⃗| sin 𝜃�→�


**Description – These equations define a three-dimensional vector**

using similar notation to two-dimensional vectors above.
**Note: 𝜃��→� is the angle of inclination, an angle measured from**

the xy-plane towards the z-axis.


|𝑎⃗| = �𝑎�[�] + 𝑎�[�] + 𝑎�[�]

𝜃�→� = tan[��] [𝑎]𝑎[�]�

𝑎�
𝜃��→� = tan[��]

�𝑎�[�] + 𝑎�[�]


𝑎� = |𝑎⃗| cos 𝜃�→� cos 𝜃��→�

𝑎� = |𝑎⃗| sin 𝜃�→� cos 𝜃��→�

𝑎� = |𝑎⃗| sin 𝜃��→�


-----

#### 103-1. Scalars and Vectors

**Consider: Why do some quantities require direction and some do not?**

F I WERE TO ASK YOU A COMFORTABLE OUTSIDE temperature for an autumn day, you might respond something
like 70° Fahrenheit. The number 70 (and the specific scale used) are all that is needed for someone to fully understand
what you mean. On the other hand, if you are giving someone directions, giving them the distance may not be enough.

# I

“Oh, its two away” might or might not get them there – because they also need to know which way to go.  Without a specific
direction, they could easily get lost.  On a basic level, this is the difference between a scalar quantity and vector quantity.
Scalar quantities, or just scalars, only require a number to describe them; whereas a vector quantity, or vector, requires both a
magnitude (number) and direction. We would then say that temperature is a scalar because it only requires a number,
whereas the directions must be a vector since it requires both the distance and direction. Table 103-1 gives some examples of
scalars and vectors.

**Table 103-1. Examples of scalars and vectors.**

**Scalars** Vectors
Time Momentum
Temperature Change in temperature
Volume Acceleration
Speed Velocity
Distance Displacement
Vector magnitude Angular momentum
Vector components Force

#### 103-2. The mathematics of vectors

**Consider: How do I visualize and write down vectors?**

A vector is any quantity that requires both a magnitude and direction. All vectors can be represented as arrows; the length of
the arrow represents the magnitude of the vector and the direction of the arrow represents the direction of the vector.
Quantities that are vectors are always noted with an arrow above the symbol. As an example, 𝑣⃗ would represent the (vector)
velocity of an object whereas 𝑣 might be used to represent the speed (scalar) of the object. One of the most important ideas
of vectors is that they are coordinate independent. This means that the physical interpretation of a vector does not depend on
the coordinate system used. So, when you are dealing with vectors, you can choose the best coordinate system for the
situation at hand and the physical interpretation of vectors will always be the same. Once you choose a coordinate system,
you must be consistent with that coordinate system.
The standard arrow representation of a vector is shown in Figure 103-1. In this figure,
we would say the vector 𝑎⃗ starts at point A and goes to point B. Again, note that this vector
is completely independent of any coordinate system – it does not matter where we have an
origin or along what direction the x-axis or y-axis are facing. The only important points are
that the arrow representation of this vector starts at point A and ends at point B.

**Figure 103-1. Standard**

Now, in order to use vectors in physics problems,

**representation of a vector**

we do place them in coordinate systems and shown in
figure 103-2. In this figure, the tail of the arrow is
placed at the origin (0, 0) and the tip of the arrow is at position (2, 3). Note that the
notation we are using here is standard from mathematics. The coordinates are listed
within parentheses in terms of the position along the horizontal axis first and the vertical
axis second.  Also, note that this is a two-dimensional vector, and we could add a third
dimension (into and out of the page) as a third number
in the parentheses.
The vectors shown in Figures 103-1 and 103-2 are

**Figure 103-2. A vector shown** both in the plane of the page; however, vectors can

**in a coordinate system.** generally be in three dimensions. Vectors which are

directly into the page and out of the page have their own

**Figure 103-3. Vector symbols**

symbols as shown in Figure 103-3. The symbol for into the page is an X with a circle around

**for into the page (left) and out**

it, representing the tail of an arrow moving away from you as the reader. The symbol out of

**of the page (right).**

the page is a dot with a circle around it representing an arrow coming directly toward you.

|Table 103-1. Examples of scalars and vectors.|Col2|
|---|---|
|Scalars Vectors||
|Time Momentum||
|Temperature Change in temperature||
|Volume Acceleration||
|Speed Velocity||
|Distance Displacement||
|Vector magnitude Angular momentum||
|Vector components|Force|


-----

There are two standard ways to write vectors in terms of their coordinates. The first is to write them in as an ordered list in
either a column-vector or row-vector notation:


𝑎⃗= �


𝑎�
𝑎��(𝑐𝑜𝑙𝑢𝑚𝑛) 𝑎⃗= �𝑎�, 𝑎�, 𝑎��(𝑟𝑜𝑤) (103-1)
𝑎�


The choice of column or row vector is simply based on space concerns and how they are being used, as you will see
throughout the text. Note that the two representations in equation 103-1 mean exactly the same thing! In either direction, the
first component represents the vector component along the x-axis, the second along the y-axis, and the third along the z-axis.

**Note: Even in two-dimensional problems, it is important to write vectors with all three**
**components since classical physics considers a three-dimensional Euclidean space.**

Another standard way to write a vector in terms of components is the use unit vector notation:

𝑎⃗= 𝑎�𝚤̂ + 𝑎�𝚥̂ + 𝑎�𝑘[�] 𝑜𝑟 𝑎⃗= 𝑎�𝑥�+ 𝑎�𝑦�+ 𝑎�𝑧̂. (103-2)

Unit vector notation gets its name from the symbols 𝚤̂ (called i-hat) or 𝑥� (called x-hat), which are unit vectors – vectors with a
magnitude of one, but with a defined direction. In essence, unit vectors just give each component a direction; since unit
vectors have a magnitude of one when you multiply the component by the magnitude of the unit vector, the value of the
component does not change.  The choice of 𝚤̂, 𝚥̂, 𝑘[�] in lieu of 𝑥�, 𝑦�, 𝑧̂ is mostly historical, although it has been used to
emphasize the point that vectors can be written in any coordinate system, not just x-y-z, spherical-polar for example.
In this text, we will use row- and column-vector notation more than unit vector notation. However, it is important to be
familiar with both since there will be times that unit vector notation helps to clarify the physics of a situation.

Looking back at Figure 103-2, we are now prepared to write the vector in terms of its components:


2

𝑎⃗= �3

0


�(𝑐𝑜𝑙𝑢𝑚𝑛) 𝑎⃗= [2, 3, 0] (𝑟𝑜𝑤). (103-3)


Again, in practice, we would only write it in one of these formats, but I do both for illustrative purposes here. The same
vector in unit-vector notation would be

𝑎⃗= 2𝚤̂ + 3𝚥̂ + 0𝑘[�] 𝑜𝑟 𝑎⃗= 2𝑥�+ 3𝑦�+ 0𝑧̂. (103-4)


**Vector Notation**

�= �𝑎�, 𝑎�, 𝑎��= 𝑎�𝚤̂ + 𝑎�𝚥̂ + 𝑎�𝑘[�].


𝑎⃗= �


𝑎�
𝑎�
𝑎�


**Description – This equation defines the vector notation for**

a vector 𝑎⃗ with components, 𝑎�, 𝑎� and 𝑎� along the x-,
y-, and z-axes, respectively.
**Note: The choice of 𝚤̂, 𝚥̂ and 𝑘[�] for the unit-vector notation is**

arbitrary; however, these most often correspond to the x, y- and z-axes, respectively.


-----

**Vector Components**

𝑎� = |𝑎⃗| cos 𝜃�→� 𝑎� = |𝑎⃗| sin 𝜃�→�

**Description – These equations define the components, 𝑎�**

and 𝑎� of a vector, 𝑎⃗, which has makes angle 𝜃�→� from
the positive x-axis towards the positive y-axis.
**Note 1: |𝑎⃗| is the magnitude of vector 𝑎⃗.**
**Note** **2: These equations are extensible to any plane, For**

example, in the y-z plane with angle measured off of yaxis, 𝑎� = |𝑎⃗| cos 𝜃�→�, 𝑎� = |𝑎⃗| sin 𝜃�→�


The **_magnitude of a vector is defined as the length of the vector. Since the x-, y- and z-components of a vector are all_**
perpendicular to each other, we can find the length from beginning to end using the (three-dimensional) Pythagorean
Theorem. The magnitude of a vector, 𝑎⃗, is denoted as |𝑎⃗|. Using this notation, the magnitude of a vector is given by

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] + 𝑎�[�]. (103-5)

The angles of the vector with respect to each axis can be found using the inverse tangent function. For the vector in Figure
103-2, the angle between the x-axis and the vector can be found as
𝜃�→� = tan[��] �[𝑎]𝑎[�]�� → 𝜃�→� = tan[��] �[3]2[�= 56.3°.] (103-6)

where 𝜃�→� represents the angle measured from the x-axis towards the y-axis. Similarly, if we wanted to know the angle
from the y-axis towards the x-axis, we could write

𝜃�→� = tan[��] �𝑎[𝑎]�[�]� → 𝜃�→� = tan[��] �[2]3[�= 33.7°.] (103-7)


Notice that the angles in equations 103-6 and 103-7 add to 90°, which we would expect, since combined they make the angle
between the x- and y-axes.
In general, the angle of a vector measured from one axis (i) towards another axis (j) can be found as
𝜃�→� = tan[��] �[𝑎]𝑎[�]��. (103-8)

The boxes below summarize the important features of vectors and the vectors notations.


**Magnitude/Angle Notation**

|𝑎⃗| = �𝑎�[�] + 𝑎�[�]       𝜃�→� = tan[��] �[𝑎]𝑎[�]�


�


**Description – These equations define the magnitude, |𝑎⃗|, and**

angle, 𝜃�→�, of a vector, 𝑎⃗, with components, 𝑎� and 𝑎�.
**Note 1: The angle, 𝜃�→�, is measured from the positive x-axis**

towards the positive y-axis.
**Note 2: These equations are extensible to any plane. For**

example, the angle of a vector in the y-z plane, measured
from the y-axis towards the z-axis is 𝜃�→� = tan[��] 𝑎�⁄𝑎�.


-----

Example 103 - 1 **Vectors in the xy-plane**

Write the vector 𝑐⃗= [5.2, 3.5, 0]𝑚 in magnitude/angle
notation.

**Solution:**

This problem asks us to directly apply the magnitude/angle
formulae to the vector, 𝑐⃗

The magnitude is


Therefore the vector 𝑐⃗ has a magnitude of 6.3 meters and
is directed 34° from the x-axis towards the y-axis.


|𝑐⃗| = �𝑐�[�] + 𝑐�[�] = �5.2[�] + 3.5[�] 𝑚= 6.3 𝑚

The angle, relative to the x-axis towards the y-axis is


𝜃�→� = tan[��] [𝑎]𝑎[�]�


= tan[��] [3.5 𝑚]

5.2 𝑚 [= 34°.]


Example 103 - 2 **Vectors in another plane**

Write the vector 𝑑[⃗] = [0, 4.9, 11.2] 𝑚𝑠⁄ in magnitude/angle
notation.

**Solution:**

This problem asks us to apply the magnitude/angle formulae
in a plane other than the xy-plane. Since this vector is in the
yz-plane, we will write the angle relative to the y-axis towards
the z-axis making the substitution


𝜃�→� = tan[��] 𝑎[𝑎]�[�]


The magnitude of the vector is

�𝑑[⃗]�= �𝑑�[�] + 𝑑�[�] = �4.9[�] + 11.2[�] 𝑚𝑠⁄ = 12 𝑚𝑠,⁄

where I have used only two significant figure to
correspond to 4.9. The angle is given by


= tan[��] [11.2]

4.9 [= 66°.]


𝜃�→� = tan[��] [𝑎]𝑎[�]�


→   𝜃�→� = tan[��] 𝑎[𝑎]�[�]


.


Therefore, the vector d has a magnitude of 12 m/s and is
directed 66° from the y-axis towards the z-axis.


Example 103 - 3 **Row vector notation.**

Imagine that a certain vector has a magnitude of 1200 N and
with an angle of 35° from the x-axis towards the y-axis.
Write this vector in row vector notation.

**Solution:**

This problem asks us to directly use the rules for vector
components and form a full vector in row vector notation.
For this problem, we will call the vector 𝑎⃗. We are given a
magnitude of 1200 N and an 𝑥→𝑦 angle of 35°


𝑎� = |𝑎⃗| cos 𝜃�→� = 1200 𝑁cos 35° = 982 𝑁.

𝑎� = |𝑎⃗| sin 𝜃�→� 1200 𝑁sin 35° = 688 𝑁.

Combining these components into vector notation, we
find

𝑎⃗= [982, 688, 0] 𝑁.


#### 103-3. Three-Dimensional Vectors

**Consider: How can vectors be extended to three dimensions?**

Although many problems in physics (especially introductory physics) can be reduced to two dimensions, there are a
number of situation in which we must perform a full three-dimensional analysis using vectors. Such a 3-D vector is shown in
Figure 103-4. For a two dimensional vector, we only needed two numbers to correctly describe the vector completely –
either the components along each of the two axes, or the magnitude of the vector and the angle relative to one axis.
For a three-dimensional vector, we must have three numbers to describe it fully. Vector components along the three axes
are the easiest way to do this. In fact, we have already done this by ensuring that we have all three components in our vector
notation


-----

𝑎⃗= �


𝑎�
𝑎�
𝑎�


�= �𝑎�, 𝑎�, 𝑎��= 𝑎�𝚤̂ + 𝑎�𝚥̂ + 𝑎�𝑘[�]. (103-9)


Writing a vector in magnitude-angle notation, however, requires the
magnitude of the vector and _two angles. The two angles we will use in_
Physics are the angle of the vector relative to the x-axis in the xy-plane,
𝜃�→�, and the angle of elevation of the vector above the xy-plane towards
the z-axis, 𝜃��→�. Please note that although this is our standard format, the
notation is designed so that you can modify these equation to any set of
coordinates, as we did for two-dimensional vectors; just be careful with the
subscripts on the angles.
The magnitude of a vector 𝑎⃗= �𝑎�, 𝑎�, 𝑎�� is given by the threedimensional Pythagorean theorem **Figure 103-4. A three dimensional vector.**

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] + 𝑎�[�]. (103-10)

The angle of projection of the vector onto the xy-plane relative to the x-axis is given by
𝜃�→� = tan[��] [𝑎]𝑎[�]�. (103-11)

Note that this equation looks exactly like the angle equation for our two-dimensional vectors because it is the angle we found
above based off of the projection of the vector on to that particular plane.
The **_angle of elevation is found using the component of the vector above the xy-plane,_** 𝑎�, and the length of the
projection of the vector onto the xy-plane, �𝑎�[�] + 𝑎�[�], giving us

𝑎�
𝜃��→� = tan[��] (103-12)
�𝑎�[�] + 𝑎�[�][.]

Finally, if we know the magnitude and angles of a three-dimensional vector, we can use trigonometry to first find the
projection onto the xy-plane (|𝑎⃗| cos 𝜃��→�) and then use what we know about two dimensional vectors to find the
components in the plane. The component related to elevation above the plane is found using simple trig. This gives us

𝑎� = |𝑎⃗| cos 𝜃�→� cos 𝜃��→�


𝑎� = |𝑎⃗| sin 𝜃�→� cos 𝜃��→�

𝑎� = |𝑎⃗| sin 𝜃��→�


(103-13)


**Three Dimensional Vectors – Magnitude and Angle**

Given a vector 𝑎⃗= �𝑎�, 𝑎�, 𝑎��

𝜃�→� = tan[��] [𝑎]𝑎[�]� (𝑎𝑛𝑔𝑙𝑒𝑜𝑓𝑥𝑦𝑝𝑟𝑜𝑗𝑒𝑐𝑡𝑖𝑜𝑛)

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] + 𝑎�[�]

𝑎�
𝜃��→� = tan[��] (𝑎𝑛𝑔𝑙𝑒𝑜𝑓𝑒𝑙𝑒𝑣𝑎𝑡𝑖𝑜𝑛)
�𝑎�[�] + 𝑎�[�]

**Note 1: 𝜃�→� is the angle to the projection of the vector on the xy-plane from the x-axis towards the**

y-axis. 𝜃��→� is the angle of elevation of the vector above the xy plane towards the z-axis
**Note 2: Unless you are specifically asked for magnitude and direction, a component form, 𝑎⃗=**

�𝑎�, 𝑎�, 𝑎�� or 𝑎⃗= 𝑎�𝑥�+ 𝑎�𝑦�+ 𝑎�𝑧̂ for example, is a perfectly good way to report a vector.


-----

**Three Dimensional Vectors – Components**

Given a vector of magnitude |𝑎⃗| and angles 𝜃�→�, 𝜃��→�,

𝑎� = |𝑎⃗| cos 𝜃�→� cos 𝜃��→�

𝑎� = |𝑎⃗| sin 𝜃�→� cos 𝜃��→�

𝑎� = |𝑎⃗| sin 𝜃��→�

**Note 1: 𝜃�→� is the angle to the projection of the vector on the xy-plane from the x-axis towards the**

y-axis. 𝜃��→� is the angle of the vector above the xy plane towards the z-axis
**Note 2: Unless you are specifically asked for magnitude and direction, a component form, 𝑎⃗=**

�𝑎�, 𝑎�, 𝑎�� or 𝑎⃗= 𝑎�𝑥�+ 𝑎�𝑦�+ 𝑎�𝑧̂ for example, is a perfectly good way to report a vector.


Example 103 - 4 **Example Problem**

A three-dimensional vector is given by 𝑎= [12.5, 8.6, 1.2] 𝑁.
Write this vector in magnitude/angle notation (that is, find the
magnitude, angle of projection in the xy-plane and angle of
inclination for this vector).

**Solution:**

This problem asks us to directly use the equations for
magnitude/angle notation of a three-dimensional vector.

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] + 𝑎�[�] = �12.5[�] + 8.6[�] + 1.2[�]𝑁= 15.2 𝑁


𝜃�→� = tan[��] [𝑎]𝑎[�]�


= tan[��] [8.6]

12.5 [= 34.5°]


𝑎� 1.2
𝜃��→� = tan[��]
�𝑎�[�] + 𝑎�[�] [= tan][��] √12.5[�] + 8.6[�][,]

𝜃��→� = 4.5°.

Therefore, this vector has a magnitude of 15.2 𝑁, an
angle of inclination of 4.5° and an angle of projection in
the xy-plane of 34.5° from the x-axis towards the y-axis.


#### 103-4. Addition and subtraction of vectors

**Consider: How can vectors be added and subtracted?**

Let’s say you walk five meters east and then 2 meters south, and we want to know where you finish relative to where you
start. In the parlance of vectors, we call this your displacement over the course of your motion. Each of these individual
displacements could be written as a vector. First, let’s assume that east is along the positive-x axis and north is along the
positive y-axis (meaning that south is along the negative-y axis). We could then write each part of your motion as

𝑑[⃗]� = [5,0,0] 𝑚 and 𝑑[⃗]� = [0, −2,0] 𝑚, (103-14)

where 𝑑[⃗]� is your motion east and 𝑑[⃗]� is your motion south. In order to find your total displacement, we would add these two
individual motions together. In order to do this, we simply add each of the components of your motion together (note that I
switch to column vectors instead of row vectors to make this more visually appealing):


𝑑[⃗]� = 𝑑[⃗]� + 𝑑[⃗]� = �


5
0
0


�𝑚+ �


0
−2

0


�𝑚= �


5 + 0
0 + −2

0


�𝑚= �


5
−2

0


�𝑚. (103-15)


Therefore, one way to report this result is 𝑑[⃗]� = [5, −2,0], which is a fine way to write this solution. However, we could also
report this result in terms of magnitude and direction:


-----

�𝑑[⃗]��= �(5 𝑚)[�] + (−2 𝑚)[�] + (0)[�] = 6.4 𝑚, 𝜃�→� = tan[��] �[−2]5 [�= −21.8°.] (103-16)

More generally, let’s say we want to add two vectors, 𝐶[⃗] = 𝐴[⃗] + 𝐵[�⃗]. The resulting vector, 𝐶[⃗], is known as the **_resultant_**
**_vector. In order to find the resultant vector, we add the components of the initial vectors:_**

𝐶� = 𝐴� + 𝐵�,


𝐶� = 𝐴� + 𝐵�,

𝐶� = 𝐴� + 𝐵�.

In vector notation this can be written


(103-17)

�. (103-18)


𝐶[⃗] = 𝐴[⃗] + 𝐵[�⃗] = �


𝐴� + 𝐵�
𝐴� + 𝐵�

𝐴� + 𝐵�


This process is shown graphically in figure 103-5. Note that Figure 103-4 also shows

**Figure 103-5. Graphical**

how vector addition is **_commutative, meaning that it does not matter what order the_** **representation of vector addition.**
addition is carried out (i.e., 𝐴[⃗] + 𝐵[�⃗] = 𝐵[�⃗] + 𝐴[⃗]). The resultant vector 𝐶[⃗] = 𝐴[⃗] + 𝐵[�⃗] is
represented as an arrow that starts at the tail of the first vector and ends at the tip of the second vector. Figure 103-6 further
shows how graphical addition of two vectors in a coordinate
system. In this figure two vectors

𝑢�⃗= [2,3,0] and 𝑣⃗= [5,1,0]. (103-19)

are added together to find


7
4
0


**Figure 103-6. Addition of two vectors, 𝒖��⃗ and 𝒗��⃗ as**
**described in the text.**


𝑢�⃗+ 𝑣⃗= �


2 + 5
3 + 1�= �
0 + 0


�. (103-20)


Example 103 - 5 **Finding the magnitude and direction**

What are the magnitude and direction of the vector sum 𝑢�⃗+ 𝑣⃗
above?

**Solution:**

This problem asks us to directly use the magnitude/angle
notation on the results of a vector summation.

First, I will call the vector summation above 𝑧⃗= 𝑢�⃗+ 𝑣⃗, if
only to simplify notation. From above, we know that

𝑧⃗= [7, 4, 0].

We can now directly apply the equation for the magnitude of
a vector to find

|𝑧⃗| = �𝑧�[�] + 𝑧�[�] + 𝑧�[�] = �7[�] + 4[�] + 0[�] = 8.1.


The angle from the x-axis towards the y-axis is


𝜃�→� = tan[��] [𝑎]𝑎[�]�


= tan[��] �[4]

7[�= 30°.]


So, this vector has a magnitude of 8.1 and is directed at
an angle of 30° from the x-axis towards the y-axis.

Alternatively, we could also report the angle from the yaxis towards the x-axis by changing variables in our
equation to find


𝜃�→� = tan[��] 𝑎[𝑎]�[�]


= tan[��] �[7]

4[�= 60°,]


which is exactly what we would expect to get since 30°
and 60° are complimentary angles.


-----

Example 103 - 6 **Vector addition**

Find the sum of the following vectors


𝑎⃗+ 𝑏[�⃗] = �


2.1 + 12.4

�= � 3.4 −5.8

−1.4 + 9.2


12.4

�+ �−5.8

9.2


2.1
3.4
−1.4


�.


Completing the operations in each of the components of
the column vector give us


12.4
−5.8�

9.2


𝑎⃗= �


2.1
3.4
−1.4


�   𝑏[�⃗] = �


**Solution:**

This problem asks us to directly find the sum of the two
vectors, 𝑎⃗+ 𝑏[�⃗]. Please note that an answer in column vector
notation is completely adequate, and follows directly


14.5
−2.4

7.8


𝑎⃗+ 𝑏[�⃗] = �


�.


If you remember, subtracting a second number from another number is the same as adding the inverse (negative) of the
second number:
𝑑−𝑒= 𝑑+ (−𝑒). (103-21)

The same is true of vectors, but what do we mean by the inverse, or negative of a vector?
Well, we mean that we take the negative of each component of the vector:


𝑉�

−𝑉[�⃗] = −�𝑉�

𝑉�


−𝑉�

�= �−𝑉�

−𝑉�


�. (103-22)


Graphically, the negative of a vector is represented by an arrow of the same length

**Figure 103-7. A vector, 𝒗��⃗, and**

(magnitude) but points in the opposite direction of the original vector. A vector and its **its negative.**
negative are shown in figure 103-7.
We are now ready to define vector subtraction as the addition of the negative of a vector. In this way, the rules for
analytical and graphical addition of vectors can still be used:


𝐴[⃗] −𝐵[�⃗] = 𝐴[⃗] + �−𝐵[�⃗]�= �


𝐴� −𝐵�
𝐴� −𝐵�

𝐴� −𝐵�


�= �


𝐴� + (−𝐵�)
𝐴� + �−𝐵���. (103-23)

𝐴� + (−𝐵�)


Example 105 - 7 **Example Problem**

Given the vectors in example 105-6 above, find the vector
subtraction 𝑎⃗−𝑏[�⃗]. Describe how this solution would differ
from the vector subtraction 𝑏[�⃗] −𝑎⃗

**Solution:**

The first part of this question is a direct application of the
definition of vector subtraction


Changing the order of vector subtraction should give us
the negative value of the original operation since

𝑏[�⃗] −𝑎⃗= −�−𝑏[�⃗] + 𝑎⃗�= −(𝑎⃗−𝑏[�⃗]).

Therefore


−10.3

9.2
−10.6


𝑎⃗−𝑏[�⃗] = �


�.


𝑏[�⃗] −𝑎⃗= �


10.3
−9.2

10.6


𝑎⃗−𝑏[�⃗] = �

which gives us


2.1
3.4
−1.4


�−�


12.4
−5.8

9.2


�= �


2.1 −12.4

3.4 + 5.8 �,
−1.4 −9.2


�.


-----

#### 103-4. Additional Vector Properties

**Consider: How do vector properties compare to properties of just**
_numbers?_

For vectors 𝐴[⃗], 𝐵[�⃗] and 𝐶[⃗] and a scalar c, the following properties hold:

(Commutative Property) 𝐴[⃗] + 𝐵[�⃗] = 𝐵[�⃗] + 𝐴[⃗] (103-24)

(Associative Property) 𝐴[⃗] + �𝐵[�⃗] + 𝐶[⃗]�= �𝐴[⃗] + 𝐵[�⃗]�+ 𝐶[⃗] (103-25)

(Vector Subtraction) 𝐴[⃗] −𝐵[�⃗] = 𝐴[⃗] + �−𝐵[�⃗]� (103-26)

(Distributive Property) c�𝐴[⃗] + 𝐵[�⃗]�= 𝑐𝐴[⃗] + 𝑐𝐵[�⃗] (103-27)

Notice that vectors follow most of the addition rules that regular numbers follow. This happens because the components of
the vectors are scalars (just numbers) and therefore most of the properties translate.

#### 103-5. Multiplication of Vectors

**Consider: Why is there more than one way to multiply vectors?**

We just saw that the addition of vectors follows directly the addition of numbers as long as we are careful and take care to
keep the components of each vector separate. Vector multiplication is, on the other hand, quite different than ‘normal’
multiplication. For Physics I, there are two important types of vector multiplication – the dot product and the cross product.
Although we will treat each of these in more detail when we need them, this section will give a very brief introduction to
these two types of multiplication.

The scalar product (dot-product).

The **_scalar product, or_** **_dot-product, of two vectors is a measure of how parallel two vectors are. Mathematically, we are_**
finding the component of one vector that is parallel to a second vector and multiplying that component of the first vector with
the magnitude of the second vector:

𝐷= 𝐴[⃗] ⋅𝐵[�⃗] = 𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵� = �𝐴[⃗]��𝐵[�⃗]�cos 𝜃. (103-28)

Dot-product notes:

1) The result of a dot-product is a scalar (thus the name scalar product).
2) The angle, 𝜃, in equation 103-28 is the angle between the two vectors.
3) We will discuss the dot product in greater detail in unit 110.


Example 105 - 8 **Scalar (dot) produce**

What is the scalar product of the vectors


12.4
−5.8

9.2


�


𝑎⃗= �


2.1
3.4
−1.4


�   𝑏[�⃗] = �


**Solution:**

This problem asks us to directly calculate the scalar product
of two known vectors:


𝑎⃗⋅𝑏[�⃗] = 𝑎�𝑏� + 𝑎�𝑏� + 𝑎�𝑏�
Therefore,

𝑎⃗⋅𝑏[�⃗] = (2.1)(12.4) + (3.4)(−5.8) + (−1.4)(9.3),

or

𝑎⃗⋅𝑏[�⃗] = −6.7.


-----

The vector product (cross-product).

The vector product, or cross product, of two vectors is a measure of how perpendicular
two vectors are. Mathematically, we are finding the component of one vector that is
perpendicular to a second vector and multiplying that component of the first vector with
the magnitude of the second vector. However, unlike the scalar product, the result of a
cross product is a vector and must therefore have a direction. The direction of the cross
product is always perpendicular to the plane formed by the two vectors in the product. If
you point your fingers in the direction of the first vector with your thumb outstretched and
curl your fingers towards the direction of the second vector, your thumb points in the
direction of the resultant. This is called the “right hand rule.”
Mathematically, if 𝑐⃗= 𝑎⃗ 𝑥 𝑏[�⃗], then

|𝑐⃗| = |𝑎⃗|�𝑏[�⃗]�sin 𝜃, (103-29)


**Figure 103-8. The right hand**
**rule for the direction of a**
**cross product**


and the direction of the resultant is given by the right hand rule.
The direction via the right hand rule is found by pointing the
index finger of your right hand in the direction of the first vector
(𝑎⃗), pointing your middle finger in the direction of the second
vector �𝑏[�⃗]�, and your thumb (made to be perpendicular to both
your index and middle fingers) points in the direction of the cross
product �𝑐⃗= 𝑎⃗ 𝑥 𝑏[�⃗]�. This process is shown in Figure 103-8.
Alternatively, the cross product can be found in full vector
form by using the determinant of a matrix formed by the two
vectors


𝚤̂ 𝚥̂ 𝑘[�]

�= �𝑎� 𝑎� 𝑎�

𝑏� 𝑏� 𝑏�


𝑎�

𝑐⃗= 𝑎⃗𝑥𝑏[�⃗] = �𝑎�

𝑎�


�𝑥�


𝑏�
𝑏�
𝑏�


�= �


𝑎�𝑏� −𝑎�𝑏�
𝑎�𝑏� −𝑎�𝑏�
𝑎�𝑏� −𝑎�𝑏�


�. (103-30)


Again, we will do more with the cross product when we need to introduce it for the physics, including explaining where this
last equation comes from.

Cross product notes:

1) The result of a cross product is a vector (thus the alternate name vector product).
2) The angle, 𝜃, in equation 103-29 is always the angle between the two vectors in the product.
3) The cross product is not commutative; in fact 𝑎⃗ 𝑥 𝑏[�⃗] = −𝑏[�⃗] 𝑥 𝑎⃗.
4) We will discuss the cross product in greater detail in unit 117.


Example 103 - 9 **Vector (cross) product**

What is the vector product of the vectors


𝑎�𝑏� −𝑎�𝑏�
𝑎�𝑏� −𝑎�𝑏�
𝑎�𝑏� −𝑎�𝑏�


�,


so,


𝑎⃗ 𝑥 𝑏[�⃗] = �


12.4
−5.8

9.2


�


𝑎⃗= �


2.1
3.4
−1.4


�   𝑏[�⃗] = �


**Solution:**

This problem asks us to directly calculate the cross product of
two vectors. In order to do this, we will use equation 103-30,


𝑎⃗ 𝑥 𝑏[�⃗] = �


(3.4)(9.2) −(−1.4)(−5.8)

(−1.4)(12.4) −(2.1)(9.2) �= �
(2.1)(−5.8) −(3.4)(12.4)


23.1
−36.7
−54.3


�


-----

-----

