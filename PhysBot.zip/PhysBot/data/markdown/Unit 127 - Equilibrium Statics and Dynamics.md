### – Equilibrium, Statics and Dynamics
## 127


_Support structures in homes, bridges, commercial antennae, just to name a few, have many forces acting upon them. In_
_order to create stability, these structure must be under static equilibrium – that is, the net force and torque on them must_
_be zero. In this unit, we discuss how to determine if stability is possible, determining forces needed to maintain stability_
_and the dynamic reaction of systems when static equilibrium is not maintained,_


##### The Bare Essentials

- Local maxima and minima on a potential energy diagram are

points of unstable and stable equilibrium, respectively. The
stability of an object is related to whether forces on the object
are located over a support point.

- The first condition of equilibrium is that the net (vector) force

on an object is zero.



- For statics problems, not only is the net force and torque zero,

but the initial velocity and angular velocity are also zero.

- When writing torque equations for statics problems, we will

use the magnitude angle formula in one-dimension

𝜏= 𝑟𝐹sin 𝜃

- In engineering, especially statics and dynamics, torque is also

referred to as the moment of a force.

- For dynamics problems, we must consider both Newton’s laws

and Newton’s laws for rotation with accelerations.


**First Condition for Equilibrium**

[��⃗]𝑭𝒏𝒆𝒕 = 𝟎

**Description – The equation describes how the net force on**

an object is zero for the first condition of equilibrium.
**Note: If the object is at rest, this is statement of translational**

static equilibrium.



- The second condition of equilibrium is that the net (vector)

torque on an object is zero.


**Second Condition for Equilibrium**

𝝉�⃗𝒏𝒆𝒕 = 𝟎

**Description – The equation describes how the net torque on**

an object is zero for the first condition of equilibrium.
**Note: If the object is at rest, this is statement of rotational**

static equilibrium.


**Dynamics Problems**

[��⃗]𝑭𝒏𝒆𝒕 = 𝒎𝒂��⃗

𝝉�⃗𝒏𝒆𝒕 = 𝑰𝜶��⃗

**Description – These equations describe how Newton’s 2[nd]**

law and 2[nd] law for rotation must be used for particle
dynamics where acceleration(s) are non-zero.
**Note: We have already seen some examples of dynamics in**

this course.


-----

#### 127.1 – Equilibrium and stability

**Consider: Is there a way to know when an object will tip over?**

N UNIT 107, WE EXPLORED THE BASICS OF potential energy diagrams including the relationships between the total
energy potential energy and kinetic energy. In general, we used such diagrams to visually relate the conservation of
energy. For example, if the total energy of a system remained the same and the potential energy decreased on the

# I

diagram, then the kinetic energy must increase.  In Unit 110, we then explored the relationship between force and potential
energy and found
𝐹[⃗] = �𝐹�, 𝐹�, 𝐹��= −�[𝜕𝑈]𝜕𝑥 [, 𝜕𝑈]𝜕𝑦 [, 𝜕𝑈]𝜕𝑧 [�= −∇��⃗𝑈,] (127-1)


where 𝐹[⃗] is the force, U is the potential energy as a function of position and [��⃗]∇ is the gradient operator. We will now explore
how these two ideas fit together to gives us a visual feel for the reaction of a system under a potential energy field. In this
section, we will consider only forces in one dimension – meaning that the potential energy will only be a function of one
variable. If we assume this variable is x, we can simplify Equation 127-1 to

𝐹� = − [𝑑𝑈]𝑑𝑥 [.] (127-2)

Since graphically, the derivative is the slope of a line at a given point, this tells us that the
force on an object is the negative slope of the potential energy curve at a given point. What
about points where the force on an object is zero? Given Equation 127-2, the force is zero
where the slope of the potential energy curve is zero – that is, where a tangent line to the
potential energy curve is horizontal.
An object placed at a position of equilibrium with zero velocity will remain at the

**Figure 127-1. A stable**

position of equilibrium. In addition:

**equilibrium.**

1. Figure 127-1 shows a **_stable equilibrium. At the exact minima on any potential_**

energy diagram, the tangent to the curve will be horizontal, meaning there is no net
force. In addition, since the potential energy rises on each side, the object (ball in
the figure) will tend to return to this point of equilibrium if disturbed, creating a
point of stability.

**Figure 127-2. An unstable**

2. Figure 127-2 shows an unstable equilibrium. At the exact maxima on any potential

**equilibrium.**

energy diagram, the tangent to the curve is horizontal so there is no net force. In
addition, the potential energy of each side of the equilibrium point will decrease
suggesting that if an object is displaced from equilibrium, it will tend to continue to
move away from the point of equilibrium.

3. Figure 127-3 shows an **_indifferent equilibrium. In an extended region where the_**

potential energy curve is horizontal, there is no force on the particle. In addition,

**Figure 127-3. A stable**

small displacements will have no effect on the net force (it remains zero), meaning

**equilibrium.**

that the object is indifferent to small displacements in regards to equilibrium.

One way to visualize stable and unstable equilibria is with a standard pencil on a table. If you lay a pencil down on a
table, it is in a state of equilibrium. Now, if you lift up one end slightly and let go, that end of the pencil will drop to the table
and aside from some slight bouncing and vibration, the pencil will return to the same equilibrium from where it started. This

is a state of stable equilibrium. However, if you stand a pencil up very carefully on its eraser,
you might be able to get it stay. Although this is a state of equilibrium, if you give the pencil
even a slight push in any direction, it will drop to the table.
The standing state of the pencil is an unstable equilibrium.
The pencil situation can be visualized in terms of
potential energy as in Figure 127-4. The standing pencil in a

**Figure 127-4. A bistable** state of unstable equilibrium is denoted in this figure at point
**equilibrium.**

2. If the pencil is displaced it will drop to the ground in one
of two ways (remember, we are using only one-dimensional

**Figure 127-5. A metastable**

potential energy graphs), and fall to a stable equilibrium at either point 1 or point 3.

**equilibrium.**


-----

Another common type of equilibrium, known as a metastable state, is shown in Figure 127-5. In this system, there are
two stable equilibria states (1 and 3 in the figure) and an unstable point above each of the stable states in terms of energy. In
a metastable state, in contrast to the bistable state, the two stable equilibria are at different total energy. In this case, point 3

would be more stable than point 1; however, it would take energy to move
the system from point 1 to point 3.
Finally, let’s consider the stability of a real system. Figure 127-6
shows a large crate sitting on an inclined plane. In this figure, x notes the
position of the center of mass, and the dotted line represents the line of
action of the gravitational force on the crate. If the box were to tip over, it
would rotate around the front-most corner in contact with the plane. Note
that in the left-most picture, the line of force for the weight strikes the

**Figure 127-6. Stability and real systems.**

incline at a point where the bottom of the crate is still in contact. The
weight of the box would tend to rotate the box counterclockwise; however,
contact between the bottom of the box and the plane will prevent this from occurring (i.e., there is a torque due to the normal
force to offset the torque of the gravitational force. Therefore, there is no net torque on the crate, and it will not fall over
(rotate).

Now consider the rightmost picture in Figure 127-6. In this case, the line of force does not pass through a support point on
the base of the crate. Since there is now a displacement between the closest support point and the line of force along the
plane (which we will call r), we find

𝑟 0 0

𝜏⃗= 𝑟⃗𝑥𝐹[⃗] = �0�𝑥� 0 �= �𝑟𝑚𝑔�. (127-4)

0 −𝑚𝑔 0

Since there is a net torque, the crate will rotate due to Newton’s 2[nd] law for rotation, and it will tumble over.
The general statement is that an **_object is stable (or in equilibrium from rotation) if the line of action of the forces_**
**_acting on it pass through a support point. If the lines of force do not pass through a support point, the object will rotate (fall_**
over in the example).


Example 127 - 1 **Positions of equilibrium**

Determine and describe the positions of equilibrium at A, B
and C in the figure below.

**Solution:**

This problem asks us to determine the positions and types of
equilibrium from a potential energy diagram.


As described above, any position that is a local minimum
on a potential energy diagram is a position of stable
equilibrium. Therefore, both points A and B are at stable
equilibrium positions.

Points of local maximum on potential energy diagrams
are points of unstable equilibrium, therefore, point C is in
unstable equilibrium.

For small displacements, A and B would tend to return to
their equilibrium positions; however, point C would tend
away from its equilibrium position.


Example 127 - 2 **When will it tip?**

Imagine the crate in Figure 127-6 is twice as tall is it is wide.
At what angle will it start to tip over?

**Solution:**

This problem asks us to use our knowledge of object stability
to determine the angle at which it will start to tip over. The


Geometry of the object at the point of tip is
shown to the right. Using trigonometry, we find

𝜃= tan[��] [𝐿]

2𝐿 [= tan][��] [1]2 [= 26.6°.]


Therefore, the crate starts to tip at about 27°.


-----

#### 127.2 – The first and second conditions of equilibrium.

**Consider: What determines if a system is in equilibrium?**

In order for a real object to be in equilibrium, it must be free from both net forces and net torques. Otherwise, the object
would either accelerate linearly (net forces) or rotationally (net torques). These conditions are known as the first and second
conditions for equilibrium:

**_First condition of equilibrium: The net force on an object must be zero so that the_**

object’s velocity does not change.

**_Second condition of equilibrium: The net torque on an object must be zero so that the_**

object’s angular velocity does not change.

The two equation boxes below summarize this in terms of Newton’s 2[nd] law and Newton’s 2[nd] law for rotation.


**First Condition for Equilibrium**

[��⃗]𝑭𝒏𝒆𝒕 = 𝟎

**Description – The equation describes how the net force on**

an object is zero for the first condition of equilibrium.
**Note: If the object is at rest, this is a statement of**

translational static equilibrium.


**Second Condition for Equilibrium**

𝝉�⃗𝒏𝒆𝒕 = 𝟎

**Description – The equation describes how the net torque on**

an object is zero for the first condition of equilibrium.
**Note: If the object is at rest, this is a statement of rotational**

static equilibrium.


An object can be moving and be in equilibrium since a state of equilibrium says nothing about velocity and angular velocity,
but rather says that these velocities cannot change. If an object is both at rest and in a state of equilibrium, we call this static
**_equilibrium. If an object is moving, but both the 1[st] and 2[nd] conditions of equilibrium hold, it is in dynamic equilibrium._**
Problems involving the forces and torques required to maintain a state of rest are called **_statics problems, and are_**
explored in the next section. Please note that systems that are not in equilibrium are called dynamic systems. Although we
have explored dynamic systems in this course without calling them as such, we will explore a couple of interesting dynamic
results after discussing statics.

#### 127.3 – Statics problems.

**Consider: How do we solve problems in static equilibrium?**

In this section, we will explore how to use the first and second conditions of equilibrium to solve systems in static
equilibrium. In the most general situation, we can set up a set of six equations for any object, three from the vector form of
Newton’s 2[nd] law


𝐹[⃗]��� = 0 → �


𝐹�,���
𝐹�,���
𝐹�,���


�= �


0
0
0


�, (127-5)


-----

and three from the vector form of Newton’s 2[nd] law for rotations

𝜏⃗��� = 0 → �


𝜏�,���
𝜏�,���
𝜏�,���


�= �


0
0
0


�. (127-6)


In practice, however, we will generally use two components from Newton’s 2[nd] law and one from the 2[nd] law for rotations.
Since we will often only use one component of the torque equation, it is also common to write it as a scalar equation;
however, it is important for you to keep in mind that it is, indeed, a vector.
**_For statics problems, the net torque around any axis must be zero, so you are free to choose your axis at the best_**
possible place. In general, this often means choosing positions where a number of forces act, since the moment arm for each
of those forces would be zero. This will help the torque equations to have fewer terms and hopefully aid you in solving the
problem.
The following examples illustrate how to use these equations.


Example 127 - 3 **Where to put the mass**

Consider the figure below of a uniform beam with mass
3.56 𝑘𝑔, which is suspended by a string attached 0.52 𝑚 from
one end. At what distance from the string, 𝑥, should the mass
on the right shown be placed so that the beam is in static
equilibrium?

**Solution:**

This is a statics problem for which we are asked to solve for a
distance for one force. First, we start by drawing a free body
diagram for the situation.

Newton’s 2[nd] law for this situation is then


or

𝑇= 72.8 𝑁.

Now to find the value of x that puts the system in static
equilibrium, we must choose a pivot point. For this
problem, I will choose where 𝑚� connects to the beam.
The reason I do this is because the center of mass of the
beam will then be at

𝑥�� = [0.52𝑚+ 𝑥]2,

Which is where the weight of the beam acts on the beam.
For the torque equation, I define counterclockwise as
positive and note that the tension force is positive, where
the weight of the beam and weight due to the 1.52 −𝑘𝑔
mass are negative. This gives a torque equation of

𝑟𝑇sin 90° − [𝑟+ 𝑥]2 𝑚𝑔sin 90° −(𝑟+ 𝑥)𝑚�𝑔sin 90° = 0,

Where I use 𝑟 to represent 0.52 𝑚 for simplicity of
writing the equation. Solving this equation for x, we get


�


0
0
𝑇−𝑚�𝑔−𝑚𝑔−𝑚�𝑔


�= �


0
0
0


�,


where 𝑚𝑔 is the weight of the beam. Solving the zcomponent for the tension, we get

𝑇= 𝑚�𝑔−𝑚𝑔−𝑚�𝑔= (𝑚� + 𝑚+ 𝑚�)𝑔,

Which gives us

𝑇= (2.35𝑘𝑔+ 3.56𝑘𝑔+ 1.52𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )


�[𝑚+ 𝑚][�][�𝑔]

𝑥= [𝑇−] [�][�] 𝑟.

�[�]�[𝑚+ 𝑚][�][�𝑔]

Using values from the problem, this gives us

𝑥= 0.65 𝑚.

Therefore, the second mass should be placed 0.65 meters
to the right of the string.

Note that we could have chosen any pivot point for this
problem since we are trying to find static equilibrium. I
chose the endpoint because it made determining the
distances as a function of x easier.


-----

Example 127 - 4 **Holding up the sign**

As shown in the figure below, a sign of mass 𝑚= 22.5𝑘𝑔 is
to be suspended from a light beam of length 𝑆= 2.40𝑚. If
the cable supporting the sign is rated for 216 𝑁 of tension,
how far from the wall can the sign by hung without snapping
the cable? For this problem, 𝜃= 30°.

**Solution:**

This is a statics problem which asks us to solve for the tension
in the cable. From the free body diagram of the system
above, we can write Newton’s 2[nd] law as


𝐿= [𝑆𝑇sin 𝜃] =

𝑚𝑔


components of the normal force where the beam is
attached to the wall.

Although Newton’s 2[nd] law would allow us to find the
horizontal and vertical components of the normal force at
the pivot of the beam under max tension, it does not help
us with where to place the mass.

Since we do not know the normal force, nor do we care
about it, I choose where the beam meets the wall as the
pivot point. Our torque equation (with counterclockwise
positive) then becomes

𝑆𝑇sin 𝜃−𝐿𝑚𝑔sin 90° = 0.

This equation can be solved for the distance from the
wall, L, as


(2.4𝑚)(216𝑁)(sin 30°)

= 1.17 𝑚
(22.5𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )


�


𝑁� −𝑇cos 𝜃

0
𝑇sin 𝜃+ 𝑁� −𝑚𝑔


�= �


0
0
0


�,


where Nv and Nh are the vertical and horizontal


Therefore, the sign can only be hung about half-way out
on the beam. Depending on the size of the sign, this may
or may not be appropriate.


Extension:

Although the problem did not ask for the normal force at the
wall under maximum tension, we can use the Newton’s 2[nd]
law equations to find this value. From the horizontal
component of the 2[nd] law, we get

𝑁� = 𝑇cos 𝜃= (216 𝑁) cos 30° = 187 𝑁.

The vertical component of the 2[nd] law gives us

𝑁� = 𝑚𝑔−𝑇sin 𝜃= (22.5𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ) −(216 𝑁) sin 30°,

which simplifies to


𝑁� = 112.5 𝑁.

From these components, we can find the magnitude and
direction of the normal force as

𝑁= �𝑁�� + 𝑁�� = 218 𝑁,


and


𝜃� = tan[��] [112.5]187 [= 31°.]


#### 127.4 – Dynamics.

**Consider: What really changes when accelerations are**
not zero?

I can’t stress enough that statics problems are a very specific situation where both
the linear and angular acceleration of a system is zero _and the initial velocity and_
angular velocity is zero. It is also very interesting to note that when you combine
the net forces and net torques, you can sometimes get results that don’t necessarily
fit with your intuition – and possibly don’t seem to fit with other situations we’ve
considered in this course.
To show such a situation, let’s return to the standard Atwood’s machine that we
first explored in Section 125-3. When we first looked at the Atwood’s machine, we
assumed the pulley was ideal, that is, it had no mass and no friction at its pulley.


**Figure 127-7. The standard Atwood**
**machine again.**


-----

When we solved this system for the acceleration of the blocks we found

𝑎= [𝑀−𝑚] (127-7)

𝑀+ 𝑚 [𝑔.]

This is a dynamics problem, because we found that as long as the two masses are not the same, we have an accelerated
system.
In Section 125-3, we allowed the pulley to have mass, such that the rotational inertia of the pulley made it so that the
tensions in each string are different, and reduced the acceleration. In this case, we had to use both Newton’s 2[nd] law and
Newton’s 2[nd] law for rotation together to find

𝑀−𝑚
𝑎= 𝑔. (127-8)
𝑀+ 𝑚+ 𝐼������⁄𝑟[�]


Again, please note that these results (Equations 127-7 and 127-8) agree with
each other in that if we allow the mass of the pulley (as part of the moment of
inertia) to go to zero, Equation 127-8 becomes Equation 127-7. Regardless,
even with the mass of the pulley accounted for, we have an acceleration as
long as the mass of the blocks are different.
On the flip side, both of the results for the Atwood’s machine suggest that
the acceleration of the system is zero if the masses on each side of the pulley
are the same. This seems to make good sense since each mass is pulling down
with the same gravitational force.
Let’s take this one step further. In the analysis where the pulley was
allowed to have mass, we assumed that there was one string, which was
attached to the pulley at the same radius on each side. What if we relax this
requirement and allow the string to enter the pulley at one radius and leave the
pulley at another as shown in Figure 127-8.
Following the same procedure for solving the Atwood’s machine from
Section 125-4, we get

𝑇� −𝑚𝑔= 𝑚𝑎�


**Figure 127-8. Free body diagram for an**
**Atwood’s machine with two radii for the**
**pulley.**


𝑀𝑔−𝑇� = 𝑀𝑎�

𝑟�𝑇� −𝑟�𝑇� = 𝐼������𝛼


(127-9)


Now, because the third equation above has two radii, this set of equations is much harder to solve than it was with only one
radii (see Equations 125-18). Also, note that the force equations are now written with two different accelerations. This is
because as the pulley rotates, the string attached at each side will move by different linear amounts for one rotation, since one
rotation is given by 2𝜋𝑟 and r is different on each side.
In this case, it is the angular motion of the pulley that is the same for each side. Therefore, we can use our relationship
𝑎= 𝛼𝑟 to write all three equations in terms of the angular acceleration as

𝑇� −𝑚𝑔= 𝑚𝛼𝑟�


𝑀𝑔−𝑇� = 𝑀𝛼𝑟�

𝑟�𝑇� −𝑟�𝑇� = 𝐼������𝛼

If we solve this set of equations for the angular acceleration, we find

𝑀𝑟� −𝑚𝑟�
𝛼= 𝑚𝑟�� + 𝑀𝑟�� + 𝐼������


(127-10)

𝑔. (127-11)


Here’s the crazy thing – the acceleration of the system is not zero if the two masses are the same. In fact, if the masses are
the same (call it 𝑚), the equation barely even simplifies

𝑟� −𝑟�
𝛼= 𝑟�� + 𝑟�� + �𝐼������⁄𝑚� [𝑔.] (127-12)


-----

We can also go back to Equation 127-11 and find a relationship between 𝑚 and 𝑀 for the acceleration to be zero, which is


𝑚= [𝑟][�]

𝑟�


𝑀. (127-13)


The key here is that when dealing with static and dynamic systems that include torque, you must be very careful to make sure
that you are in the limit that you believe you should be, as this accelerating Atwood’s machine with the same mass shows!


-----

