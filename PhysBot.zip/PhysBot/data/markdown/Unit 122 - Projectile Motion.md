### – Projectile Motion
## 122


_Ideal projectile motion is the motion of an object in the presence of only gravity. In order to use this approximation, all_
_other forces, including air resistance, much be negligible. In this unit, we explore this important model and show some_
_of the major results often seen in introductory physics._


##### The Bare Essentials

- Objects tossed through the air at relatively low velocity can be

modeled as if they are only acted on by gravity. This is the
**_ideal projectile motion approximation._**



- Similarly, the position as a function of time for projectiles can

be found.


**Position (Projectile Motion)**


**Acceleration (Projectile Motion)**


𝒗𝟎,𝒙𝒕+ 𝒙𝟎
𝒗𝟎,𝒚𝒕+ 𝒚𝟎

− [𝟏]

𝟐 [𝒈𝒕][𝟐] [+ 𝒗][𝟎,𝒛][𝒕+ 𝒛][𝟎]


�


𝒂��⃗(𝒕) = �


𝟎
𝟎 �
−𝒈


𝒓�⃗(𝒕) = �


**Description – this equation gives the vector acceleration of**

an object, 𝑎⃗, in the ideal projectile motion approximation.
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.


**Description – This equation gives the position as a**

function of time for an object moving in ideal projectile
motion with initial velocity and position given by 𝑣⃗� =

[𝑣�,�, 𝑣�,�, 𝑣�,�] and 𝑟⃗� = [𝑥�, 𝑦�, 𝑧�] respectively.
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.



- Using the kinematic relationships, the velocity vector for

projectiles as a function of time can be deduced.



- The pathlength of a projectile can be found by integrating the

magnitude of the velocity (speed) over the time of interest
although the equation becomes quite complicated.


**Velocity (Projectile Motion)**


𝒗��⃗(𝒕) = �


𝒗𝟎,𝒙
𝒗𝟎,𝒚
−𝒈𝒕+ 𝒗𝟎,𝒛


�


**Description – This equation gives the velocity as a**

function of time for an object moving in ideal projectile
motion with initial velocity given by 𝑣⃗� =

[𝑣�,�, 𝑣�,�, 𝑣�,�].
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.


-----

#### 122.1 – Motion with just gravity

**Consider: How does an object move when it is only acted on by**
gravity?

T RELATIVELY LOW VELOCITY, OBJECTS MOVING through air near the surface of the earth act as if the only
force acting on them is the force of gravity. That is, at low speeds we can neglect air resistance, and as along as there
are no contact forces or appreciable electric or magnetic forces, the object’s motion is closely approximated by just

# A

gravity. Motion under this approximation is known as **_ideal projectile motion, or often just projectile motion.  The object_**
undergoing projectile motion is called the projectile.

Since the gravitational force only acts in the z-direction, we can write the acceleration for projectile motion as


0

𝑎⃗= � 0

−𝑔


(122-1)


�,


where g is the local gravitational field strength at the position of the projectile. The x- and y-components of the acceleration
are zero since there are no horizontal forces acting on the particle. As with most times that g comes into play, we can, in
reality, use this equation any place that we can define g – the surface of the moon, another planet, etc., as long as we can
reliably ignore other forces.


**Acceleration (Projectile Motion)**


𝟎

𝒂��⃗(𝒕) = � 𝟎 �

−𝒈


**Description – this equation gives the vector acceleration of**

an object, 𝑎⃗, in the ideal projectile motion approximation.
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.


Using the overall kinematic relationships, and noting that we have a constant vector acceleration, we can then find the
velocity as a as a function of time as


�

𝑣⃗= �𝑎⃗𝑑𝑡

�


�

= ��

�


0
0 �𝑑𝑡
−𝑔


(122-2)


= �


𝑣�,�
𝑣�,�
−𝑔𝑡+ 𝑣�,�


�,


where 𝑣�,�, 𝑣�,�, and 𝑣�,� are the components of the initial velocity in the x-, y- and z-direction, respectively.


**Velocity (Projectile Motion)**


𝒗��⃗(𝒕) = �


𝒗𝟎,𝒙
𝒗𝟎,𝒚
−𝒈𝒕+ 𝒗𝟎,𝒛


�


**Description – This equation gives the velocity as a**

function of time for an object moving in ideal projectile
motion with initial velocity given by 𝑣⃗� =

[𝑣�,�, 𝑣�,�, 𝑣�,�].
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.


-----

We can now find the relationship for the position as a function of time by once again using the kinematic relationships and
integrating. In this case, we get


�

𝑟⃗= �𝑣⃗𝑑𝑡

�


�

= ��

�


𝑣�,�
𝑣�,� �𝑑𝑡
−𝑔𝑡+ 𝑣�,�


= �


𝑣�,�𝑡+ 𝑥�
𝑣�,�𝑡+ 𝑦�

− [1]

2 [𝑔𝑡][�] [+ 𝑣][�,�][𝑡+ 𝑧][�]


�, (122-3)


**Position (Projectile Motion)**


𝒓�⃗(𝒕) = �


𝒗𝟎,𝒙𝒕+ 𝒙𝟎
𝒗𝟎,𝒚𝒕+ 𝒚𝟎

− [𝟏]

𝟐 [𝒈𝒕][𝟐] [+ 𝒗][𝟎,𝒛][𝒕+ 𝒛][𝟎]


�


**Description – This equation gives the position as a**

function of time for an object moving in ideal projectile
motion with initial velocity and position given by 𝑣⃗� =

[𝑣�,�, 𝑣�,�, 𝑣�,�] and 𝑟⃗� = [𝑥�, 𝑦�, 𝑧�] respectively.
**Note: 𝑔 is the local gravitational field strength in which the**

projectile moves.


The remainder of this unit is devoted to applications of these projectile motion equations (Equations 122-1 through 122-3.
Please note that it is often, but not always possible to find a plane in which the projectile moves, reducing the three
dimensional projectile problem to two dimensions.

#### 122.2 – One dimensional projectile motion

**Consider: What happens when you throw something straight up?**

We will first consider what happens when an object is thrown straight up, such that the x- and y- components of the velocity
are zero, meaning that the motion will be completely one-dimensional. This type of motion is called free fall. Simplifying
the projectile motion equations for section 122.1 to this condition gives us

𝑧(𝑡) = 𝑧� + 𝑣��𝑡− [1]2 [𝑔𝑡][�] and 𝑣�(𝑡) = 𝑣�� −𝑔𝑡. (122-4)

As we saw in Unit 120, there are times when we do not explicitely know the time. In this case. we can use the direct
relationship between the velocities and positions,

**Figure 122-1. Kinematic graphs for a vertically thrown object.**


-----

𝑣��(𝑡) = 𝑣��� −2𝑔(𝑧(𝑡) −𝑧�). (122-5)

Before solving vertical projectile motion problems, we will first think about this very qualitatively. Figure 122-1 shows
the position-versus-time (a), velocity-versus-time (b) and acceleration-versus-time (c) for a vertically thrown object. Table
122-1 gives some important information related to the velocity and acceleration of the object in the three areas of its motion;
on its way up, at its peak, and on its way back down.

**Table 121-1. Important relationships for vertical projectile motion.**


**Region** **Velocity**
**(direction)**


**Velocity**
**(change)**


**Acceleration**


**On the way up** up decreasing 9.8 𝑚/𝑠[�] down

**At peak** 𝑣= 0 turning around 9.8 𝑚/𝑠[�] down

**On the way down** down increasing 9.8 𝑚/𝑠[�] down


Please note:


**_even at the peak of its motion, where the velocity is zero, the acceleration of a vertically_**

**_thrown object is 9.8 m/s[2] down, since it is acted on by gravity._**

One of the most common misconceptions found in Physics I is that the acceleration of a
vertically thrown or launched object at its peak is zero. Since the acceleration is the rate of change
of velocity, if both the acceleration and velocity were zero at the peak of motion, this means that
the velocity will remain zero (since zero acceleration means the velocity will not change). This is
tantamount to saying that “what goes up must stay up” since the velocity remains zero, the object
would not come down.
Figure 122-2 shows a “stroboscopic” view of a ball thrown upward through its entire motion
from where it was launched to where it lands. There is a symmetry to an object in free fall. The
motion of the ball in Figure 122-2 is the same on the way up as it is on the way down – meaning
that there is no way to tell from a plot such as this figure to tell whether it is upward or downward
motion. In reality, the motion in Figure 122-2 is downward. The pictures of the ball are all evenly
spaced in this figure, so you can see how the speed
increases over time since the spacing between equal time
periods increases. The numbers in the figure show the
distance traveled by the bottom of the ball at each
interval.
Figure 122-3 shows further symmetry in free fall
motion. The left side of this figure shows an object
launched vertically at 8 m/s, which slows until its peak at
the top of the diagram. If allowed to fall back down, the
object would have a velocity of 8 m/s down just before
striking the ground at the height it first started. The right
side of Figure 122-3 shows the motion of an object

**Figure 122-2. Strob-** **Figure 122-3. Comparison of an**

dropped from the same height as the peak of the object

**oscopic view of an** **object thrown to a certain height with**

in the left diagram will likewise fall to a speed of 8 m/s

**object in free-fall.** **one dropped to that same height.**

just before striking the ground. In problems, you can use
such symmetries to simplify calculations – you know that at the peak of motion the velocity is zero, and you know that an
object in free fall will have the same speed with opposite direction when it reaches the height at which it started.
We are now ready to show a couple of examples related to free fall motion. Keep in mind the conceptual ideas from this
section and try to use them to simplify calculations while using Equations 122-4 and 122-5 for vertical-only free fall
problems.


Example 122 - 1 **Throwing a ball straight up**

Imagine you throw a ball straight up so that it reaches a
maximumum height of 3.7 meters (12 feet). Determine

(a) The speed at which the ball left your hand,


(b) The time the ball is in the air if you catch it at

the same height you released it,
(c) The speed of the ball just before you catch it.


-----

**Solution:**

This problems asks us to use the projectile motion
relationships in one dimension to find speeds and time.

(a) First, we define the height at which the ball leaves (and
eventually returns) to your hand as 𝑧= 0. Given, this, we
know the initial and final height, as well as the speed at the
final height (since the ball must come to rest at its maximum
height)

𝑧� = 0,
𝑧(𝑡) = 3.7 𝑚,

𝑣(𝑡) = 0.

Given that we know heights and one speed and aren’t yet
asked anything about time, the easiest solution is to use the
relatiobship

𝑣��(𝑡) = 𝑣��� −2𝑔(𝑧(𝑡) −𝑧�).

Using know information from the problem, we get


⁄

𝑡= [𝑣][��] [8.5 𝑚𝑠] = 0.867 𝑠.

𝑔 [=] 9.8 𝑚𝑠⁄ [�]

The time we found is to the peak of the motion. The
symmetry of free fall tells us that it will take the same
amount of time to fall back down to the same height it
started. Therefore

𝑡= 2(0.867 𝑠) = 1.74 𝑠.

(c) By symmetry the velocity of the ball will have the
same magnitude (speed) just before being caught as it did
just after being tossed. Therefore, the speed just before
being caught is 8.5 m/s.


(b) Again, comparing the known values to the what we
are looking for (time), the relevant projectile motion
equation is

𝑣�(𝑡) = 𝑣�� −𝑔𝑡   →   𝑡= [𝑣][��] [−𝑣]𝑔 [�][(𝑡)].

Using our known values, we find


0 = 𝑣��� −2(9.8 𝑚𝑠⁄ �)(3.7𝑚−0).

Solving for the initial speed, we find

𝑣�� = 8.5 𝑚𝑠.⁄


Example 122 - 2 **Time of flight**

A rock is thrown vertically at 10.2 m/s. (a) At what time(s) is
the rock 2.5 meters above where it is thrown? (b) What is the
speed of the rock at this height?

**Solution:**

(a) This problem asks us to use the one-dimensional free fall
equations to determine the time that an object is at a certain
height. Assuming that we call the height at which the rock is
launched 𝑧= 0, we know

𝑧� = 0
𝑧(𝑡) = 2.5 𝑚.
𝑣�� = 10.2 𝑚𝑠⁄

Using the one-dimensional equation for position as a function
of time,

𝑧(𝑡) = 𝑧� + 𝑣��𝑡− [1]2 [𝑔𝑡][�][,]


𝑡= [10.2 ± �(10.2)][�] [−4(4.9)(2.5)] = 0.28, 1.8 𝑠.

2(4.9)

Therefore, there are two times when the rock is at 2.5
meters - 𝑡= 0.28 𝑠 (on the way up) and 𝑡= 1.8 𝑠 (on
the way down).

(b) We can find the speed of the rock at each of times in
part (a) using equation 122-4

𝑣(0.28𝑠) = 10.2 [𝑚] [𝑚]

𝑠 [−�9.8] 𝑠[�][�(0.28 𝑠) = 7.46 𝑚]𝑠 [,]

𝑣(1.8 𝑠) = 10.2 [𝑚] [𝑚]

𝑠 [−�9.8] 𝑠[�][�(1.8 𝑠) = −7.45 𝑚]𝑠 [.]


form as


�4.9 [𝑚] [𝑚]

𝑠[�][�𝑡][�] [−�10.2] 𝑠[�][�𝑡+ 2.5 𝑚= 0.]

We can solve this using the quadratic formula,


we get


2.5 𝑚= 0 + �10.2 [𝑚] [𝑚]

𝑠[�][�𝑡−1]2 [�9.8] 𝑠[�][�𝑡][�][.]

This is a quadratic equation that we can rewrite in standard


This shows the symmetry of vertical motion – at the same
height the rock has the same speed both up and down,
just in different directions.


-----

#### 122.3 – Two dimensional projectile motion

**Consider: When I throw an rock from a cliff, can I figure out where it**
will land?

In all cases of ideal projectile motion, the horizontal direction of a projectiles initial velocity can define the direction of one
of the axes chosen for the motion. Since in our ideal approximations, there are no horizontal forces, the horizontal motion
will then always be along this line. In this way, we can guarantee that ideal projectile motion is along just two dimensions as
opposed to three. We will make use of this fact when considering projectile motion in multiple directions and reduce the
motion to one horizontal dimension as well as the vertical dimension (usually the z-direction).
Let’s say that a projectile is launched with a speed 𝑣 at an angle 𝜃 above the horizontal. Assuming we choose the
horizontal axis of this motion along the x-axis, we can use this information to find the components of the initial velocity as


𝑣⃗� = �


𝑣��

0
𝑣��


�= �


𝑣� cos 𝜃

0
𝑣� sin 𝜃


�. (122-6)


Again, note that this was defined in terms of an angle measured from the horizontal towards the vertical.
As with all ideal projectile motion, we know that the acceleration is only in the z-direction, 𝑎� = −𝑔. Knowing this, we
can write the velocity and position equations for a projectile motion in two dimensions as


𝑣⃗(𝑡) = �


𝑣�,�

0
−𝑔𝑡+ 𝑣�,�


�= �


𝑣� 𝑐𝑜𝑠𝜃

0
−𝑔𝑡+ 𝑣� 𝑠𝑖𝑛𝜃


�, (122-7)


and


�= �


𝑟⃗(𝑡) = �


− [1]

2 [𝑔𝑡][�] [+ 𝑣][�,�][𝑡+ 𝑧][�]


𝑣�,�𝑡+ 𝑥�

0


(𝑣� 𝑐𝑜𝑠𝜃)𝑡+ 𝑥�

0

− [1]

2 [𝑔𝑡][�] [+ (𝑣][�] [𝑠𝑖𝑛𝜃)𝑡+ 𝑧][�]


�. (122-8)


Figure 122-4 shows the parabolic motion of a projectile with the
horizontal and vertical components of the velocity at many points.
There are some interesting consequences for two-dimensional
projectile motion:

1) The **_horizontal component of the velocity does not change_**

with time.
2) The **_vertical component of the velocity does change with_**

time: it decreases as the height of the projectile increases and
increases as the height of the projectile decreases.
3) At the peak of the motion, the velocity of the projectile is the

horizontal component of the initial velocity (since the vertical
component is zero here).
4) The motion of the projectile is **_symmetric around the_**

**_maximum height (H) of the motion. The range of the_**
projectile (R) is only defined if the projectile returns to its
initial height.

In addition,


**Figure 122-4. Parabolic motion of an ideal**
**projectile showing the horizontal and vertical**
**components of velocity at many points.**


1) the time of flight of an ideal projectile is determined by its vertical motion, including its initial and final height and

the initial vertical component of the velocity
2) the horizontal displacement is determined by the horizontal component of the initial velocity and the time (from the

vertical component).


-----

In addition, for a projectile fired on flat
land, the maximum range in ideal motion
occurs at a launch angle of 45°. All angles
greater than or less than 45° have a shorter
range as shown in Figure 122-5. What’s
interesting is that complementary angles
(angles that add to 90°) for a given launch
speed have the same range, as also shown in
Figure 122-5. What this means is that
projectiles launched at 30° and 60° land in the
same place; projectiles launched at 15° and
75° land in the same place, etc.
For such complimentary angles, the
difference comes in the times – since the time

**Figure 122-5. Range of a projectile launch with a speed of 10 m/s at**

of flight is determined by the vertical

**different angles, noting the relationship of complementary angles.**

component of velocity and not the speed,
projectiles launch at a higher angle will be in the air longer, and reach a higher maximum height, even if they land in the
same place.  All of these patterns can be seen in Figure 122-5.


Example 122 - 3 **Flat land**

In a very large, flat field, a ball is launched at 14.5 m/s at an
angle of 32° above the horizontal. How long is the ball in the
air and how far from the its launch point does the ball hit the
ground. You may assume that the ball is launched from
ground level.

**Solution:**

This is a multidimensional projectile motion problem. The
overall motion of the ball will resemble Figure 122-4.

We can set ground level as 𝑧= 0, so that the initial and final
vertical positions will be zero. We can also set the launch
point as 𝑥= 0. Therefore, we know

𝑧� = 0,
𝑧(𝑡) = 0,

𝑥� = 0.

We can also use our vector relationships to break the initial
velocity into horizontal and vertical components,


0 = 0 + �7.68 [𝑚] [𝑚]

𝑠 [�𝑡−1]2 [�9.8] 𝑠[�][�𝑡][�][.]


12.30

0
7.68


𝑣⃗� = �


𝑣� cos 𝜃

0
𝑣� sin 𝜃


�= �


(14.5 𝑚𝑠⁄ ) cos 32°

0 �= �
(14.5 𝑚𝑠⁄ ) sin 32°


�𝑚𝑠⁄


From here, we can use the two-dimensional projectile motion
equations to find the time and displacement as the problem
asks for. We will start by using the equation in the vertical
direction to find the time of flight

𝑧(𝑡) = 𝑧� + 𝑣��𝑡− [1]2 [𝑔𝑡][�][.]

Using the known values shown above, this gives us


If we factor a t from each term and divide the entire
equation by 4.9 m/s[2], we find

𝑡(𝑡−1.57 𝑠) = 0.

This equation has two solutions, 𝑡= 0 and 𝑡= 1.57𝑠.
The first solution tells us that the ball is at 𝑧= 0 at 𝑡= 0,
which is our initial condition. This solution does not help
us, but it is true. However, 𝑡= 1.57 𝑠 gives us a second
time at which the ball is at the height of interest.
Therefore, we can say that the flight of the ball takes
1.75s.

Now that we know the time of flight of the ball, we can
use the projectile motion equation in the horizontal
direction to find how far the ball travels in the x-direction
as

𝑥(𝑡) = 𝑥� + 𝑣��𝑡.

Using our known velocity and time, this gives us

𝑥(2.5 𝑠) = 0 + (12.3 𝑚𝑠⁄ )(1.75 𝑠) = 19.3 𝑚.

This problem illustrates a very common technique for
projectile motion problems – use the vertical information
to find the time-of-flight and then use this time to find
horizontal displacement. This is certainly not the only
method for solving projectile motion problems, but it is a
good default if you are having trouble starting a multidimensional projectile motion problem.


-----

Example 122 - 4 **The rock and the cliff**

A rock is thrown from a sea-side cliff towards the ocean
below. If the rock is thrown from a height 27.2 meters above
the water below with a speed of 22.1 with an angle 20° above
the horizontal, how far from the base of the cliff does the rock
land and how long is the rock in the air before striking the
water?

**Solution:**

The motion of the rock is described by the figure below

If we call the level of the water 𝑧= 0, and the horizontal
position where the rock is launched 𝑥= 0, we know

𝑧� = 27.2 𝑚,

𝑧(𝑡) = 0,

𝑥� = 0.

We can also use our vector relationships to break the initial
velocity into horizontal and vertical components,


0 = 27.2 + �7.56 [𝑚] [𝑚]

𝑠 [�𝑡−1]2 [�9.8] 𝑠[�][�𝑡][�][.]


In order to find the time(s) from this equation, we must
use the quadratic formula. First, here is the above
equation in standard form

0 = �4.9 [𝑚]

𝑠[�][�𝑡][�] [−�7.56 𝑚]𝑠 [�𝑡−27.2.]


20.77

0
7.56


𝑣⃗� = �


𝑣� cos 𝜃

0
𝑣� sin 𝜃


�= �


(22.1 𝑚𝑠⁄ ) cos 20°

0 �= �
(22.1 𝑚𝑠⁄ ) sin 20°


�𝑚𝑠⁄


From here, we can use the two-dimensional projectile motion
equations to find the time and displacement as the problem
asks for. We will start by using the equation in the vertical
direction to find the time of flight

𝑧(𝑡) = 𝑧� + 𝑣��𝑡− [1]2 [𝑔𝑡][�][.]

Using the known values shown above, this gives us


Using the quadratic formula, we find

𝑡= [7.56 ± �(7.56)][�] [−4(4.9)(−27.2)] = −1.71, 3.25 𝑠.

2(−27.2)

As you can see, one of the times we get from the
quadratic formula is negative. We can neglect this result
as non-sensical.

_As an aside, the negative time value is the time that the_
_rock would be at the level of the water if the motion of the_
_rock were allowed to move backwards to make a full_
_parabola in the figure above. The math doesn’t know this_
_is physically impossible, so you have to recognize this._

To find where the rock hits the water, we can now use the
horizontal component of the projectile motion equation

𝑥(𝑡) = 𝑥� + 𝑣��𝑡,

which gives us

𝑥(3.25 𝑠) = 0 + (20.77 𝑚𝑠⁄ )(3.25 𝑠) = 67.5 𝑚.

Therefore, the rock hits the water 67.5 meters from the
base of the cliff, 3.25 seconds after it is thrown.


Extension:

How far above the water is the rock 2.5 seconds after being
launched?

**Solution:**
We know that the rock is in the air at 2.5 seconds because it
takes 3.25 seconds for the rock to hit the ground. Since we
want to know how high the rock is, we use the position
equation in the vertical direction

𝑧(𝑡) = 𝑧� + 𝑣��𝑡− [1]2 [𝑔𝑡][�][.]


For this extension, we know all of the values on the right
side of the equation, so

𝑧(2.5𝑠) = 27.2 + �7.56 [𝑚] [𝑚]

𝑠 [�(2.5𝑠) −1]2 [�9.8] 𝑠[�][�(2.5𝑠)][�][.]


Solving this, we get

𝑧(2.5𝑠) = 15.5 𝑚

Therefore, the rock is 15.5 meters at 2.5 seconds.


-----

#### 122.4 – Pathlength traveled by a projectile (optional)

**Consider: Is there a way to tell the distance a projectile has traveled**
while in the air?

The displacement between the beginning point and ending point of a projectile is quite easy to determine – we simply find
the coordinates of where the projectile strikes the ground and subtract the coordinates of where the projectile was launch.
The actual distance traveled by the object (pathlength) is considerably harder to find. This statement is true for motion of an
accelerated object in general; however, ideal projectile motion gives a perfect example of how to use vector calculus to
determine such a length. Those of you taking multivariable calculus concurrently with Physics (or before) will recognize this
as a complex application of the pathlength equation.
In general, the pathlength followed by an object is given by the integral with respect to time of the speed of the object:


�

𝑑= �|𝑣⃗|𝑑𝑡

�


(122-9)
;


therefore, we must first write a general statement for the speed of a projectile as a function of time. Since we know the x- and
y-components of the velocity as a function of time for ideal projectile motion,

𝑣� = 𝑣�� and 𝑣� = 𝑣�� −𝑔𝑡, (122-10)

the speed as a function of time is

|𝑣⃗| = �𝑣�[�] + 𝑣�[�] = �𝑣��� + �𝑣�� −𝑔𝑡��. (122-11)


The pathlength is then given by

Taking the integral we find


�

𝑑= � [�]𝑣��� + �𝑣�� −𝑔𝑡�

�


�
𝑑𝑡


−�𝑣�� −𝑔𝑡�[�]𝑣��� + �𝑣�� −𝑔𝑡�


𝑣��� + �𝑣�� −𝑔𝑡� 𝑑𝑡. (122-12)

�

� −𝑣��� log ��𝑣��� + �𝑣�� −𝑔𝑡�� + 𝑣�� −𝑔𝑡�

� . (122-13)
2𝑔 �


𝑑=


�

Interestingly, the limits only lead to a more complicated expression, since even at t = 0, many terms are left in the equation.
Therefore, the pathlength as a function of time for ideal projectile motion is


𝑑=


𝑣���𝑣��� + 𝑣��� + 𝑣��� log ��𝑣��� + 𝑣��� + 𝑣���−�𝑣�� −𝑔𝑡��𝑣��� + �𝑣�� −𝑔𝑡�� −𝑣��� log ��𝑣��� + �𝑣�� −𝑔𝑡�� + 𝑣�� −𝑔𝑡� (122-14)

.
2𝑔


As crazy as this equation looks, it is just a matter of plug-and-chug assuming we know 𝑣��, 𝑣��, 𝑔 and 𝑡. However, I
hope this gives you a feel for how quickly pathlength calculations can get complicated, even for motion that we know is
along a perfect parabola!
It is interesting to note two extremes for this equation and show that they give the correct answer. First, if we use t = 0,
we would expect to get a distance of zero, which is exactly what the equation tells us.
Second, if we use 𝑣�� = 0, suggesting that the object was launched vertically, we get

𝑑�������� = [𝑉][��]� −�𝑣�� −𝑔𝑡��𝑣2𝑔 �� −𝑔𝑡�, (122-15)


where the straight brackets represent the absolute value. This is interesting because as the projectile is on the way up, the
equation reduces to


-----

𝑑��������,�� = 𝑣��𝑡− [1]2 [𝑔𝑡][�][,] (122-16)

which is exactly what we find from our one-dimensional kinematic equation in the vertical direction (assuming 𝑦� = 0). On
the way back down, the equation is a bit more complicated, but this is because the pathlength equation is giving us the
distance traveled and not the displacement. If we solve for the time in which the projectile would return to its initial height,
our pathlength equation gives us the correct value of two times the height the projectile reaches for the distance traveled.
These extremes suggest that the general equation given above for pathlength of an ideal projectile is, indeed, correct.


Example 122 - 5 **Pathlength of a thrown rock**

What is the distance traveled (pathlength) by the rock in
Example 122-4 between the time it is released and the time it
hits the water?

**Solution:**

In order to solve this parabolic pathlength problem, we must
use Equation 122-14 using known values from Example 1224:


𝑣��� log��𝑣��� + �𝑣�� −𝑔𝑡�� + 𝑣�� −𝑔𝑡�= 878.8 𝑚�⁄𝑠�.

Putting this all together, we find


𝑣���𝑣��� + 𝑣��� = 167.1 𝑚�⁄𝑠�,


𝑣��� log��𝑣��� + 𝑣��� + 𝑣���= 1462 𝑚�⁄𝑠�,

�𝑣�� −𝑔𝑡�[�]𝑣��� + �𝑣�� −𝑔𝑡�� = −776.3 𝑚�⁄𝑠�,


𝑑=


𝑣⃗� = �


𝑣��

0
𝑣��


�= �


20.77

0
7.56


�𝑚𝑠,⁄


(167.1 + 1462 + 776.3 −878.8) 𝑚[�]⁄𝑠[�]
,
2(9.8 𝑚𝑠⁄ [�])


𝑡= 3.25 𝑠.

As noted above, although this is a complicated calculation, it
is really plug-and-chug given the known values since we
already did the full integral for you. In order, each of the
terms in the equation are


or

𝑑= 77.9 𝑚.

Therefore, the pathlength of the rock during free fall is
77.9 𝑚.


-----

