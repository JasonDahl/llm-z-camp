### – Angular momentum and torque
## 117


_Linear momentum and its conservation allow us to understand and solve many problems related to collisions. In a_
_similar fashion, angular momentum – the rotational analogy to linear momentum, allows us to solve problems of_
_collisions and explosions for extended bodies. If a collision acts on a body away from the body’s center of mass, the_
_body will undergo a torque, which will result in a change in angular momentum._

##### The Bare Essentials



- The cross-product of two vectors relates how perpendicular

the vectors are. The magnitude of the cross product is the
magnitude of one vector multiplied by the component of the
other perpendicular to the first. The direction of the cross
product is always perpendicular to both initial vectors and in a
direction given by the right-hand rule.



- The angular momentum, 𝐿[�⃗], of a massive object around any

reference point is given by the vector connecting the reference
point and the object and the momentum of the object.


**Angular Momentum**

𝑳[��⃗] = 𝒓�⃗ 𝒙 𝒑��⃗

**Description – This equation defines the angular**

momentum, 𝐿[�⃗], of an object moving with linear
momentum, 𝑝⃗, at a position, 𝑟⃗, relative to a chosen axis.
**Note: The SI unit of angular momentum is 𝑘𝑔⋅𝑚[�]/𝑠.**


**Vector Cross Product (Component Form)**


�̂ �̂ 𝒌[�]

𝒂��⃗ 𝒙 𝒃[��⃗] = �𝒂𝒙 𝒂𝒚 𝒂𝒛

𝒃𝒙 𝒃𝒚 𝒃𝒛


�


**Description – This equation shows how to calculate the**

vector cross product of two vectors, 𝑎⃗ 𝑥 𝑏[�⃗], using
component form.
**Note: 𝑎⃗= �𝑎�, 𝑎�, 𝑎�� and** 𝑏[�⃗] = �𝑏�, 𝑏�, 𝑏��.



- The angular momentum, 𝐿[�⃗], of a rotating rigid body is given by

its moment of inertia and its angular velocity.



- In component form, the cross product of two vectors reduces

to

𝑎�𝑏� −𝑎�𝑏�

𝑎⃗ 𝑥 𝑏[�⃗] = �𝑎�𝑏� −𝑎�𝑏� �

𝑎�𝑏� −𝑎�𝑏�


**Angular Momentum**

𝑳[��⃗] = 𝑰𝝎���⃗

**Description – This equation defines the angular**

momentum, 𝐿[�⃗], of a rigid body with moment of inertia, 𝐼,
rotating with angular velocity, 𝜔��⃗.
**Note: The SI unit of angular momentum is 𝑘𝑔⋅𝑚[�]/𝑠.**


**Vector Cross Product (Magnitude/Angle form)**

**Magnitude: �𝒂��⃗ 𝒙 𝒃[��⃗]�= |𝒂��⃗|�𝒃[��⃗]�𝐬𝐢𝐧𝜽**

**Direction: Right Hand Rule**

**Description – This equation describes how to find the**

magnitude of the vector cross product of two vectors,
𝑎⃗ 𝑥 𝑏[�⃗], using the magnitude of two vectors, |𝑎⃗| and �𝑏[�⃗]�
and the angle between them, 𝜃. The direction of the
cross product is then found by using the right hand rule.


**Torque**

𝝉�⃗𝒏𝒆𝒕 = [𝒅𝑳��⃗]𝒅𝒕

**Description – This equation defines the net torque on an**

object, 𝜏⃗���, in terms of the time rate of change of the
angular momentum of the object.
**Note: The SI unit of torque is 𝑁⋅𝑚.**



- The torque on an object, 𝜏⃗, is the time rate of change of the

angular momentum of the object.


-----

#### 117.1 – The vector cross product

**Consider: Why is the vector cross product important for rotational**
variables?

E INTRODUCED THE VECTOR CROSS PRODUCT when talking about
vectors in Unit 104. We saw that the cross product is a measure of how
perpendicular two vectors are. It also produces a resultant that is a vector

# W

perpendicular to both of the vectors involved in the product. In this unit, we will talk
about two quantities that are inherently both vector by nature and also directly related to
rotational motion: angular momentum and torque.
Consider a rotating merry-go-round. How can we describe the direction for which the
ride rotates? We could say counterclockwise, but this is ambiguous – what is

**Figure 117-1. Direction of a**

counterclockwise as viewed from above is clockwise when viewed from below! One way

**vector for clockwise rotation**

to get rid of this ambiguity is to define a vector related to the rotation. This vector cannot

**(viewed from above).**

lie in the plane of the rotation, because this would
once again be ambiguous. However, if we define the vector as perpendicular (normal)
to the surface which is rotating, we have everything we need. The magnitude of the
vector will be related to the strength of the rotating variable. As for the direction, there
are two vectors perpendicular to the surface (one up and one down in relation to the
merry-go-round) and so the direction of this vector can be related to clockwise versus
counterclockwise. Figures 117-1 and 117-2 show how we can define the direction for

**Figure 117-2. Direction of a** angular variables related to the rotation of a solid object, such as our merry-go-round.
**vector for counterclockwise** As noted in Unit 104, the vector cross product can be found using determinants as
**rotation (viewed from above).**


𝚤̂ 𝚥̂ 𝑘[�]

�= �𝑎� 𝑎� 𝑎�

𝑏� 𝑏� 𝑏�


𝑐⃗= 𝑎⃗𝑥𝑏[�⃗] = �


𝑎�
𝑎�
𝑎�


�𝑥�


𝑏�
𝑏�
𝑏�


�, (117-1)


for two vectors, 𝑎⃗= �𝑎�, 𝑎�, 𝑎�� and 𝑏[�⃗] = �𝑏�, 𝑏�, 𝑏��. In order to find this 3x3 determinant, we can reduce it to a sequence of
2x2 determinants as

𝚤̂ 𝚥̂ 𝑘[�]

�𝑎� 𝑎� 𝑎��= �𝑎𝑏�� 𝑎𝑏��[�𝚤̂ −�𝑎]𝑏�[�] 𝑎𝑏��[�𝚥̂ + �]𝑎𝑏�� 𝑎𝑏��[�𝑘�.] (117-2)

𝑏� 𝑏� 𝑏�

Each of the 2x2 determinants is found by multiplying the upper-left and lower-right components and subtracting the
multiplication of the upper-right and lower-left components. Performing this on each of the determinants yields

𝑎⃗𝑥𝑏[�⃗] = �𝑎�𝑏� −𝑎�𝑏��𝚤̂ −(𝑎�𝑏� −𝑎�𝑏�)𝚥̂ + �𝑎�𝑏� −𝑎�𝑏��𝑘[�], (117-3)

which can be written more succinctly as

𝑎�𝑏� −𝑎�𝑏�

𝑎⃗𝑥𝑏[�⃗] = �𝑎�𝑏� −𝑎�𝑏� �. (117-4)

𝑎�𝑏� −𝑎�𝑏�


**Vector Cross Product (Component Form)**


𝒂��⃗ 𝒙 𝒃[��⃗] = �


�̂ �̂ 𝒌[�]
𝒂𝒙 𝒂𝒚 𝒂𝒛
𝒃𝒙 𝒃𝒚 𝒃𝒛


�


**Description – This equation shows how to calculate the vector**

cross product of two vectors, 𝑎⃗ 𝑥 𝑏[�⃗], using component form.
**Note: 𝑎⃗= �𝑎�, 𝑎�, 𝑎�� and** 𝑏[�⃗] = �𝑏�, 𝑏�, 𝑏��.


-----

Similarly to the dot product, the cross product can also be written in terms of the magnitude of each vector and the angle
between them as

�𝑎⃗𝑥𝑏[�⃗]�= |𝑎⃗|�𝑏[�⃗]�sin 𝜃, (117-4)

As can be seen in Figure 117-3, the product |𝑎⃗|�𝑏[�⃗]�sin 𝜃 is equal to the area of the
parallelogram formed by the two vectors contained in the cross product. Equation 117-4

only gives the magnitude of the cross product, but not the
direction. In order to determine the direction of the cross
product using this method, we must use the right-hand-rule.

**Figure 117-3. Magnitude and**
**direction of the cross product of**

There are two versions of the general right hand rule. For **vectors a** and **_b._**
the first one, you


**Figure 117-4. One version**
**of the right-hand-rule.**


1) Point your index finger of your right hand in the direction of the first vector, a.
2) Point your middle finger in the direction of the second vector, b.
3) Your outstretched thumb, as shown in Figure 117-4 points in the direction of the
cross product of the two vectors.


For the second version, you

1) Flatten your right hand with your thumb outstretched (as shown in Figure

117-4).
2) Point the figures of your hand in the direction of the first vector, a.
3) Point your palm in the direction of the second vector, b. You may need

to bend your figures slightly if the vectors are not perpendicular

**Figure 117-5. One version of the**

4) Your thumb points in the direction of the cross product. **right-hand-rule.**

You should try each of these methods with the vectors in Figure 117-3 to verify that you understand how to find the direction
of a cross product.


**Vector Cross Product (Magnitude/Angle form)**

**Magnitude: �𝒂��⃗ 𝒙 𝒃[��⃗]�= |𝒂��⃗|�𝒃[��⃗]�𝐬𝐢𝐧𝜽**

**Direction: Right Hand Rule**

**Description – This equation describes how to find the**

magnitude of the vector cross product of two vectors,
𝑎⃗ 𝑥 𝑏[�⃗], using the magnitude of two vectors, |𝑎⃗| and �𝑏[�⃗]�
and the angle between them, 𝜃. The direction of the
cross product is then found by using the right hand rule.


Example 117 - 1 **Cross product – magnitude/angle**

What is the cross product, 𝑎⃗𝑥𝑏[�⃗], if both vectors are in the xyplane, 𝑎⃗ has magnitude of 2.3 directed 12° north of east and


that the angle between the two vectors is 72° - 12° = 60°.
We can then find

�𝑎⃗ 𝑥 𝑏[�⃗]�= (2.3)(7.2) sin 60° = 14.

For the direction, we use the right hand rule to find the
direction is up.


𝑏[�⃗] has a magnitude of 7.2 and is directed 72° north of east.

**Solution:**

This problem is best suited to the magnitude/angle
formulation of the vector cross product. We must first realize


-----

Example 117 - 2 **Cross product – components**

What is the cross product of the two vectors, 𝑎⃗= [4, −2, 5]
and 𝑏[�⃗] = [−1, −4, 5]?

**Solution:**

Since we have the components of two vectors, it is easiest to
use the component form of the cross product as


10

𝑎⃗ 𝑥 𝑏[�⃗] = �−25�.

−18


𝑎�𝑏� −𝑎�𝑏�

𝑎⃗ 𝑥 𝑏[�⃗] = �𝑎�𝑏� −𝑎�𝑏�

𝑎�𝑏� −𝑎�𝑏�


(−2)(5) −(5)(−4)


�= � (5)(−1) −(4)(5) �.

(4)(−4) −(−2)(−1)


Simplifying this relationship, we get


𝚤̂ 𝚥̂ 𝑘[�]

𝑎⃗ 𝑥 𝑏[�⃗] = �𝑎� 𝑎� 𝑎�

𝑏� 𝑏� 𝑏�

which reduces to


Again, this is a perfectly valid way to report a vector
unless you are specifically asked for magnitude and
direction.


�= �


𝚤̂ 𝚥̂ 𝑘[�]
4 −2 5
−1 −4 5


�,


#### 117.2 – Angular momentum of a rotating rigid body

**Consider: How can we quantify the momentum of a rotating body?**

Why do planets such as earth continue to rotate, essentially forever? Why is it that when a figure skater doing a twirl pulls
his or her arms in, the rate at which she rotates increases? Why is it that you feel more stable on a bicycle when the wheels
are spinning at a high rate as compared to when you try to sit stationary on that same bike? Each of these questions has to do
with angular momentum and its conservation.
Simply put, angular momentum is the rotational counterpart to the linear momentum that we studies in the last three
units. Let’s first start by remembering the relationship between translational kinetic energy and rotational kinetic energy
from Unit 109. The two energies are written, respectively, as
𝐾= [1]2 [𝑚𝑣][�] and 𝐾��� = [1]2 [𝐼𝜔][�][.] (117-5)

That is to say we can relate these equations by saying that the momentum of inertia is the rotational counterpart to the mass
(inertia) of an object and the angular speed is the angular counterpart to the linear speed.
We can use the same type of reasoning to relate linear and angular momentum and come up with an equation for the
latter. We know that the linear momentum of an object with mass m and velocity v is given by

𝑝⃗= 𝑚𝑣⃗, (117-6) **Table 117-1. Common moments of inertia**

**(see Table 109-2)**

Using the same analogies as above suggests that we should be able to **Shape** **Moment of inertia**
write the linear momentum of a rotating rigid body as

**Particle** 𝐼= 𝑀𝑅[�]

𝐿[�⃗] = 𝐼𝜔��⃗, (117-7)

**Rod held at end** 𝐼= [1]

3 [𝑀𝐿][�]

where 𝐿[�⃗] is the angular momentum. Note that just as linear momentum
is in the direction of the velocity, angular momentum is in the direction **Rod held in center** 𝐼= [1]

12 [𝑀𝐿][�]

of the angular velocity. The SI unit for angular momentum is 𝑘𝑔⋅
𝑚[�]/𝑠. **Cylindrical shell** 𝐼= 𝑀𝑅[�]
Remember that the moment of inertia of a point particle rotating
on a rigid body is given by 𝐼= 𝑀𝑅[�], where M is the mass of the

**Disk** 𝐼= [1]

particle and R is the distance of the particle from the axis of rotation of 2 [𝑀𝑅][�]
the body. For extended objects, the moment of inertial is some fraction
of this value. Common relationships for the moment of inertia are **Hollow sphere** 𝐼= [2]

3 [𝑀𝑅][�]

found in Table 109-2 (recreated in part here as Table 117-1). It is also
worth repeating that the direction of the angular velocity (and therefore **Solid sphere** 𝐼= [2]

5 [𝑀𝑅][�]

angular momentum) is found using a right hand rule as shown in
Figure 109-5.


-----

**Angular Momentum**

𝑳[��⃗] = 𝑰𝝎���⃗

**Description – This equation defines the angular**

momentum, 𝐿[�⃗], of a rigid body with moment of inertia, 𝐼,
rotating with angular velocity, 𝜔��⃗.
**Note: The SI unit of angular momentum is 𝑘𝑔⋅𝑚[�]/𝑠.**


Example 117 - 3 **Angular momentum of a disk**

What is the angular momentum of a solid disk with a mass of
21 kg and radius 1.75 m, if it rotates with an angular velocity
of 0.52𝑘[�] 𝑟𝑎𝑑/𝑠.

**Solution:**

This is a direct application of the equation for the moment of
inertia of a rotating rigid body. First we note that for a solid
disk the moment of inertia is

𝐼= [1]

2 [𝑀𝑅][�]


Therefore, the angular momentum can be written

𝐿[�⃗] = 𝐼𝜔��⃗= [1]

2 [𝑀𝑅][�][𝜔��⃗.]

Using the known values from the problem, we get


or


𝐿[�⃗] = [1]

2 [(21 𝑘𝑔)(1.75 𝑚)][�][�0.52𝑘� 𝑟𝑎𝑑/𝑠�,]

𝐿[�⃗] = 16𝑘[�] 𝑘𝑔⋅𝑚[�]/𝑠.


#### 117.3 – Angular momentum of a moving particle

**Consider: How can a particle moving in a straight line be related to**
rotations?

Imagine running in a straight line towards the very edge of a playground merry-go-round. Just as your reach the ride, you
jump up, land on the edge and grab ahold of the handle so you won’t slide off. What happens? Do you keep moving in a
straight line as Newton’s 1[st] law would suggest you should? Hopefully not – this would mean you lost your grip and slid
right off the merry-go-round. However, assuming you can maintain your grip, you will ‘stick’ to the ride and you and the
entire system will start rotating. How can linear motion be directly related to rotational motion?
The answer is that objects moving in a line have angular momentum
relative to all points in space that are along the line of motion of the object!
Later we will use the conservation of angular momentum to calculate exactly
how fast you can get such a ride moving by jumping onto it; however, for
now, it is enough for us to visualize the situation.  Let’s think about the parts
that go into how to get the merry-go-round moving. What if you were to run
straight at the center of the ride and jump on? Well, that would probably not
get it rotating very well. This suggests that how far we are from the axis of
rotation is important – the farther the better.
Just like linear momentum, we also have to be concerned with how large **Figure 117-6. Relationship between 𝒓�⃗, 𝒑��⃗, 𝜽 and**
and how fast we are moving – in fact, the ability to increase the rotations of 𝒓� **for the angular momentum of a moving**
the merry go round is related to the linear momentum of the object. Putting **particle.**
this all together, we get
𝐿[�⃗] = 𝑟⃗𝑥𝑝⃗, (117-8)

where 𝐿[�⃗] is the angular momentum of the object moving in a straight line (you in our example) and 𝑟⃗ is a vector from the axis
of rotation to the object moving in a straight line, and 𝑝⃗ is the linear momentum of the object. The cross product allows us to
relate the distance of the object at any time to the _distance of closest approach,_ 𝑟� as can be seen in Figure 117-6.
Mathematically, this relationship is

|𝑟⃗𝑥𝑝⃗| = |𝑟⃗||𝑝⃗| sin 𝜃= (|𝑟⃗| sin 𝜃)|𝑝⃗| = 𝑟�|𝑝⃗|. (117-9)


-----

**Angular Momentum**

𝑳[��⃗] = 𝒓�⃗ 𝒙 𝒑��⃗

**Description – This equation defines the angular**

momentum, 𝐿[�⃗], of an object moving with linear
momentum, 𝑝⃗, at a position, 𝑟⃗, relative to a chosen axis.
**Note: The SI unit of angular momentum is 𝑘𝑔⋅𝑚[�]/𝑠.**


As with the angular momentum of a rotating rigid body, the angular momentum of an object moving linearly is a
vector. In this case, we can use the right hand rule for cross products directly (see Section 117-1) to find the direction of
the angular momentum.

Example 117 - 4 **Example Problem**

At a certain time, a particle of mass 0.95 kg is moving with a We can now find the angular momentum of this particle
velocity given by [2, 5, -1] m/s and is at a position [4, 3, 7] directly by using equation 117-8,
relative to a chosen origin. What is the angular momentum of
the particle in this reference frame? 4 1.9

𝐿[�⃗] = 𝑟⃗ 𝑥 𝑝⃗= �3�𝑚 𝑥� 4.75 �𝑘𝑔⋅𝑚𝑠⁄ .

**Solution:** 7 −0.95

This is a direct application of the angular momentum of a By completing this cross product, we will have the
particle relative to given axis. The velocity vector and angular momentum:
position vector will define a plane and the angular momentum
will be perpendicular to this plane. (3)(−0.95) −(7)(4.75)

𝐿[�⃗] = � (7)(1.9) −(4)(−0.95) �𝑘𝑔⋅𝑚[�]⁄𝑠,

We start by finding the momentum of the particle, (4)(4.75) −(3)(1.9)


or


𝐿[�⃗] = �


𝑝⃗= 𝑚𝑣⃗= (0.95𝑘𝑔) �


2
5
−1


�𝑚𝑠⁄ = �


1.9
4.75 �𝑘𝑔⋅𝑚𝑠⁄ .
−0.95


−36.1

17.1
13.3


�𝑘𝑔⋅𝑚[�]⁄𝑠,


#### 117.4 – Torque and angular momentum

**Consider: Is there an angular quantity related to force?**

We found in Unit 114-3, we found that the force-momentum principle relates how a net force on an object is related to the
rate of change of its momentum. Continuing the analogy between linear and angular momentum, there is also a quantity
which relates how a force on an object relates to the change in angular momentum of the object. This quantity is called
**_torque. Torque is the tendency for a force to cause the change in rotation of an object. We will study exactly how to_**
calculate the torque on an object due a force in Unit 123. However, for now, it is important to realize that torque is a measure
of the change in angular momentum of an object, given by

𝜏⃗��� = [𝑑𝐿�⃗]𝑑𝑡 [.] (117-10)

Note that torque is a vector and the direction of the torque is the same direction as the change in angular momentum and
not necessarily the angular momentum itself. Just as with the relationship between velocity and acceleration, if the direction
of the torque is parallel to the angular momentum, the angular speed of the object increases; if the direction of the torque is
opposite (antiparallel) to the angular momentum, the angular speed of the object decreases; if the direction of the torque is at
some other angle to the angular momentum, the angular speed and/or direction of the angular velocity may change.


-----

**Torque**

𝝉�⃗𝒏𝒆𝒕 = [𝒅𝑳��⃗]𝒅𝒕

**Description – This equation defines the net torque on an**

object, 𝜏⃗���, in terms of the time rate of change of the
angular momentum of the object.
**Note: The SI unit of torque is 𝑁⋅𝑚.**


Example 117 - 5 **Average torque**

The angular momentum of a large ball changes from
34.1𝚥̂ 𝑘𝑔⋅𝑚[�]⁄ to 𝑠, 17.1𝑘[�] 𝑘𝑔⋅𝑚[�]⁄ in 4.5 seconds. What 𝑠
is the average net torque asking on the ball during this time?

**Solution:**

This problem asks us to directly apply the relationship
between torque and angular momentum to determine the
average net torque. As we have done with average velocity
and average acceleration, we can write the average net torque
as

𝜏⃗��� = [�𝐿�⃗]�𝑡 [.]


We can then find the average net torque, but directly
substituting our known information into this equation,
giving us


0

1

𝜏⃗��� = �𝑡[1] [�𝐿�⃗][�] [−𝐿�⃗][�][�=] 4.5 𝑠 [��] 0

17.1

Which gives us


�−�


0
34.1

0


��𝑁∙𝑚.


𝜏⃗��� = �


0
−7.57�𝑁∙𝑚.

3.8


-----

-----

