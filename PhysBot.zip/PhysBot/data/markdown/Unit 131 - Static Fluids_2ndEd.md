### – Fluids are Different than Solids
## 131


_In our studies of physics so far, we have mostly been concerned with solid, rigid bodies. Occasionally, we have_
_included drag or considered the force of buoyancy; however, in all of these cases, we were exploring how a solid_
_object behaves when interacting with a liquid or gas. In 131 we begin a three-unit discussion of fluids. Fluids differ_
_from solids in a number of ways, most notably their ability to fill a container regardless of the container’s shape –_
_that is to say fluids flow. In addition, we will explore the ideas of pressure and how the way gravity and pressure_
_relate to each other leads to our understanding of buoyancy._

#### Integration of Ideas

Review the idea of density.
Review the idea of a normal force.

#### The Bare Essentials



- Although there are many states of matter, the three most

common are solids, liquids and gasses.



- A commonly used unit for pressure is the atmosphere

(atm), where 1 𝑎𝑡𝑚= 101.3 𝑘𝑃𝑎

- Gravity causes pressure to vary with depth.


**Common States of Matter**

**Solid –** Molecules are locked into place leading
to material that is rigid, although it can be
deformed by external forces.
**Liquid –** Although free to move relative to each
other, intermolecular forces keep
molecules close together. Liquids flow,
but their density remains relatively
constant under pressure.
**Gas –** Molecules are free to move relative to
each other and interact very weakly, so
gasses flow and change density due to
external pressure.



- The force of buoyancy is derived from this pressure

variation.


**Variation of Pressure with Depth**

𝑷= 𝑷𝟎 + 𝝆𝒈𝒉 (131-4)

**Description: P is the pressure at some depth h** **_below a_**
point where the pressure is known to be P0.  is the
density of the fluid and g is the gravitational field
strength.



- **_Pressure is a measure of how much force is distributed_**

over an area.


**The Definition of Pressure**

𝑷= [𝒅�𝑭��⃗][𝑵][�] (131-1)

𝒅𝑨

**Description: This equation defines the pressure, P, as**

the magnitude of a small piece of a normal force,
𝑑�𝐹[⃗]��, acting on a small area dA.
**Note: The standard unit of pressure is the Pascal,**

where 1 Pa = N/m[2]


**Force of Buoyancy**

𝑭𝑩 = 𝝆𝒇𝒍𝒖𝒊𝒅𝒈𝑽𝒅𝒊𝒔𝒑𝒍𝒂𝒄𝒆𝒅 (131-7)

**Description: 𝐹�is the buoyant force for an object**

submerged so that it displaces a volume 𝑉��������� of
a fluid with density 𝜌�����. g is the gravitational
field strength.
**Note: The force of buoyancy is directed towards lower**

pressure (usually, but not always, upwards).


-----

#### 131-1: States of Matter

**Consider: How does the way atoms and molecules interact affect their**
_shape and consistency?_

EPENDING ON FACTORS SUCH AS temperature and pressure, the atoms and molecules in a given substance can
interact in very different ways. At low temperatures, the molecules tend to interact very strongly, and form a rigid
structure known as a molecular lattice. This is the hallmark of a **solid. Solids have a well-defined shape, their**

# D

volume is generally not affected by reasonable pressure changes, and two solids will not diffuse into each other if placed in
contact.
If we add a bit more energy to the system, the molecules can become dislodged from the lattice and move relative to
each other or flow. This is the most prominent property of fluids – complete molecules that can move and flow relative to
each other. If the molecules still interact relatively strongly, they will remain closely spaced, which we call a liquid. If we
continue to add more energy, the molecules separate further until they are widely spaced and interact very weakly; a state we
call a **gas. The molecular arrangements for solids, liquids and gasses, known as the** **phase or** **state of the substance, are**
shown in Figure 131-1.
Although solids, liquids and gasses are the most common
states of matter, they are by no means the only phases that
scientists have discovered. Another widely known, fourth state of
matter, are plasmas. Generally speaking, a plasma is phase where
enough energy has been added to the system to allow electrons to
be dislodged from their atoms, so nuclei and electrons live in a
‘soup.’
There are many known phases beyond the four already
discussed; however, we need to create extreme circumstances in

**Figure 131-1: Molecular representation of the three basic**

order to measure these exotic phases. For example, at very low

**states of matter.**

temperature, large numbers of atoms can start to act as one – a
phase known as a Bose-Einstein condensate. Somewhere between solids and liquids are phases where molecules are free to
move relative to each other in one- or two-dimensions, but not all three – a state known as liquid crystals. When energy
densities become extreme, such as was seen in the first few microseconds of the universe, a phase known as quark-gluon
plasmas existed. In this crazy phase, energy is so extreme that individual quarks, normally locked together inside of nuclei,
are free to float around separately. Figure 131-2 summarizes many of the phases of matter currently known.

#### 131-2: Pressure

**Consider: When a force acts over an area, how can we quantify the**
_effect on each small piece of the area?_

Fluid pressure is an idea we deal with all the time in everyday life. We inflate basketballs, air mattresses, and tires. When
you dive to the bottom of a pool or fly in an airplane, you can feel the pressure differences build up between the inside and
outside of your ears. When you listen to a weather report, the meteorologist will often talk about pressure differences in the

**Figure 131-2. Modern known states of matter. States are given with no definition.**


-----

atmosphere.
Many of you have probably squeezed air out of a deflating balloon, or toothpaste out of the tube before going to bed.
These two examples help to illustrate the physical idea of pressure, when we increase the force on a sample of fluid, the
pressure, or force per unit area in the fluid increases.


**The Definition of Pressure**

𝑷= [𝒅�𝑭��⃗][𝑵][�] (131-1)

𝒅𝑨

**Description: This equation defines the pressure, P, as the magnitude**

of a small piece of a normal force, 𝑑�𝐹[⃗]��, acting on a small area
dA.
**Note: The standard unit of pressure is the Pascal, where 1 Pa = N/m[2]**


Again, putting this in context, when you squeeze the tube of toothpaste, you are increasing the pressure in the paste itself.
Since the pressure inside the tube is now higher than the pressure of the air around it, the toothpaste experiences a net force
and spews from the tube.
To be very precise, we need to define the pressure at a point, because pressure can change continuously through both a
solid or fluid. In practice at an introductory level, we can approximate the pressure as the magnitude of the net normal force
divided by the area over which the force acts.
It should be pointed out that this pressure is not only **Connection: Air Pressure and You**
exerted on the surface of the fluid, but is contained
throughout the entire volume – an idea we will come back A good average estimate for the surface area of a human is
to in greater depth later. As you can see from the box 2 m[2]. Given standard air pressure of one atmosphere, this
above, the standard unit of pressure is the pascal (Pa), suggests that the force of the air on your body right now is
which is the same as a N/m[2]. Standard air pressure is approximately 2.026 x 10[5] N, or 45,000 lbs! How is it
known as 1 atmosphere = 1 atm = 1.013 x 10[5] Pa. possible that we can live under such immense force all the
The pressure in a fluid is often reported in one of two time?
ways: Absolute pressure is the pressure in a fluid relative
to a vacuum and gauge pressure is the pressure in a fluid relative to its surroundings (often the atmosphere). It is important
to know whether a given value for pressure is absolute or gauge. A good rule of thumb is to assume that the measurement is
_absolute unless it either specifically says it is gauge pressure, or if it says something like ‘relative to the exterior.’_

#### 131-3: Variation of Pressure with Depth

**Consider: Why do your ears hurt when you dive deep underwater?**

Instinctively, we can surmise that fluid pressure increases with depth. In the last section, I introduced the idea of pressure by
mentioning how your ears feel when you dive deep into a pool or during landing while you are traveling in a plane. This is
exactly the point – as you move down through the fluid (water in the case of the pool

**Table 131-1. Density of various**

and air in the case of the plane), fluid pressure increases. Now, we _feel this pressure_

**fluids and solids.**

because the pressure of the fluid inside your ears has not changed, and the difference

**Fluid (0º)** Density

between the outside and inside has created a small force on your eardrum; however,

(kg/m[3])

what we are concerned with right now is just the external air pressure.
Why is it that the pressure increases? Consider this quick example – you lie down **Fresh Water** 1000
on the floor and place a small piece of plywood on your stomach. Would you rather **Sea Water** 1030
have a 30 lb. toddler stand on the board, or a 230 lb. man? Most people would choose **Benzene** 879
the toddler because their weight would be considerably more comfortable. We can **Glycerin** 1260
also think about this in terms of pressure though – approximately the same area of **Mercury** 13600
plywood would be in contact with you no matter which of our subjects were standing **Blood** 1060
on you. So, since the areas are the same and the man weighs considerably more than **Ice** 917
the toddler, the pressure your body where it contacts the plywood would also be much **Iron** 7860
greater. There is a direct analogy between this example and air pressure – the pressure **Lead** 11300
in the air around you is caused by the weight of the air column above you, **Air (STP)** 1.29

|Table 131-1. Density of various fluids and solids.|Col2|
|---|---|
|Fluid (0º) Density (kg/m3)||
|Fresh Water 1000||
|Sea Water 1030||
|Benzene 879||
|Glycerin 1260||
|Mercury 13600||
|Blood 1060||
|Ice 917||
|Iron 7860||
|Lead 11300||
|Air (STP)|1.29|


-----

(𝜌𝑉𝑔)���

=
𝐴


(𝜌𝐴ℎ𝑔)𝐴 ��� = 𝜌���𝑔ℎ. (131-2)


𝑃��� = [𝑊]𝐴[���] =


(𝑚𝑔)���

=
𝐴


In the above equation, I used the fact that the mass of an object is its density multiplied by its volume. Density is an intrinsic
property, meaning that it is a property of the material itself. The density of some important fluids can be found in table 1311.
When you dive deep into a pool, the water pressure around you is the weight of the water column above you _plus the_
weight of the air above you. We can write this as the change of pressure due to the water, plus the initial pressure at the
water’s surface, so
𝑃����� = 𝑃������� + 𝜌�����𝑔ℎ. (131-3)

This situation can be generalized by thinking about the pressure a distance h below a position with known pressure P0 as
shown in equation 131-4 below.


**Variation of Pressure with Depth**

𝑷= 𝑷𝟎 + 𝝆𝒈𝒉 (131-4)

**Description: P is the pressure at some depth h** **_below a point where_**
the pressure is known to be P0.  is the density of the fluid and g is
the gravitational field strength.


#### 131-4: Pascal’s Principle

**Consider: How and why does a hydraulic lift work?**

_Any external force can increase pressure in a confined fluid. In the above discussion of variation of pressure with depth, the_
increased pressure came from gravity; however, you are creating the increased pressure in our model tube of toothpaste when
you squeeze it. In fact, when you increase the pressure by squeezing the tube of toothpaste, the pressure throughout the entire
fluid increases, not just where you are squeezing. This is a very important idea which is called Pascal’s Principle:

**Pascal’s Principle. Any external pressure applied to a confined fluid**

is transmitted throughout the entire fluid.

In reality, Pascal’s Principle only holds for ideal fluids, which we will discuss
in the next Unit; however, for most fluids you will encounter, Pascal’s Principle is
a very good approximation. Also, any pressure in the fluid from Pascal’s Principle
is in addition to variation of pressure with depth that we discussed above.
The prototypical physics application of Pascal’s Principle is the hydraulic lift,
shown in Figure 131-3. In such a lift, a small plate is connected by a confined
fluid to a larger plate. If a relatively small force is placed on a small plate, there is **Figure 131-3. Diagram of a hydraulic**
an increase in pressure in the fluid, which is transmitted throughout the entire fluid. **lift. F1 is the input force on area A1**
At the large plate, this increase in pressure results in a larger force. **and F2 is the output force on area A2.**


Example 131 - 1  Hydraulic lift

The foot pedal of a hydraulic lift has an area of 0.2 m[2].
How much force would you have to exert on the foot pedal
to lift a 1000 kg car, if the plate the car rests on has an area
of 8 m[2]?

**Solution:**

This is a direct application of Pascal’s Principle. When we


push on the foot pedal, the pressure increase in the fluid
will be transmitted through the entire fluid, leading to a
larger force under the car. From Pascal’s Principle:

𝑃� = 𝑃�

Now, we can plug in what we know about forces and
pressure:
.


-----

𝐹�
𝐴�


= [𝐹][�]

𝐴�


→ 𝐹� = 𝐴[𝐴][�]�


𝐹�.


In order to lift the car, we must overcome the force of
gravity on the car, so 𝐹� = 𝑚�𝑔= 1000𝑘𝑔(9.8 𝑁/𝑘𝑔),


which gives us a weight of 9800 N. Therefore

𝐹� = [0.2 𝑚]8 𝑚[�][�] [980 𝑁= 245 𝑁.]

We would only need to exert 245 N to start to raise the car


#### 131-5: Buoyancy

**Consider: Why do you feel lighter when swimming in water?**

We are now in a position to determine the exact cause of the buoyant force.
In previous units, we described the buoyant force as the upward force that
a fluid (usually liquid) uses to hold up a floating object against the force of
gravity, but we completely left out the details of how this force works. The
buoyant force is a result of how pressures vary with depth. Consider
Figure 131.4 showing the forces resulting from pressure on a cube
submerged in water. Before we consider the derivation of the buoyant
force, let’s think about how this works conceptually. Since the object is
submerged in water, there is a force pushing down on the top of the object
which is given by our general equation 𝐹= 𝑃𝐴. In addition, there is a
force pushing up on the bottom of the object, also given by 𝐹= 𝑃𝐴, but
we know from our discussion above that the pressure at the bottom surface
of our cube must be larger than the pressure at the top surface! This means
that the upward force on the bottom of the object will ‘win’ because it is
larger than the downward force on the top of the object! The net force that **Figure 131.4: Pressure on a fully submerged**
results from combining the downward force on the top and upward force **object. Note that the pressure at a given**
on the bottom is known as the buoyant force. Also note that we do not **height is constant, so the force due to the**
have to consider the forces on the sides of the cube, since forces at each **pressure on the sides will cancel. However,**

**since the pressure on the top and bottom faces**

given height will cancel.

**are different, there is a net (buoyant) force in**

Consider the net force on the object in the z-direction,

**the vertical direction.**

𝐹���,� = 𝐹������ −𝐹��������. (131-5)

Each of these forces are due to the pressure on the object, so we can substitute our known equation for force from pressure,
including our equation for variation of pressure with depth

𝐹���,� = 𝑃𝐴−𝑃�𝐴= �𝑃� + 𝜌�����𝑔ℎ�𝐴−𝑃�𝐴= 𝜌�����𝑔ℎ𝐴= 𝜌�����𝑔𝑉, (131-6)

where ℎ𝐴, the height of the object multiplied by its cross-sectional area, was replaced by the volume of the object, V.  It is
very important to note that, in this case, the volume of the object is equal to the amount of water that the object had to
displace (the volume of water that would fill the space of the cube if the cube were not there). What if the object were only
partially submerged? Well, then we would only want to include the part of the volume of the object that is submerged, which
is still the volume of the water displaced. Since in both cases, the necessary volume is the fluid volume displaced, we write
the general equation for our buoyant force based on this quantity.


**Force of Buoyancy**

𝑭𝑩 = 𝝆𝒇𝒍𝒖𝒊𝒅𝒈𝑽𝒅𝒊𝒔𝒑𝒍𝒂𝒄𝒆𝒅 (131-7)

**Description: 𝐹�is the buoyant force for an object submerged so that**

it displaces a volume 𝑉��������� of a fluid with density 𝜌�����. g is
the gravitational field strength.
**Note: The force of buoyancy is directed towards lower pressure**

(usually, but not always, upwards).


-----

#### 131-6: Archimedes’s Principle

**Consider: How is it that a steel ship can float on top of the water?**

Consider again the equation for the buoyant force we found above. We could rewrite this equation slightly by realizing that
the density of the fluid, 𝜌�����, and the volume of the fluid displaced, 𝑉��������� can be combined to find the mass of the water
displaced (𝑚����� = 𝜌�����𝑉���������). The buoyant force then becomes the displaced mass of the fluid multiplied by the
gravitational field strength, which, as usual, gives us the weight of the displaced fluid. Archimedes’s Principle sums on this
discussion nicely:


**Archimedes’s Principle. The buoyant force on an object is equal to**

the weight of the fluid displaced by the object.


Example 131 - 2  Body Fat

In the human body, the average density of fat deposits is
about 900 kg/m[3], and the average density of lean mass is
about 1100 kg/m[3]. With these values, Archimedes’s Principle
gives us one of the most accurate ways to measure body fat
percentage as this example will show.

Consider a person standing on a ‘scale’ on the bottom of a
pool of water. This scale can be any way of measuring the
force it takes to keep the person from sinking, but thinking
about someone standing on a scale is the easiest to visualize.

For our example, let’s say we have a 72 kg person (with a
weight of 706 N), and that the scale reads 38 N when the
person stands on our scale fully submerged.

The free body diagram of the person will consist
of the force of gravity, the force of buoyancy
and the normal force is shown to the right:

Note that in the free body diagram, the normal
force is the force that the scale will read (the
force it takes to hold the person up).

All of our forces are in the z-direction and considering the fact
that there is no acceleration, we can use the free body diagram
to construct a Newton’s Second Law equation:

𝐹���,� = 𝐹� + 𝐹� −𝐹� = 𝑚𝑎� = 0.

Similarly to the last example, we can substitute in for the
known forces, and find


The density of the person can then be found using 𝑚=
𝜌𝑉, or

72 𝑘𝑔

𝜌= [𝑚] [𝑘𝑔]

𝑉 [=] 0.068𝑚[�] [= 1060] 𝑚[�][.]

This value is much closer to the density of lean mass than
to that of fat, but just what is the percentage? In order to
calculate this, we take the percentage of body fat
multiplied by the density of fat added to the percentage of
lean mass multiplied by its density and set that equal to
the density of our person. Since we can assume the body
is made of only fat and lean mass, if we call the percent
body fat x, then the percent lean muscle mass must be 1 –
x. Putting this all together, we find:

𝑥𝜌��� + (1 −𝑥)𝜌���� = 1060kg/m[�],

𝑥(900 kg/m[�]) + (1 −𝑥)(1100 kg/m[�]) = 1060kg/m[�],

Solving for x, we find x = 0.20. The person has a body
fat percentage of 20%. This is right at the upper range of
what is considered healthy.


𝐹� + 𝜌�����𝑔𝑉��������� −𝐹� = 0.

Inspecting this equation, you can realize that the only
value we do not know is the volume displaced, which in
this case must also be the volume of the person:


706 𝑁−38 𝑁

𝑉= [𝐹][�] [−𝐹][�]

𝜌�����𝑔 [=] �1000 [𝑘𝑔]

𝑚[�][��][9.8𝑚]𝑠[�] [�]


= 0.068𝑚[�].


A little bit more:

The analysis above assumes there is no air in the person’s
lungs. Since air has a very low density compared to fat and
lean mass, any air in the person’s lungs will change the
average density of the person quite a bit. You can easily test
this out for yourself. Next time you are in the pool, try
floating on your back with as deep a breath as you can take.


For most people, this is relatively easy. Now, while lying
on your back, slowly blow as much air out of your lungs
as you can. Again, most people begin to sink when their
lung capacity is at about one-half. Almost everyone sinks
with a complete exhale. This should give you a feel for
how the air in your lungs can change your overall
buoyancy.


-----

Example 131 - 3  Floating iceberg

Consider an iceberg floating in the waters of the arctic. How
much of the iceberg is visible above the water? The density
of ice is about 920 kg/m[3], and the density of seawater is about
1030 kg/m[3].

**Solution:**
At first glance, you might think we need to know the volume
of the iceberg, but since only the density was given, let’s see
if we can arrange the problem so we only need the densities.

The free body diagram for ice floating in water is relatively
simple:

Since the ice is floating in water, it is not accelerating in any
direction, so 𝑎⃗= 0. Using Newton’s Second Law to
construct an equation based on the free body diagram, we get

𝐹���,� = 𝐹� −𝐹� = 𝑚𝑎� = 0.


Substituting in for the known forces, we find

𝜌�����𝑔𝑉��������� −𝑚���𝑔= 0.

The mass of the ice can be replaced with the density of
the ice multiplied by its volume, leading to.

𝜌�����𝑔𝑉��������� −𝜌���𝑔𝑉��� = 0

Notice that every term in this equation has a g, so we can
cancel out that variable, and solve for the volume ratio of
the displaced water to that of ice:


𝑉���������

𝑉���


𝜌���
=
𝜌�����


= [920 𝑘𝑔/𝑚][�]

1030 𝑘𝑔/𝑚[�] [= 0.89]


This result says that volume of the water displaced is
89% of the total volume of the iceberg – or rather that
89% of the iceberg is under water! This means that only
11% of the iceberg can be seen.


#### 131-7: Fluids are Different than Solids

In this unit, we discussed how fluids are different than solids. For one, if you were to put a force on a solid, you may deform
it some, but in general, the shape of the solid does not change drastically. (This assumes that the force is not great enough to
break the solid, which can be very complicated to discuss.)  Fluids, on the other hand, respond drastically to an outside force
– either the pressure inside the fluid is increased by the ratio of the force to the area over which the force acts, or the fluid can
be forced to move as with our tube of toothpaste example.
As another example to consider in the end, think of a helium-filled balloon placed in a car you are driving. When you hit
the brakes to slow down, you feel as though you are being pushed forward – which is really the result of your inertia
(Newton’s 1[st] Law) and the fact that you want to maintain your velocity while the car slows down. However, when you hit
the brakes, the helium balloon appears to be pushed backwards! How is this possible? Just like you, the air in the car has
inertia and wants to continue moving forward, and as it hits the windshield of your car, the windshield exerts a force on the
air, increasing the pressure, while the air in the back of the car has a slightly decreased pressure. We now have a variation in
pressure just like in our derivation of the buoyancy force – but with the pressure lower in the back of the car instead of higher
in the atmosphere. So, instead of trying to float up, the balloon floats backwards. Weird, eh?
All of the differences discussed between solids and fluids in this unit assumed that the fluid was, at least initially, at rest.
In the next two units, we will explore what happens when fluids move, and how things change even more in that case.


-----

-----

