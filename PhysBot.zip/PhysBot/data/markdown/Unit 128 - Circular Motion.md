### – Circular Motion
## 128


_In previous units, we have described how accelerations parallel or anti-parallel to motion are responsible for increases_
_and decreases in speed, respectively. In addition, we have described how acceleration perpendicular to motion is_
_responsible for a change in direction. In Unit 128, we describe how these two components of acceleration, relative to_
_the direction of motion, can be responsible for circular motion._


##### The Bare Essentials

- Circular motion can either be uniform (constant speed) or non
uniform (varying speed)

- The centripetal acceleration of an object (the acceleration that

keeps something moving in a circle) is related to the speed of
the object and the radius of the circle. An object undergoing
only centripetal acceleration will experience uniform circular
**_motion_**



- Banking a curve for cars or banking the wings of an airplane

allow for the normal force and lift force to create a centripetal
acceleration, aiding the object in turning.

- Planetary orbits are the result of Newton’s universal law of

gravity creating a centripetal acceleration


**Centripetal Acceleration**

𝒂��⃗𝒄 = − [𝒗]𝒓[𝟐] [𝒓�]

**Description – The equation describes the net centripetal**

acceleration, 𝑎⃗�, of an object undergoing uniform
circular motion at a speed, 𝑣, in part of a circle of radius,
𝑟.
**Note: The radial vector, 𝑟̂, always points away from the**

center of circulation; therefore –𝑟̂ always points towards
the center of circulation.



- The period is the time it takes an object moving in uniform

circular motion traverse one time completely around the
circule.


**Newton’s Universal Law of Gravity**

[��⃗]𝑭𝒈 = − [𝑮𝒎]𝒓[𝟏][𝟐][𝒎][𝟐] 𝒓�

**Description – This equation describes the gravitational**

force between two massive objects with masses 𝑚� and
𝑚�. 𝑟 is the distance between the objects and the force
on one object is always directed towards the other.
**Note 1: For a circular orbit, �𝐹[⃗]��= 𝑚𝑎�** = 𝑚𝑣[�]⁄𝑟



- An object undergoing non-uniform circular motion will

experience both a centripetal acceleration and a tangential
acceleration


**Acceleration in non-uniform circular motion**


𝒂��⃗𝒕𝒐𝒕𝒂𝒍 = − [𝒗]𝒓[𝟐] [𝒓�+ 𝒅𝒗]𝒅𝒕 [𝜽�]

**Description – This equation describes how circular motion**

with varying speeds can be written in terms of a
centripetal acceleration (change in direction, 𝑟̂ term) and
a change in speed (tangential acceleration, 𝜃[�] term).
**Note: This equation uses a coordinate system defined**

relative to the instantaneous direction of motion with 𝜃[�]
in the direction of motion and 𝑟̂ perpendicular to the
motion.


**Period (Circular Motion)**

𝑻= [𝟐𝝅𝒓]

𝒗

**Description – This equation defines the period, 𝑇, of an**

object in uniform circular motion in terms of the radius
of the circle it moves, 𝑟, and the linear speed of its
motion, 𝑣.
**Note 1: This equation is defined only for uniform circular**

motion.


-----

#### 128.1 – Curved motion

**Consider: How do you change the direction of a moving object?**

N THE KINEMATICS UNITS, WE DESCRIBED how accelerated objects in one-dimension will

1) Speed up, if the velocity and acceleration are parallel, or
2) Slow down, if the velocity and acceleration are antiparallel.

# I

These statements are generally true, but what happens when the acceleration vector is neither parallel nor antiparallel to the
velocity? This case inherently brings our discussion into multiple dimensions, as shown in Figure 128-1. In this figure, a
particle is moving around a circle with an initial angular speed of
𝜔. In this figure, the particle is moving around in a circular pattern
with increasing speed. This insert at the right of this figure shows
how the acceleration at the right-most point on the circle can be
broken into components which are parallel and perpendicular to
the velocity at that point:


The **_tangential acceleration,_** 𝑎� or 𝑎� is parallel to the
motion and is responsible for increases or decreases in
speed as we have previously discussed

**Figure 128-1. Definitions of radial and tangential**

The radial acceleration, 𝑎� is responsible for the change **accelerations for motion in a circle where speed**
in motion of the object and does not change the speed. In

**also changes.**

the case of circular motion, the radial acceleration is
defined pointed outwards, and the centripetal acceleration, 𝑎�, is defined as the negative of the radial acceleration. It
is the centripetal acceleration that is responsible for keeping the object moving in a circle.

We will come back to the combined effects of tangential and centripetal acceleration in Section 128-3; however, it is
important for us to first describe how centripetal acceleration is responsible for keeping an object moving in a circle.

#### 128.2 – Uniform circular motion

**Consider: What causes objects to move in a circle?**

The term uniform circular motion is used to describe an object moving in a circle with no change in speed. Following our
discussion above, this suggests that an object moving in uniform circular motion has a centripetal acceleration, but no
tangential acceleration. Now, not just any magnitude of centripetal acceleration will keep an object moving in a circle. If the

acceleration is too small, the object does not change its direction fast enough to move in
a circle; similarly, if the acceleration is too big, it will collapse towards the center of
motion.
One important feature of uniform circular motion is that the acceleration vector
must point directly towards the center at all points, as shown in Figure 128-2. The
magnitude of the acceleration required to keep an object moving in circle at a specific
speed is
𝑎� = [𝑣]𝑟[�][,] (128-1)


**Figure 128-2. Velocity and**
**acceleration in uniform circular**
**motion.**


where 𝑣 is the linear speed of rotation in a circle of radius, 𝑟.
Please note that for an object moving in uniform circular motion, the net force on
the object directed towards the center of its circular motion is the centripetal force,
𝐹���,������ = 𝐹� = 𝑚𝑎� = [𝑚𝑣]𝑟 [�][.] (128-2)


As such, the centripetal force is a consequence of real forces, and should therefore not be listed in a free body diagram. Once
all forces are summed in the radial direction, the acceleration on the right side of Newton’s 2[nd] law is replaced by the
centripetal acceleration, Equation 128-1.


-----

It should also be noted that the radial direction for a circle is defined everywhere as away from the center of circular
motion. Since an object must have an acceleration pointing towards the center of its circular motion, we can define this as
the negative of the radial direction. Given this, if we define the direction of the radial vector as 𝑟̂, we can then write the
centripetal acceleration as
𝑎⃗� = − [𝑣]𝑟[�] [𝑟̂.] (128-3)


**Centripetal Acceleration**

𝒂��⃗𝒄 = − [𝒗]𝒓[𝟐] [𝒓�]

**Description – The equation describes the net centripetal**

acceleration, 𝑎⃗�, of an object undergoing uniform
circular motion at a speed, 𝑣, in part of a circle of radius,
𝑟.
**Note: The radial vector, 𝑟̂, always points away from the**

center of circulation; therefore –𝑟̂ always points towards
the center of circulation.


The use of the centripetal acceleration and its relationship to the net force can be
seen by looking at forces on a person while riding a vertical loop in a roller coaster, as
shown in Figure 128-3. For each of these examples, we will take up as the positive zdirection. Looking at the bottom of the loop, we see the net force on the object is


𝐹[⃗]��� �


0
0
𝑛−𝑚𝑔


� (128-3)


**Figure 128-3. Free body**
**diagram for an object moving in**
**a loop.**


We can then use Newton’s second law to show
𝑛−𝑚𝑔= 𝑚𝑎� → 𝑛−𝑚𝑔= 𝑚 [𝑣]𝑟[�] [.] (128-4)

**_Note, again, that it is the acceleration on the right side of Newton’s 2[nd] law where we replace the acceleration with 𝒗[𝟐]⁄ . 𝒓_**
Looking at the top point in Figure 128-3, the net force is

𝐹���,� = −𝑛−𝑚𝑔. (128-5)

which leads to
−𝑛−𝑚𝑔= 𝑚𝑎� → −𝑛−𝑚𝑔= −𝑚 [𝑣]𝑟[�] [.] (128-6)

The accelerations, and therefore velocities, for each of these situations is different. It is also interesting to note that at the

point on the side of Figure 128-3, the normal force is not either parallel or
perpendicular to the motion of the train. Therefore, this cannot be uniform circular
motion, since it has components of acceleration parallel to the motion.
As another example of circular motion, consider a mass at the end of a string
which is swung around in a horizontal circle. The only horizontal force acting on
the mass is the tension in the string, so this tension acts as the centripetal force and
we could use Newton’s 2[nd] law to find the tension in the string. But what happens
when if the force required to keep the mass moving in a circle at a given speed
exceeds the maximum possible tension of the string? Well, in this case, the string

**Figure 128-4. A mass moving in** would snap, and the mass would fly off in a straight line directed tangentially to the
**circular motion at the end of a string** circle at the point where the string snapped. We know that the mass must move in a
**which then breaks.** straight line after the string breaks by Newton’s 1[st] law, since there are no horizontal


-----

forces acting on the mass. This situation is shown in Figure 128-4.


Example 128 - 1 **Centripetal acceleration**

What is the magnitude of the centripetal acceleration of a car
moving around a curve with a radius of 500 m if the car is
traveling at a constant speed of 25 m/s?

**Solution:**

This problem is a direct application of the equation for
centripetal acceleration

𝑎� = [𝑣]𝑟[�][.]


Using the values from the problem

⁄ )[�]
𝑎� = [(25 𝑚𝑠]500 𝑚 .

Simplifying, we find

𝑎� = 1.25 𝑚𝑠⁄ [�].

This is a very reasonable acceleration for a person
traveling around a corner.


Example 128 - 2 **An unbanked curve**

If the car from example 128-1 has a mass of 900 kg, and is
traveling on an unbanked curve so that it is only the force of
static friction stopping the car from sliding off the edge of the
road, what is the minimum coefficient of static friction
required to maintain this motion?

**Solution:**

This problem is an application of centripetal force used to
maintain curved motion. Since the car is on a horizontal
surface, our vertical forces are the normal force and the
gravitational force, and the only horizontal force we have is
friction. Therefore, Newton’s 2[nd] law gives us


or

𝜇� ≥0.13.

This is a very reasonable coefficient of static friction
between a rubber tire and the road. It would not be hard
for a car to maintain this curve at this speed. If we
wanted to find the max speed at which we could travel
around this curve using a very reasonable 𝜇� = 0.5, we
just found we would solve Newton’s law for the speed
and find

𝑣���,�.� = 50 𝑚/𝑠.


We can now use the normal force from the z-component
equation and the fact that the acceleration must be the
centripetal acceleration we have from Example 128-1 to
find

⁄

𝜇� ≥ [𝑚𝑎]𝐹�[�] = [𝑚𝑣]𝑚𝑔[�] [𝑟] = 𝑟𝑔[𝑣][�][.]

Using values from the problem, we get


𝜇� ≥


(25 𝑚𝑠⁄ )[�]

(500 𝑚)(9.8 𝑚𝑠⁄ [�])[,]


�


𝐹�

0
𝐹� −𝐹�


�= 𝑚�


𝑎
0
0


�.


The z-component of Newton’s 2[nd] law tells us that

𝐹� = 𝐹� = 𝑚𝑔.

From the x-component, we find

𝐹� ≤𝜇�𝐹� = 𝑚𝑎.


When an object moves in a circle at constant speed, we can define the period of motion as the time it takes to traverse
once around the circle. We know that the speed of an object can be found as the distance traveled by the object divided by
the time it takes to move are the circle. Also, since we know that the distance to go once around a circle is its circumference,
2𝜋𝑟, we can write
𝑣= [2𝜋𝑟] (128-7)

𝑇 [,]

where 𝑇 is the period of the circular motion. This equation can be rewritten to find the period in terms of the radius of the
circle and the uniform speed of the object.
𝑇= [2𝜋𝑟]

𝑣 [.] (128-8)


-----

**Period (Circular Motion)**

𝑻= [𝟐𝝅𝒓]

𝒗

**Description – This equation defines the period, 𝑇, of an**

object in uniform circular motion in terms of the radius
of the circle it moves, 𝑟, and the linear speed of its
motion, 𝑣.
**Note 1: This equation is defined only for uniform circular**

motion.


Example 128 - 3 **Example Problem**

A 2.00-kg mass is twirled around a horizontal circle while
attached to a 1.20-m string with a tension of 22.1 N. What is
the period of motion of this mass?

**Solution:**

This is an application of centripetal force and the relationship
for period of motion. To start this problem, we must note that
the only horizontal force acting on the mass is the tension in
this string, which must also therefore act as a centripetal
force. Therefore, we can write

𝐹� = 𝑚𝑎� = [𝑚𝑣]𝑟 [�][.]

From this equation, we can find the speed of the mass as it
revolves as

𝑣= [�𝐹][�][𝑟] .

𝑚 [= �(22.1 𝑁)(1.20 𝑚)](2.00 𝑘𝑔)


Solving, we find

𝑣= 3.64 𝑚𝑠⁄ .

Now that we know the speed of the mass, we use the
general equation for period

𝑇= [2𝜋𝑟]

𝑣 [.]

Using the values from the problem, we get


𝑇= [2𝜋(1.20 𝑚)] = 2.07 𝑠.

3.64 𝑚𝑠⁄

Therefore, it takes 2.07 s for the mass to go once around
in its circle.


#### 128.3 – Non-uniform circular motion

**Consider: Can objects speed up and slow down while moving in a**
circle?

In the last section, we assumed only a centripetal acceleration on an
object – that is an acceleration keeping the object moving in circular
motion at constant speed. We now consider what happens when we
allow the acceleration to have a vector component that is not directed
towards the center of the circle. Consider, again, Figure 128-1, which
is recreated here for convenience.
The acceleration vector at the rightmost point in the figure does
not point directly towards the center of the circle. In this case, we
define a coordinate system with one axis pointed directly towards the
center of the circle and one tangential to the circle at the point we care
about. The inset on the right side of Figure 128-1 shows how the **Figure 128-1. Definitions of radial and tangential**
vector acceleration can be broken into components along these axes. **accelerations for motion in a circle where speed**
The centripetal acceleration (𝑎� in the figure) represents the part of the **also changes.**


-----

acceleration responsible for keeping the object moving in a circle and the tangential acceleration (𝑎� in the figure) is
responsible for the change in speed. Please note that 𝑎� in the figure is parallel to the velocity at that point, which we
described earlier as the part of the acceleration responsible for speeding up or slowing down an object. Since these
components are perpendicular to each other, we can use this coordinate system to write the total acceleration as
𝑎⃗����� = − [𝑣]𝑟[�] [𝑟̂ + 𝑑𝑣]𝑑𝑡 [𝜃�,] (128-9)

where v is the speed of an object moving in a circle with radius r, 𝑟̂ is the radial direction, and 𝜃[�] is the direction tangential to
the curve at the point of interest. Please note that the differential 𝑑|𝑣⃗| is explicitly used to express that the tangential
component is responsible for a change in speed.
Equation 128-9 is a mathematical statement for what we’ve said about acceleration from the first time we introduced the
term – as the change in velocity, acceleration plays a role in both the change in speed and the change in direction. We can
now see that these two effects are related to two components of acceleration, with the radial (centripetal) acceleration
changing the direction and the tangential acceleration changing the speed.


**Acceleration in non-uniform circular motion**


𝒂��⃗𝒕𝒐𝒕𝒂𝒍 = − [𝒗]𝒓[𝟐] [𝒓�+ 𝒅𝒗]𝒅𝒕 [𝜽�]

**Description – This equation describes how circular motion**

with varying speeds can be written in terms of a
centripetal acceleration (change in direction, 𝑟̂ term) and
a change in speed (tangential acceleration, 𝜃[�] term).
**Note: This equation uses a coordinate system defined**

relative to the instantaneous direction of motion with 𝜃[�]
in the direction of motion and 𝑟̂ perpendicular to the
motion.


Example 128 - 4 **Changing speed and direction**

A car is traveling around a counterclockwise, near-circular
bend in the road with a radius of 320 m. If at a certain instant,
the car is traveling due east at 24 m/s, and is slowing down at
1.2 m/s[2], what is the magnitude and direction of the total
acceleration at that instant?

**Solution:**

This problem is an application of non-uniform circular
motion, which we know because the problem discusses
traveling around a curve and changing speed. First, we must
find the centripetal acceleration


Now, if the object is traveling east and slowing down, the
direction of the tangential acceleration must be opposite
that of the velocity of the time. Therefore, the direction
of the tangential acceleration is west. Using standard
coordinate system, we can write the total acceleration as


𝑎⃗����� = (1.8𝚥̂ −1.2𝚤̂) 𝑚𝑠⁄ [�] = �


−1.2

1.8

0


�𝑚𝑠⁄ [�].


𝑎� = [𝑣]𝑟[�] [=]


(24 𝑚𝑠⁄ )[�]

= 1.8 𝑚𝑠⁄ [�].
320 𝑚


We know that the car is traveling east and curved
counterclockwise, meaning it is moving towards the north.
Therefore, the direction of the centripetal acceleration is
north.


The magnitude and acceleration of the acceleration are
now found in the standard fashion for vectors:

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] = 2.16 𝑚𝑠,⁄

and

𝜃= tan[���][�]

�� [= 56°][ north of west. ]


-----

#### 128.4 – Banked motion

**Consider: Why are road curves banked, and why do planes tip their**
wings to turn?

Have you ever noticed that as you approach a curve on a road, there is often a road sign with a lower
speed shown than the general speed limit on the road? Such a sign is shown in Figure 128-5. These
signs are not speed limits for the curve in the same sense as the general speed limit for the road,
rather, these signs tell drivers the speed at which they should be able to go around curves and
maintain traction, even if the roads are completely slick (no friction), such as can happen when ice
forms on the road during winter.
Since we know that it is friction between a car’s tires and the road that allows a car to take a

corner, how is it possible for this to occur with
no friction? This is one of the reasons why

**Figure 128-5.**

roads are banked around curves. This situation

**Curve speed sign.**

is very similar to what happens to the normal
force on a box when placed on an inclined plane. As we discussed in
Unit 126, the normal force on an inclined plane is not vertical, and
therefore has horizontal and vertical components. The normal force on
a car on a banked road has both horizontal and vertical components to
its normal force. The horizontal component of the normal force can be
used as a centripetal force as long as the angle of banking and speed of
the car fit the equation for centripetal acceleration.
This situation is shown in Figure 128-6, where a ball is represented
as moving in a circle due to a banked slope. Even though we have an
inclined plane, when discussing the motion of an object on a banked

**Figure 128-6. A ball moving in curved motion due** curve, we do not use a sloped coordinate system – instead, we use a
**to a banked slope.** standard x-axis as horizontal and z-axis as vertical. Given this,

Newton’s 2[nd] law for the free body diagram inset of Figure 128-6 gives
us

𝐹� sin 𝜃 𝑎�

𝐹��� = � 0 �= 𝑚� 0 �, (128-10)

𝐹� cos 𝜃−𝑚𝑔 0

where we have set the acceleration as a centripetal acceleration since we anticipate the banking will change the direction of
the object (i.e., moving around the curve). The vertical component of the net force can be solved to give the normal force of
the surface on the ball (which could be important if there is friction)
𝐹� = cos 𝜃[𝑚𝑔] [,] (128-11)

and the horizontal component relates the centripetal acceleration

𝑚𝑔

𝐹� sin 𝜃= 𝑚 [𝑣]𝑟[�] → cos 𝜃 [sin 𝜃= 𝑚𝑣]𝑟[�][.] (128-12)


Solving this for the speed, we find

𝑣= �𝑔𝑟tan 𝜃. (128-13)

With equation 128-13, you can find the speed at which you could go around a curve of radius r
with banking angle 𝜃 and not require friction. That is, this is how they find the speed for a
curve as noted in Figure 128-5. Please note that this analysis did not include friction at all.
The system could be extended to include friction as a force parallel to the surface.
The same situation can be used to analyze an airplane ‘banking’ to turn while in flight.
When the airplane angles the entire body, the lift generated by the wings also changes angle,
just as banking changes the angle of the normal force. The horizontal component of the lift
can then be used to generate a centripetal force just as the normal force did above.


**Figure 128-7. A banking**
**airplane.**


-----

Example 128 - 5 **The best speed and the curve**

What is the no-friction speed for a curve with a banking angle
of 10°, if the curve is part of a circle with radius 230 m?

**Solution:**

This problem is a direct application of the banked, no friction
result found above. Therefore, we will use

𝑣= �𝑔𝑟tan 𝜃.


Using the values from the problem

𝑣= �(9.8 𝑚𝑠⁄ [�])(230 𝑚)(tan 10°),

which gives us

𝑣= 20 𝑚𝑠.⁄

Therefore, this curve can be taken at a comfortable 45
mph.


#### 128.5 – Newton’s universal law of gravity

**Consider: Why do planets move in nearly circular orbits?**

In Unit 106, we showed that the gravitational field a distance r from the center of a gravitating body of mass m is given by

𝑔⃗= − [𝐺𝑚] (128-14)

𝑟[�] [𝑟̂.]

If we say that the gravitational field is caused by a mass 𝑚�, we can write a general equation for the gravitational force on a
mass 𝑚� in such a gravitational field as
𝐹[⃗]� = 𝑚𝑔⃗= − [𝐺𝑚]𝑟[�][�][𝑚][�] 𝑟̂ (128-15)

Equation 128-15 is known as Newton’s Universal Law of Gravity. Until the advent of the general theory of relativity in the
early 20[th] Century (see Volume II of this text), this Universal Law of Gravity was used to determine the motion of planetary
objects, solar systems and galaxies for hundreds of years.


**Newton’s Universal Law of Gravity**

[��⃗]𝑭𝒈 = − [𝑮𝒎]𝒓[𝟏][𝟐][𝒎][𝟐] 𝒓�

**Description – This equation describes the gravitational**

force between two massive objects with masses 𝑚� and
𝑚�. 𝑟 is the distance between the objects and the force
on one object is always directed towards the other.
**Note 1: For a circular orbit, �𝐹[⃗]��= 𝑚𝑎�** = 𝑚𝑣[�]⁄𝑟


If one of the masses in Equation 128-15 is much, much larger than the other, then we can look in the reference frame of
the larger mass and assume that the smaller mass moves around it in either circular or elliptical motion. Although it is not a
large extension of our discussion here to explore elliptical motion, we will focus on circular motion for now. If we treat the
Universal Law as a centripetal force on the smaller mass, we can write

𝑣[�]

− [𝐺𝑚]𝑟[�][�][𝑚][�] 𝑟̂ = −𝑚�𝑎�𝑟̂ = −𝑚� 𝑟 [𝑟̂.] (128-16)

Simplifying this, we find


𝑣= [�𝐺𝑚][�] (128-17)

𝑟 [.]


-----

When large massive objects move around each

**Connection: Exoplanets**

other in circular or elliptical paths, these paths are
called orbits. Please note that an object in orbit is

In reality, both the larger mass and the smaller mass orbit around

not _weightless, but rather it is just in_ _free-fall, just_

the center of mass of the system. This means that even for a planet

as for objects in ideal projectile motion as we

orbiting a star, the star actually has a small orbit around the center

previously discussed. In order to see this, consider

of mass of the system. When we look at such a system from here

the idea of Newton’s Canon as shown in Figure

on earth, this is recognized as a slight ‘wobble’ in the star. In fact,

128-8. The

this is how we have found many of the **_exoplanets, or planets_**

figure shows

around other stars besides the sun, that we now know exist.

the results of
a cannonball
fired horizontally with different initial speeds. Paths A and B represent projectile
motion as discussed in Unit 122. As you can see, path B travels a much farther
distance than path A. In fact, it travels much more than would be predicted by our
projectile motion equations because of the curvature of the earth – as the projectile
flies through the air, the earth ‘drops out’ from below it due to this curvature. This is a
specific initial speed for the cannonball where the drop in height of the cannonball as it
flies is just met by the drop out of the earth due to its curvature – this is represented by
curve C and is, by definition, a **_circular orbit. At fast speeds, we can get elliptical_**

**Figure 128-8. Newton’s cannon.**

orbits (parth D), or even allow the cannonball to escape earth’s grip entirely (curve E).
It can be surprising to new physics students that orbits are just free-fall with such a perfectly matched horizontal velocity.
When we launch objects into orbit today, we use a combination of vertical and horizontal velocities, but the idea of how you
get an orbit fits very well with Newton’s cannon above.


-----

-----

