### – Friction
## 124


_Frictional forces are all around us. We talk about a box sliding across a frictionless floor, but we know this doesn’t_
_really exist. We say that rolling objects only experience static friction, then why do they slow down? We complete_
_projectile motion problems where we ignore air resistance, but we know air is there. Unit 124 begins our study of how_
_friction can be included in mechanical systems, giving more realism to our studies._


##### The Bare Essentials

- Friction is caused by the transverse motion of objects

compressed together and is due to physical interactions of
surfaces as well as adhesion.

- **_Static friction occurs between surfaces not moving relative to_**

each other


**Rolling resistance**

𝑭𝑹 = 𝑪𝑹𝑵

**Description – This equation defines the magnitude of the force**

of rolling friction, 𝐹�, between a surface and a rolling object
as proportional to the normal force between the rolling object
and the surface it rolls on. The constant of proportionality,
𝐶�, is known as the coefficient of rolling friction.
**Note 1: The coefficient for a rigid wheel on a perfectly elastic**

surface is given by 𝐶� = �𝑧/𝑑, where 𝑧 and 𝑑 are the
sinkage depth and diameter of the wheel, respectively.
**Note 2: Ordinary tires on concrete have a 𝐶� between 0.010 and**

0.015.



- **_Rolling resistance is due to the deformation of rolling bodies_**

causing a loss of energy. This is very different than the static
and kinetic friction described above.


**Static Friction**

𝑭𝒔 ≤𝝁𝒔𝑭𝑵

**Description – The equation describes how the magnitude of the**

maximum static friction force is related to the normal force
between two objects and the coefficient of static friction for
those two materials.
**Note 1: When an object is at rest, the magnitude of the static**

friction force is equal to the applied force working to move
the object. This equation is only used to describe the
_maximum static friction force._



- **_Kinetic friction occurs between surfaces which are moving_**

relative to each other.



- **_Drag is a friction-related force as a solid object moves_**

through a fluid (liquid or gas). There are two analytical
forms of drag based on object speed and fluid density.


**Kinetic Friction**

𝑭𝒌 = 𝝁𝒌𝑭𝑵

**Description – The equation describes how the magnitude of the**

kinetic friction force between two surfaces is related to the
normal force between the two objects and the coefficient of
kinetic friction for the two materials.



- For two specific surfaces, the coefficient of static friction is

always greater than the coefficient of kinetic friction:

𝜇�             - 𝜇�,

however, note that it is possible for 𝜇� of one set of materials
to be larger than 𝜇� for another set of materials.

- Whereas static friction can both add or remove mechanical

energy to/from a system, kinetic friction always removes
mechanical energy from a system.


**Drag Force**

𝐹� = [1]2 [𝜌𝑣][�][𝐶][�][𝐴] 𝐹� = −𝑏𝑣

High-velocity drag Low-velocity drag

**Description – These equation define the magnitude of the force**

of drag based on the speed of the object, 𝑣 and either the
linear drag coefficient, 𝑏 or the density of the fluid, 𝜌, the
cross-sectional area of the object, 𝐴, and the drag coefficient,
𝐶�.
**Note 1: The linear drag equation is generally used in liquids at**

low speed or in gasses at speeds up to around 100 𝑚/𝑠.
**Note 2:** 𝐹� is known as the drag equation and 𝐹� is known as

either Stokes drag or viscous drag.
**Note 3: A particle undergoing only linear drag will slow down as**

𝑣(𝑡) = 𝑣�𝑒[�]�[�] [�].


-----

#### 124.1 – Introduction to friction

**Consider: What is friction?**

RICTION IS A FORCE THAT IS ALL AROUND US and very hard to eliminate.  Conceptually, friction leads young
children astray – we all just ‘know’ that when we push a small toy across the floor, it will slow down and come to rest.
This gives many of us a false impression that after a pushed object leaves our hand, it will later come to rest even if we

# F

don’t interact with the object. All told, this gives the false impression that Newton’s 1[st] law is simply not true – an object in
motion does not appear to stay in motion. Of course, the reality is that friction is acting on that toy as it moves across the
floor, and this is why the toy comes to rest. The unbalanced force of friction creates an acceleration directed opposite to the
direction of motion of the toy, and it therefore slows down.
In this unit, we will explore two types of frictional interaction:

**_Friction: An interaction between two solid objects that opposes the relative motion or_**

attempted relative motion of the objects,

**_Drag: An interaction between a solid object in a fluid (liquid or gas) that acts in the_**

opposite direction to the motion of the solid object relative to the fluid.

We will start by describing friction and how it conceptually and analytically changes the nature of motion when solid
surfaces are in contact. Following this, we will discuss how drag makes it hard for a ship to maintain speed and how it
changes the trajectory of balls. Finally, we will explore rolling resistance (often called rolling friction), which causes rolling
objects to slow over time.
Friction is one of the most important examples of a non-conservative force, meaning that it does not cause the storage of
energy as potential energy. Possibly contrary to your gut instinct, we will also see that the transfer of energy through friction
can add energy to a system as well as remove it – meaning that friction can cause objects to move faster, where instinctually
we often think of it as only slowing objects down.

#### 124.2 – Static and kinetic friction

**Consider: How do solid objects slide relative to each other?**

Surfaces are rough. It doesn’t matter how smooth they may feel to you, on a microscopic
level, there are tiny little bumps and dips that can get stuck together. Figure 124.1 shows
a depiction of a surface as we continue to zoom in. On the top of the figure is what we
might think of as a smooth surface; however, the next three levels show just how jagged it
can get as we look at smaller and smaller levels.
When two surfaces arew pushed against each other with one trying to slide by the
other, the little microscopic peaks and grooves push against each other creating a resistive
force parallel to the surface of the objects. This process is shown in Figure 124-2. If you
can imagine, the extent to which the peaks and valleys settle into each other is a function
of how strongly the objects are pushed together – another way to say this, is that the
friction force must be proportional to the normal force between the two surfaces.
When we talk about two surfaces experiencing friction it is called dry friction. There
are actually two parts to dry friction between the surfaces:


1) The roughness of the surface as described above.
2) Adhesion, which accounts for how surfaces can stick together.


**Figure 124-2. Why surfaces resist relative motion**
**as one tries to slide by the other.**


**Figure 124-1. How a**
**“smooth” surface is really**

The adhesion piece for friction **rough at high magnification.**
can be very complicated. The
model of friction we will introduce in this unit is called the **_Coulomb_**
**_model of friction, named after Charles-Augustin de Coulomb, who will_**
be very important in Physics II. The Coulomb model does not work
well for surfaces with very high levels of adhesion – such as adhesive
tapes and hook and loop fasteners.  In this course, we will assume all
dry friction can be adequately modeled via the Coulomb
approximation.


-----

Static friction

**_Static friction, sometimes called stiction, is the dry friction between two surfaces that are not moving relative to each_**
other. As noted above, due to friction, we expect that the ability of surfaces to resist motion between themselves is
proportional to the normal force between them,

𝐹� ∝𝐹�. (124-1)

The constant of proportionality for static friction is called the coefficient of static friction, 𝜇�. We must be careful though let’s say we find that a box on a table can withstand a net horizontal force of 5 N before it starts to move. Therefore, if we
push on the box with a force of 2 N, the box will not move. But this means that the friction force is 2 N directed in the
opposite direction to the applied force, otherwise Newton’s 2[nd] law tells us that the box must accelerate. The key here is that
the force of static friction will oppose a net applied force up to a maximum force. All told, we can write this as

𝐹� ≤𝜇�𝐹�. (124-2)

Again, the reason this equation 124-2 has a less than or equal sign is that the force of static friction opposes the net force
applied up to the maximum value of 𝜇�𝐹�.
A few notes on the coefficient of static friction (all are true for kinetic friction described below as well):

1) 𝜇� is unitless, since it relates two forces,
2) the minimum value of 𝜇� is zero and there is no maximum value,
3) for most pairs of surfaces, 𝜇� has a value between 0 and 1.


**Static Friction**

𝑭𝒔 ≤𝝁𝒔𝑭𝑵

**Description – The equation describes how the magnitude of the**

maximum static friction force is related to the normal force
between two objects and the coefficient of static friction for
those two materials.
**Note 1: When an object is at rest, the magnitude of the static**

friction force is equal to the applied force working to move
the object. This equation is only used to describe the
_maximum static friction force._


Kinetic friction

The kinetic friction is a friction between two dry surfaces that are moving relative to each other. Like static friction,
kinetic friction is proportional to the normal force between the two surfaces in question. However, unlike static friction,
kinetic friction is always equal to a coefficient multiplied by the normal force. For kinetic friction, we use the coefficient of
kinetic friction, 𝜇�, such that

𝐹� = 𝜇�𝐹�. (124-2)

For any two given surfaces, the coefficient of kinetic friction is always smaller than the coefficient of static friction. In
words, this says that it is harder to get an object moving than it is to keep it moving. Representative values for the
coefficients of static and kinetic friction for two surfaces are given in Table 124-1.


-----

**Kinetic Friction**

𝑭𝒌 = 𝝁𝒌𝑭𝑵

**Description – The equation describes how the magnitude of the**

kinetic friction force between two surfaces is related to the
normal force between the two objects and the coefficient of
kinetic friction for the two materials.


**Table 124-1. Common values for 𝝁𝒔 and 𝝁𝒌**

**Surfaces** 𝝁𝒔 𝝁𝒌
Tires on dry concrete 1.0 0.8
Shoes on wood 1.0 0.7
Steel on steel 0.7 0.5
Tires on wet concrete 0.7 0.5
Tires on asphalt 0.6 0.4
Metal on wood 0.5 0.3
Wood on wood 0.4 
Tires on icy concrete 0.3 0.2
Shoes on ice 0.1 0.05
Ice on ice 0.1 0.03
Teflon on Teflon 0.04 0.04
Human joints (healthy) 0.01 0.003

Direction of the force of friction

For dry friction (both static and kinetic), **_the direction of the friction force on an object always opposes the relative_**
**_motion of the two surfaces creating the friction interaction. For kinetic friction, this almost always means that the friction_**
force is directed opposite the motion of one surface relative to the other. However, for static friction, we must be very
careful. Here are a couple of situations in which the force of static friction is in the direction of motion:

1) Walking. Without friction, your feet would simply slide straight

back when you push off to walk. The force of friction in this
case is in the direction you want to go.
2) Objects on the bed of a truck, train, plane, etc. In this case,

static friction is the force that starts the motion of the object. It
can be counterintuitive for many students that friction can
actually increase the speed of an object; however, in the case of
a box in the back of a pickup truck, this is exactly what happens
– the inertia of the box would keep it motionless if there were
no friction, so it is the friction force that creates the motion.

**Figure 124-3. Relationship between applied force**
**and friction force.**

Figure 124-3 shows a graphical relationship for the net applied force
versus friction force. Note again that the friction force opposes the applied force exactly up until the critical maximum value
of static friction. Then the object begins to move and the friction force from that time on is that of kinetic friction.

Figure 124-4 shows a free body diagram of a box on a table at rest being pushed to
the left by an external force. Note that, in this case, the force of friction opposes the
applied force. The inset of Figure 124-4 shows the roughness of the apparently smooth

##### 𝐹 surfaces as discussed earlier in this Unit. Solving problems including friction follows 𝐹� the same process as noted in Unit 123; however, the fact that the magnitude of the

friction force is related to the normal force couples the two dimensions. Using the free
body diagram in Figure 124-4, Newton’s second law for this system is

##### 𝐹� ≤𝜇𝐹�

−𝐹+ 𝐹�

##### 𝐹� 𝐹[⃗]��� = � 0 �= 𝑚𝑎⃗, (124-3)

𝐹� −𝐹�

**Figure 124-4. Free body diagram**
**including friction.**

where I have taken to the right as positive x and up as positive z. Noting that the box is


-----

at rest so that all components of acceleration are zero, the z-component becomes

𝐹� −𝐹� = 0 → 𝐹� = 𝐹�. (124-4)

We can then use this to find the maximum applied force to maintain static friction

−𝐹+ 𝐹� = 0 → 𝐹= 𝐹� ≤𝜇�𝐹� = 𝜇�𝐹�. (124-5)

Therefore the maximum applied force before the block starts to move, in this particular case, is the coefficient of static
friction multiplied by the weight of the block.


Example 124 - 1 **Determining coefficients of friction**

The friction force on a block moving at 2.1 m/s is determined
to be 9.87 N. If the normal force between the block and
surface is 19.3 N, what is the coefficient of kinetic friction for
this system?

**Solution:**

This is a direct application of the definition of friction, since


𝐹�� = 𝜇�𝐹� →    𝜇� = [𝐹]𝐹[��]�


.


Using values from the problem, we find

𝜇� = [9.87 𝑁]19.3 𝑁 [= 0.51]


Example 124 - 2 **Will it move, or will it not?**

A 5.19-kg block sits stationary on a perfectly flat, horizontal
surface. A horizontal force with a magnitude of 45 Newtons
acts on the block. The coefficient of static and kinetic friction
between the block and the surface are 0.50 and 0.33,
respectively. Will the block move? If it does, what is its
acceleration after it starts to move?

**Solution:**

This problem asks us to use our knowledge of friction to
determine the acceleration of a block, if any. We start by
noting that the free body diagram of this block is the same as
that in Figure 123-4. Therefore, we can write Newton’s 2[nd]
law as

−𝐹+ 𝐹� 𝑎

𝐹[⃗]��� = � 0 �= 𝑚�0�,

𝐹� −𝐹� 0

where the acceleration in the x-component could be zero, and
we know the acceleration in the z-component is zero since the
block will not be leaving the surface.

First, we need to test if this block will move, which means
that the applied force must be larger than the maximum static
friction force (from the x-component of Newton’s 2[nd] law).
We know the maximum static friction force is given by the
coefficient of static friction multiplied by the normal force.
We can use the z-component of Newton’s 2[nd] law to find this
force as

𝐹� −𝐹� = 0   →    𝐹� = 𝐹� = 𝑚𝑔.

Therefore, we can write the maximum static friction force as


𝐹��,��� = 𝜇�𝑚𝑔= (0.50)(5.19𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ),

which gives us

𝐹��,��� = 25.4 𝑁.

Since the applied force parallel to the surface (horizontal
in this case) is larger in magnitude than the maximum
static friction force, the object will accelerate.

We can now use kinetic friction along with the xcomponent of Newton’s 2[nd] law to find the acceleration
of the system as

−𝐹+ 𝐹� = 𝑚𝑎   →   𝑎= [𝜇][�][𝑚𝑔−𝐹]𝑚,

where I note that the friction force is the same as the one
given for static friction above with the coefficient of
kinetic friction replacing the coefficient of static friction.
Using values from the problem, we find


𝑎=


(0.33)(5.19𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ ) −45 𝑁
,
5.19𝑘𝑔


or

𝑎= −5.44 𝑚𝑠⁄ [�].

Note that the negative sign says that the direction of the
acceleration is in the direction of the applied force
(negative x-direction).


-----

Example 124 - 3 **Friction in an elevator**

Imagine that a 3.87-kg block is placed on the horizontal floor
of an elevator which is accelerating upwards at 1.33 m/s[2]. If
the coefficient of static friction between the block and the
floor is 0.25, what is the maximum horizontal force that can
be applied to the block before it starts to move?

**Solution:**

This is an application of static friction with a vertical
acceleration. Noting that the free body diagram for this
problem, again looks like Figure 123-4, we can write
Newton’s 2[nd] law as


𝐹[⃗]��� = �


−𝐹+ 𝐹�

0
𝐹� −𝐹�


�= 𝑚�


0
0
𝑎


�,


where the acceleration in the z-drirect is that of the elevator
and there is no acceleration in the x-direction since we are
assuming static friction.


From the z-component of Newton’s 2[nd] law, we can
determine the normal force

𝐹� −𝐹� = 𝑚𝑎   →    𝐹� = 𝐹� + 𝑚𝑎= 𝑚(𝑔+ 𝑎).

It is important to note that the normal force is not equal to
the weight of the block in this case.

We can now use this normal force to solve for the
maximum force of static friction,

𝐹�� ≤𝜇�𝐹� = 𝜇�𝑚(𝑔+ 𝑎).

Using values from this problem, we find

𝐹�� ≤(0.25)(3.87𝑘𝑔)(9.8 0𝑁𝑘𝑔⁄ + 1.33 𝑚𝑠⁄ [�]).

Therefore, the maximum static friction force is

𝐹��,��� = 10.8 𝑁.


#### 124.3 – Rolling resistance

**Consider: Why does a rolling ball slow down and stop?**

When an object rolls without slipping, there is a static friction interaction at the point of
contact between the rolling body and the surface on which the body rolls. Now, we all
know that if you roll a ball on a flat surface it will slow down and eventually stop, even if
it takes quite a while to happen. The static friction interaction cannot cause this – static
friction does not remove energy from a system in the same way kinetic friction does.
This new reaction is called **_rolling resistance or_** **_rolling drag, and is due to the_**
deformation of both the rolling body and the surface. As the system deforms and then
relaxes, friction internal to the body and the surface causes energy to leave the system,
mostly in the form of heat. The overall effect is far less than what is generally seen in
kinetic friction, which is why a rolling object will tend to go much farther before slowing
down than an object of the same material sliding across the surface.
Figure 124-5 depicts how a rolling disk compresses the surface it is rolling on leading
to rolling resistance. In this figure, W is the weight of the disk, F is the rolling resistance
force, N is the normal force and r is the radius of the disk. Note that the normal force at
the point noted is not vertical because it must be perpendicular to the surface at the point **Figure 124-5. Forces involved**
of contact – which is perpendicular to the surface of the disk at that point. **in rolling resistance.**
The force of rolling resistance can be written in analogy to the dry frictional forces in
the last section. In lieu of the static and kinetic coefficients of friction, we will use a coefficient called the rolling resistance
**_coefficient or equivalently the_** **_coefficient of rolling friction,_** 𝐶�. Using this analogy, the force of rolling friction can be
written

𝐹� = 𝐶�𝐹�. (124-6)

The coefficient of rolling friction can be well-defined for certain specific situations – see the equation box below. Table 1242 gives some typical values for 𝐶�.


-----

**Rolling resistance**

𝑭𝑹 = 𝑪𝑹𝑭𝑵

**Description – This equation defines the magnitude of the force**

of rolling friction, 𝐹�, between a surface and a rolling object
as proportional to the normal force between the rolling object
and the surface it rolls on. The constant of proportionality,
𝐶�, is known as the coefficient of rolling friction.
**Note 1: The coefficient for a rigid wheel on a perfectly elastic**

surface is given by 𝐶� = �𝑧/𝑑, where 𝑧 and 𝑑 are the
sinkage depth and diameter of the wheel, respectively.
**Note 2: Ordinary tires on concrete have a 𝐶� between 0.010 and**

0.015.


**Table 124-2. Some values for rolling resistance**
**Surfaces** 𝐶�

Steel wheel on steel rail (railroad) 0.0003 – 0.0004
Steel ball bearing on steel 0.001 – 0.0015
Passenger railroad car on rail 0.0020
High performance bicycle tires 0.0022 – 0.005
Tractor trailer tire on road 0.0045 – 0.008
Car tires on concrete 0.010 – 0.015
Car tires on sand 


Example 124 - 4 **Rolling resistance**

If a 2400-kg car is rolling on sand, what is the rolling
resistance for this car?

**Solution:**

This is a direct application of our definition of rolling
resistance. In order to find the rolling resistance, we must
first find the magnitude of the normal force between the car
and the sand;

𝐹� = 𝑚𝑔= (2400𝑘𝑔)( 9.8 0𝑁𝑘𝑔⁄ ) = 23,500 𝑁.


Using the coefficient for car tires on sand from Table
124-2, we find the rolling resistance to be

𝐹� = 𝐶�𝑁= (0.3)(23,500 𝑁),

or

𝐹� = 7,050 𝑁.

This is a sizeable force, which helps explain why cars will not
roll very far on a sandy beach.


#### 124.3 – Drag

**Consider: What are the friction-like effects of an object moving**
through air or water?

The static, kinetic and rolling resistances we have explored so far in this Unit are not
functions of the speed at which the objects are moving, at least in the Coulomb
approximation. When solid objects move through fluids (liquids and gases) however,
this is not the case. Depending on the exact situation, the drag force, as it is called, can
depend either linearly on the speed of the object, or by the square of the speed of the
object. For most sports projectiles or other objects moving at high speed through a low
density fluid, gas for example, the drag force can be written

𝐹� = [1]2 [𝜌𝑣][�][𝐶][�][𝐴,] (124-7)


where 𝜌 is the density of the fluid, 𝑣 is the speed of the object relative to the fluid, 𝐶� is
the drag coefficient, which depends on geometry and 𝐴 is the cross-sectional area of the
object presented to the fluid as it moves. Some common values for the drag coefficient **Figure 124-6. Measured drag**
are given in Figure 124-6. **coefficients.**
When the object is very small, the object moves slowly or the density of the fluid is
high (liquids), the drag is more accurately measured as proportional to the speed of the object as

𝐹� = −𝑏𝑣, (124-8)

where b is the linear drag coefficient. The linear version of drag is know as either Stokes drag or linear drag.


-----

Determining the motion of an object under the quadratic form of drag is very hard; however, for an object only under the
influence of linear drag, Newton’s 2[nd] law in one-dimension can be written

−𝑏𝑣= 𝑚𝑎 → −𝑏𝑣= 𝑚 [𝑑𝑣] (124-9)

𝑑𝑡 [,]

where I have used the kinematic relationship between velocity and acceleration. The equation on the right of 124-9 represents
a first order, linear differential equation for speed. We can rearrange this equation as


𝑑𝑣

(124-10)

𝑑𝑡 [= −𝑏]𝑚 [𝑣,]


which can be rearranged to


𝑑𝑣

(124-11)

𝑣 [= −𝑏]𝑚 [𝑑𝑡.]

Each side of this equation can be integrated from an initial speed at time 𝑡= 0 to a final speed at 𝑡= 𝑡, giving us


ln 𝑣−ln 𝑣� = − 𝑚[𝑏] [(𝑡−0)] → 𝑣(𝑡) = 𝑣�𝑒[�]�[�] [�]. (124-12)

As you can see, a particle moving under linear drag will slow down at an exponential rate.


**Drag Force**

𝐹� = [1]2 [𝜌𝑣][�][𝐶][�][𝐴] 𝐹� = −𝑏𝑣

High-velocity drag Low-velocity drag

**Description – These equation define the magnitude of the force**

of drag based on the speed of the object, 𝑣 and either the
linear drag coefficient, 𝑏 or the density of the fluid, 𝜌, the
cross-sectional area of the object, 𝐴, and the drag coefficient,
𝐶�.
**Note 1: The linear drag equation is generally used in liquids at**

low speed or in gasses at speeds up to around 100 𝑚/𝑠.
**Note 2:** 𝐹� is known as the drag equation and 𝐹� is known as

either Stokes drag or viscous drag.
**Note 3: A particle undergoing only linear drag will slow down as**

𝑣(𝑡) = 𝑣�𝑒[�]�[�] [�].


Example 124 - 5 **Slowing things down in water**

A 0.142-kg ball is dropped into water with an initial speed of
12 m/s. If the linear drag coefficient for this ball in water is
0.33 kg/s, how long will it take the ball to lose 99% of its
speed due to drag alone?

**Solution:**

This is an application of linear drag. We start by rearranging
the equation of motion for linear drag to solve for the time

𝑣(𝑡) = 𝑣�𝑒[�]�[�] [�] → 𝑡= [𝑚]𝑏 [ln �𝑣]𝑣(𝑡)[�] [�.]


The final speed, v(t) will be 0.01𝑣�, since we want it to
lose 99% of its value. Therefore

12 𝑚𝑠⁄

𝑡= [0.142 𝑘𝑔]

0.33 𝑘𝑔𝑠⁄ [ln �]0.01(12 𝑚𝑠⁄ )[�,]

which reduces to

𝑡= 1.98 𝑠.

Therefore, it takes 1.98 seconds for the ball to come very
close to rest (lose 99% of its speed).


-----

