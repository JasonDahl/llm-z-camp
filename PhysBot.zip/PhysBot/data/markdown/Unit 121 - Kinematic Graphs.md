### – Kinematic Graphs
## 121


_In Unit 120 we learned the analytical relationships between position, velocity and acceleration. Although these_
_mathematical relationships give us a powerful tool to relate such variables, it can be hard to gain an intuitive feel for_
_exactly what is occurring in such situations. In Unit 121, we explore a graphical means for relating the same variables_
_that can give a valuable, second way of thinking about the situations._

##### The Bare Essentials

- When graphically describing motion, we use position-versus
time, velocity-versus-time and acceleration-versus-time graphs.

- You must break each graph into sections – each section starts

where there is a discontinuity, change in slope or change in
concavity. Work each section of each graph separately.

- When working in the direction of derivatives:

  - Each section of the velocity graph represents the slope of
each section of the position graph.
  - Each section of the acceleration graph represents the slope
of each section of the velocity graph

- When working in the direction of antiderivatives:

  - Each point of each section of the velocity graph represents
the area under the curve of the acceleration graph to that
point.
  - Each point of each section of the position graph represents
the area under the curve of the velocity graph to that point.


-----

#### 121.1 – Graphs of position, velocity and acceleration

**Consider: How can we visualize graphs of position, velocity and**
acceleration and their relationship to each other?

N UNIT 120, WE EXPLORED THE RELATIONSHIP between position, velocity and acceleration both in general, and
specifically for constant acceleration. One way to gain an appreciation and conceptual grasp of these relationships is to
analyze graphs of the situations. Consider, first, the general equation for position as a function of time for motion with

# I

constant acceleration

𝑥(𝑡) = [1] (121-1)

2 [𝑎𝑡][�] [+ 𝑣][�][𝑡+ 𝑥][�][,]

The graph of Equation 121-1 is a parabola. If the acceleration is positive, we have a parabola which opens up and if the
acceleration is negative, we have a parabola which opens down. In addition, the value 𝑥� shows us where the position is at
time 𝑡= 0. Now, if we consider the velocity (the derivative of the position as a function of time), we get

𝑣(𝑡) = 𝑎𝑡+ 𝑣�, (121-2)

which, when graphed, is a straight line with a slope of 𝑎 and a y-intercept of 𝑣�. In this case we see that if the acceleration is
positive, we have a line which slopes upward and if the acceleration is negative, we have a line which slopes down.
Finally, we can take another derivative and find the relationship for acceleration

𝑎= 𝑎, (121-3)

which is constant as expected – remember, these equations were designed for constant acceleration. The relationships we just
derived are pictured in the right-most column of Figure 121-1 and the general equation for position as a function of time is
shown at the top of the column.
In a general sense, the graphs of position, velocity and acceleration will resemble this column for any motion under
constant acceleration. As noted above, the parabola may open up or down and the slope of the velocity may be positive or
negative depending on the sign of the acceleration; however, the general trend of shapes


###### 𝒙= 𝒙𝟎 𝒙= 𝒙𝟎 + 𝒗𝟎𝒕 𝒙= 𝒙𝟎 + 𝒗𝟎𝒕+ [𝟏]

𝟐[𝒂𝒕][𝟐]

**Figure 121-1. Kinematic graphs for different initial conditions.**


-----

𝑝𝑎𝑟𝑎𝑏𝑜𝑙𝑎
(𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛)


����������
�⎯⎯⎯⎯⎯⎯� [ 𝑠𝑙𝑜𝑝𝑒𝑑 𝑙𝑖𝑛𝑒 ]

(𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦)


����������
�⎯⎯⎯⎯⎯⎯�  [ ℎ𝑜𝑟𝑖𝑧𝑜𝑛𝑡𝑎𝑙 𝑙𝑖𝑛𝑒]

(𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛) [,]


will hold true.
To summarize; for accelerated motion

1) The x-vs-t graph is a parabola which opens up for positive acceleration and opens down

for negative acceleration,
2) The v-vs-t graph is a sloped straight line with a slope equal to the acceleration,
3) The a-vs-t graph is a horizontal line at the value of the acceleration.

What about motion with no acceleration, but with an initial velocity? In this case, our kinematics equation are those of
Equations 121-1 through 121-3, but with 𝑎= 0. Explicitly, the equations are

𝑥(𝑡) = 𝑥� + 𝑣�𝑡, 𝑣(𝑡) = 𝑣�, 𝑎= 0. (121-4)

The graphs of these three equations are shown in the middle three columns of Figure 121-1. As you can see, the position
versus time graph is a sloped line, the velocity versus time graph is a horizontal line and the acceleration versus time graph is
zero everywhere. We see a similar relationship to the graphs of accelerated motion; however, the position graph starts with a
straight line. In fact we see



[ 𝑠𝑙𝑜𝑝𝑒𝑑 𝑙𝑖𝑛𝑒 ]

(𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛)


����������
�⎯⎯⎯⎯⎯⎯�  [ ℎ𝑜𝑟𝑖𝑧𝑜𝑛𝑡𝑎𝑙 𝑙𝑖𝑛𝑒]

(𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦)


���������� 𝑧𝑒𝑟𝑜
�⎯⎯⎯⎯⎯⎯�
(𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛)[,]


To summarize graphs of motion with no acceleration, but with an initial velocity:

1) The x-vs-t graph is a sloped straight line with a slope equal to the acceleration,
2) The v-vs-t graph is a horizontal line at the value of the acceleration,
3) The a-vs-t graph is zero everywhere.

Finally, we can consider motion where both the acceleration and initial velocity are zero, giving us

𝑥(𝑡) = 𝑥�, 𝑣(𝑡) = 0, 𝑎= 0. (121-5)

This motion is shown in the left-most column of Figure 121-1. This is motion at a constant position, with the velocity and
acceleration zero everywhere in that region.
Overall, we see these general relationships as we try to move from position to velocity to acceleration

𝒅𝒆𝒓𝒊𝒗𝒂𝒕𝒊𝒗𝒆 𝒅𝒆𝒓𝒊𝒗𝒂𝒕𝒊𝒗𝒆 𝒅𝒆𝒓𝒊𝒗𝒂𝒕𝒊𝒗𝒆

𝒑𝒂𝒓𝒂𝒃𝒐𝒍𝒂 �⎯⎯⎯⎯⎯⎯�  𝒔𝒍𝒐𝒑𝒆𝒅 𝒍𝒊𝒏𝒆 �⎯⎯⎯⎯⎯⎯�  𝒉𝒐𝒓𝒊𝒛𝒐𝒏𝒕𝒂𝒍 𝒍𝒊𝒏𝒆 �⎯⎯⎯⎯⎯⎯�  𝒛𝒆𝒓𝒐.

The real power of kinematic graphs, as they are called, is to allow us to visualize motion, especially final positions and final
speeds, given a large number of changes over time. Later in this unit, we will show how to pull all of this information
together; however, for now, we are trying to create relatively simple sets of graphs.
In this course, we will consider kinematic graphs of constant acceleration (including 𝑎= 0) for now. This is because we
want to limit the position graphs to lines and parabolas, which are relatively easy to handle. When considering non-constant
acceleration, the position graphs can get very hard to create. One place where we will deviate from this rule later on is
oscillatory motion, where we will see that acceleration is related to either a sine or cosine function. Although this makes the
velocity and position graphs tenable, we will leave these examples for a later Unit.


Example 121 - 1 **Example Problem**

A car accelerates from rest to 20 m/s in 2 seconds. It then
maintains its speed of 20 m/s for 8 seconds. Finally, the car
slows to rest in 3 seconds. Starting with a position versus
time graph, draw, qualitatively, a position-versus time,
velocity-versus-time and acceleration versus time graph for
this motion.


**Solution:**

This problem asks us to draw the three kinematics graphs
for the motion described starting with the position versus
time graphs.


-----

The position-versus-time graph is shown on top in the figure
to the right. You can see that the graph is broken into three
sections

1) The initial acceleration (upward parabola),
2) Sloped line represented motion at 20 m/s,
3) The final acceleration (downward parabola).
Please note that the initial and final parabolas are only very
small parts of a full parabola. To draw these, we match
known slopes at the beginning and end (0 and 20 for the first
section).

The velocity-versus-time graph shows the derivative of the
position-versus time graph including

1) sloped line with a positive acceleration,
2) horizontal line for constant speed,
3) sloped line with a negative acceleration.

The acceleration-versus-time graph shows the derivative of
the velocity versus-time graph including

1) a positive constant acceleration for 2 seconds,
2) zero acceleration for 8 seconds,
3) a negative constant acceleration for 3 seconds.


#### 121.2 – Creating graphs from acceleration and velocity

**Consider: How can we produce kinematic graphs if we start with**
acceleration instead of velocity?

We also saw in Unit 120, that we can find the velocity and position functions as a function of time by taking the integral of
the acceleration and velocity, respectively. This is analogous to moving up Figure 121-1, starting with the acceleration
graphs and moving up through velocity to position. Using an analogy to what we found in section 121.1 for the relationships
and the shapes of the graphs, we can write

𝒊𝒏𝒕𝒆𝒈𝒓𝒂𝒍 𝒊𝒏𝒕𝒆𝒈𝒓𝒂𝒍 𝒊𝒏𝒕𝒆𝒈𝒓𝒂𝒍

𝒛𝒆𝒓𝒐 �⎯⎯⎯⎯�  𝒉𝒐𝒓𝒊𝒛𝒐𝒏𝒕𝒂𝒍 𝒍𝒊𝒏𝒆 �⎯⎯⎯⎯�  𝒔𝒍𝒐𝒑𝒆𝒅 𝒍𝒊𝒏𝒆 �⎯⎯⎯⎯�  𝒑𝒂𝒓𝒂𝒃𝒐𝒍𝒂.

For example, if we have a constant, or zero acceleration, we would expect


��������
�⎯⎯⎯⎯� [𝑝𝑎𝑟𝑎𝑏𝑜𝑙𝑎]

(𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛)[,]


ℎ𝑜𝑟𝑖𝑧𝑜𝑛𝑡𝑎𝑙 𝑙𝑖𝑛𝑒

(𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛)


��������
�⎯⎯⎯⎯�  [𝑠𝑙𝑜𝑝𝑒𝑑 𝑙𝑖𝑛𝑒]

(𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦)


which is exactly what you will see if you refer again to Figure 121.1.
The specifics become a bit more difficult when moving in this direction.
We know that the derivative of a function represents the slope of the tangent
line at the point of the derivative. This allows us to write, say, the velocity
of an object directly from the slope of the position-versus-time graph is a
region. However, the integral of a function gives us the area under the curve
between the points of integration of the function of interest. This can be
considerably harder to interpret, especially if we are looking to be very
precise in making our graphs or computing final results.


**Figure 121-2. Area under the curve as a visual**
**integration.**


-----

Figure 121-2 shows the integral of a function, f(x) as the area under the
curve between points a and b. In terms of kinematic graphs, the area under the
curve represents the change in the function above in the kinematic
relationships. For example, if you find the area under a velocity-versus-time
graph between two points to be 35 m, then the change in position between
those same two positions is 35 m. Note well that this is not the final position,
but the change in position during that interval!

Figure 121-3 shows this relationship specifically for a velocity-versus-time
graph. In this figure, the change in position of the object between times 𝑡� and
𝑡� are noted by 𝑠. As an example, let’s say that the value of s once calculated is
25 m. Then, if the object is at position 𝑥= 10 𝑚 at 𝑡�, then it would be at
10𝑚+ 25𝑚= 35 𝑚 at 𝑡�. Again, I can not stress enough that s represents the
change in position and not the final position itself.

Figure 121-3 also shows the acceleration of the object at three points

**Figure 121-3. The change in position, s,** around the peak at 𝑡�. As you can see, this object is changing acceleration from
**and accelerations at various positions on** positive to negative at this point since the slope of the velocity is changing from
**a v-vs-t graph.** positive to negative here.

Example 121 - 2 **Kinematic graphs from acceleration**

An object undergoes an acceleration given by the following
graph


Find the velocity-versus-time and position-versus-time graphs
for this motion.

**Solution:**

Qualitatively, the graphs of this motion are shown to the right.
Qualitatively note that

 - regions where the acceleration are zero have constant
velocity. If that velocity is positive, the position is
increasing, if it is negative, the position is decreasing,
and if it is zero, the position does not change.
 - regions where the acceleration is positive have velocity
with a positive slope and positions with upward
opening parabolas
 - regions where the acceleration is negative have velocity
with negative slope and position with downward
opening parabolas.


More quantitatively, the shaded areas under the curve
become the change in the value of the next graph. For
example, consider the first positive acceleration. The
shaded region under that curve is how much the velocity
will change over that same period.


#### 121.3 – Connecting graphs and computations

**Consider: How do kinematic graphs relate to kinematic calculations?**

In this section, we are going to take a deeper look into the acceleration graph from Example 121-2 above and connect it to
constant acceleration calculations similar to the ones done near the end of Unit 120. First, consider a slightly more detailed
version of the acceleration graph from Example 121-2 above, which is shown in Figure 121-4.


-----

**Figure 121-4. Acceleration versus time graph for analysis in this section.**

In this example, the object starts with a velocity of zero and an initial position of 𝑥= 10𝑚. The regions of the graph
above are as follows:

1) Zero acceleration for 7 s.
2) An acceleration of 2 m/s[2], which starts at t=7 s and lasts for 4 s.
3) Zero acceleration for 5 s.
4) An acceleration of -4 m/s[2], which starts at t=16 s and lasts for 2 s.
5) Zero acceleration for 3 s.
6) An acceleration of -1 m/s[2], which starts at t=21 s and lasts for 4 s.
7) Zero acceleration for 13 s.
8) An acceleration of 4 m/s[2], which starts at t=38 s and lasts for 1 s.

For each of these regions, we need to calculate the final velocity and position, so that they can become the initial velocity and
position for the next section. We will take this region-by-region and compare the final results to the graphs in Example 1212.

Region 1: Zero acceleration for 7 s.

Since there is no acceleration and this initial velocity of this section is zero, the final velocity of this region is
also zero and the position of x=10m has not changed.

Region 2: Acceleration of 2 m/s[2] for 4 s.

Since we have an accelerated region, with initial speed of zero and initial position of x=10m

𝑥(𝑡) = 10 𝑚+ 0(4𝑠) + [�] [𝑚] [𝑚]

� [�2] 𝑠[�][�(4 𝑠)][�] [= 26𝑚          𝑣(𝑡) = 0 + �2] 𝑠[�][�(4 𝑠) = 8 𝑚]𝑠 [.]


Region 3: Zero acceleration for 5 s.

𝑥(𝑡) = 16 𝑚+ 8 [𝑚]

𝑠 [(5 𝑠) +][ �]�[(0)(5 𝑠)][�] [= 66𝑚          𝑣(𝑡) = 8 𝑚]𝑠 [+ (0)(4 𝑠) = 8 𝑚]𝑠 [.]


Region 4: Acceleration of -4m/s[2] for 2 s.

𝑥(𝑡) = 56 𝑚+ 8 [𝑚] [𝑚] [𝑚]

𝑠 [(2 𝑠) +][ �]� [�−4] 𝑠[�][�(2 𝑠)][�] [= 74 𝑚          𝑣(𝑡) = 8 𝑚]𝑠 [+ �−4] 𝑠[�][�(2 𝑠) = 0 𝑚]𝑠 [.]


Region 5: Zero acceleration for 3 s.

𝑥(𝑡) = 64 𝑚+ 0 [𝑚] [𝑚] [𝑚]

𝑠 [(3 𝑠) +][ �]� [�0] 𝑠[�][�(3 𝑠)][�] [= 74 𝑚          𝑣(𝑡) = 0 𝑚]𝑠 [+ �0] 𝑠[�][�(3 𝑠) = 0 𝑚]𝑠 [.]


-----

Region 6: Acceleration of -1 m/s[2] for 4s

𝑥(𝑡) = 64 𝑚+ 0 [𝑚] [𝑚] [𝑚]

𝑠 [(4 𝑠) +][ �]� [�−1] 𝑠[�][�(4 𝑠)][�] [= 66 𝑚          𝑣(𝑡) = 0 𝑚]𝑠 [+ �−1] 𝑠[�][�(4 𝑠) = −4 𝑚]𝑠 [.]


Region 7: Zero acceleration for 13 s.

𝑥(𝑡) = 56 𝑚+ �−4 [𝑚] [𝑚] [𝑚]

𝑠 [�(13 𝑠) +][ �]� [�0] 𝑠[�][�(13 𝑠)][�] [= 14 𝑚          𝑣(𝑡) = −4 𝑚]𝑠 [+ �0] 𝑠[�][�(13 𝑠) = −4 𝑚]𝑠 [.]


Region 8: Acceleration of 4 m/s[2] for 1s.


𝑥(𝑡) = 4 𝑚+ �−4 [𝑚] [𝑚] [𝑚]

𝑠 [�(1 𝑠) +][ �]� [�4] 𝑠[�][�(1 𝑠)][�] [= 12 𝑚          𝑣(𝑡) = −4 𝑚]𝑠 [+ �4] 𝑠[�][�(1 𝑠) = 0 𝑚]𝑠 [.]

If you check each of these regions with the graphs in Example 121-2, you will see that the analytical values we just found
completely agree with those graphs. It can take quite a while to get use to drawing position-versus-time, velocity-versus-time
and acceleration-versus-time graphs; however, they can give you a very powerful way to understand kinematic motion and
compare expected results to completely analytic results for constant acceleration.
Specifically, for each accelerated region above, if you compare the area under the acceleration-versus-time graph (the
acceleration multiplied by the time difference since they are all rectangles), you will see that each of these is equal to the
change is speed of the object during that period. Mathematically, this is not surprising because the equation for velocity in
constant acceleration is

𝑣(𝑡) = 𝑎𝑡+ 𝑣� → 𝑣(𝑡) −𝑣� = ∆𝑣= 𝑎𝑡, (121-2)

which tells us exactly that the change in velocity is the area under the curve as just described.


-----

-----

