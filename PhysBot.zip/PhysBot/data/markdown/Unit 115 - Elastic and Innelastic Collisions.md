### – Elastic and Inelastic Collisions
## 115


_In this unit, we will apply the conservation of momentum in one dimension to collision and explosion problems. There_
_are three important types of collisions: elastic, inelastic and perfectly inelastic, depending on how the objects interact_
_during the collision. This unit will also help prepare you for Unit 116 which will discuss some applications of the_
_conservation of momentum._


##### The Bare Essentials

- Collisions fall into two basic categories:

   - **_Elastic collisions – both energy and momentum are_**
conserved
   - **_Inelastic collisions – only momentum is conserved._**

- In an elastic collision, changes in potential energy can usually

be ignored so that we compare initial and final kinetic energies
as well as initial and final momenta.

- A totally, or perfectly inelastic collision is a special category

of inelastic collisions where the objects stick together in the
final state.

- In the elastic collision of multiple objects, we can have two

unknowns since we can use both momentum and energy
conservation.



- In the inelastic collision of multiple objects, we can only have

one unknown since we can only use momentum conservation.


**Inelastic Collision**

𝚫𝒑��⃗𝒔𝒚𝒔 = 𝟎

**Description – This equation describes how an inelastic**

collision or explosion conserves only momentum.
**Note: The collision must occur on a fast scale to ensure**

conservation of momentum.



- In a perfectly inelastic collision, we only have one final

velocity because the objects stick together.


**Elastic Collision**

𝚫𝒑��⃗𝒔𝒚𝒔 = 𝟎          𝚫𝑲𝒔𝒚𝒔 = 𝟎

**Description – The equation describes how an elastic**

collision conserves both the momentum and kinetic
energy of an isolated system.
**Note: The collision must occur on a fast scale to ensure**

conservation of momentum.


**Perfectly Inelastic Collision**

𝒑��⃗𝟏,𝒊 + 𝒑��⃗𝟏,𝒊 + 𝒑��⃗𝟏,𝒊 + ⋯= (𝒎𝟏 + 𝒎𝟐 + 𝒎𝟑 + ⋯)𝒗��⃗𝒇

**Description – The equation simplifies the conservation of**

momentum equation for a perfectly inelastic collision
noting that the final velocity of all particles must be the
same.
**Note: The collision must occur on a fast scale to ensure**

conservation of momentum.


-----

#### 115.1 – Momentum and three types of collisions/explosions

**Consider: How does momentum relate to collisions?**

N THIS UNIT, WE WILL EXPLORE HOW the conservation of momentum can be
used to investigate collisions and explosions. Consider the collision of two cars.
Just before the collision, there is a good chance the drivers in each of the cars will hit

# I

the brakes, most likely causing friction to slow them down. After the collision, the cars
might stick together or the might bounce off of each other and skid to a stop. Therefore,
both before and after the collision, the two-car system has external forces acting on
objects in the system – it is not an isolated system. However, during the short period
while the collision is actually occurring, the forces between the two cars so overwhelm
any external forces that we can treat the system as isolated – for this short period of time.
You see, during this short time, external forces such as friction, gravity and the normal
force might affect the system, but they are not responsible for the changes in motion

**Figure 115-1. A cartoon**

during that time, only the internal forces between the two objects are responsible for this

**explosion. Although we often talk**

change.

**about collisions for momentum**

The same argument can be made for explosions. When a bomb explodes, the

**conservation, keep in mind that it**

chemical interaction between molecules causes a rapid transfer of energy from chemical **holds for explosions as well.**
potential energy to kinetic energy (and heat, sound and pressure as well). The actual
explosion occurs over a very short period of time, so that we can treat the system as isolated and use the conservation of
momentum. Throughout the next couple of units the term collision will be used for systems that can be treated as isolated as
described above. Keep in mind that although we use just “collision” to describe this process, it also holds for explosions.
There are three types of collisions we will be concerned with


**_Elastic Collision – A collision to conserves both momentum and kinetic energy. In_**

reality, this type of collision is very rare; however, many systems are close enough to
be modeled as elastic

**_Inelastic collision – A collision where momentum is conserved but kinetic energy is not_**

conserved. The vast majority of collisions in everyday life are of this type.

**_Perfectly (totally) inelastic collision – A collision where the colliding particles stick_**

together. The interaction between particles that allows them to stick together
guarantees that kinetic energy will not be conserved. These collisions are relatively
easy to calculate since there is only one final velocity.

In this unit, we will explore each of these types of collisions in one-dimension. In Unit 116 we will explore collisions
and explosions in three dimensions as well as some real-life consequences of such interactions.

#### 115.2 – Inelastic collisions

**Consider: How do I use the conservation of momentum in a collision**
problem?

Before delving into the conservation of momentum and collisions, there is a very important distinction to make:

**Be careful with the term inelastic collision. Any collision or explosion where kinetic**
**energy is not conserved is an inelastic collision. When objects stick together in a**
**collision, it is called a totally or perfectly inelastic collision. Don’t just assume object**
**stick together in all inelastic collisions!**

Unless otherwise told specifically in a problem, you should assume all collisions are inelastic collisions. The vast
majority of collisions in everyday life are inelastic, since most lose at least some mechanical energy through radiation as
sound, light, heat, pressure waves (shock waves) or deformation (changing shape). How many collisions have you noticed in
your life that included absolutely no sound or change in shape?  Even colliding billiard balls give of a distinctive crack and
colliding silly putty morphs to odd shapes during their respective collisions.


-----

In the next section, we will see that there are truly elastic collisions – such as when a comet changes its direction as it
approaches the sun. In addition, if very little energy is lost we can model some other systems as elastic – such as the
colliding billiards balls of the last paragraph. In this case, sound waves carry away so little energy that the motion of the
balls after the collisions is what we would expect from an elastic collision. More on this later.
To investigate a general inelastic collision, we should first start with the conservation of momentum.


**Inelastic Collision**

𝚫𝒑��⃗𝒔𝒚𝒔 = 𝟎

**Description – This equation describes how an inelastic**

collision or explosion conserves only momentum.
**Note: The collision must occur on a fast scale to ensure**

conservation of momentum.


In practice there are two ways to approach using the conservation of momentum equation for collisions. To illustrate this
consider the collision of two particles which are moving along the x-axis. In this case, we could write the conservation of
momentum equation as

∆𝑝� + ∆𝑝� = 0 → �𝑝�� −𝑝���+ �𝑝�� −𝑝���= 0, (115-1)

where 𝑝�� and 𝑝�� are the final and initial momenta of particle 1 and 𝑝�� and 𝑝��are the final and initial momenta of particle
2, respectively. This form works very well conceptually in terms of describing what is occurring with momentum,
momentum transfer and the conservation of momentum.  Equation 115-1 also works well for calculating each terms;
however, it is also common to rearrange Equation 115-1 so that all of the initial terms are on one side of the equation and all
of the final terms are on the other side of the equation as
𝑝�� + 𝑝�� = 𝑝�� + 𝑝��. (115-2)

Again, keep in mind that I wrote this for two interacting particles, but you could write this for as many are in a system, each
additional particle would represent a new term on each side (initial and final). Also, remember that for each particle in each
condition (initial and final) the momentum can be written using 𝑝= 𝑚𝑣, which gives u

𝑚�𝑣�� + 𝑚�𝑣�� = 𝑚�𝑣�� + 𝑚�𝑣��. (115-3)

Whether you prefer to use Equation 115-1 or Equation 115-2 does not matter – both are completely valid; however, in
this book we will tend to use the first version since it is more directly related to the definition of the conservation of
momentum.
In an inelastic collision, we only have one equation to work with. This means that we can only have one unknown,
which is typically (but not always) the final velocity of one of the particles. The following examples will demonstrate how
the conservation of momentum can be applied to some simple inelastic collisions.


Example 115 - 1 **Colliding Carts**

A 115-g cart, initially moving at 2.0 m/s strikes an identical
cart which is initially at rest. After the collision, the first cart
recoils at 0.50 m/s in the opposite direction of its initial
motion. How fast is the cart that was initially at rest moving
after the collision?

**Solution:**

This problem asks us to use the conservation of momentum in
one dimension to find one of the final velocities when all
other velocities are known. In order to do this, we start with
the equation for the conservation of momentum for a one

dimensional collision of two objects:

∆𝑝� + ∆𝑝� = 0  →  �𝑝�� −𝑝���+ �𝑝�� −𝑝���= 0.

The mass in the momentum of each term of this equation
are the same, so they can be factored out and canceled,
leaving

�𝑣�� −𝑣���+ �𝑣�� −𝑣���= 0.

Solving for the final velocity of the second cart, we get


-----

𝑣�� = 𝑣�� + 𝑣�� −𝑣��.

Even though we have a one dimensional problem, we must be
very careful with signs. If we take the direction of the initial
speed as the positive direction, then when the first cart
rebounds backwards (in the opposite direction), we must use
the fact that it is moving in the negative direction (-0.50 m/s).


Substituting our known values in, we find

𝑣�� = 0 + 2 𝑚𝑠⁄ −(−0.50 𝑚𝑠⁄ ),

which simplifies to

𝑣�� = 2.5 𝑚/𝑠.


Example 115 - 2 **A more complex collision**

Two balls are initially moving directly towards each other.
One ball of mass 2.5 kg is initially moving at 1.7 m/s east.
The second ball, with mass 0.90 kg, is initially moving west at
2.1 m/s. After the balls collide, the 2.5 kg ball is found to
move 0.15 m/s east. What is the final velocity of the 0.90 kg
ball?

**Solution:**

Similar to Example 115-1, this is a one-dimensional collision
of two bodies, so we can start with a similar conservation
equation:

∆𝑝� + ∆𝑝� = 0  →  �𝑝�� −𝑝���+ �𝑝�� −𝑝���= 0,

Where the subscript 1 represents the 2.5-kg ball and the
subscript 2 represents the 0.90-kg ball. Since the masses of
the balls are different, we must keep them in the equation.
Using the definition of classical momentum, we can now
write

�𝑚�𝑣�� −𝑚�𝑣���+ �𝑚�𝑣�� −𝑚�𝑣���= 0.


Solving this equation for the final velocity of ball 2, we
find

𝑣�� = 𝑣�� − 𝑚[𝑚][�]� �𝑣�� −𝑣���.

Using the known values from the problem, we get


𝑣�� = −2.1m/s − 0.90𝑘𝑔[2.5𝑘𝑔] [(0.15m/s −1.7m/s),]

where I have make the initial velocity of ball 2 negative
since it was moving in the opposite direction to ball 1’s
initial motion.

Simplifying this expression, we find

𝑣�� = 2.21 𝑚𝑠⁄ .

Therefore ball 2 moves away from the collision at 2.21
m/s in the initial direction of ball 1.


#### 115.3 – Perfectly inelastic collisions

**Consider: What happens when objects stick together?**

When objects collide and stick together, they must have the same final velocity. In order for this to occur, some energy must
have been expended in the ‘sticking.’ For example, if two small objects collide with oppositely facing Velcro on their
surfaces, some energy goes into the strands of Velcro interweaving. If a car and small truck collide energy went into the
deformation of both vehicles and the intermingling of parts that holds the two vehicles close.
The net effect is that any collision where objects stick together must lose kinetic energy and therefore must be inelastic.
This type of collision is called a perfectly or totally inelastic collision. Since we know the final velocities must be the same,
we can simplify the conservation of momentum equation. Again, assuming that our objects are moving just along the x-axis
before the collision, we can rewrite Equation 115-3 as

𝑚�𝑣�� + 𝑚�𝑣�� = 𝑚�𝑣� + 𝑚�𝑣�, (115-4)

where I have used only one final velocity, 𝑣�, since we know they must be the same. This equation can then be simplified to

𝑚�𝑣�� + 𝑚�𝑣�� = (𝑚� + 𝑚�)𝑣�, (115-5)

As before, this equation is written for just two interacting particles, but can be expanded by including a new terms for each
additional particle.


-----

**Perfectly Inelastic Collision**

𝒑��⃗𝟏,𝒊 + 𝒑��⃗𝟏,𝒊 + 𝒑��⃗𝟏,𝒊 + ⋯= (𝒎𝟏 + 𝒎𝟐 + 𝒎𝟑 + ⋯)𝒗��⃗𝒇

**Description – The equation simplifies the conservation of**

momentum equation for a perfectly inelastic collision
noting that the final velocity of all particles must be the
same.
**Note: The collision must occur on a fast scale to ensure**

conservation of momentum.


The examples below show how this equation can be used to relate initial and final momenta.


Example 115 - 3 **A car meets a barrier**

A 1500-kg car moving north on ice at 22 m/s strikes a 250-kg
barrier which is initially at rest. If the car and barrier stick
together, what is the speed of the car/barrier mess
immediately after the collision?

**Solution:**

This is a perfectly inelastic one-dimensional collision problem
since the objects involved stick together. Given this, we can
start with a two-object, perfectly inelastic collision equation
(equation 115-5) as

𝑚�𝑣�� + 𝑚�𝑣�� = (𝑚� + 𝑚�)𝑣�.


Solving for the final velocity, we find

𝑣� = [𝑚][�]𝑚[𝑣][��]� [+ 𝑚]+ 𝑚[�]�[𝑣][��]

Noting that 𝑣�� = 0, we find


.


⁄
𝑣� = [1500 𝑘𝑔(22 𝑚𝑠) + 0]1500 𝑘𝑔+ 250 𝑘𝑔 = 19 𝑚𝑠⁄ .

Therefore, the combined mass leaves the collision at 19
m/s in the same direction the car was initially moving.


#### 115.4 – Elastic collisions

**Consider: Does energy conservation play a role in collisions?**

In an elastic collision, both momentum and kinetic energy are conserved:

∆𝑝⃗��� = 0 ∆𝐾��� = 0, (115-6)

Once again, I will rewrite these equations in terms of the initial and final states for two particles in a one-dimensional system
using the mass and speed or velocity of each particle

�𝑚�𝑣�� −𝑚�𝑣���+ �𝑚�𝑣�� −𝑚�𝑣���= 0,


�[1] � − [1] � �+ �[1] � − [1] � �= 0.

2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��]


(115-7)


Although the second equation in 115-7 could be simplified by removing the common ½, I will leave it in this form so that
each term resembles kinetic energy.
Equations 115-7 give us two equations for the same system – which allows us to solve for two unknowns.
Mathematically, this is much more difficult process than for all inelastic collisions because the terms in the kinetic energy
equation deal with the square of the velocity and not just the velocity. However this is just a situation of solving two
equations for two unknowns, however tedious it may become.
Although solving for the final speeds in an elastic collision is one possible use of Equations 115-7, they are also used to
test whether a given collision is elastic or inelastic. Once you have the results of a collision calculation, you can compare the
initial and final kinetic energy for the system and see if it is conserved.


-----

As a bit of an aside, you can also use the technique described in the last paragraph to test for the validity of a collision,
which crash investigators routinely do when there are differing accounts of an accident. Unless there is some sort of energy
source, you would not expect the final kinetic energy after a collision to be more than the initial kinetic energy. Witness
accounts of an accident which lead to increases in kinetic energy can easily be proven false and removed from investigations.
This type of scientific forensic analysis is often used for automobile, train and aircraft accidents.


Example 115 - 4 **Is energy conserved?**

Is the collision in Example 115-2 elastic, inelastic or perfectly
inelastic?

**Solution:**

This problem asks us to determine if a collision is elastic or
inelastic. In order to do this, we must determine the total
kinetic energy before the collision and compare it to the total
kinetic energy after the collision. (Note that we can eliminate
perfectly inelastic as the type of collision since the objects do
not stick together.)

First, we will find the kinetic energy of the two object both
before and after the collision:

𝐾�� = [1]2 [𝑚][�][𝑣][��]� = [1]2 [(2.5𝑘𝑔)(1.7 𝑚𝑠]⁄ )[�] = 3.61 𝐽


𝐾�� = [1]2 [𝑚][�][𝑣][��]� = [1]2 [(0.90𝑘𝑔)(2.21 𝑚𝑠]⁄ )[�] = 2.20 𝐽

Using these values, we find the total kinetic energy
before and after the collision are

𝐾� = 3.61 𝐽+ 1.98 𝐽= 5.59 𝐽,
and

𝐾� = 0.028 𝐽+ 2.20 𝐽= 2.23 𝐽,

respectively.

As you can see, the kinetic energy of the system is
considerably lower after the collision than it is initially.
Thus, this is an inelastic collision. Incidentally, the
system lost


𝐾�� = [1]2 [𝑚][�][𝑣][��]� = [1]2 [(0.90𝑘𝑔)(−2.1 𝑚𝑠]⁄ )[�] = 1.98 𝐽

𝐾�� = [1]2 [𝑚][�][𝑣][��]� = [1]2 [(2.5𝑘𝑔)(0.15 𝑚𝑠]⁄ )[�] = 0.028 𝐽


5.59 𝐽−2.23 𝐽

𝑥100 = 60%
5.59 𝐽

of its initial kinetic energy, meaning that the system lost
more than half of its energy to heat, light, sound, etc.


Example 115 - 5 **An elastic collision**

A pool ball (ball 1), initially moving at 4.5 m/s makes a headon elastic collision with a second identical ball (ball 2), which
is initially at rest. What are the final velocities of each ball?

**Solution:**

This problem asks us to solve an elastic collision where each
of the initial velocities are known, but neither of the final
velocities are given. In order to do this, we start with are
known equations for an elastic collision of two objects in one
dimension (equations 115-7):

�𝑚�𝑣�� −𝑚�𝑣���+ �𝑚�𝑣�� −𝑚�𝑣���= 0,

�[1] � − [1] � �+ �[1] � − [1] � �= 0.

2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��] 2 [𝑚][�][𝑣][��]


We can immediately simplify these two equations by noting
that all of the masses are the same, so the mass can be
factored out and canceled from each equation. Also, we know
that the initial velocity of ball 2 is zero (𝑣�� = 0). With these


simplifications, the conservation of momentum and
kinetic energy can be written

𝑣�� −𝑣�� + 𝑣�� = 0   →  𝑣�� + 𝑣�� = 4.5 𝑚𝑠⁄,

𝑣��� −𝑣��� + 𝑣��� = 0   →   𝑣��� + 𝑣��� = (4.5 𝑚𝑠⁄ )[�],

where I have inserted the initial velocity of ball 1 on the
right side of each equation. These equations represent a
set of two equations with two unknowns, 𝑣�� and 𝑣��.

Solving this set of equation is tedious. We must first
solve the linear equation for one of the final speeds and
then substitute this into the second equation. This gives
us a quadratic for one speed, which we must them solve
using the quadratic formula. This result can then be used
in the linear equation to find the other final speed.

There are two solutions to the equations we found above:

𝑣�� = 0, 𝑣�� = 4.5 𝑚𝑠⁄,


-----

and

𝑣�� = 4.5 𝑚𝑠⁄,     𝑣�� = 0.

The second solution is impossible because it requires the first
ball to completely pass through the second ball (which
remains at rest). The mathematics do not understand that this
is physically impossible, so we must use our intuition to
eliminate the second answer.

The second solution, however, is completely plausible. It
says that as ball 1 comes in at 4.5 m/s and strikes ball 2 (at
rest), ball 1 will come to rest and ball 2 will move away at the
same speed ball 1 initially had. This conserves both
momentum and energy and is therefore consistent with an
elastic collision.


Again, please note the complexity of this problem in
terms of its mathematical solution – and this was for a
problem where all of the masses can be eliminated from
the equations and one of the initial speeds is zero.

Therefore, elastic collision problems can get analytically
very complex, and require quite a bit of time and paper to
solve. One reasonable method of solution is to set up
equations from Equations 115-7, as we did above, and
then use a mathematics program such as Mathematica or
Wolfram Alpha to solve the equations for you. This
works well for large homework problems or for projects
involving energy conservation.


-----

-----

