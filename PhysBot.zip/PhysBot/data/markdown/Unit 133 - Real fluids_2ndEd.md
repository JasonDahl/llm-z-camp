### – Real Fluids Move Mountains
## 133


_In the last unit, we applied Bernoulli’s Equation to ideal fluids to explore the effects of moving fluids. However, the fact_
_that ideal fluids ignore all the effects of friction – both inside the fluid and with the boundaries of fluid flow – eliminates_
_the most interesting effects of the fluids. In this unit, we introduce a few of the more tractable effects of real fluids,_
_including pressure changes and turbulence, and conclude with how real fluids can literally move matter around._

#### The Bare Essentials



- Viscosity is a measure of friction in a fluid.



- Reynolds’s Number helps us determine whether a flow is

laminar or turbulent


**Definition of Viscosity**

𝜼= 𝑭 [𝒚] (133-1)

𝒗𝟎𝑨[.]

**Description: This equation defines the viscosity of a**

fluid as found by placing the fluid between two flat
plates. F is the force it takes to keep the upper plate
a fixed distance, 𝑦, above a stationary plate of crosssectional area, A, moving at a speed, 𝑣�, relative to
the stationary plate.
**Unit: The unit of viscosity is 𝑃𝑎⋅𝑠.**


**Reynolds’s Number for Tube Flow**

𝑹𝑬 = [𝟐𝝆𝒗𝒓]𝜼 (133-4)

**Description: This equation defines the Reynold’s**

Number for fluid flow in a tube of radius r in terms
of the density of the fluid, 𝜌, the speed of the fluid
flow, 𝑣, and the viscosity of the fluid, 𝜂.
**Note: Flow is laminar if 𝑅� < 2000, unstable if 𝑅� is**

between 2000 and 3000 and turbulent if 𝑅� > 3000.



- Poiseuille’s Law tells us how pressure decreases in a real

fluid as it flows. In reverse, this law also tells us how a
difference in pressure can cause a fluid flow.


**Poiseuille’s Law**

𝑷𝟏 −𝑷𝟐 = [𝟖𝜼𝑳𝑸]𝝅𝒓[𝟒] (133-3)

**Description: Poiseuille’s Law tells us how a difference**

in pressure between two points (1 and 2) is related to
the volume flow rate of a fluid, Q, the fluid
viscosity, 𝜂, and the length and radius of the tube the
fluid flows in, L and r, respectively.


**Reynolds’s Number for Object Moving in a Fluid**

𝑹′𝑬 = [𝝆𝒗𝑳]𝜼 (133-5)

**Description: This equation defines the Reynold’s**

Number for an object in a fluid in terms of the
density of the fluid, 𝜌, the speed of the object, 𝑣, a
characteristic length of the object, 𝐿, (diameter of a
sphere for example), and the viscosity of the fluid,
𝜂.
**Note: Flow behind the object is laminar if 𝑅′� < 1,**

unstable if 𝑅′� is between 1 and 10[6] and exhibits a
turbulent wake if 𝑅′� > 10[6].


**Important Note: You must be very careful with the variable definitions for each section in this unit. Unfortunately, the**
variables used for real fluids are not as standard as they are for many other areas of introductory physics. However, if you are
careful, and use the above boxes you should be ok, since each box explicitly defines the variables used in each equation.


-----

#### 133-1 - Viscosity


**Consider: How do we take friction into account for moving fluids?**

UR DISCUSSION OF IDEAL FLUIDS in the last unit never allowed us to talk about the differences between real
fluids. You all know that pouring water from a container into a bowl is qualitatively very different from pouring
maple syrup from a container into a bowl. The water flows almost effortlessly, and very little of the water sticks to

# O

the side of the container as it flows out. On the other hand, maple syrup is slow to react to the pour, and sticks quite readily
to the sides of the container. The major difference between these two flows is the **_viscosity of the fluid. Water has a low_**
viscosity and syrup has a high viscosity.  Viscosity is a measure of the friction – both the
internal friction as molecules try to slide by each other and also friction with the surface of
any container.
Viscosity is only defined precisely for **_laminar flow. Laminar flow is a very smooth_**
type of flow that occurs in layers where the different layers of the fluid do not mix.
Turbulent flow, on the other hand, is characterized by swirls, known as eddies, that cause
the fluid to mix in irregular patterns. Figure 133-1 shows an initially laminar flow turning
into a turbulent flow as the smoke from a candle rises.
The viscosity of a fluid is measured using a specific type of flow known as _Couette_
_flow, where a section of fluid is trapped between two plates. The lower plate is held_
stationary and the upper plate is pulled along the fluid. Since we are now allowing there to
be friction we must maintain a constant force to keep the upper plate moving. In performing
this experiment, care is always taken to make sure that the motion of the fluid maintains
laminar flow. The general setup used to determine viscosity is shown in Figure 133-2.

We would expect the **Figure 133-3 - Laminar and**
magnitude of the force we must **turbulent flow as smoke from a**

**candle rises.**

apply to the upper plate in Figure
133-2 to depend on the size of the
plate (𝐴), the distance between the plates (𝑦) and the velocity that
we wish the upper plate to move (𝑣�). Specifically, as the upper
plate gets larger and contacts more fluid, we would expect the
necessary force to also increase. Similarly, if we want to move the

**Figure 133-2 - Setup used to determine the viscosity of a** upper plate at a larger speed, we need a larger force. However,
**fluid.** since the fluid is moving in layers, the farther apart the plates are,

the more layers the fluid can break into between the plates and the
easier we would expect it to be to move this plate. Mathematically, this reasoning is represented as

𝐹= 𝜂 [𝑣][�][𝐴] (133-1)

𝑦 [.]


The constant of proportionality in this equation, 𝜂, is dependent on the type of fluid and defines the _viscosity of the fluid._
Rewriting the equation to solve for the viscosity, we find.

**Table 133-1. Viscosity of various**
**fluids**

**Definition of Viscosity**

**Fluid (ºC)** Viscosity
(𝑃𝑎∙𝑠)

𝜼= 𝑭 [𝒚] (133-1) **Air (20º)** 1.810 𝑥10[��]

𝒗𝟎𝑨[.] **Oxygen (20º)** 2.030 𝑥10[��]

**Water (20º)** 1.002 𝑥10[��]

**Description: This equation defines the viscosity of a fluid as found by**

**Water (0º)** 1.792 𝑥10[��]

placing the fluid between two flat plates. F is the force it takes to

**Blood (20º)** 1.910 𝑥10[��]

keep the upper plate a fixed distance, 𝑦, above a stationary plate of

**Blood (37º)** 2.084 𝑥10[��]

cross-sectional area, A, moving at a speed, 𝑣�, relative to the

**Milk (20º)** 3.000 𝑥10[��]

stationary plate.

**Motor Oil** 0.200

**Unit: The unit of viscosity is 𝑃𝑎⋅𝑠.**

**Honey (20º)** 2 −10
**Maple Syrup** 2 −3

Table 133-1 gives the viscosity values for a few important fluids.


-----

What, physically, does viscosity do to a fluid? Here we can rely on what we know about how friction affects various
systems. In an ideal fluid, where we consider no friction with the surface of an object, the flow rate is uniform throughout the
entire volume, as shown in Figure 133-3(a). However, when viscosity is taken into consideration, the friction between the
fluid and the walls of the pipe slow the fluid down. In fact, in a semi-ideal approximation, the fluid up against the walls of
the pipe would not move, but the layers of fluid as we move towards the center of the pipe would move consistently faster
and faster. The layer directly in the middle of the flow would move the fastest. This effect can be seen in Figure 133-3(b).
Many of you have seen the effects viscocity has on fluid speed when viewing the flame of a Bunsen burner; Figure 133-3(c).

#### 133-2 - Poiseuille’s Law

**Consider: What effects does viscosity have on pressure?**

In unit 202, we briefly explored the idea that
when you squeeze a tube of toothpaste, you
increase the pressure throughout the paste and if
this pressure is then larger than atmospheric
pressure, the toothpaste will spew from the tube.
However, when considering ideal fluids, we
were not able to go any further because without
friction, we have no way to account for just how
fast the toothpaste leaves the tube.
The most important idea is that any flow in
the toothpaste, and therefore generalizing to any
fluid, is caused by differences in pressures
between two points. You might expect that the **Figure 133-3 - Fluid flow in an ideal fluid (a) and a fluid with viscosity**
larger the difference in pressure, the larger the **(b). Visualization of this effect with a Bunsen burner (c).**
flow would be. All we need is a constant of
proportionality to relate the difference in pressures between two points and volume flow rate of the fluid. Since we needed to
include friction in order to relate the two and friction tends to resist motion between two objects, we can define our constant
of proportionality as a resistance to flow, R, and can immediately write

𝑄= [𝑃][�] [−𝑃][�], (133-2)

𝑅

where Q is the volume flow rate and P1 – P2 is the difference in pressure between points 1 and 2, respectively. An important
point about this equation is that the higher the resistance, the lower the flow rate for a given pressure difference.
What factors play into this resistance to flow? Assume the flow is confined to a circular pipe. Since viscosity plays an
important role in real fluids, we would expect that a fluid with a higher viscosity has a higher resistance. Similarly, the
longer the pipe, the more a viscous fluid will interact with the sides of the pipe increasing the resistance. On the other hand,
the larger the radius of the pipe, the more fluid can go through the pipe without interacting with the sides, decreasing the
resistance. Using these conceptual ideas, the resistance in a pipe has been experimentally determined to be

𝑅= [8𝜂𝐿] (133-3)

𝜋𝑟[�][,]

where 𝜂 is the viscosity of the fluid, L is the length of the pipe and r is the radius of the pipe.
Combining our flow rate equation from above with this pipe resistance leads to Poiseuille’s Law:


**Poiseuille’s Law**

𝑷𝟏 −𝑷𝟐 = [𝟖𝜼𝑳𝑸]𝝅𝒓[𝟒] (133-3)

**Description – Poiseuille’s Law tells us how a difference in pressure**

between two points (1 and 2) is related to the volume flow rate of
a fluid, Q, the fluid viscosity, 𝜂, and the length and radius of the
tube in which the fluid flows, L and r, respectively.


-----

Poiseuille’s Law is most often used in one of two ways: it can be used to determine the volume flow rate of a fluid given
a known pressure difference between two points, or it can be used to determine the pressure drop between two points for a
known volume flow rate. Of course, there are many other possibilities – it could be used for pipe design, etc., but these are
lesser used results. I should note that Poiseuille’s Law can be analytically derived from a set of fluid equations known as the
Navier-Stokes equations; however, this derivation is quite complicated and beyond the scope of this course.


Example 133-1:  Blood Pressure

The circulatory system of a human utilizes a masterful
combination of the continuity equation and Poiseuille’s
Law to deliver oxygen to the organs of your body. When
blood leaves the left ventricle of your heart (the main
pump), it enters the aorta, an artery with a cross sectional
area of about 1 cm[2], flowing at about 25 cm/s. Blood
travels approximately 25 cm in the aorta until it splits into
arteries, arterioles and eventually the capillaries that supply
your tissue with oxygen and nutrients. In your capillary
bed, blood flows at approximately 1 mm/s.

If your systolic blood pressure is 120 mmHG (the 120 in a
reading of 120/80), what is the pressure in the blood just
before the aorta splits into arteries?  Also, given that blood
flows so slowly in the capillaries, what is the total crosssectional area of the capillary bed?

**Solution:**

The answer to the first question is a direct application of
Poiseuille’s Law. We know the pressure at the beginning
of the aorta, we know we have blood and therefore the
viscosity, we know the length the blood travels and the
cross-sectional area of the aorta.


The area of the capillary bed is 250 times the area of the
aorta!! This is how nutrients can be delivered to your entire
body. Also, just FYI, in your capillaries the blood pressure
is down to around 15 mmHg – the increase in the crosssectional area is also important to prevent blood pressure
from dropping to zero!


Plugging in values, we find:


𝑃� −𝑃� = [8𝜂𝐿𝑄]𝜋𝑟[�]

𝑃� = 0.25 𝑚𝑚𝐻𝑔.

As for the second question, this is a direct application of the
continuity equation (review!):

𝑣�𝐴� = 𝑣�𝐴�

We know the speeds in both the aorta and in the capillary
bed, and we also know the cross-sectional area of the aorta.
Solving for the area of the capillary bed, we find:

𝑣�𝐴� = 𝑣�𝐴�


𝐴� = [𝑣][�]𝑣[𝐴]� [�]


=


(25 𝑐𝑚/𝑠)(1𝑐𝑚[�])

= 250 𝑐𝑚[�].
0.1 𝑐𝑚/𝑠


#### 133-3 - Reynolds’s Number and Turbulence

**Consider: Is there a way to quantify the type of fluid flow for real**
_fluids?_

There are a number of factors that work together to determine whether a
real fluid flow will be laminar or turbulent. Possibly the most important
of these factors is the speed at which the fluid moves. At low speeds,
flow tends to be laminar, but at high speeds it tends to be turbulent or in
an unstable state between the two. Viscosity plays an important role in
this transition and when it happens. The shape of the overall flow, or
the shape of an object moving through the fluid can be an important
factor. Figure 133-4 shows a visualization of both laminar and
turbulent flow inside a pipe. A single flow can even change from
laminar to unstable to turbulent as shown in Figure 133-1.
Luckily, we have a factor that can help us determine the type of
flow that is likely for a given set of parameters, known as Reynolds’s
**_Number. The form of Reynolds’s number is different for each given_** **Figure 133-4 - Visualizing laminar (a) and**

**turbulent (b) flow in a pipe of diameter d.**

situation. First, we will consider flow in a uniform pipe, for which the
Reynolds’s Number is shown in the box below.


-----

**Reynolds’s Number for Tube Flow**

𝑹𝑬 = [𝟐𝝆𝒗𝒓]𝜼 (133-4)

**Description – This equation defines the Reynold’s Number for**

fluid flow in a tube or radius r in terms of the density of the
fluid, 𝜌, the speed of the fluid flow, 𝑣, and the viscosity of the
fluid, 𝜂.
**Note – Flow is laminar if 𝑅� < 2000, unstable if 𝑅� is between**

2000 and 3000 and turbulent if 𝑅� > 3000.


Finding the Reynolds’s Number for a flow does not guarantee that it will fit into the expected category. For example, if you
were to calculate a Reynolds’s Number of 1800 for a fluid flow inside of a tube, but in reality the tube is very rough on its
inner surface, there is a reasonable chance that at least some of the flow would be turbulent. However, Reynolds’s Number
gives us a very good predictor of turbulent versus laminar flow.
We can also calculate the Reynolds’s number for an object moving in a fluid, as shown in the following box:


**Reynolds’s Number for Object Moving in a Fluid**

𝑹′𝑬 = [𝝆𝒗𝑳]𝜼 (133-5)

**Description – This equation defines the Reynold’s Number for an object**

in a fluid in terms of the density of the fluid, 𝜌, the speed of the fluid
flow, 𝑣, a characteristic length of the object 𝐿 (diameter of a sphere for
example), and the viscosity of the fluid, 𝜂.
**Note – Flow behind the object is laminar if 𝑅′� < 1, unstable if 𝑅′� is**

between 1 and 10[6] and exhibits a turbulent wake if 𝑅′� > 10[6].


It is very important to point out that the range of values for the type of flow (laminar, unstable, and turbulent) is different for
the two forms of Reynold’s Number given. As an example, a value of RE = 4000 for water flow in a tube is almost certainly
turbulent, whereas the wake behind an object with an R’E = 4000 will be unstable, but could still resemble laminar flow more
than turbulent flow.

#### 133-4 - Real Fluids Move Mountains

As mentioned earlier in the Unit 133, the main difference between ideal fluids and real fluids is the inclusion of friction when
examining real fluids. Although earlier on we used this notion of friction to define the viscosity of the fluid, the fact that real
fluids are viscous has tremendous long-term effects on the earth through a process known as erosion. Consider this thought
experiment: Imagine laying on a beach on a warm summer day. You then lightly put your hand on top of the sand and move
it to the side. Some of the sand on the top layer will move with you – at least a little. Although this is an effect of a solid
(your hand) on small solid particles (the sand), the same effect is true for fluids sliding over solids.
We can make the example even tighter if you now imagine walking down to where the ocean waves lap up against the
sand. If you were to look down at the sand through the water as a wave flows in and then out, you may actually be able to
see the sand and other debris moving below.
This is erosion on a small scale – the process of a fluid moving soil and rock from one place and depositing it in another.
To really see erosion on a normal day, you need pretty strong waves. On a moderate scale, the erosive effects of waves are
apparent after a strong storm, such as blizzard or hurricane. Many beach-front properties in New England, the Carolinas and
Florida have been endangered or destroyed by this type of storm-related erosion.


-----

On geologic time scales - thousands to millions of years - the tiny, individual
effects of fluid friction on the solid surfaces of the earth can literally move mountains
worth of sand and soil – thus the name of the unit. Consider the Grand Canyon, as
shown in figure 133-5. The Grand Canyon is 277 miles long, 18 miles wide at its
widest point and over a mile deep. The entire canyon was formed through water
erosion by the Colorado River and its tributaries over the last tens of millions of
years. As the river flowed, friction between the water and the land slowly picked up
material and transported it down river and out of the canyon. The breathtaking scenes
available to visitors, as well as the unique rock structures available to geologists and
other scientists are due to the mere frictional forces described above.
The same can also be true of the air’s effect on land. Although the density of air
is only 1/1000 that of water, winds also have the ability to move quite fast, from
sustained winds of 50 miles per hour in desert plains to even 100 or 150 miles per
hour in a hurricane. Over long periods of time, the fluid movement of air over land
can cause similarly spectacular views to that of water with the Grand Canyon.
Consider the natural arch shown in Figure 133-6. This unnamed arch is located on a
desert plain in Jordan. The erosion of the arch took place over millions of years, as
winds flowing over the planes slowly ate away at the rock. Small imperfections in the

rock structure allowed the winds to unevenly erode
areas of the arch until a hole formed in the middle

**Figure 133-5. Picture of the Grand**

of its structure. Air was then able to move through

**Canyon with the Colorado River**

the center of the arch, further widening the gap until **below.**
the structure we see today formed. Unfortunately,
such arch structures are not permanent, as continued erosion over time will widen the
center hole further until the upper part of the arch cannot sustain itself and the arch will
collapse.
The science behind erosion is, of course, much more complicated than we can get into
here. As an example, there are actually many types of erosion including deflation (air

**Figure 133-6. Natural arch**

picking up small loose particles) and abrasion (particles suspended in the fluid bouncing

**formed by erosion in Jebel**

off of other material). However, all types of erosion have one thing in common at their

**Kharaz, Jordan.**

basis – they arise from friction internal and external to some fluid.


-----

