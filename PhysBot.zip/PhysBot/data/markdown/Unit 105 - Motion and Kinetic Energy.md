### – Motion and Kinetic Energy
## 105


_Unit 105 explores ways in which we can precisely describe the relative ideas of position and motion. In this unit, we will_
_encounter some of our first common misconceptions about physics – namely that 1) velocity and speed are essentially the_
_same thing (they are not), and 2) velocity and acceleration can be easily conflated (they are very different). We will also_
_reintroduce kinetic energy and explore its properties a bit more in detail than in Unit 103._

###### Integration of Ideas

    - We will further explore the ideas of vectors (Unit 104) and kinetic energy (Unit 103).


###### The Bare Essentials

- The position of an object is its vector relationship to a

reference point (usually the origin of a coordinate system).



- Acceleration is the time rate of change of velocity.


**Acceleration**


**Position Vector**

𝒓�⃗= �𝒓𝒓 𝒙𝒓 𝒙, 𝒓𝒚𝒓 𝒚, 𝒓𝒛𝒓 𝒛�

**Description – The equation defines the position vector, 𝑟⃗𝑟, of an**

object in terms of its components, 𝑟𝑥𝑟 𝑥, 𝑟𝑦𝑟 𝑦 and 𝑟𝑧𝑟 𝑧.
**Note 1: In practice, this vector must be relative to some coordinate**


𝒅𝒅𝒗𝒗𝒚

𝒂��⃗=𝒂 [𝒅][��⃗][𝒗][𝒅] [𝒗]

𝒅𝒅𝒅 𝒅 [= �𝒅]𝒅[𝒅][𝒗]𝒅𝒅 [𝒗][𝒙]𝒅 [,] 𝒅𝒅𝒅 𝒅 [, 𝒅]𝒅[𝒗][𝒅] 𝒅𝒅 [𝒗][𝒛]𝒅 [� ]

**Description – The equation defined the acceleration, 𝑎⃗𝑎, (vector) of**

an object as the derivative of the velocity, 𝑣⃗𝑣, with respect to
time.
**Note 1: The SI unit of acceleration is the 𝑚𝑚/𝑠𝑠[2].**
**Note 2: The average acceleration of an object can be found as**


system origin.
**Note 2: The SI unit for position is the meter (m).**

- Displacement is the vector change in position of an object.


**Displacement Vector**


𝚫𝚫𝒓�⃗= �𝚫𝒓 𝚫𝒓𝒙𝒓 𝒙, 𝚫𝚫𝒓𝒚𝒓 𝒚, 𝚫𝚫𝒓𝒛𝒓 𝒛�

**Description – The equation defines the displacement (vector), Δ𝑟⃗𝑟,**

in terms of differences in compoents, Δ𝑥𝑥, Δ𝑦𝑦, and Δ𝑧𝑧.
**Note: Δ𝑟⃗= 𝑟𝑟** ⃗2𝑟 −𝑟⃗1𝑟, meaning that only the final and initial

positions are required for the displacement.

- Velocity is the time rate of change of position.


𝑎⃗𝑎𝑎𝑎𝑎𝑎𝑎𝑎 = Δ𝑣⃗Δ𝑡𝑣⁄

- **Note: Acceleration is always a vector. If you are discussing**
the scalar form of acceleration it is the magnitude of the
**_acceleration._**

- **_Kinetic Energy is the energy of motion, and depends only an_**
object’s mass and speed.


**Kinetic Energy**

𝑲𝑲 = (𝜸𝜸 −𝟏𝟏)𝒎𝒎𝒄𝒄[𝟐][𝟐]

**Description – This equation precisely describes the kinetic energy**

of an object of mass, 𝑚𝑚 and speed, 𝑣𝑣.

**Note: 𝜸𝜸** = �𝟏𝟏 −𝒗𝒗[𝟐][𝟐]⁄𝒄𝒄[𝟐]�−[𝟏]𝟐𝟐


**Velocity**

𝒗��⃗=𝒗 [𝒅][𝒓][�⃗][𝒅] [𝒓]

𝒅𝒅𝒅 𝒅 [= �][𝒅]𝒅[𝒓][𝒅] 𝒅𝒅 [𝒓][𝒙]𝒅 [, 𝒅]𝒅[𝒓][𝒅] 𝒅𝒅 [𝒓][𝒚]𝒅 [,𝒅]𝒅[𝒅][𝒓]𝒅𝒅 [𝒓][𝒛]𝒅 [�]

**Description – This equation defines the instantaneous velocity of**

an object, 𝑣⃗𝑣. as the time rate of change of its position, 𝑟⃗𝑟.
**Note 1: The SI unit for velocity and speed is m/s.**
**Note 2: Instantaneous speed can be found as the magnitude of the**

velocity vector.
**Note 3: The average velocity of an object can be found as 𝑣⃗𝑎𝑣** 𝑎𝑎𝑎𝑎𝑎 =

Δ𝑟⃗Δ𝑡𝑟⁄


**Kinetic Energy (Classical Limit)**

𝑲𝑲 = [𝟏]
𝟐𝟐 [𝒎][𝒎][𝒗][𝒗][𝟐][𝟐]

**Description – This equation describes the classical kinetic energy**

of an object of mass, 𝑚𝑚 and speed, 𝑣𝑣.
**Note 1: This equation can be used when 𝑣𝑣** < ~3𝑥𝑥10[6] 𝑚𝑚⁄ . 𝑠
**Note 2: 𝑣𝑣[2]** = 𝑣⃗⋅𝑣𝑣 ⃗𝑣.


-----

##### 105.1 – Coordinate Systems and Position

**Consider: How can we visualize the ‘where’ of an object?**

N ORDER TO DESCRIBE WHERE AN OBJECT is and how it moves, we first need to
devise a vocabulary that will let us precisely describe position and motion. This is the
point of a coordinate system or **_reference frame: A set of standards by which we can_**

# I

make measurements. The standard coordinate system we will use for classical physics is a
right-handed, Euclidean coordinate system, as shown in Figure 105-1. Notice that each of
the three axes, x-, y-, and z- are oriented perpendicular to each other. Also, note the
direction of the z-axis relative to the x- and y-axis. If you were to place your right hand
along the positive x-axis and curl your figures towards the positive y-axis, your thumb
points in the direction of the positive z-axis. This process is shown in Figure 105-2. This is
the first example or a right-hand-rule that we will see in this course. We will come back to
this when we discuss cross-products, torque and
magnetic force. Please note that if you do the same
thing with your left hand, the positive z-axis will point **Figure 105-1. A three-**
in the wrong direction! **dimensional coordinate**
Visualizing position and motion in three **system**
dimensions can be quite hard. Many of the problems in
Physics I are inherently two-dimensional, or can be
reduced to two dimensional problems. When we can reduce a problem to just two
dimensions, it is much easier to draw the references frame and visualize positions in that

**Figure 105-2. Determining the** frame. Take Figure 105-3 for example. This
**direction of the z-axis for a right-** figure depicts a two-dimensional x-y axis along
**handed coordinate system where** with four positions noted as ordered pairs (x,y).
**A is the x-axis and B is the y-axis.** A few things to note about Figure 105-3:

1) Each of the axes (x and y) are in meters (not shown on graph).
2) There is a well-defined origin noted as (0,0).
3) The tick-marks (and grid lines) are evenly distributed. Note that the x- and
y- axis may have different spacings, but the spacing on a single axis should
be consistant.

With this information in hand, we can define the position of each of the noted
points (relative to the origin of the coordinate system) as

𝑟𝑟⃗1 = [0, 0, 0] 𝑚𝑚, **Figure 105-3. A two-dimensional**

**coordinate system with four positions.**
**Note: each axis is in meters. (Need to**

𝑟𝑟⃗2 = [2, 3,0] 𝑚𝑚,

**add a, b, c, d to points)**

𝑟𝑟⃗3 = [−3,1,0 ] 𝑚𝑚,

𝑟𝑟⃗4 = [−1.5, −2.5,0] 𝑚𝑚.

Each of these positions, written as vectors, allows us to uniquely define the four points. Also note again that although all
of our position vectors are in the x-y place, we still write the z-component of the vector as zero. Consider for yourself how
you would need to write these vectors if Figure 105-3 showed a y-z plane as opposed to the x-y plane, and you should be able
to convince yourself why having all three componenets is important. In each of these cases, we wrote the position vector in
the form
𝑟𝑟⃗= �𝑟𝑟𝑥𝑥, 𝑟𝑟𝑦𝑦, 𝑟𝑟𝑧𝑧� (105-1)

where 𝑟𝑟⃗ is the position vector and 𝑟𝑟𝑥𝑥, 𝑟𝑟𝑦𝑦 and 𝑟𝑟𝑧𝑧 and the compoents of the position relative to some origin.
It is very important to note that the real position of an object is independent of the coordinate system, but the way we
write the position vector does depend on the system. For example, consider again the positions in Figure 105-3 above. Let’s
say another person sets the origin of a coordinate system where (2,3) is loacted in the figure. We could still write each of the
positions as vectors (and the physical meaning would not change); however, the way the positions apear would be different.


-----

(0,0) would be (−2, −3) in the new coordinate system since we have to move two places to the left and three places down
from the new origin.


Example 105 - 1 **Positions in new coordinate system**

Find the positions of the points (−3,1) and (−1.5, −2.5) from
Figure 105-1 in a coordinate system where the origin lies at
(2,3) in that figure.

**Solution:**

This problem asks us to use our knowledge of position vectors
to write the positions in a new coordinate system. Starting at
point (2,3) in Figure 105-1 (our new origin), we need to


move five places to the left and two places down to get to
point B, giving us

𝑟𝑏𝑟 𝑏 = [−5, −2, 0].

Similarly, in order to get to point c, we must move 3.5
places to the left and 5.5 places down, given us

𝑟𝑐𝑟 𝑐 = [−3.5, −5.5, 0].


Building off of these examples, we can define the position vector of an object relative to some origin as given in the box
below.


**Position Vector**

𝒓�⃗= �𝒓𝒓 𝒓𝒙𝒙, 𝒓𝒓𝒚𝒚, 𝒓𝒓𝒛𝒛�

**Description – The equation defines the position vector, 𝑟⃗𝑟,**

of an object in terms of its components, 𝑟𝑥𝑟 𝑥, 𝑟𝑦𝑟 𝑦 and 𝑟𝑧𝑟 𝑧.
**Note: In practice, this vector must be relative to some**


coordinate system origin.

As noted in Unit 101, the SI unit for position is the meter (m), although other common units include the kilometer (km),
centimeter (cm), millimeter (mm), foot (ft), inches (in) and miles (mi). Unless otherwise noted, you should try to use meters
in physics.

##### 105.2 – Displacement and Distance

**Consider: What are some ways to represent changes in position?**

This difference between displacement and distance are much greater than just saying that one (displacement) is a vector and
the other (distance) is a scalar. As we will see below, there are times where the magnitude of the displacement of an object is
the same as its distance traveled; however, there are times when this is not true at all. Pay close attention to this short
discussion, because these differences will be important for the remainder of this course!
The displacement of an object is defined as the difference between its final position and its initial position:

Δ𝑟𝑟⃗= 𝑟𝑟⃗2 −𝑟𝑟⃗1, (105-2)

where Δ𝑟𝑟⃗ is the displacement and 𝑟𝑟⃗2 and 𝑟𝑟⃗2 represent the final and initial positions, respectively. This can also be written in
terms of components, given us

𝑥𝑥2 𝑥𝑥1

Δ𝑟𝑟⃗= �𝑦𝑦2�−�𝑦𝑦1�. (105-3)

𝑧𝑧2 𝑧𝑧1

Thus, the displacement can be written as the vector differences of components as

Δ𝑟𝑟⃗= [Δ𝑥𝑥, Δ𝑦𝑦, Δ𝑧𝑧] = �Δ𝑟𝑟𝑥𝑥, Δ𝑟𝑟𝑦𝑦, Δ𝑟𝑟𝑧𝑧�. (105-4)

It is very important to note that you only need the starting position and the ending position to find the displacement – it is
completely independent of the path between the two points!


-----

**Displacement Vector**

𝚫𝚫�⃗= �𝚫𝒓𝒓 𝚫𝒓𝒓𝒙𝒙, 𝚫𝚫𝒓𝒓𝒚𝒚, 𝚫𝚫𝒓𝒓𝒛𝒛�

**Description – The equation defines the displacement**


(vector), Δ𝑟⃗𝑟, in terms of differences in compoents, Δ𝑥𝑥,
Δ𝑦𝑦, and Δ𝑧𝑧.
**Note: Δ𝑟⃗= 𝑟𝑟** ⃗𝑓𝑟 𝑓𝑓𝑓𝑓 𝑓𝑓𝑓𝑓 𝑓 −𝑟⃗𝑖𝑟 𝑖𝑖 𝑖𝑖𝑖𝑖 𝑖𝑖𝑖𝑖 𝑖𝑖𝑖 meaning that only the final and

initial positions are required for the displacement.

**_Distance, on the other hand, requires us to add up all the little pieces of_**
motion along the path taken by a particle – meaning that the _distance is path_
_dependent. A curvy path between two points will give you a larger distance than_
a straight path between those two points; however, the displacement would be the
same. This distinction is shown in Figure 105-4.
Let us now consider the difference between these two quantities for a simpler
situation – motion along a single axis. Figure 105-5 depicts a particle moving
along the positive x-axis 5 meters and then along the negative x-axis for 3 meters.
To find the total distance traveled by the particle, we must add together the
distances for each leg: 5 **Figure 105-4. The difference between**

#### A B C meters and 3 meters in distance (curved line) and displacement

this case. This suggests **(straight line) between two points.**
that the distance covered
by the particle during the entire trip is 8 meters.
When considering displacement, we only need the beginning

**Figure 105-5. The difference between displacement**

and ending points. In this example the beginning point as at the

**(solid arrow) and distance (dotted arrows) for a**
**motion from point A to point C and back to point B.** origin and the ending point is at 𝑥𝑥= 3𝑚𝑚. Using the definition of the

displacement, this gives us


3 0

Δ𝑟𝑟⃗= 𝑟𝑟⃗2 −𝑟𝑟⃗1 = �0�𝑚𝑚−�0

0 0


3

�𝑚𝑚= �0

0


�𝑚𝑚. (105-5)


Thus, the displacement of the particle is 3 meters along the positive x-axis. You can see that the distance the particle traveled
(8 meters) is difference from the magnitude of the displacement (3 meters)! How can this be? It turns out that we are
attempting to measure two very different quantities when we measure distance versus displacement. Distance is a the total
pathlength covered by the motion of the object. Displacement measures only how far and in what directly an object has
moved. As we’ll see below, this can be very important when discussing the difference between velocity and speed.
Before we move on to velocity and speed, I want to point out that there is a second way to calculate the total
displacement in the example above: we can also find the sum of the individual displacements that make up a motion. To do
this, we say that the particle underwent two displacements: 1) the displacement from 0 to +5 meters (Δ𝑟𝑟⃗1 = [5,0,0]) and 2)
the displacement from +5 meters to +3 meters, which is given by


3

Δ𝑟𝑟⃗2 = �0

0


5

�−�0

0


−2

�= � 0

0


�. (105-6)


Summing these two displacements, we find


5 −2

Δ𝑟𝑟⃗= Δ𝑟𝑟⃗2 −Δ𝑟𝑟⃗1 = �0�𝑚𝑚+ � 0

0 0


3

�𝑚𝑚= �0

0


�𝑚𝑚; (105-7)


yielding the same answer we found in equation 105-5 above – that the net displacement is 3 meters along the positive x-axis.
Either of these methods can be used to find the displacement, and which method is best really depends on the specific
situation at hand.


-----

Example 105 - 2 **New displacement**

A point particles moves at constant speed from point A at

[3, 5, 6] to point B at [5. −2, −4] and then to point C at

[3, −2, 1]. What is the displacement of the particle between
points A and C?

**Solution:**

This question asks us to directly determine displacement from
its definition. Please note that for displacement we are only


concerned with the starting and ending positions, so we
do not need to consider point B in this problem.
Using the definition of displacement,

3 3 0
Δ𝑟⃗= 𝑟𝑟 ⃗𝐶𝑟 𝐶 −𝑟⃗𝐴𝑟 𝐴 = �−2�𝑚𝑚 −�5�𝑚𝑚 = �−7�𝑚𝑚.
1 6 −5

Therefore, the displacement between points A and C is

[0, −7, −5]𝑚𝑚.


##### 105.3 – Velocity and Speed

**Consider: What is the difference between velocity and speed?**

Conceptually, instantaneous velocity, or just velocity, is a measure of how fast and in what direction a particle is moving at a
specific instance of time. It is very important to keep in mind that velocity is a vector and therefore must contain both
magnitude and direction. Mathematically, this can be accomplished by finding the rate of change of position with respect to
time, as
v�⃗= [𝑑][𝑑][𝑟][⃗][𝑟] (105-8)

𝑑𝑑𝑑 𝑑[.]


Note that equation 105-8 is a vector derivative. Although it may seem daunting when you first think about it, performing a
vector derivative just requires us to complete three separate derivatives – one for each dimension. Writing out equation 1058 including what we know about the position vector gives us

(105-9)

v�⃗= [𝑑]

𝑑𝑑𝑑 𝑑 [�𝑟𝑟][𝑥𝑥][, 𝑟𝑟][𝑦𝑦][, 𝑟𝑟][𝑧𝑧][�= ][�][𝑑]𝑑[𝑑][𝑟]𝑑𝑑 [𝑥][𝑟]𝑑 [, ][𝑑]𝑑[𝑑][𝑟]𝑑𝑑 [𝑦][𝑟]𝑑 [, ][𝑑]𝑑[𝑑][𝑟]𝑑𝑑 [𝑧][𝑟]𝑑 [�,]

where I have used the fact that the derivative can be carried into each component of the vector.
The **_instantaneous speed (often just called speed) of an object is the magnitude of the instantaneous velocity._**
Technically, we should use the symbol |v�⃗| for speed; however, in practice, “𝑣𝑣” without the vector or magnitude symbols are
often used. Instantaneous speed can be found from a velocity vector in the same way we usually find the magnitude of a
vector:

|v�⃗| = v = �𝑣𝑥𝑣[2]𝑥 + 𝑣𝑦𝑣[2]𝑦 + 𝑣𝑧𝑣[2]𝑧, (105-10)

The SI units for both velocity and speed are meters/second (m/s), although any derived unit of a length divided by a time
can represent velocity or speed.


**Velocity**

𝒗��⃗=𝒗 [𝒅][�⃗][𝒓][𝒅] [𝒓]

𝒅𝒅𝒅 𝒅 [= �][𝒅]𝒅[𝒓][𝒅] 𝒅𝒅 [𝒓][𝒙]𝒅 [, 𝒅]𝒅[𝒓][𝒅] 𝒅𝒅 [𝒓][𝒚]𝒅 [,𝒅]𝒅[𝒅][𝒓]𝒅𝒅 [𝒓][𝒛]𝒅 [�]

**Description – This equation defines the instantaneous velocity of**

an object, 𝑣⃗𝑣. as the time rate of change of its position, 𝑟⃗𝑟.
**Note 1: The SI unit for velocity and speed is m/s.**
**Note 2: Speed can be found as the magnitude of the velocity**

vector.
**Note 3: The average velocity of an object can be found as 𝑣⃗𝑎𝑣** 𝑎𝑎𝑎𝑎𝑎 =

Δ𝑟⃗Δ𝑡𝑟⁄


-----

There will be times when instead of the functional form of a position vector, we know only a starting position of a
particle, the ending position of the particle and the time it takes for the particles to move between the two positions. In this
case, although we cannot find an instantaneous velocity at any one point in space or time, we can find the average velocity of
the particles motion. Since we know the starting and ending positions, we can find the particle’s displacement, and then
define average velocity as the displacement over time:

(105-10)

v�⃗ave = [Δ𝑟][⃗][𝑟]

Δ𝑡𝑡[.]

In a similar fashion, we can define the average speed of an object as the distance it travels divided by the time
between the starting and ending point, vave = distance/time. _It is very important to note that the average velocity of an_
_object and it’s average speed need not be the same!_


Example 105 - 3 **Instantaneous velocity example**

The position of a particle is given as a function of time by

2
𝑟⃗= �𝑟 2𝑡𝑡[2] −3� 𝑚𝑚.
0

What are the velocity and of the particle at time 𝑡𝑡 = 3 𝑠𝑠.

**Solution:**

This problem asks us to use the definition of velocity of a
position function to find the velocity and speed at a specific
time. In order to do this, we must first find the equation for
velocity as a function of time by taking the derivative of each
component of the position.

𝑣𝑥𝑣 𝑥 = [𝑑] [𝑑]

𝑑𝑑𝑑 𝑑 [(𝑟][𝑥][𝑟] [𝑥][) =] 𝑑𝑑𝑑 𝑑 [(2) = 0]


𝑣𝑦𝑣 𝑦 = [𝑑] [𝑑]

𝑑𝑑𝑑 𝑑 [(𝑟][𝑥][𝑟] [𝑥][) =] 𝑑𝑑𝑑 𝑑 [(2𝑡][𝑡][2][ −3) = 4𝑡][𝑡][ 𝑚][𝑚][/𝑠][𝑠]

𝑣𝑧𝑣 𝑧 = [𝑑] [𝑑]
𝑑𝑑𝑑 𝑑 [(𝑟][𝑥][𝑟] [𝑥][) =] 𝑑𝑑𝑑 𝑑 [(0) = 0]

So, the velocity as a function of time is given by

0
𝑣⃗= �𝑣 4𝑡� 𝑚𝑚⁄ .𝑠
0

Plugging in 2 seconds into this equation, we find the
velocity to be

𝑣⃗(2 𝑠𝑣 𝑠) = (8 𝑚𝑚/𝑠𝑠)𝚥𝚥̂.

The speed is the magnitude of this vector, or 8 m/s.


Example 105 - 4 **Average velocity example**

In the vector from example 106-3, what is the average
velocity between 𝑡𝑡 = 2 𝑠𝑠 and 𝑡𝑡 = 4 𝑠𝑠?

**Solution:**

This problem requires us to use the definition of average
velocity. First, we must find the position at the two times,


𝑣𝑎𝑣 𝑎𝑎 𝑎𝑎𝑎 =


2 2 0

𝑟⃗(2 𝑠𝑟 𝑠) = �5� 𝑚𝑚,   𝑟⃗(4 𝑠𝑟 𝑠) = �29� 𝑚𝑚 →Δ𝑟𝑟 = �24� 𝑚𝑚.

0 0 0


Average velocity is then


(24 𝑚𝑚)𝚥𝚥̂

= (12 𝑚𝑚⁄ )𝚥𝑠 𝚥̂.
2 𝑠


How can we visualize instantaneous and average velocity from a graph of
position versus time? In Unit 121, we will explore this question in depth;
however, I think it is important to get some of the basics down at this point.
Consider figure 105-6, which shows the path of an object over time. Points P
and Q represent where the object was located at times t1 and t2, respectively.
The average velocity is the slope of the line connecting points P and Q. You
can see this because the definition of the slop is the change in the vertical axis
(Δ𝑥𝑥 in this case) divided by the change in the horizontal axis (Δ𝑡𝑡 in this case).
If you remember back from calculus, the derivative of a function is
represented by the slope of a tangent line to the function at that point. Since
the instantaneous velocity is a derivative of position with respect to time, the
instantaneous velocity is represented on a position versus time graph as the
slope of a tangent line at the point we care about. This is shown in Figure 1056 as the tangent line to the curve at point P. Note that the velocity at point Q is


**Figure 105-6. Diagram for instantaneous and**
**average velocity as the slopes of lines on an x-t**
**graph..**


-----

not shown in the graph (it would make the graph too busy); however, if you visualize a tangent line at point Q, you might
guess that this tangent will have a larger slope that the tangent line at point P, meaning that the instantaneous velocity at point
Q is larger than the instantaneous slope at point P, meaning that the particle is moving faster. This change in velocity is what
we call acceleration, and we will explore this concept in the next section.

##### 105.4 – Acceleration

**Consider: How is acceleration different than velocity?**

In Section 105.3, we just described velocity as the rate of change of position. It is also possible for velocity to change with
time, which we call **_acceleration. Also, just like our discussion of velocity above, we can define an_** **_instantaneous_**
**_acceleration (also just called_** **_acceleration), as the acceleration of a particle one instance of time, and the_** **_average_**
**_acceleration as the difference in velocity over a given time divided by that time interval._**


**Acceleration**


𝒂��⃗= 𝒂 [𝒅][𝒅][��⃗][𝒗][𝒗] [𝒅][𝒗][𝒅] [𝒗][𝒛]

𝒅𝒅𝒅𝒅 [= �𝒅]𝒅[𝒅][𝒗]𝒅𝒅 [𝒗][𝒙]𝒅 [, 𝒅]𝒅[𝒗][𝒅] 𝒅𝒅 [𝒗][𝒚]𝒅 [,] 𝒅𝒅𝒅 𝒅 [� ]

**Description – The equation defined the acceleration, 𝑎⃗𝑎,**

(vector) of an object as the derivative of the velocity, 𝑣⃗𝑣,
with respect to time.
**Note 1: The SI unit of acceleration is the 𝑚𝑚/𝑠𝑠[2].**
**Note 2: The average acceleration of an object can be found**


as 𝑎⃗𝑎𝑎 𝑎𝑎 𝑎𝑎𝑎 = Δ𝑣⃗Δ𝑡𝑣⁄

Although the math relating velocity to position and acceleration to velocity looks the same, this is about where the
similarities end. In our everyday lives, it is easy to conflate the ideas of velocity and acceleration, and treat them as if they
are almost the same thing. I’m going to describe a couple of common misconceptions related to acceleration. As you read
each of these, keep in mind that acceleration is how the velocity changes.

  - **Misconception #1: If the velocity of an object is zero, its acceleration must be zero.**

However: Remember that acceleration is the change in velocity. If misconception #1 were true, something at
rest could never move, because if its velocity is zero (not moving), the object needs a non-zero acceleration to
start moving!.

  - **Misconception #2: Larger velocity means larger acceleration.**

However: Consider an object moving very fast (jet plane for example). If it continues moving in a straight line
at the same speed, its velocity is not changing, and the acceleration is therefore zero. Also, if the plane slows
down very slightly over a long time, it would have a very small acceleration; however, still be moving fast.

  - **Misconception #3: Same velocity means same acceleration for two objects.**

However: Let’s say a small car is traveling along a straight section of freeway at a constant 45 mph (let’s say
the speed limit is 65 mph).  This small car’s acceleration is zero. Consider a woman driving a pickup truck,
entering an onramp to the freeway, wishing to go 75 mph. At some point, the pickup truck has to be moving
45 mph; however, it is still speeding up meaning it is has a non-zero acceleration.

These misconceptions will probably reemerge over time, and we certainly don’t expect them to disappear just because they
are written in this book. So, don’t be surprised if sometime during this semester, your instructor points you back to this page
to remind yourself of these common misconceptions.
A non-zero acceleration changes _something about velocity. Since velocity is made up of speed and direction,_
acceleration can change one of both of these features. Also, another important point is

**_acceleration is a vector. To discuss a scalar, you must say the magnitude of acceleration._**


-----

This is in contrast to velocity, where we had a separate name for the magnitude – speed. There is no separate designation
when it comes to acceleration and it’s magnitude.
Just how acceleration changes velocity depends on the relative directions of the two vectors. As a general rule

1. if acceleration and velocity are parallel to each other, the object

increases in speed,
2. if acceleration and velocity are _anti-parallel_ to each other

(opposite directions), the object decreases in speed,
3. if acceleration and velocity are _perpendicular_ to each other, the

object changes direction.

If an acceleration vector and the velocity vector are at an angle other than
those just noted, the acceleration can be broken up into components
parallel to the velocity (called tangential acceleration) and perpendicular
to the velocity (called centripetal acceleration), and the above rules then **Figure 105-7. Tangential (𝒂𝒂𝒕𝒕) and radial (𝒂𝒂𝒏𝒏)**

**components of an acceleration along a curved**

hold for each of the components. This is shown in Figure 105-7. At this

**path.**

point, we will consider how acceleration changes the speed of an object
(#1 and #2 above) and will consider changes in direction in Unit 128.


Example 105 - 5 **Acceleration example 1**

The position vector of an objects is given by

5𝑡
𝑟⃗= �𝑟 0 � 𝑚𝑚.
4𝑡𝑡[2] + 3

What is the acceleration of the object at time 𝑡𝑡 = 2 𝑠𝑠 and 𝑡𝑡 =
5 𝑠𝑠.

**Solution:**

This problem asks us to use the definition of acceleration find
the acceleration of an object at specific times. In order to do
this, we must first find the functional form of the object’s
velocity as a function of time:


5

𝑣⃗=𝑣 [𝑑][𝑑][𝑟][⃗][𝑟] 0 � 𝑚𝑚⁄𝑠𝑠.
𝑑𝑑𝑑 𝑑 [= �]

8𝑡


We can then find the acceleration as a function of time by
taking another derivative of this velocity function, giving
us

0
𝑎⃗=𝑎 [𝑑][𝑑][𝑣][⃗][𝑣] 0� 𝑚𝑚⁄𝑠𝑠[2].
𝑑𝑑𝑑 𝑑 [= �]
8

Since this acceleration of (8 𝑚𝑚⁄𝑠𝑠[2])𝑧𝑧̂ does not depend on
time, the acceleration will be the same at all times.
Therefore, the acceleration at both 𝑡𝑡 = 2 𝑠𝑠 and 𝑡𝑡 = 5 𝑠𝑠 is
(8 𝑚𝑚⁄𝑠𝑠[2])𝑧𝑧̂.


Example 105 - 6 **Acceleration example 2**

Imagine a person driving eastward at 25 m/s (55 mph) sees
the brake lights of the car in front of them and hits the brakes
for 1.5 seconds, slowing to a final speed of 12 m/s (30 mph).
What are the magnitude and direction of the car’s average
acceleration during this time?

**Solution:**

For this problem, we must use the definition of average
acceleration and a conceptual understanding of the direction
of acceleration relative to velocity.
The magnitude of the average acceleration over a finite
time can be found from the acceleration equation as


𝑎⃗=𝑎 [𝑑][𝑑][𝑣][⃗][𝑣]
𝑑𝑑𝑑 𝑑 [  →  𝑎][⃗][𝑎][𝑎][𝑎][𝑎] [𝑎][𝑎][𝑎] [ = Δ𝑣]Δ𝑡[⃗]𝑡 [𝑣][.]

Since both our initial and final velocities east, we can set
our coordinate system such that east is the positive x-axis
and write

(12 𝑚𝑚⁄ −25 𝑚𝑠 𝑚⁄ )𝑖𝑠
𝑎⃗𝑎𝑎𝑎𝑎 𝑎𝑎𝑎 = [Δ𝑣][⃗][𝑣] = −8.6 𝑚𝑚⁄𝑠𝑠[2].
Δ𝑡𝑡 [=] 1.5 𝑠

Since the answer is negative, we know that the direction
of the acceleration is along the negative x-axis, or west.


A bit more:  We could intuitively determine the direction of
the acceleration in this problem. Since the velocity is east and


and the car is slowing down, the direction of the
acceleration must be opposite the velocity – west.


-----

In the last part of the velocity section above, we considered what velocity looks like on a position-time graph. We can
do the same for acceleration by first noting that

𝑑𝑑𝑟⃗𝑟

(105-11)

a�⃗= [𝑑][𝑑][𝑣][⃗][𝑣] [𝑑]

𝑑𝑑𝑑 𝑑 [=] 𝑑𝑑𝑑 𝑑𝑑𝑑 𝑑 [= ][𝑑]𝑑[𝑑]𝑑[2]𝑡𝑡[𝑟][2][⃗][𝑟][,]

or rather that the acceleration can be written as the second derivative of the position function. Again, remember from
calculus that the second derivative of a function gives you the curvature, or concavity, of the function. So, accelerated
motion is described by curvature on a position-time graph. In fact a positive curvature (curve opening up), represents a
positive acceleration and a curve opening down represented a negative acceleration.
Looking again at point P in Figure 105-6, you can see that the velocity is positive (positive slope for the tangent line) and
that the acceleration is positive (curve opens up at point P). Since both velocity and acceleration are positive (parallel to each
other), I would expect the object to increase in speed. This is exactly what happens, since we already described how the
speed at point Q is larger than the speed at point P.

**Putting it all together**

As one final note on the relationship between position, velocity and
acceleration, consider figure 105-8, which shows a velocity vs time graph with a
varying velocity. Since the acceleration at a given time is given by the derivative to
the velocity function, this is represented on the velocity-time graph as the slope of
the tangent line at that point (just like the velocity is the slope of the tangent line on
a position-time graph).  Three accelerations are noted near t1, a positive
acceleration, a(1) with a positive slope, a zero acceleration. a(2) with a zero slope
and a negative acceleration, a(3), with a negative slope. Note that in each case, the
velocity is still positive, even though the acceleration can be positive, negative or
zero.
A second important feature of Figure 105-8 is the shaded region between t1
and t2. Since velocity is found by taking the derivative of position, a change in
position can be found by taking the anti-derivative of the velocity function:

**Figure 105-8. Description of how**
**acceleration a(1-3) and displacement,**

𝑣𝑣⃗= [𝑑][𝑑][𝑟][⃗][𝑟] (105-12) **s, can be found on a velocity-time**

𝑑𝑑𝑑 𝑑 [   →   Δ𝑟𝑟⃗= �𝑣𝑣⃗𝑑𝑑𝑑𝑑.] **graph.**

Since the antiderivative of a function is found as the area under the curve, the shaded region in Figure 105-8 represents the
displacement, s, of the object undergoing the given velocity function shown in the figure.

##### 105.5 – Kinetic Energy

**Consider: What does ‘energy of motion’ mean?**

The general form for kinetic energy was introduced in Unit 103, when we discussed the conservation of energy in general.
Remember that most general form for the kinetic energy may not be the same as what you’ve seen before if you’ve
previously had physics.


**Kinetic Energy**

𝑲𝑲 = (𝜸𝜸 −𝟏𝟏)𝒎𝒎𝒄𝒄[𝟐][𝟐]

**Description – This equation precisely describes the kinetic**

energy of an object of mass, 𝑚𝑚 and speed, 𝑣𝑣. c is the
speed of light in vacuum.

**Note: 𝛾𝛾** = (1 −𝑣𝑣[2]⁄𝑐𝑐[2])[−]2[1]


-----

Let’s take a look at what happens to this equation as an object approaches the speed of light. In order to do this, we must first
write out the kinetic energy equation with the Lorentz factor included, giving us

1
𝐾𝐾= � −1�𝑚𝑚𝑐𝑐[2].

(105-13)

�1 −𝑣𝑣[2]⁄𝑐𝑐[2]

If we then attempt to plug in the speed of light for 𝑣𝑣, notice that the term in the denominator goes to zero, meaning the entire
kinetic energy function is undefined. A deeper analysis would show that as the speed of the object approaches the speed of
light, the kinetic energy tends towards infinity, so we can say that the kinetic energy of an object approaches infinity as its
speed approaches the speed of light. Note that this is independent of the mass of the object!
This is one of the realities of Einstein’s special theory of relativity – a massive object can never reach the speed of light
because its kinetic energy would tend towards infinity. Later in the course, we will see that other factors also tend towards
infinity such as the object’s momentum and the force required to continuously accelerate the object.
For speeds above approximately 3 𝑥𝑥 10[6] 𝑚𝑚/𝑠𝑠 you must use the relativistic form of the kinetic energy. The conservation
of energy simply does not hold for the classical approximation to this equation in that case. However, when speeds are below
this limit, you can use the classical approximation to this kinetic energy equation as shown in the box below (see section 1035).


**Kinetic Energy (Classical Limit)**

𝑲𝑲 = [𝟏]
𝟐𝟐 [𝒎][𝒎][𝒗][𝒗][𝟐][𝟐]

**Description – This equation describes the classical kinetic**


energy of an object of mass, 𝑚𝑚 and speed, 𝑣𝑣.
**Note 1: This equation can be used when 𝑣𝑣** < ~3𝑥𝑥10[6] 𝑚𝑚⁄ . 𝑠
**Note 2: 𝑣𝑣[2]** = 𝑣⃗⋅𝑣𝑣 ⃗𝑣.

Please note: the full, relativistic equation for the kinetic energy always works. However, at slow speeds, your calculator may
not have enough digits to fully calculate the kinetic energy in this way. Generally, if this is the case, the classical equation
for kinetic energy is a very good approximation.
Both kinetic energy equations include a 𝑣𝑣[2] term. If we know the speed of an object, 𝑣𝑣[2] is easy to calculate; it is just the
speed squared. However, what if we know the velocity in vector form? Well, the kinetic energy equation (as with all energy
equations) is a scalar equation, so somehow we must get rid of the vector nature of the velocity.
It turns out that 𝑣𝑣[2] is really the vector dot product (scalar product) of the velocity with itself: 𝑣𝑣⃗⋅𝑣𝑣⃗. We can start by
writing out the definition of the dot product of two vectors, as seen in Unit 104:


𝑎𝑎⃗⋅𝑏𝑏[�⃗] = �𝑎𝑎𝑥𝑥, 𝑎𝑎𝑦𝑦, 𝑎𝑎𝑧𝑧��


𝑏𝑏𝑥𝑥
𝑏𝑏𝑦𝑦
𝑏𝑏𝑧𝑧


�= 𝑎𝑎𝑥𝑥𝑏𝑏𝑥𝑥 + 𝑎𝑎𝑦𝑦𝑏𝑏𝑦𝑦 + 𝑎𝑎𝑧𝑧𝑏𝑏𝑧𝑧 (105-14)


We can simplify this by substituting the components of the velocity in for each of the two vectors in this equation, giving us

𝑣𝑣[2] = 𝑣𝑣⃗⋅𝑣𝑣⃗= 𝑣𝑣𝑥𝑥2 + 𝑣𝑣𝑦𝑦2 + 𝑣𝑣𝑧𝑧2. (105-15)

Let’s say, for example that we have a velocity given by 𝑣𝑣⃗= [2, 5, 3]𝑚𝑚/𝑠𝑠. We could then calculate the square of the velocity
to be given by
𝑣𝑣[2] = 𝑣𝑣⃗⋅𝑣𝑣⃗= (2[2] + 5[2] + 3[2]) 𝑚𝑚𝑠𝑠⁄ = 38 𝑚𝑚[2]/𝑠𝑠[2] . (105-16)

Also note that the speed of this object would be given by the square root of this number, 6.2 m/s, in this case.


-----

Example 105 - 7 **Kinetic energy of a block of ice.**

What is the classical kinetic energy of a 1.74-kg block of ice
moving with a velocity of 〈2.2, 0, 1.7〉 𝑚𝑚/𝑠𝑠?

**Solution:**

The first thing to notice is that all components of the velocity
are much smaller than the speed of light, so we can assume
the classical limit for kinetic energy. Therefore, this problem
asks us to directly apply the classical equation for kinetic
energy,

𝐾𝐾 = [1]
2 [𝑚][𝑚][𝑣][𝑣][2][.]

In order to do this, we must first find the square of the speed
from the velocity using equation 105-15:


𝑣𝑣[2] = 𝑣𝑥𝑣2 + 𝑣𝑦𝑣2 + 𝑣𝑧𝑣2 = (2.2)2 + (0)2 + (1.7)2,

with all numbers in m/s. This gives us

𝑣𝑣[2] = 7.73 𝑚𝑚[2]/𝑠𝑠[2].

This can now be directly used in the equation for kinetic
energy

𝐾𝐾 = [1]
2 [𝑚][𝑚][𝑣][𝑣][2][ = 1]2 [(1.74 𝑘][𝑘][𝑘][𝑘][)(7.73 𝑚][𝑚][2][/𝑠][𝑠][2][) = 6.73 𝐽][𝐽][.]

The kinetic energy of this block of ice is 6.73 J.


Extension: Using speed first.

Another way to solve this equation is to first find the speed of
the block of ice using the magnitude of the velocity and then
using this in the equation for kinetic energy:

|𝑣⃗| = 𝑣 �𝑣𝑥𝑣[2]𝑥 + 𝑣𝑦𝑣[2]𝑦 + 𝑣𝑧𝑣[2]𝑧 = 2.78 𝑚𝑚/𝑠𝑠.

The kinetic energy is then


𝐾𝐾 = [1] ⁄ )[2] = 6.73 𝐽𝐽.

2 [𝑚][𝑚][𝑣][𝑣][2][ = 1]2 [(1.74 𝑘][𝑘][𝑘][𝑘][)(2.78 𝑚][𝑚] [𝑠]

You can see that this gives us the exact same answer in a
slightly different way. The choice is yours! If you look
close, you’ll see that these two methods are really the
same since

�𝑣⃗∙𝑣𝑣 ⃗𝑣 = |𝑣⃗|𝑣


Example 105 - 8 **A human spaceship**

How much kinetic energy would an average, 70-kg person
have if moving at one-half the speed of light? How does this
energy compare to a classical approximation?

**Solution:**

This problem asks us to directly apply the relativistic kinetic
energy equation and then compare the results to the classical
approximation. To calculate the relativistic kinetic energy,
we start with

𝐾𝐾 = (𝛾𝛾 −1)𝑚𝑚𝑐𝑐[2].

Let’s first find a value for 𝛾𝛾 with 𝑣𝑣 = 0.5𝑐𝑐:


We can now calculate the kinetic energy,

𝐾𝐾 = (𝛾𝛾 −1)𝑚𝑚𝑐𝑐[2] = (1.155 −1)(70 𝑘𝑘𝑘𝑘)(3𝑥𝑥10[8] 𝑚𝑚⁄ )𝑠 [2],

which gives us

𝐾𝐾 = 9.77 𝑥𝑥 10[17] 𝐽𝐽.

We can now compare this to the classical approximation,
noting that ½ the speed of light is 1.5𝑥𝑥10[8] 𝑚𝑚⁄ as 𝑠

𝐾𝐶𝐾 𝐶𝐶 𝐶𝐶 𝐶𝐶 𝐶𝐶𝐶 = [1] ⁄ )[2] = 7.78 𝑥𝑥 10[17] 𝐽𝐽.
2 [(70 𝑘][𝑘][𝑘][𝑘][)(1.5𝑥][𝑥][10][8] [ 𝑚][𝑚] [𝑠]

The classical approximation is 20% less than the more
accurate relativistic kinetic energy equation. There is no
question that the relativistic form must be used in this
case.


= 1.155.


(0.5𝑐𝑐)[2]
𝛾𝛾 = (1 −𝑣𝑣[2]⁄𝑐𝑐[2])[−1]2 = �1 − �

𝑐𝑐[2]


−[1]
2


-----

-----

