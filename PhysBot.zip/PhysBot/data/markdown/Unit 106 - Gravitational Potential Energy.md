## – Gravitational Potential Energy
# 106


_In unit 106, we introduce the first potential energy function that we will encounter in Physics I. In addition, we will_
_couple these gravitational potential energy functions with kinetic energy to explore simple conservation of energy_
_problems._


#### The Bare Essentials

- When two objects interact gravitationally, they store energy as

gravitational potential energy.



- If the gravitational field can be considered to be constant over

a change in distance (i.e. any changes in distance are small
when compared to the distance from a massive body), the
gravitational potential energy can be written in a simpler form.


**Gravitational Potential Energy**

𝑼𝒈𝑼 𝒈 = − [𝑮][𝑮][𝒎][𝒎][𝟏][𝟏][𝒎][𝒎][𝟐]
𝒓𝒓𝟏𝟏𝟏

**Description – This equation describes the gravitational**

potential energy, 𝑈𝑔𝑈 𝑔, stored between two masses, 𝑚1𝑚 and
𝑚𝑚2, whose centers of mass are separated by a distance,
𝑟12𝑟 .
**Note 1: The reference frame for this equation is set so that**


𝑈𝑔𝑈 𝑔 = 0 when 𝑟12𝑟 = ∞.
**Note 2: The constant of proportionality, 𝐺𝐺, is known as the**

universal gravitational constant and has a value 𝐺𝐺 =
6.67 𝑥𝑥 10[−11] 𝐽𝐽 ⋅𝑚𝑚/𝑘𝑘𝑔𝑔[2] = 6.67 𝑥𝑥 10[−11] 𝑚𝑚[3]⁄𝑘𝑘𝑘𝑘 ∙𝑠𝑠[2].

- The (vector) gravitational field of a large, spherical object can
be written in terms of the object’s mass and the distance from
the center of mass of the object.


and must be kept consistent for a given system.
**Note 2: In order to use this approximation, 𝑔𝑔 must be**

approximately constant over all values of ℎ for a given
system; therefore Δℎ must be much smaller than the
radius of the large body.

- Conservation of energy (COE) can be used to solve problems
with gravitational potential energy and kinetic energy. (We
will add to our COE repertoire in the next few units as well).


**Gravitational Potential Energy**
**(approximation near large body)**

𝑼𝒈𝑼 𝒈 = 𝒎𝒎𝒎𝒎𝒎 𝒎

**Description – This equation describes the gravitational**

potential energy of a mass, 𝑚𝑚, in a gravitational field
strength, 𝑔𝑔, and height ℎ.
**Note 1: The reference frame for this equation is arbitrary**


**Gravitational Field**


𝒈��⃗= −𝒈 [𝑮]𝟐[𝑮][𝑮]𝟐 [𝒓][�][𝒓][𝟏][𝟏][𝟏][𝟏]

𝒓𝒓𝟏𝟏𝟏

**Description – The equation describes the gravitational**

field, 𝑔⃗𝑔, of a large, spherical object of mass, 𝑚𝑚, a
distance 𝑟12𝑟 from the center of mass of the object.
**Note 1: This equation assumes we are outside the radius of**

the object.
**Note 2: The reference frame for this equation is set so that**


𝑔⃗= 0𝑔 when 𝑟12𝑟 = ∞.

- The gravitational field strength, 𝑔𝑔, is the magnitude of the
gravitational field, |𝑔𝑔⃗|, and is always a positive number. Near
the surface of the earth 𝑔𝑔= 9.80 𝑁𝑁𝑘𝑘𝑘𝑘⁄ = 9.80 𝑚𝑚𝑠𝑠⁄ [2].


-----

### 106.1 – The gravitational interaction

**Consider: Why do objects with mass attract each other?**

As we saw in units 101 and 102, the gravitational interaction is both fundamental _and macroscopic. As one of the four_
fundamental interactions, it relates how any two massive bodies interact. On a macroscopic level, we can deduce the way an
object will move based on its position relative to other masses. To be clear, any two objects with mass attract each other via
the gravitational interaction; however, we will see that unless at least one of the two objects is very massive, the interactions
is very hard to detect.
So, how does one detect the gravitational interaction? Below, we will describe how two objects interacting
gravitationally store energy between them in the form of **_gravitational potential energy. This is the first of the_** **_potential_**
**_energies that we will encounter. In general, a potential energy is any form of stored energy that depends only on position_**
(unlike kinetic energy that depends on speed). Once we know a little bit about gravitational potential energy, we can then use
the conservation of energy and the conversion of potential energy to kinetic energy to measure the gravitational interaction.

### 106.2 – Gravitational potential energy

**Consider: How much energy is stored between objects with mass?**

The gravitational potential energy between two massive particles, 𝑚1𝑚, and 𝑚𝑚2, is directly proportional to their masses and
inversely proportional to the distance between the centers of mass of the particles, 𝑟12𝑟 .  This makes sense, since you would
expect larger masses to have a stronger interaction and expect the strength of the interaction to decrease as the objects get
farther apart.


**Gravitational Potential Energy**

𝑼𝒈𝑼 𝒈 = − [𝑮][𝑮][𝒎][𝒎][𝟏][𝟏][𝒎][𝒎][𝟐]

𝒓𝒓𝟏𝟏𝟏


(106-1)


**Description – This equation describes the gravitational**

potential energy, 𝑈𝑔𝑈 𝑔, stored between two masses, 𝑚1𝑚 and
𝑚𝑚2, whose centers of mass are separated by a distance,
𝑟12𝑟 .
**Note 1: The reference frame for this equation is set so that**


𝑈𝑔𝑈 𝑔 = 0 when 𝑟12𝑟 = ∞.
**Note 2: The constant of proportionality, 𝐺𝐺, is known as the**

universal gravitational constant and has a value 𝐺𝐺 =
6.67 𝑥𝑥 10[−11] 𝐽𝐽 ⋅𝑚𝑚⁄𝑘𝑘𝑔𝑔[2] = 6.67 𝑥𝑥 10[−11] 𝑚𝑚[3]⁄𝑘𝑘𝑘𝑘 ∙𝑠𝑠[2].

As shown in Note 1 of the equation box, this equation for the gravitational potential energy assumes that 𝑈𝑈𝑔𝑔 = 0 when 𝑟𝑟12 =
∞, meaning that the potential energy between to objects tends towards zero as their separation gets very, very large. This is
also why the equation for gravitational potential energy has a negative sign as well. The gravitational interaction is always
attractive (as far as we know). Therefore, if two masses are free to move and are only affected by the gravitational
interaction, they will tend to move towards each other, with some of the potential energy converted to kinetic energy. In
order for the kinetic energy to be positive when the objects get closer (starting from rest), the equation for the gravitational
potential energy must be negative.
Technically, equation 106-1 only holds for point particles. However, this equation can approximately be used as long as
the objects are outside of each other – meaning that the separation between the centers of mass, 𝑟𝑟12, is greater than the
combined size of the objects. This is relatively easy to show for spherical objects, although I will leave it to interested
readers to find a proof of such a statement. If you think about it, on a large scale, where the gravitational interaction plays its
largest role, many of the interacting objects are approximately spherical – planets, stars, etc. Therefore, the approximation
works extremely well. Even near the surface of the earth, at least one of the objects (the earth) is quite spherical, and since it
is by far the dominant object when things our size are interacting with the planet, the approximation is, again, quite good.


-----

Example 106 - 1  You and your neighbor

What is the gravitational potential energy stored between two
70-kg people separated by 2 meters?

**Solution:**

This problem is a direct application of the equation for
gravitational potential energy:

𝑈𝑔𝑈 𝑔 = − [𝐺][𝐺][𝑚][1][𝑚] [𝑚][𝑚][2]
𝑟12𝑟

Substituting in known values, we find


(6.67 𝑥𝑥 10[−11] 𝐽𝐽 ⋅𝑚𝑚⁄𝑘𝑘𝑔𝑔[2])(70 𝑘𝑘𝑘𝑘)(70 𝑘𝑘𝑘𝑘)
𝑈𝑔𝑈 𝑔 = −,
2 𝑚

leading to

𝑈𝑔𝑈 𝑔 = 1.63 𝑥𝑥 10[−7] 𝐽𝐽.

The scale of this result shows just how weak the
gravitational interaction is. We will see that this is very
small when compared to other potential energies.


### 106.3 – The gravitational field

**Consider: How can we visualize gravity?**

Drop a hammer anywhere near the surface of the earth, and it falls to the ground.
This is true whether you are here in New London, or in Shanghai, China.  The
gravitational interaction between the hammer and the earth causes it to move
towards the center of the earth when released (until it hits the ground and stops
because of other interactions).  The same can be said of the moon. If you are
standing on the moon and drop a hammer, it falls to the surface of the moon
because of the gravitational interaction between the hammer and the moon.  You
could make the same arguments – both for earth and the moon – if the object you
are dropping is not a hammer, but almost anything else as well.
In physics, we say that the earth (or the moon) create a **_gravitational field,_**
which can then act on an object if it is placed in that field. Gravitational fields are
vectors, since we can describe how objects (such as the hammer) will react in terms
of both how fast they will react (magnitude) and in what direction they move
(direction). Figure 106-1 shows a graphical representation of the gravitational field **Figure 106-1. Gravitational field of**
of the earth which fits everything described above. The lines in this figure are **the earth.**
called **_gravitational field lines and represent the direction that an object would_**
move if released from rest at some point. The strength of the gravitational field is depicted by how close the field lines are
to each other. Notice that if you move away from the earth, the lines become more spread out – meaning that the strength of
the gravitational field decreases as you move away from the earth. If you think about it, this fits with the equation 106-1
above which says that the gravitational interaction between two objects decreases as the distance between the object
increases.
There is an important point to make about the gravitational field:

**A gravitational field is produced by a single massive object. It is a measure of how a second massive**
**object would react if placed in the field of the first object.**

So, we know that the gravitational field will always point towards the center of mass of the object creating the field. The
strength of the field will have to do with the mass of the object creating the field and how far we are from the center of mass.
However, since the field lines radiate directly away from the object in a spherical pattern (think about extending Figure 106-1
to three dimensions), the area over which the field lines are spread will increase as 𝑟𝑟[2] as we move a distance 𝑟𝑟 from the
object (remember, the surface area of a sphere is given by 4𝜋𝜋𝑟𝑟[2]). This means that the strength of the field will decrease as
1 𝑟𝑟⁄ [2] as we move away from the center. We use the symbol 𝑔𝑔⃗ to denote the (vector) gravitational field.
The gravitational field strength, 𝑔𝑔, is the magnitude of the gravitational field (|𝑔𝑔⃗|) at some point relative to the center of
the object creating the field.


-----

A couple of important notes:

1) 𝑔𝑔 is always a positive number since it is the magnitude of a vector. When used in vector form, the direction of 𝑔𝑔⃗
may be negative.
2) 𝑔𝑔 is sometimes also called the acceleration due to gravity, although this is a bit of a misnomer – it is the acceleration
of an object in a gravitational field in the absence of all other interactions.
3) 𝑔𝑔⃗ can be defined for any object, not just the earth.
4) The units of 𝑔𝑔 are either 𝑁𝑁⁄𝑘𝑘𝑘 or 𝑚𝑚⁄𝑠𝑠[2]


**Gravitational Field**


𝒈��⃗= −𝒈 [𝑮]𝟐[𝑮][𝑮]𝟐 [𝒓][�][𝒓][𝟏][𝟏][𝟏][𝟏] (106-2)

𝒓𝒓𝟏𝟏𝟏

**Description – The equation describes the gravitational**

field, 𝑔⃗𝑔, of a large, spherical object of mass, 𝑚𝑚, a
distance 𝑟12𝑟 from the center of mass of the object.
**Note 1: This equation assumes we are outside the radius of**

the object.
**Note 2: The reference frame for this equation is set so that**

𝑔⃗= 0𝑔 when 𝑟12𝑟 = ∞.


Example 106 - 2 **The earth**

What is the gravitational field at the surface of the earth?

**Solution:**

This problem asks us to directly use information about the
earth to find the gravitational field at the surface of our planet.
We first assume the earth is a perfect sphere, so that the
direction of the gravitational field is “down”.
Using astronomical data from the table at the end of this
book, we can then find just the magnitude of the gravitational
field:


(6.67 𝑥𝑥 10[−11] 𝐽𝐽 ⋅𝑚𝑚⁄𝑘𝑘𝑔𝑔[2])(5.98𝑥𝑥10[24]𝑘𝑘𝑘𝑘)

|𝑔⃗| = 𝑔 [𝐺][𝐺][𝐺]2 [=],

𝑟12𝑟 (6.38𝑥𝑥10[6] 𝑚𝑚)[2]

which gives us

|𝑔⃗| = 9.80 𝑚𝑔 𝑚⁄𝑠𝑠[2].

Please note, this is a crude approximation for g at the
surface of the earth based on astronomical data. The
actual value is different depending on where you are.


Gravity in New London

Due to irregularities in the shape and composition of the
earth, the actual gravitational field strength varies by position,
even if you are near sea level. The most accurate
experimentally determined value for |𝑔⃗|𝑔 in the New London
area is


|𝑔⃗|𝑔 𝑁𝑁𝑁𝑁𝑁 𝑁 𝐿𝐿𝐿𝐿𝐿 𝐿𝐿𝐿𝐿 𝐿𝐿 𝐿 = 9.80435 𝑚𝑚⁄𝑠𝑠[2].

There is a myth that 𝑔𝑔 is over 9.81 m/s[2] in the New
London area. This is simply not true.


Example 106 - 3 **The moon**

What is the gravitational field strength at the surface of the
moon?

**Solution:**

This problem asks us to directly calculate the magnitude of
the gravitational field of the moon at its surface. We will do
this by using the equation for magnitude of the gravitational
field and using values from the table at the end of the book:


(6.67 𝑥𝑥 10[−11] 𝐽𝐽 ⋅𝑚𝑚⁄𝑘𝑘𝑔𝑔[2])(7.35𝑥𝑥10[22]𝑘𝑘𝑘𝑘)

|𝑔⃗| = 𝑔 [𝐺][𝐺][𝐺]2 [=],

𝑟12𝑟 (1.74𝑥𝑥10[6] 𝑚𝑚)[2]

or

|𝑔⃗| = 1.62 𝑚𝑔 𝑚⁄𝑠𝑠[2].

Note: This is about 1/6[th] the gravitational field strength at
the surface of the earth.


-----

### 106.4 – Gravity near a very large object

**Consider: What about mgh?**

Equation 106-1 assumes a coordinate system where the gravitational potential energy is defined to be zero when the objects
are infinitely far apart. What if we want to set up a coordinate system where our zero is some other place (such as the surface
of the earth)? We can do this by adding a constant to equation 106-1 that is designed to give a value of zero for the potential
energy at that point:
𝑈𝑈𝑔𝑔 = − [𝐺][𝐺][𝑚][1][𝑚] [𝑚][𝑚][2] + [𝐺][𝐺][𝑚][1][𝑚] [𝑚][𝑚][2]. (106-3)

𝑟 𝑟𝑒𝑟

Note, again, that this equation has the same form as our original gravitational potential energy equation (equation 106-2);
however, it is zero when 𝑟𝑟= 𝑟𝑟𝑒𝑒. Remember that this is still a perfectly good definition for the potential energy since we have
change it by a constant and it is only differences in potential energy that are physically important.
Now, let’s simplify this equation a little bit by pulling out like terms and rearranging to make the negative between the
terms:
𝑈𝑈𝑔𝑔 = 𝐺𝐺𝑚𝑚1𝑚𝑚2 �[1] − [1] (106-4)

𝑟𝑒𝑟 𝑟𝑟[�.]

If we want to find the gravitational potential energy a distance h above the ground at some point, this means that 𝑟𝑟= 𝑟𝑟𝑒𝑒 + ℎ,
that is the distance from the center of the earth to the surface (𝑟𝑟𝑒𝑒) plus the height above the surface (ℎ). Substituting this in,
we find

1 1

𝑈𝑈𝑔𝑔 = 𝐺𝐺𝑚𝑚1𝑚𝑚2 � [1] − �= [𝐺][𝐺][𝑚][1][𝑚] [𝑚][𝑚][2] �1 − (106-5)

𝑟𝑒𝑟 ℎ+ 𝑟𝑒𝑟 𝑟𝑒𝑟 1 + (ℎ𝑟⁄ )𝑒𝑟 [�,]

where in the last term, I have also pulled the common factor 𝑟𝑒𝑒𝑟 out of the parentheses. I’m now going to try and simplify this
more by combining terms in the parentheses (using a common denominator):

𝑈𝑈𝑔𝑔 = [𝐺][𝐺][𝑚]𝑟[1][𝑚]𝑒𝑟 [𝑚][𝑚][2] �[1 + (ℎ𝑟]1 + (ℎ𝑟⁄ )⁄ )[𝑒]𝑒[𝑟]𝑟 [−] 1 + (ℎ𝑟1 ⁄ )𝑒𝑟 [�= ][𝐺][𝐺][𝑚]𝑟[1][𝑚]𝑒𝑟 [𝑚][𝑚][2] �1 + (ℎ𝑟ℎ𝑟⁄ 𝑒⁄ )𝑟 𝑒𝑟 [�.] (106-6)

Next, I will combine like terms and rearrange the order of terms so that values for different objects are essentially separated:

1

𝑈𝑈𝑔𝑔 = 𝑚𝑚1 �[𝐺]𝑟[𝐺][𝑚]𝑒𝑟[2]𝑒 [𝑚][2] 1 + (ℎ𝑟⁄ )𝑒𝑟 [�ℎ.] (106-7)

Up until now, we have made zero approximations – this is simply a rewriting of the gravitational potential energy equation
resetting the zero point at the radius of the earth and comparing it to the potential energy a distance ℎ above the surface. We
can now simplify the equation if we make the following assumptions


1) 𝑚𝑚2 is the mass of the earth (up until now 𝑚𝑚1 and 𝑚𝑚2 have been completely interchangeable)
2) 𝐺𝐺𝑚𝑚2 𝑟𝑟⁄ 𝑒𝑒2 is the gravitational field strength of the earth, 𝑔𝑔 (see section 106.3)

3) 𝑚𝑚1 is the mass of the object placed a distance ℎ above the surface (call it just 𝑚𝑚.)
4) As long as ℎ≪𝑟𝑟𝑒𝑒 the second term in parentheses is very close to 1. This is the same as saying that the height above
the surface of the earth is very small when compared to the radius of the earth.

With these simplifications and assumptions, we can now write the gravitational potential energy as

𝑈𝑈𝑔𝑔 = 𝑚𝑚𝑚𝑚ℎ. (106-8)

It is very important to remember that this equation is an approximation when 𝑔𝑔 is known and ℎ is very small compared to 𝑟𝑟𝑒𝑒!
Also, there is no reason that this derivation is specific to earth – remember, the gravitational field strength, 𝑔𝑔, can be defined
for any large body. So, as long as we can define 𝑔𝑔 and the height above the surface of the body is small compared to the
radius of the body, this approximation holds.
Finally, the reference distance is also arbitrary. We could just as easily have derived this equation with our reference
height 20 meters above the surface of the earth as opposed to just the radius of the earth. What this means is that you can
choose the zero of height to be anywhere you want (as long as the assumptions still hold), and then h is just measured relative
to that zero point.


-----

**Gravitational Potential Energy**
**(approximation near large body)**

𝑼𝒈𝑼 𝒈 = 𝒎𝒎𝒎𝒎𝒎 𝒎

**Description – This equation describes the gravitational**

potential energy of a mass, 𝑚𝑚, in a gravitational field
strength, 𝑔𝑔, and height ℎ.
**Note 1: The reference frame for this equation is arbitrary**

and must be kept consistent for a given system.
**Note 2: In order to use this approximation, 𝑔𝑔 must be**

approximately constant over all values of ℎ for a given
system, and ℎ must be much smaller than the radius of
the large body.


Example 106 - 4 **Potential energy I**

What is the gravitational potential energy of a 12-kg block at
a height of 22 meters above the ground of the earth? Take the
ground to be the zero of height in this problem.

**Solution:**

This is a direct application of the gravitational potential
energy equation for an object near a large body (earth). We
start with the equation for potential energy,


𝑈𝑔𝑈 𝑔 = 𝑚𝑚𝑚𝑚ℎ,

and then substitute in relevant values, noting that the
height of 22 meters can be used since we are asked for 22
meters above the ground and the ground is the zero-point
of height. This gives us

𝑈𝑔𝑈 𝑔 = (12 𝑘𝑘𝑘𝑘)(9.80 𝑚𝑚⁄𝑠𝑠[2])(22 𝑚𝑚) = 2587 𝐽𝐽 = 2600 𝐽𝐽.


Example 106 - 5 **Potential energy II**

A 2.0-kg physics book initially has zero potential energy
while sitting on top of a 1.2-meter high table. What is the
gravitational potential energy of this book if it falls to the
ground?

**Solution:**

Like example 106-4, this is a direct application of the
equation for gravitational potential energy near the surface of
a large body. However, in this case, since the zero point
energy is above the point we wish to calculate, we must


use -1.2 meters for the final height of the object. This
gives us

𝑈𝑔𝑈 𝑔 = 𝑚𝑚𝑚𝑚ℎ= (2.0 𝑘𝑘𝑘𝑘)(9.80 𝑚𝑚⁄𝑠𝑠[2])(−1.2 𝑚𝑚),
or

𝑈𝑔𝑈 𝑔 = −23.5 𝐽𝐽 = −24 𝐽𝐽.

**_Do not be scared off by the negative. Potential energies_**
are all relative to a specific point, so the negative hear
just tells us that it is less than the value on top of the
table.


### 106.5 – Conservation of Energy

**Consider: How does this change the conservation of energy?**

We are now ready to take a first look at conservation of energy problems. In the classical limit, the total energy of a system is
defined as the sum of the kinetic energy of each object and all of the potential energies between the objects.

𝐸𝐸= 𝐾𝐾1 + 𝐾𝐾2 + 𝐾𝐾3 + ⋯+ 𝑈𝑈12 + 𝑈𝑈13 + ⋯ (106-9)

We can then apply the conservation of energy to the entire system

Δ𝐸𝐸= 𝐸𝐸𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓 − 𝐸𝐸𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖 = 0    or    𝐸𝐸𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖𝑖 = 𝐸𝐸𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓𝑓. (106-10)


-----

Solving conservation of energy problems

The following steps are important for understanding how conservation of energy equations work. I strongly suggest
following all of these steps at least until you are very comfortable with the process.

1) **_Define all of the objects in the system of interest. This will usually include not only a specific object of interest but_**
also all of the objects which this object interacts with.
2) **_Draw two pictures of the system – one representing the initial situation and one representing the final situation._**
3) **_Label all objects in your picture and show important variables related to their energies (speed or height relative to_**
the zeros for example).
4) **_Write the conservation of energy equation, making sure to include terms for all energies in the system._**
5) **_Solve the conservation of energy equation._**
6) **_Describe the results in terms of the physical reactions of the system._**

Special note on large objects

**Connection: The most important equation not to use**

Did you know that when you throw a rock
down off a cliff, the kinetic energy of the It is so very easy for introductory physics students to simply write down
earth changes as the kinetic energy of the
rock changes? As you can imagine, this

𝑚𝑚𝑚𝑚ℎ= [1]

change in kinetic energy of the earth is 2 [𝑚𝑚𝑣𝑣][2][.]
very small, and has little effect on the

We want to make it very clear that this is never an acceptable starting point for a

change in kinetic energy of the rock.
Therefore, in conservation of energy conservation of energy problem. First, it is unclear whether the ℎ and 𝑣𝑣 are initial or

final values, and shows no connection to the interactions creating the potential

problems, we can often ignore the change

energy.

in kinetic energy of an object if it is very
massive compared to the other objects in It is always better to start from the conservation of energy equation, define all types
the system. of energy in the system, and simplify from there. In this manner, you will almost
As an example, again consider the never miss a possible type of energy, and will prove to your instructor that you are
rock being dropped off of a cliff. In this trying to solve the problem as opposed to simply plugging numbers into an (all too
case the two objects of interest are the rock often incorrect) equation.
and the earth and we could write the
conservation of energy equation as
Δ𝐸𝐸= 0 = Δ𝐾𝐾𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟 + Δ𝐾𝐾𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒ℎ + Δ𝑈𝑈𝑔𝑔, (106-11)

where Δ𝑈𝑈𝑔𝑔 is assumed to be the gravitational potential energy between the earth and the rock. Just to finish this quick
example, we can ignore the change in kinetic energy of the earth, since it is so massive compared to the rock (Δ𝐾𝐾𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒ℎ = 0),
and write

2 2 (106-12)

Δ𝐸𝐸= 0 = [1] − [1] + 0 + 𝑚𝑚𝑟𝑟𝑔𝑔ℎ𝑓𝑓 −𝑚𝑚𝑟𝑟𝑔𝑔ℎ𝑖𝑖,

2 [𝑚𝑚][𝑟𝑟][𝑣𝑣][𝑓𝑓] 2 [𝑚𝑚][𝑟𝑟][𝑣𝑣][𝑖𝑖]

where 𝑚𝑚𝑟𝑟 is the mass of the rock, 𝑣𝑣𝑖𝑖 and 𝑣𝑣𝑓𝑓 are the initial and final speeds of the rock, respectively and ℎ𝑖𝑖 and ℎ𝑖𝑖 are the
initial and final heights of the rock (relative to some common reference point), also respectively. The zero in this equation
represents the fact that we can neglect the change in kinetic energy of the earth. Please see the connection box above for a
warning about simplifying equation 106-12 too early and too much.

### 106.6 – Examples

**Consider: How can we use all of this in problems?**

The following examples are designed to help you in setting up conservation of energy problems. At this point, we can only
use kinetic energy and gravitational potential energy in one of the forms given in this chapter. Over the next few units, we
will expand the number and types of potential (and kinetic) energy that we can use in the conservation of energy. Please get
used to using the conventions while we have just two type of energy so that the transition to many types of energy will be
more smooth.


-----

Example 106 - 6 **Thinking in terms of energy**

If an object has 20.0 J of energy when at a height of 123 the falling object since it is suggested that the object has
meters above the ground just before being released from rest, only 20.0 J of potential energy at its initial height. In this
how much kinetic energy will it have just before striking the case, we can eliminate Δ𝐾𝑒𝐾 𝑒 and use the gravitational
ground below? potential energy near a large object, leading to

**Solution:** 𝐾𝑜𝐾 𝑜,𝑓𝑓 −𝐾𝑜𝐾 𝑜,𝑖𝑖 + 𝑈𝑔𝑈 𝑔,𝑓𝑓 −𝑈𝑔𝑈 𝑔,𝑖𝑖 = 0,

This is a direct application of the conservation of energy where all values are now for the object alone. We can
including gravitational potential and kinetic energy. In our now define the zero-point height of the problem as the
system, we must include the object and the earth. Therefore, ground, meaning that the initial height is 123 meters, and
the conservation of energy equation for this system is the final height is zero meters (so that 𝑈𝑔𝑈 𝑔,𝑓𝑓 = 0). In

addition, the object is initially at rest so 𝐾𝑜𝐾 𝑜,𝑖𝑖 = 0. Using

Δ𝐾𝑜𝐾 𝑜 + Δ𝐾𝑒𝐾 𝑒 + Δ𝑈𝑔𝑈 𝑔 = 0, these simplifications, we find

where Δ𝐾𝑜𝐾 𝑜 and Δ𝐾𝑒𝐾 𝑒 are the change of kinetic energy of the 𝐾𝑜𝐾 𝑜,𝑓𝑓 −𝑈𝑔𝑈 𝑔,𝑖𝑖 = 0    or    𝐾𝑜𝐾 𝑜,𝑓𝑓 = 𝑈𝑔𝑈 𝑔,𝑖𝑖 .
object and earth, respectively, and Δ𝑈𝑔𝑈 𝑔 is the change in
gravitational potential energy of the earth-object system. Therefore, the final kinetic energy is equal to the initial
We can assume that the earth is much more massive than potential energy with is 20.0 J.

It’s not just semantics:

If you continue on from the results of example 106-6 and which looks remarkably like the equation we say _not to_
substitute in known equations for the kinetic and potential use in the connection box on the last page. However, this
energy, we get equation specifically states which values are initial and

which are final and the process showed why other terms

1 2 = 𝑚𝑚𝑚𝑚ℎ𝑖𝑖, could be neglected. important to solving a physics problem than the actual These other steps are more
2 [𝑚][𝑚][𝑣][𝑓][𝑣]

**_answer._**


Δ𝐾𝑜𝐾 𝑜 and Δ𝐾


-----

Example 106 - 8


-----

-----

