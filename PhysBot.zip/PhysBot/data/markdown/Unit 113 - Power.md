### – Power
## 113


_Power is the rate at which energy is transferred. This transfer can be between types of energy, between objects or even_
_between systems. In this unit, we explore the general idea of power and how it relates directly to energy and work and_
_how this relationship can be extended to how power relates to force and velocity._

##### Integration of Ideas

    - The types of energy from units 103 - 109.
    - The relationship between work and force from unit 110.


##### The Bare Essentials

- Power is the time rate of change of energy for a particle or a

system.



- The power needed to maintain a given velocity is related to the

force that must be exerted.


**Power**

𝑷= [𝒅𝑬]

𝒅𝒕

**Description – This equation defines the power transferred**

as the rate of change of energy with respect to time.
**Note 1: Power can be defined as the rate of change of any**

type of energy with respect to time be it potential,
kinetic or internal energy.
**Note 2: The SI unit of power is the Watt (W).**


**Power From Force and Velocity**

𝑷= 𝑭[��⃗] ∙𝒗��⃗

**Description – This equation relates how much energy per**

second (power) is transformed as a specific force, 𝐹[⃗], acts
on an object moving with velocity, 𝑣⃗.
**Note: 𝐹[⃗] must be constant over the time interval used for the**

equation to hold.



- One non-standard, historical unit of power is the horsepower

(hp), Although the conversion between horsepower and joules
has no standard value, we will use

1 ℎ𝑝= 745.7 𝑊

- The kilowatt-hour is a unit of energy often used to measure

electricity usage in residential and commercial systems:

1 𝑘𝑊ℎ= 3.6 𝑥 10[�] 𝐽= 3.6 𝑀𝐽.


-----

#### 113.1 – How energy changes with time

**Consider: How does power relate to changes in energy?**

NITS 105 – 112 HAVE INTRODUCED YOU to many ‘types’ of energy: kinetic, gravitational potential, elastic
potential, chemical potential and internal energy just to name a few.  We have also explored how the conservation of
energy tells us that energy can flow between these different types and into and out of a system so long as the total

# U

amount of energy does not change. The term power describes the time rate of change of energy in two possible ways:


1) The rate at which one type of energy is transformed into another type of energy,
2) The rate at which energy enters or leaves a system.

This definition of power is quite general. Since we can use it for any type of energy, we tend to define power using the
generic symbol E as opposed to any specific type of power:

𝑃= [𝑑𝐸] (113-1)

𝑑𝑡 [.]

Keep in mind that when using this equation, you can substitute in any form of energy you need, so that it could be
written 𝑃= 𝑑𝐾𝑑𝑡⁄ for kinetic energy, or 𝑃= 𝑑𝑈�⁄𝑑𝑡for gravitational potential energy. The key is that power is always
going to represent the rate of change of one form of energy into another form. The SI unit for power is the Watt (W), where

1 𝑊= 1 𝐽𝑠⁄ . (113-2)


**Power**

𝑷= [𝒅𝑬]

𝒅𝒕

**Description – This equation defines the power transferred**

as the rate of change of energy with respect to time.
**Note 1: Power can be defined as the rate of change of any**

type of energy with respect to time be it potential,
kinetic or internal energy.
**Note 2: The SI unit of power is the Watt (W).**


You are probably familiar with the term Watt from household lighting.  Traditional, incandescent light bulbs used for
living room lamps and desk lamps are rated as either 60 Watts or 100 Watts. These values relay the rate at which electrical
energy is transformed into other forms of energy – both electromagnetic (light) energy and heat in this case. Part of the
problem with incandescent bulbs is that a large portion of energy transfer goes to heat as opposed to light. Modern compact
fluorescent lights (CFL) and light emitting diode (LED) bubs have tremendously reduced the “wasted” heat and allowed
more energy to be transformed to light. As an example, you might see packaging from an LED light stating

**_60 W Equivalent LED Light Bulb._**

A closer reading of the packaging may show that this bulb only uses 8.5 Watts of electrical power to produce the same light
output as a traditional 60 Watt incandescent light bulb. These more efficient bulbs save on overall energy transfer (wattage)
by reducing the amount of electrical to thermal energy transfer while maintaining the electrical to light transfer.
These savings add up over time. Keep in mind, again, that power is the rate of energy transfer. In the discussion above,
the 60-Watt equivalent light bulb saves 51.5 Watts. To see how much energy we save, we can first rearrange the equation for
power to solve for energy
𝑑𝐸= 𝑃𝑑𝑡 → ∆𝐸= 𝑃∆𝑡, (113-3)

where I have allowed the small changes in time and energy (𝑑𝐸 and dt) to be expanced to macroscopic differences (∆𝐸 and
∆𝑡). Using this, you can see that the savings in energy are dependent on both the power and the time. For our example


-----

1 second: 𝐸= (51.5 𝑊)(1 𝑠) = 51.5 𝐽,

10 seconds: 𝐸= (51.5 𝑊)(10 𝑠) = 515 𝐽,

1 minute: 𝐸= (51.5 𝑊)(60 𝑠) = 3090 𝐽.

Although I have used electrical energy to introduce the ideas of power, again, any form of energy can be used.
As with most units, the measurement of power spans many orders of magnitude in physics. Table 113-1 gives
representative values for many common energy output regimes including the energy transfer involved.

**Table 113-1. Some typical values for power and the types of energy involved.**

Power (W) Types of transfer
**Sun** 3.9 𝑥10[��] Nuclear → electromagnetic
**Nuclear power plant** 1 𝑥10[�] Nuclear → electric
**Pickup truck while running** 1.50 𝑥10[�] Chemical → mechanical
**Radio station** 1.00 𝑥10[�] Electrical → electromagnetic
**Toaster oven** 1500 Electrical → thermal
**Resting human** 100 Chemical → thermal
**Laser pointer** 1 𝑥10[��] Electrical → electromagnetic


Example 113 - 1 **Instantaneous power**

Imagine water waves transfer energy into a system with the
following function

𝑊= (−10𝑒[���]) 𝐽.

What is the power entering the system at 𝑡= 2 𝑠𝑒𝑐𝑜𝑛𝑑𝑠?

**Solution:**

This problem asks us to use the definition of power to
determine the power entering a system at a given time.


We start with the equation for power, noting that our
energy transfer mechanism is mechanical work,

𝑃= [𝑑𝑊] [𝑑]

𝑑𝑡 [=] 𝑑𝑡 [(−10𝑒][���][) = 20𝑒][���][.]


At t = 2 s, we get

𝑃= 20𝑒[��(�)] = 0.37 𝑊.


Example 113 - 2 **Average Power**

Friction brings a 2.0-kg block to rest from a speed of 11.2 m/s
in 2.4 seconds. What is the average power as energy is
removed from the system?

**Solution:**

This problem asks us to find average power in terms of how
energy changes per time. In order to do this, we first note that

𝑃= [𝑑𝐸]𝑑𝑡 → 𝑃��� = [∆𝐸]∆𝑡 [.]


The loss of energy in the system is from kinetic energy,
so we find

⁄ )[�]

�[𝑚𝑣][�] �[(2.0 𝑘𝑔)(11.2 𝑚𝑠]

𝑃��� = [𝐾][�]∆𝑡[−𝐾][�] = [0 −]∆𝑡[�] = [−][�] 2.4 𝑠 .


or


𝑃��� = −52.3 𝑊


Almost as an aside, an old unit of power is the horsepower (hp). Ironically, the term horsepower was originally coined
by James Watt (who the current SI unit _watt is named after) in the late 18[th] century to compare the power output of steam_
engines to that or horses. Unfortunately, the term horsepower has been defined in many different ways over the last two
centuries, with each having slightly different values related to the modern watt. For our purposes, we will use the following
conversion factor:
1 ℎ𝑝= 745.7 𝑊. (113-4)


-----

#### 113.2 – The kilowatt-hour (kWh) 

**Consider: What is a kilowatt-hour?**

The kilowatt-hour is a unit that confuses physics students worldwide. Although it explicitly has the word watt as part of its
name, it is not a unit of power. A kilowatt-hour is produced by expending 1000 watts of power for one hour. Since it is a
unit of power multiplied by time, it is actually a measure of energy with very strange units:

1 𝑘𝑊ℎ= 1000 𝑊ℎ= 1000 (𝐽/𝑠)ℎ𝑟. (113-5)

Since there are 3600 seconds in an hour, the conversion factor between kWh and Joules is then

1 𝑘𝑊ℎ= 3.6 𝑀𝐽. (113-6)

The unit kWh is most commonly used when discussing electric energy and especially household and commercial electricity
bills. For example, at the time of writing this book the average cost of electricity in Connecticut is 15.50 cents/kWh. This
rate can be used to calculate the cost to run various electronics, appliances and households. Why such confusing
nomenclature? As with most non-SI units, the answer is mostly historical; however it is especially interesting to note that in
the United States, the kWh is one of the few units that does have an SI unit (Watt) as part of its definition.


Example 113 - 3 **Cost to run a heater**

How expensive is it to run a 1500-W space heater for 8 hours
in Connecticut?

**Solution:**

This problem asks us to use the definition of kilowatt-hour
and the price of electricity in CT to determine cost of running
a space heater.


The energy output, in kWh for a 1500-W heater for 8
hours is

𝐸= (1.5 𝑘𝑊)(8 ℎ𝑟) = 12 𝑘𝑊ℎ.

Since electricity is 15.50 cents/kWh, we find

𝐶𝑜𝑠𝑡= (12 𝑘𝑊ℎ)($0.1550/𝑘𝑊ℎ) = $1.86


#### 113.3 – Power and forces

**Consider: How do forces relate to power?**

In Unit 110, we introduced the infinitesimal piece of work done by a force, 𝐹[⃗], acting over a displacement, 𝑑𝑥⃗ as

𝑑𝑊= 𝐹[⃗] ⋅𝑑𝑥⃗. (113-7)

Please note that in Unit 110, we defined the work as the integral of this equation; however, for the time being we only care
about the tiny bit of work done over a very small displacement. Above, in Section 113.1, we learned that power is the time
rate of change of energy, which in this case would be the rate at which work is done by/performed on the object or system:

𝑃= [𝑑𝑊] [𝑑] (113-8)

𝑑𝑡 [=] 𝑑𝑡 [�𝐹⃗⋅𝑑𝑥⃗�.]

If we assume that the time over which the force acts over the displacement is small enough so that the force is constant over
that time, we can remove the force from the time derivative, leaving us with

𝑃= 𝐹[⃗] ⋅ [𝑑𝑥⃗] (113-9)

𝑑𝑡 [= 𝐹⃗∙𝑣⃗,]


where I have used the fact that velocity is the derivative of displacement with respect to time.
Equation 113-9 defines the relationship between power and force; however, we must be careful that both the force and
velocity are approximately constant over the time interval for which we are finding the power.


-----

**Power**

𝑷= 𝑭[��⃗] ∙𝒗��⃗

**Description – This equation relates how much energy per**

second (power) is transformed as a specific force, 𝐹[⃗], acts
on an object moving with velocity, 𝑣⃗.
**Note: 𝐹[⃗] must be constant over the time interval used for the**

equation to hold.


The relationship we just found between force and power can be very important, when, for example, you know that a
certain force is required to keep a system moving at a certain velocity. IN this case, Equation 113-9 allows you to find the
energy per second (power) required to keep the system constant.
Consider riding a bike: When cruising on a flat surface, we must continue to add energy mechanical energy to the system
(from the chemical energy in our bodies) in order to maintain speed. We will later study why air resistance and rolling
friction remove mechanical energy from the bike. Regardless of the reason, however, we know that we have to maintain a
force on the bike to keep it moving at the given speed. For example, if you must exert an average force of 100 N to keep a
bike rolling at 8 m/s (18 mph)

𝑃= 𝐹[⃗] ∙𝑣⃗= (100 𝑁)(8 𝑚𝑠⁄ ) = 800 𝑊. (113-9)

In this quick example, we did not have to worry about the directions and the dot product since the force and velocity are
parallel to each other. Remember that the dot product is a measure of how parallel two vectors are to each other and includes
a cosine of the angle between the vectors (and cos 0 = 1 in this case).


Example 113 - 4 **Elevator power**

An elevator car with a weight of 12,000 N and carrying
passengers totaling 2,500 N needs to ascend at 2.5 m/s. How
much power is must be delivered by the elevator’s motors if
(a) the elevator system is essentially frictionless and (b) if the
system must overcome a constant friction force of 3 000 N?

**Solution:**

This problem asks us to find the power that must be delivered
by a motor given a force and velocity that must be
maintained.

(a) If there is no friction in the system, the motor must only
overcome the combined weight of the system,

𝐹�,����� = 12,000 𝑁+ 2500 𝑁= 14,500 𝑁.

The power that must be delivered by this motor is then given
by the power from force and velocity equation

𝑃= 𝐹[⃗] ∙𝑣⃗= �𝐹[⃗]�|𝑣⃗| cos 𝜃.

Since the force needed to lift the elevator is in the same
direction as the velocity of the elevator, we can write


𝑃= 𝐹[⃗] ∙𝑣⃗= (14,500 𝑁)(2.5 𝑚𝑠⁄ )(cos 0°),

or

𝑷= 𝟑𝟔, 𝟐𝟓𝟎 𝑾.

(b) Any friction in the system will add to the force that
must be exerted by the motor in order to lift the elevator.
Later in the course, we will discuss how to deal with
accelerations, but for now, we will assume that the
elevator is ascending at constant speed. The force the
motor must exert will be the sum of the weight of the
system and the friction,

𝐹����� = 14,500 𝑁+ 3,000 𝑁= 17,500 𝑁.

The power delivered by the motor is found in a similar
fasion to part a above:

𝑃= 𝐹[⃗] ∙𝑣⃗.

Using the force value including friction gives us

𝑃= (17,500 𝑁)(2.5 𝑚𝑠⁄ )(cos 0°) = 𝟒𝟑, 𝟕𝟓𝟎 𝑾.


-----

Example 113 - 5 **Bicycle power again**

A bicyclist must exert an average forward force of 30 N to
maintain a 10 m/s speed. Assuming an efficiency of 15%,
how much energy will this bicyclist release during a 30minute ride?

**Solution:**

This problem asks us to relate force and speed to energy used
in a given time. In order to do this, we will find the power
produced by the bicyclist and then find the overall energy
using the time and efficiency of the process.
First, we can find the average power exerted by the
bicyclist (noting that the average force and velocity are in the
same direction) as

𝑃= 𝐹[⃗] ∙𝑣⃗= (30 𝑁)(10 𝑚𝑠⁄ )(cos 0°) = 300 𝑊.

Thirty minutes is equivalent to 1800 seconds, therefore, we
can find the mechanical energy released over this time as


𝑊���� = 𝑃∆𝑡= (300 𝑊)(1800 𝑠) = 5.4 𝑥 10[�]𝐽.

Now, if we use the 15% efficiency, the chemical energy
used in the body for this process is

𝑊���� = [𝑊]0.15 [����] [= 5.4 𝑥 10]0.15 [�][𝐽] = 3.6 𝑥 10[�]𝐽.


Finally, we can convert this to Calories to find

𝑊���� = 3.6 𝑥 10[�]𝐽 4186 𝐽[1 𝐶𝑎𝑙] [= 860 𝐶𝑎𝑙.]

As you can see, bicycling in this fashion consumes a
number of Calories. Keep in mind, however, that the
average speed of the bicycle in this problem is 22 mph
for 30 minutes – not a leisurely ride.


-----

