### – Conservation of Angular Momentum
## 118


_The angular momentum of an isolated system is conserved in a similar fashion to linear momentum. This can allow us to_
_solve problems in which a system of particles changes shapes, or in the collision of rotating objects. In addition, the_
_conservation of angular momentum can be combined with the conservation of momentum to solve even more complex_
_collision problems._

###### The Bare Essentials

- For angular momentum, an isolated system is one for which

there is no net external torque:

𝑑𝐿[�⃗]���

𝑑𝑡 = 𝜏⃗��� = 0   →    𝐿[�⃗]��� = 𝑐𝑜𝑛𝑠𝑡𝑎𝑛𝑡

- Like linear momentum, the angular momentum of an isolated

system is conserved.


**Conservation of Angular Momentum**

𝚫𝑳[��⃗]𝒔𝒚𝒔 = 𝟎

**Description – This equation defines the conservation of**

angular momentum by saying that the change in angular
momentum of an isolated system () must be zero.
**Note: ∆𝐿[�⃗]���** = ∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ⋯, for as many objects

are in the system.



- Most collisions of extended objects involve conservation of

linear and angular momentum.

- Gyroscopes use the conservation of angular momentum to

provide stability to many systems. Gyroscopes are designed to
have three perpendicular axes that are free to rotate freely
relative to each other – a spin axis and two gimbal axes.

- Gyroscopes can be used for ship stability and guidance, angle

measurement and precise position and orientation
measurements.


-----

##### 118-1 – The conservation of angular momentum

**Consider: Is there a similar conservation law for angular momentum as**
there is for linear momentum?

UST AS WITH LINEAR MOMENTUM, THE real power of angular momentum comes from that fact that it is
_conserved for an isolated system. In fact, when dealing with angular momentum, we had to neglect any apparent_
changes in rotation since we did not know how to deal with them. Think of it this way – if you roll a ball towards a

# J

meter stick, if the ball collides with the stick anywhere besides the stick’s center of mass, the stick will start to rotate about its
center of mass and the center of mass of the stick will also begin to move linearly. We can deal with both parts of this
motion by considering the conservation of linear and angular momentum, respectively.
In this first part of the unit, we consider only the conservation of angular momentum – that is, we will concern ourselves
with situations in which we do not have to worry about the conservation of linear momentum. A perfect example of this
situation is when a figure skater begins a slow turn with his or her arms outstretched. As the arms of the skater are pulled in
towards the body, the rotational speed of the skater increases. Although this seems like it would be a violation of the
conservation of energy, what is happening here is that when the skater pulls in his or her arms, the moment of inertia of the
system is changing and therefore the rotational speed must change to compensate.
We will now look at this situation in more detail. Consider that the skater initially must have a momentum of inertia
given by 𝐼� and rotates with an angular speed 𝜔�. We can then write the magnitude of the angular momentum of the skater as

L� = 𝐼�𝜔�. (118-1)

At some later time, we can similarly write the angular momentum of the skater in terms of his or her final moment of inertia
and angular velocity

L� = 𝐼�𝜔�. (118-2)

The conservation of angular momentum would suggest that the initial angular momentum of the system be equal to the final
angular momentum, which gives us

𝐿� = L� → 𝐼�𝜔� = 𝐼�𝜔�. (118-3)

solving for the final rotation speed, we find
𝜔� = 𝐼[𝐼][�]� 𝜔�. (118-4)

Finally, we can interpret the situation. Since the moment of inertia is a measure of how far the average particles that make up
an object are from the axis of rotation, the initial moment of inertia of the skater must be larger than the final moment of
inertia, since as the skater’s arms are pulled in, all of the particles that make up an arm get closer to the axis of rotation.
Therefore, Equation 118-3 tells us that if 𝐼� < 𝐼� then 𝜔� must be greater than 𝜔�, and we have the solution that the angular
speed of the skater increases as arms are drawn in.
We can now take this very qualitative description and make it more quantitative. In general, the conservation of angular
momentum would say
∆𝐿[�⃗] = 0, (118-5)

where ∆𝐿[�⃗] = 𝐿� −𝐿� is the difference between the final and angular momentum of the system, which can be made up of many
objects. Therefore, we can expand this definition to

∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ⋯= 0, (118-6)

where the subscripts represent all possible objects in the system. Note that in our discussion above, we used a system where
there were no external torques acting on the system. In general, this is the definition of an isolated system in regards to the
conservation of angular momentum. Consider the relationship between angular momentum and torque in this situation,

𝑑𝐿[�⃗]𝑑𝑡��� = 𝜏⃗��� = 0 → 𝐿[�⃗]��� = 𝑐𝑜𝑛𝑠𝑡𝑎𝑛𝑡. (118-7)


-----

**Conservation of Angular Momentum**

𝚫𝑳[��⃗]𝒔𝒚𝒔 = 𝟎

**Description – This equation defines the conservation of**

angular momentum by saying that the change in angular
momentum of an isolated system () must be zero.
**Note: ∆𝐿[�⃗]���** = ∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ∆𝐿[�⃗]� + ⋯, for as many objects

are in the system.


Remember that we have two basic forms for writing the angular momentum of a body, one for rotating extended bodies and
one for objects moving linearly relative to some rotational axis,

𝐿[�⃗] = 𝐼𝜔��⃗ and    𝐿[�⃗] = 𝑟⃗𝑥𝑝⃗, (118-8)

respectively. The following examples will help give you an idea of how to use both forms of the angular momentum in the
conservation equations.


Example 118 - 1 **A disk and a hoop**

A disk with mass, 𝑚= 22 𝑘𝑔, and radius, 𝑟= 12𝑐𝑚, is
rotating with at a rate of 7.6 𝑟𝑎𝑑/𝑠 around a vertical axis
directly through its center and perpendicular to the surface of
the disk. If a non-rotating hoop with radius 10 cm and a mass
of 11 kg is dropped onto the rotating disk and eventually
rotates with the disk due to friction, what is the final angular
speed of the system?

**Solution:**

This is a conservation of angular momentum problem for two
objects. As such, we can start with our general equation for
the conservation of angular momentum.

∆𝐿� + ∆𝐿� = 0,

where I have neglected the vector symbols since the objects
share the same axis of rotation and geometrical orientation
(vertical). By including the initial and final states, we can
write the conservation equation as

𝐿�,� −𝐿�,� + 𝐿�,� −𝐿�,� = 0.

Since the initial angular speed of the disk is zero, we can
simplify this equation to

𝐿�,� −𝐿�,� + 𝐿�,� = 0.

The moment of inertia of our disk is given by

𝐼= [1] �,

2 [𝑀][�][𝑅][�]


Where the subscript 𝑑 represents the disk. Similarly, the
moment of inertia of the hoop is

𝐼= 𝑀�𝑅��,

Using these moments of inertial, we can write the
conservation of angular momentum as


1
2 [𝑀][�][𝑅][�]�𝜔� − [1]2 [𝑀][�][𝑅][�]�𝜔� + 𝑀�𝑅��𝜔� = 0.


Solving for the final angular speed gives us

𝑀�𝑅��
𝜔� = � � [𝜔][�][.]

𝑀�𝑅� + 2𝑀�𝑅�


Using our known values, we find


𝜔� =


(22𝑘𝑔)(0.12𝑚)[�]

(22𝑘𝑔)(0.12𝑚)[�] + 2(11𝑘𝑔)(0.10𝑚)[�] [�7.6 𝑟𝑎𝑑]𝑠 [�,]


which simplifies to

𝜔� = 4.5 𝑟𝑎𝑑/𝑠.

The final angular speed is lower than the initial angular
speed, which makes sense since we have a larger
momentum of inertia after the collision of the disk and
hoop.


-----

Example 118 - 2 **The running kid**

A child runs towards the edge of a merry go round, jumps on,
and hangs on to the side so that he sits on the edge. The
merry go round has a diameter of 4.8 m and a mass of 87 kg,
and was rotating at 1.4 rad/s before the kid jumped on. If the
kid has a mass of 30 kg and was running at 4.2 m/s before the
collision along a line tangent to the edge of the merry go
round, what is the final angular speed of the system? At the
time of impact, the kid is moving in the same direction as the
merry go round at that point.

**Solution:**

This is a conservation of angular momentum problem which
contains both a rotating rigid body as well as angular
momentum of a linearly moving object (the kid). Since all of
the motion in this problem happens in a plane, we can neglect
the vector nature of angular momentum, and only worry about
whether the objects are rotating in the same direction or
opposite directions. Solving this is a matter of using the
conservation of angular momentum for two bodies:

𝐿�,� −𝐿�,� + 𝐿�,� −𝐿�,� = 0,

where I'll call object 1 the merry go round and object 2 the
kid. For the merry go round, we can use the rotating rigid
body angular momentum equation with the moment of inertia
of a disk, giving us

𝐿�,� −𝐿�,� = [1]2 [𝑀][�][𝑅][�]�𝜔� − [1]2 [𝑀][�][𝑅][�]�𝜔�.


about the center of the merry go round. For the initial
situation, we use the angular momentum of a particle
moving relative to an axis, noting that the angle between
the radius vector and the velocity is 90°,

|𝑟⃗ 𝑥 𝑝⃗| = |𝑟⃗||𝑝⃗| sin 90° = 𝑅�𝑝�.

For the final situation, we can use that the kid acts as a
point particle at the edge of the merry go round.
Therefore, the change in angular momentum of the kid is

𝐿�,� −𝐿�,� = 𝑀�𝑅��𝜔� −𝑅�𝑝�,

Note that the final angular speed of the two objects is the
same since they stick together. Putting this all together
and solving for the final angular speed gives us


𝜔� =


𝑅�𝑝� + [1]2 [𝑀][�][𝑅][�]�𝜔�

1 � � [.]
2 [𝑀][�][𝑅][�] + 𝑀�𝑅�


The kid gives us an interesting situation where initially she is
running in a straight line, but after the collision she is rotating


Of course, the initial momentum of the kid, 𝑝� can be
found using 𝑝� = 𝑚�𝑣�. Using the values from the
problem, we get

𝜔� = 1.54 [𝑟𝑎𝑑]𝑠 [.]

Note that the symbolic equation for the final angular
speed can also be viewed as the total angular momentum
of the system divided by the total moment of inertia of
the system after the collision.


##### 118-2 – The conservation of angular momentum and linear momentum

**Consider: Can linear and angular momentum be conserved at the same**
time?

Collision problems between extended objects conserve both linear and angular momentum. Up to this point we have not
considered angular momentum problems where the center of mass of the system is unconstrained. For example, in example
problem 118-2 above, although the angular momentum is conserved because there are no external torques, linear momentum
is not conserved because there is an external force on the merry go round where it attaches to the ground. When considering
a problem that is isolated in terms of both external forces and external torques, we can use both conservation equations
simultaneously

∆𝐿[�⃗] = 0 and  ∆𝑝⃗= 0, (118-9)

For many of the problems that use both conservation laws, the problem comes down to essentially solving the linear and
angular momentum parts separately. Unfortunately the same lack of constraint that allows us to use both laws at the same
time also removes the ability to relate angular and linear variables (such as with rolling without slipping). The following
example shows how to deal with this quantitatively.


-----

Example 118 - 3 **A meter stick and clay**

Imagine a meter stick is laying horizontally on a table at rest.
A piece of clay is rolled towards the ruler such that the
direction of the clay’s velocity is perpendicular to the length
of the ruler. If the clay and ruler stick together after colliding,
describe the motion of the system. For this problem, the ruler
has a mass of 200 grams, and the clay has a mass of 200
grams and it is initially moving with a speed of 1.2 m/s.

**Solution:**

This is a problem that combines the conservation of linear
momentum and angular momentum, since there are no
external forces or torques affecting the motion of the table.
We must take conservation of angular momentum into
account because the clay initially has momentum that is not
directed to the center of mass of the ruler/clay system. We
can first determine the linear motion following the collision
by using the equation for a perfectly inelastic collision,

𝑚�𝑣� + 𝑚�𝑣� = (𝑚� + 𝑚�)𝑣�.

For this problem I will define object 1 as the stick and object
2 as the clay. Noting that the meter stick was initially at rest,
the final velocity can be written


𝑣� = 0.60 [𝑚]𝑠 [.]

We can calculate the final angular velocity of the system
in a similar fashion to other angular momentum problems
in this unit. First, we note that since the entire motion of
the system occurs in a plane, we do not have to worry
about the vector nature of angular momentum. This then
becomes a two body angular collision as we have seen
before

𝐿�,� −𝐿�,� + 𝐿�,� −𝐿�,� = 0,

where I will set object 1 as the ruler and object 2 as the
clay. The solution to this problem is very similar to
example 118-2, except that this initial angular speed of
the ruler is zero and the moment of inertia a of the ruler is
that of a rod rotating about its center. Therefore, the
conservation of angular momentum becomes


𝜔� −�[1]2 [𝐿�𝑚][�][𝑣][�] [= 0,]


1
12 [𝑀][�][𝐿][�][𝜔][�] [−0 + 𝑚][�] [�1]2 [𝐿�]


�


or


𝑚�
𝑣� = 𝑚� + 𝑚�


1
2 [𝐿𝑚][�][𝑣][�]

1
12 [𝑀][�][𝐿][�] [+ 𝑚][�] [�][1]2 [𝐿�]


�[.]


𝑣�.


𝜔� =


Using values given in the problem, this is


Using numbers from the problem, we find

𝜔� = 1.8 𝑟𝑎𝑑/𝑠.


##### 118-3 – Gyroscopes and rotational stability

**Consider: How can the conservation of angular momentum be used in**
real life?

Since angular momentum is a vector, the conservation of angular
momentum suggests that both the magnitude and direction should be
maintained. You may have asked – “why does it seem to be easier to
stay upright on a bicycle when you are moving than when you are at
rest?” The answer to this question lies, in part, with the conservation of
momentum.
When your bicycle is at rest, the wheels do not have angular
momentum about the center of each wheel. However, when the bike is
moving and the wheels are spinning, each wheel does maintain angular
momentum. Any attempt to change the direction of angular momentum
(such as tipping to one side) requires a torque in the correct direction,
which is not created by gravity.
Another object where you can see the conservation of angular
momentum in play is a gyroscope, as shown in Figure 118-1. Although **Figure 118-1. Diagram of a three-dimensional**
designs certainly vary some, all standard 3-D gyroscopes allow for **gyroscope.**
rotation along any of three perpendicular axes. In the gyroscope


-----

pictured in Figure 118-1, the three axes are created by

1) a spinning disk, with the axis of rotation perpendicular to the plane of a rotating disk (rotor). This is known as the

spin axis.
2) two gimbals, which are rings with rotational axes perpendicular to the spin axis and perpendicular to each other.
3) a frame, which holds the entire system on a stand.

By the conservation of angular momentum, the direction of the spin axis will tend to remain constant, even if any or all of the
other axes move around. As a quick example, if the entire gyroscope were to be placed in the bed of a pickup truck with the
rotor spinning and the spin axis pointed vertically, and then the truck were to drive up a hill, you would find that the spin axis
would still be vertical and the gimbals would have rotated to allow this to happen.

**Stability**
Large gyroscopes can be used for ship stability. When a spinning gyroscope is on a ship in rolling seas, the spin axis
will tend to stay aligned with its original orientation. Mechanical servos can be used to keep the ship aligned with the axis of
rotation of the gyroscope as opposed to aligned with the surface of the water (which continues to change as waves sweep by).
In this way, gyroscopes can add to the stability of the ship. Cruise ships have used gyroscopes for stability for quite a few
years.

**Angle Measurement**
If the spin axis of a gyroscope is defined to be 0° in some system, then the angle of each gimbal relative to the spin axis
can give a very precise measurement of angle deviation. The example of a truck driving up a hill above is one example of
angle measurement via gyroscopes.

**Consumer Electronics**
Gyroscopes are used today in many consumer electronics including the iPhone 5s, Wii Motion Plus controllers and the
Samsung Galaxy Note series. In such electronics, gyroscopes are combined with accelerometers (direct measures of
acceleration) to give very precise measurements of angle relative to vertical.


-----

