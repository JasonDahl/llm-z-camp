### – Energy and Forces
## 110


_Unit 110 introduces some relationships between forces and energy transfer. Along the way, we will define work as the_
_transfer of mechanical energy and determine whether or not energy transferred to/from a system can be recovered._


##### The Bare Essentials

- A force describes a push or pull on an object. The force on an

object is related to the spatial rate of change of the potential
energy of the object.



- **_Work is a measure of how much mechanical energy is_**

_transferred into or out of a system as a force acts over a_
displacement (conservative) or distance (non-conservative).


**Force from Potential Energy**

𝑭𝒙,𝒂𝒗𝒆 = − [𝚫𝑼]𝚫𝒙

**Description – This equation relates how a an average**

component of force along the x-axis, 𝐹�,���, arises from
a change in potential energy, ∆𝑈, which varies in space.
**Note: This equation can be used for any dimension, but it**

must be used for one-dimensional motion.


**Mechanical Work (constant force)**

𝑾= 𝑭[��⃗] ∙𝒅[��⃗]

**Description – This equation describes the work, 𝑊, done**

by a constant force, 𝐹[⃗], over a displacement, 𝑑[⃗].



- Regions on a potential energy graph where the force (position

rate of change of potential energy) is zero are called
**_equilibrium positions. If the potential energy is at a minimum_**
this is a stable equilibrium. If the potential energy is at a
maximum it is an unstable equilibrium.

- The dot product or scalar product is a vector multiplication

that relates components of two vectors which are parallel to
each other.


**Mechanical Work (non-constant force)**

𝒃

𝑾= �𝑭[��⃗] ⋅𝒅𝒙��⃗

𝒂

**Description – This equation describes the work, 𝑊, done**

by a force, 𝐹[⃗], over a small displacement, 𝑑𝑥⃗.
**Note: 𝑎 and 𝑏 represent initial and final positions of the**

displacement.


**Scalar (dot) Product**

𝒂��⃗⋅𝒃[��⃗] = 𝒂𝒙𝒃𝒙 + 𝒂𝒚𝒃𝒚 + 𝒂𝒛𝒃𝒛

𝒂��⃗⋅𝒃[��⃗] = |𝒂��⃗|�𝒃[��⃗]� 𝒄𝒐𝒔 𝜽

**Description – These equations define the dot product of**

two vectors, 𝑎⃗ and 𝑏[�⃗].
**Note 1: The first version of the dot product is often used if**

you know the components of the vectors and the second
version is often used if you know the magnitude of the
vectors and the angle between them.
**Note 2: Combining the first and second versions of the dot**

product allows you to find the angle between two
vectors.



- **_Note: Work is not energy itself, but is a measure of how much_**

mechanical energy is transferred.
_-_ **_Positive work on a system represents energy transferred_**
_into the system. Negative work on a system represents_
energy transferred out of a system.
_-_ **_Positive work by a system represents energy transferred_**
_out of the system. Negative work by the system_
represents energy transferred into the system.

- The work due to a conservative force is independent of the

path taken in calculating the work done. A conservative force
is dependent only on the position of the object. Work due to a
conservative force can be stored as potential energy

- The work due to a non-conservative force depends on the

path used in calculating the work. Work due to nonconservative forces often leads to mechanical energy loss that
cannot be recovered (work due to friction for example).


-----

#### 110-1. Force


**Consider: What is a force?**

E HAVE ALLUDED TO THE IDEA OF forces throughout the course without giving a very precise definition.  It
is true that the colloquial idea of a force as a push or pull is very accurate; however, this definition does not allow
us to do much with it. Although we will not be able to precisely define a force until we study momentum in Unit

# W

114, we can make the definition a bit tighter at this point by saying that a force is the result of an interaction that, on its own,
tends to change the motion of an object. Notice that this definition says “on its own.” Just as we had offsetting interactions
in unit 102, we can also have offsetting forces so that the motion of an object doesn’t change even though multiple forces
may be working to change the motion independently.
In this unit, we are going to look closely at how forces are related to energy – specifically how are forces related to
_changes in energy. It turns out that if an object is in a potential field that varies in space, there is a force on an object. This is_
exactly what happens when you drop a ball from your hand – since the gravitational potential energy of the ball is a function
of height, i.e., it changes with height, there is a force on the ball. On the flip side, if we make or allow a force to act over a
distance, that force will cause a change in energy of the object. This is the goal of Unit 110: to see how changes in energy
lead to or are caused by forces.

#### 110-2. Potential energy and forces

**Consider: How does a change in potential energy lead to a force?**

Any potential energy field that is not constant in space will push or pull on an object placed in that field. Put another way,
when the potential energy of an object depends on position, there will be a force on the object due to the interaction creating
the potential energy. In order to see this, let’s look at two examples that will fit with your intuition – gravity and springs.
In Unit 106, we saw that the gravitational potential energy of a mass near the surface of the earth is given by 𝑚𝑔ℎ.
Using the notation we have defined earlier in the text, the height of an object is really the z-component of the position above
a reference point, so we can write
𝑈� = 𝑚𝑔ℎ= 𝑚𝑔𝑧, (110-1)


where 𝑚 is the mass of the object, 𝑔 is the gravitational field strength of 100
the earth and 𝑧 is the height of the object above our reference point
(which is completely arbitrary). Now, we all know what happens if you 80
hold, say, a ball in the air and simply let it go – it falls towards the

60

earth. Consider Figure 110-1, which shows a plot of the gravitational
potential energy as a function of height. As you can see, this plot is a 40
straight line sloping upward (positive slope of 𝑚𝑔 in fact). So,
although the potential energy is increasing as height increases, the force 20
on the ball if released would be negative. It turns out that this is a

0

general feature of the relationship between potential energy and force. 0 2 4 6 8 10
In fact, it turns out that the magnitude of the average force is given by **Height (m)**
the average slope of the potential energy curve.  Putting these two ideas

**Figure 110-1. Gravitational potential energy of a**

together, we see **1-kg ball as a function of height.**
𝐹�,��� = − [∆𝑈]∆𝑧 [.] (110-2)

For our specific example of the gravitational potential energy near the surface of the earth we can first note that a change in
height is really a change in the z-component of the gravitational potential energy. We can then simplify

𝐹�,��� = − [∆(𝑚𝑔𝑧)]∆𝑧 = − [𝑚𝑔∆𝑧]∆𝑧 = −𝑚𝑔. (110-3)

Note that this force has all the attributes we just talked about. The force is represented by the slope of the potential energy
**_graph with the opposite sign._**
Although we just used the familiar gravitational potential energy to relate energy to force, this general process works for
all potential energies. It also works for any dimension so that


-----

𝐹�,��� = − [∆𝑈]∆𝑥 [,] 𝐹�,��� = − [∆𝑈]∆𝑦 [,] 𝐹�,��� = − [∆𝑈]∆𝑧 [.] (110-4)

Again, please note that these are for **_average forces._** **Important note:** **_Using the average force equation only works for_**
**_differences in position along one axis._**


**Force from Potential Energy**

𝑭𝒙,𝒂𝒗𝒆 = − [𝚫𝑼]𝚫𝒙

**Description – This equation relates how a an average**

component of force along the x-axis, 𝐹�,���, arises from
a change in potential energy, ∆𝑈, which varies in space.
**Note: This equation can be used for any dimension, but it**

must be used for one-dimensional motion.


**_Tip: Don’t forget the minus sign! This is a very common mistake when finding force_**
**_from potential energy which can give you a very wrong answer._**

The force at a specific point in space (instantaneous force) is hard to find. Just as we did with velocities, we can think
about what happens as ∆𝑥, ∆𝑦 and ∆𝑧 become very small, that is turning our difference equations above into derivatives. We
did this when considering how to move from average velocities to instantaneous velocities earlier in the course. In that case,
our differences with respect to time became derivatives; however, we have a problem – the derivatives in this energy case
need to happen over three dimensions, not just one.
In vector calculus, we introduce the term 𝜕𝑈𝜕𝑥⁄ to represent the partial derivative of 𝑈 with respect to x. When taking
a partial derivative, you treat the symbol in the denominator as the only variable (that is, treat all other variables as constants)
and take the derivative as you normally would. Therefore, each term in equation 110-4 would require a separate derivative,
which could then be combined into a vector as

𝐹[⃗] = −�𝐹�, 𝐹�, 𝐹��= −�[𝜕𝑈]𝜕𝑥 [, 𝜕𝑈]𝜕𝑦 [, 𝜕𝑈]𝜕𝑧 [�,] (110-6)

.

I show the full calculus-based version of this relationship for your information. We will not require you to do multidimensional derivatives in Physics I.


Example 110 - 1  Finding the force.

Suppose an object moves 2.3 m along the positive x-axis. If
the initial and final potential energy of the object are
measured to be 21 𝐽 and 17 𝐽, respectively, what is the
average force on the object during this period?

**Solution:**

This problem asks us to use changes in potential energy to
determine the average force on an object. We know that

𝐹�,��� = − [∆𝑈]∆𝑥 [= −𝑈][�]∆𝑥[−𝑈][�].


Since we know all of the values in this equation, we find

𝐹�,��� = − [17 𝐽−21 𝐽]2.3 𝑚 = 0.17 𝑁.

Therefore, we know that the 𝑥-component of the force on
the object is 0.17 𝑁. Therefore, we can write the vector
forces as

𝐹��� = [0.17, 0, 0] 𝑁.

Again, note that even though the change in potential
energy was negative, the average force is positive!


-----

#### 110-3. Scalar (dot) products

**Consider: How can I measure how parallel two vectors are relative to**
each other?

In Section 104.5 we briefly introduced the scalar product of two vectors. This type of multiplication is named after the fact
that you start with two vectors and at the end of the multiplication, the result is a scalar. The scalar product is denoted as the
two vectors with a dot in between them; the scalar product of a vector 𝐴[⃗] and vector 𝐵[�⃗] is

𝐶[⃗] = 𝐴[⃗] ∙𝐵[�⃗], (110-7)

which gives rise to the alternate name dot product for the scalar product.
**_The scalar product of two vectors is a measure of how parallel the vectors are_**
**_relative to each other.  Figure 110-2 shows two vectors separated by an angle_** 𝜃. In
order to find the scalar product of these two vectors, we first find the component of one
vector along the second vector, which is given by

𝐴� = 𝐴cos 𝜃, (110-8)


This component is then multiplied by the magnitude of the second vector, so

𝐴[⃗] ∙𝐵[�⃗] = �𝐴[⃗]��𝐵[�⃗]�cos 𝜃. (110-9)

A couple of notes:


**Figure 110-2. Finding the scalar**
**product of 𝑨[��⃗] and 𝑩[��⃗].**


1) If A[��⃗] and B[��⃗] are parallel to each other (cos 0° = 1), then A[��⃗] ∙B[��⃗] = �A[��⃗]��B[��⃗]�,
2) If A[��⃗] and B[��⃗] are perpendicular to each other (cos 90° = 0), then A[��⃗] ∙B[��⃗] = 0,
3) If A[��⃗] and B[��⃗] are anti-parallel to each other (cos 180° = −1), then A[��⃗] ∙B[��⃗] = −�A[��⃗]��B[��⃗]�.

The scalar product can also be thought of in terms of the components of each vector. Imagine we start with two vectors

𝐴[⃗] = 𝐴�𝑥�+ 𝐴�𝑦�+ 𝐴�𝑧̂   and   𝐵[�⃗] = 𝐵�𝑥�+ 𝐵�𝑦�+ 𝐵�𝑧̂.

We can treat each of these vectors of the sum of three vectors, one along each axis. In this case, the scalar product of 𝐴�𝑥�
with 𝐵[�⃗] will yield only 𝐴�𝐵� since 𝐴� is parallel to 𝐵�, but perpendicular to the other components of 𝐵[�⃗]. The same reasoning
can be used for the other components of 𝐴[⃗], so that we find overall

𝐴[⃗] ∙𝐵[�⃗] = 𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵�. (110-10)

In practice, you can use whichever form makes sense for a given problem (either equation 110-9 or 110-10). If we combine
these two definitions, you can also use the scalar product to find the angle between two vectors since

𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵� = �𝐴[⃗]��𝐵[�⃗]�cos 𝜃. (110-11)

Many of the standard mathematical properties hold true for the scalar product such as

_-_ **_distributive property: 𝐴[⃗]_** ∙�𝐵[�⃗] + 𝐶[⃗]�= 𝐴[⃗] ∙𝐵[�⃗] + 𝐴[⃗] ∙𝐶[⃗]

_-_ **_commutative property: 𝐴[⃗]_** ∙𝐵[�⃗] = 𝐵[�⃗] ∙ 𝐴[⃗]

_-_ **_homogeneous scaling: 𝑐�𝐴[⃗]_** ∙𝐵[�⃗]�= �𝑐𝐴[⃗]�∙𝐵[�⃗] = 𝐴[⃗] ∙�𝑐𝐵[�⃗]�


-----

**Scalar (dot) Product**

𝒂��⃗⋅𝒃[��⃗] = 𝒂𝒙𝒃𝒙 + 𝒂𝒚𝒃𝒚 + 𝒂𝒛𝒃𝒛

𝒂��⃗⋅𝒃[��⃗] = |𝒂��⃗|�𝒃[��⃗]� 𝒄𝒐𝒔 𝜽

**Description – These equations define the dot product of**

two vectors, 𝑎⃗ and 𝑏[�⃗].
**Note 1: The first version of the dot product is often used if**

you know the components of the vectors and the second
version is often used if you know the magnitude of the
vectors and the angle between them.
**Note 2: Combining the first and second versions of the dot**

product allows you to find the angle between two
vectors.


Example 110 - 3 **Scalar product with angle**

Two vectors, with magnitudes �𝑆[⃗]�= 4.2 𝑚 and �𝑇[�⃗]�= 1.9 𝑚.
The vector 𝑆[⃗] is directed along the positive x-axis, while 𝑇[�⃗]
makes an angle of 30° clockwise from the positive y-axis
towards the positive x-axis in the xy plane. What is the scalar
product of 𝑆[⃗] and 𝑇[�⃗]?

**Solution:**

This problem asks us to find the scalar product of two vectors
where we know the magnitudes of the vectors and the angles


between them.
Since 𝑇[�⃗] makes an angle of 30° with the y-axis, it
makes and angle of 60° with the x-axis. This is
important, since 𝑆[⃗] is along the x-axis and we need the
angle between the two vectors. Therefore

𝑆[⃗] ∙𝑇[�⃗] = �𝑆[⃗]��𝑇[�⃗]�cos 𝜃= (4.2 𝑚)(1.9 𝑚) cos 60°,

Which simplifies to 𝑆[⃗] ∙𝑇[�⃗] = 4.0 𝑚[�].


Example 110 - 4 **Scalar product with components**

Find the scalar product of the two vectors,

𝐴[⃗] = 12𝚤̂ −7.5𝚥̂ + 3.3𝑘[�],
and

𝐵[�⃗] = −2.5𝚤̂ + 2.5𝚥̂ + 2.5𝑘[�].

**Solution:**

This problem asks us to find the scalar product of two vectors
given in unit vector notation. We will directly use 110-10,


𝐴[⃗] ∙𝐵[�⃗] = 𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵�.

Substituting known values into this equation, we find

𝐴[⃗] ∙𝐵[�⃗] = (12)(−2.5) + (−7.5)(2.5) + (3.3)(2.5),

which simplifies to

𝐴[⃗] ∙𝐵[�⃗] = −40.5


Extension:  Approximate directions

The fact that the dot product, 𝐴[⃗] ∙𝐵[�⃗], above suggests that the
vectors point roughly in opposite directions. If the scalar
product of two vectors is positive, they roughly point in the
same direction. You can see this by considering the other


form of the scalar product: 𝐴[⃗] ∙𝐵[�⃗] = �𝐴[⃗]��𝐵[�⃗]�cos 𝜃; if 𝜃 (the
angle between the two vectors) is between 90° and 270°,
the result of the scalar product is negative.


-----

Example 110 - 5 **Finding the angle**

What is the angle between the vectors 𝐴[⃗] and 𝐵[�⃗] in example
110-4 above?

**Solution:**

This problem asks us to find the angle between two vectors.
We will do this by using both forms of the scalar product
(equations 110-9 and 110-10):

𝐴[⃗] ∙𝐵[�⃗] = �𝐴[⃗]��𝐵[�⃗]�cos 𝜃= 𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵�

Solving this equation for the angle gives us


𝜃= cos[��] �[𝐴][�][𝐵][�] [+ 𝐴][�][𝐵][�] [+ 𝐴][�][𝐵][�]

�𝐴[⃗]��𝐵[�⃗]�


�.


We must first note that we have already found the scalar
product of these two vector using the component form:

𝐴[⃗] ∙𝐵[�⃗] = 𝐴�𝐵� + 𝐴�𝐵� + 𝐴�𝐵� = −40.5.


In order to use the magnitude-angle form, we need to find
the magnitude of both 𝐴[⃗] and 𝐵[�⃗], as

�𝐴[⃗]�= �𝐴[�]� + 𝐴�[�] + 𝐴�[�] = 14.5,

�𝐵[�⃗]�= �𝐵�[�] + 𝐵�[�] + 𝐵�[�] = 4.33.

We can now put this together as

−40.5
𝜃= cos[��] �
(14.5)(4.33)[�= 130°.]

In the extension to Example 110-4, we suggested that the
angle of the two vectors should between 90° and 270°,
suggestion the vectors pointed in generally opposite
directions. Here, we found this angle to be exactly 130°.


#### 110-4. Mechanical work

**Consider: How does a force transfer energy into or out of system?**

The term work has many meanings in everyday life: you go to work in the morning; it takes work to hold up a baby; the
computer screen works today. In physics, however, work has a very specific meaning. To delineate the differences between
the everyday use of the word work and our meaning here, we will talk about mechanical work. Although it is very easy to
fall into the trap of calling this simply work (which may happen in this book!) try to keep the everyday meaning separate
from the physics meaning.
In physics, work is a measure of energy that a force adds to or
removes from a system. Consider pulling a small block across a table
at a constant speed as shown in Figure 110-3. In this figure, a force of
magnitude 𝐹 is applied to a box at an angle, 𝛼, to pull it across the floor
a distance, 𝑑. For each little bit of motion 𝑑𝑥, friction is removing
energy from the system, so the force must act to replenish this energy
to keep the box at a constant speed.

**Figure 110-3. Pulling a small box a distance d**
**across a table.**

Consider:

1) The vertical (z-component) of the force does not help us in terms of adding energy to the box, it only reduces the

force with which the box compresses the ground.
2) The horizontal (x-component) of the force does help maintain motion by adding energy to the system.

Therefore, we need only consider the component of the force parallel to the displacement (scalar product!). In addition,
either increasing the force or displacement would increase the amount of energy added to the box. Taking all of this into
consideration we define the mechanical work as the energy transferred into the system by our force as it acts over a
displacement, and write this as
𝑊= 𝐹[⃗] ∙𝑑[⃗]. (110-12)


-----

**Mechanical Work (constant force)**

𝑾= 𝑭[��⃗] ∙𝒅[��⃗]

**Description – This equation describes the work, 𝑊, done**

by a constant force, 𝐹[⃗], over a displacement, 𝑑[⃗].


**_Note: Mechanical work measures a transfer of energy. It is not an energy itself!_**

Figure 110-4 shows a force-displacement graph of our constant force F in Equation
110-12. Note that the mechanical work is the area under the force-displacement curve.
There are many situations (a spring for example) where the force is not constant
over a range of displacements. In this case, we break the motion up into very small
displacements, 𝑑𝑥⃗, over which the force is
approximately constant and add the contribution
(integral) of all of the small displacements.
This gives us a much more general equation for
the work performed by a force over a
displacement as


**Figure 110-4. Force-displacement**
**graph for a constant force. The**
**shaded area represents work.**


�

𝑊= �𝐹[⃗] ⋅𝑑𝑟⃗, (110-13)

�


where 𝑎 and 𝑏 represent the initial and final positions of the motion over which the
force acts. Figure 110-5 shows a hypothetical force-displacement graph for a nonconstant force similar to Figure 110-4.
Although equation 110-13 is the most general form of the equation for mechanical
work, keep in mind that you can immediately use equation 110-12 in any problem
when you know the force is constant and avoid having the evaluate the integral.


**Figure 110-5. Force-displacement**
**graph for a non-constant force. The**
**shaded area represents work.**


**Mechanical Work (non-constant force)**

𝒃

𝑾= �𝑭[��⃗] ⋅𝒅𝒓�⃗

𝒂

**Description – This equation describes the work, 𝑊, done**

by a force, 𝐹[⃗], over a small displacement, 𝑑𝑟⃗.
**Note: 𝑎 and 𝑏 represent initial and final positions of the**

displacement.


Example 110 - 6 **Works with magnitudes and angles**

If the magnitude of the force in Figure 110-3 is 112 N and the
displacement is 10.2 m, how much work is done by the force
at an angle of (a) 30° and (b) 60°?

**Solution:**

This problem asks us to use the definition of mechanical work
to determine the energy transferred by the force in Figure
110-3. For each part of the problem we will use Equation
110-12 for a constant force:


𝑊= 𝐹[⃗] ∙𝑑[⃗] = 𝑊= �𝐹[⃗]��𝑑[⃗]�cos 𝜃.

(a) Using the known values for the force and
displacement along with and angle of 30°, we get

𝑊= (112 𝑁)(10.2 𝑚) cos 30° = 989 𝐽.

(b) We solve this exactly the same as part (a), using an
angle of 60°:


-----

𝑊= (112 𝑁)(10.2 𝑚) cos 60° = 571 𝐽.

You can see that when the force and displacement are more
parallel, the force more effectively transfers energy into the
system.


As we just saw in this example, constant force problems
are relatively straightforward to solve if you know
magnitudes and angles. In the next example, we will see
that this is also true for constant forces when we know
vector components.


Example 110 - 7 **Work with magnitudes and angles**

Again consider Figure 110-3. If the force and displacement
are given by 𝐹[⃗] = [97, 56, 0] 𝑁 and 𝑑[⃗] = [10.2, 0, 0] 𝑚,
respectively, what is the work done by the force on the block
during the displacement?

**Solution:**

This problem asks us to find work using vector components
for force and displacement. Following Equation 110-10, we
can write

𝑊= 𝐹[⃗] ∙𝑑[⃗] = 𝐹�𝑑� + 𝐹�𝑑� + 𝐹�𝑑�.


Using the given values from the problem, we substitute to
find

𝑊= (97 𝑁)(10.2 𝑚) + (56𝑁 )(0) + (0)(0),

which gives us

𝑊= 989 𝐽.

Please note that this is the exact same problem as
Example 110-6(a), except that the force and displacement
were given as components as opposed to magnitudes!!


Example 110 - 8 **Work with non-constant forces**

A particle of mass 2.0 kg is acted on by a force

𝐹[⃗](𝑥, 𝑦) = 2𝑥[�]𝚤̂ + 4𝑥𝑦𝚥̂.

What is the work done by this force if the particle moves from
𝑥= 2.1 𝑚 to 𝑥 = 7.1 𝑚?

**Solution:**

This problem asks us to directly compute the work due to a
non-constant force. To do this we will use the equation

�


Note that both dy and dz are zero in this problem since
the entire motion is along the x-axis.
We can now substitute this into the integral for work
as

�

𝑊= �2𝑥[�]𝑑𝑥,

�

with 𝑎= 2.1 𝑚 and 𝑏= 7.1 𝑚. Completing the integral,
we find


𝑊= [2]

3 [𝑥][�][�]


�.��

�.��


= 232 𝐽.


𝑊= �𝐹[⃗] ⋅𝑑𝑟⃗

� Therefore, 232 J of energy is transferred into the system

by the force acting over the given displacement. Note

Our first step is to complete the scalar product inside of the that, in this region, the x-component of the force is
integral pointed towards the positive x-axis and the displacement

𝐹� 𝑑𝑥 2𝑥[�] 𝑑𝑥 was along the positive x-axis. Since these are parallel,

𝐹[⃗] ⋅𝑑𝑟⃗= �𝐹��∙�𝑑𝑦�= �4𝑥𝑦�∙� 0 �= 2𝑥[�]𝑑𝑥. energy is transferred into the system (positive work on

𝐹� 𝑑𝑧 0 0 the system).

We have to be careful when talking about mechanical work because we can discuss it in terms of work done on a system by a
force external to the system or we can talk about work done by the system on its environments. In either case, the work can
either be positive or negative (since the result of the scalar product can either be positive or negative.

For work done on a system:

  - Positive work on a system represents energy transferred into the system,

  - Negative work on a system represents energy transferred out of the system.


-----

For work done by a system:

  - Positive work by a system represents energy transferred out of the system,

  - Negative work by a system represents energy transferred into the system.

You can see how knowing if the work is on or by a system is important – the roles of positive and negative work are reversed
depending on the where the force starts. If the force creating work is produced in the system, it is work by the system. If the
force emanates from outside the system, it is work on the system.

#### 110-6. Net work

**Consider: How do you deal with work if there are many forces on an**
object?

In the previous section, we dealt with the work do to a single force. There are two ways to deal with multiple forces on an
object:

1) Find the net force (which we will discuss in Units 119-129) and find the mechanical work due to this net force,
2) Find the mechanical work due to each force and add these mechanical works.

Since the first method requires techniques we will learn later in the course, we will now focus in on the second method.
Since mechanical work is a scalar, if you find the work due to each force that acts on an object individually, you can then
simply add each of the mechanical works together as

𝑊��� = 𝑊� + 𝑊� + 𝑊� + ⋯ (110-14)


Example 110 - 9 **Net work on an incline**

Imagine that a 1.3 kg box is pushed 2.3 meters up the surface
of an inclined plane. The surface of the inclined plan makes
an angle of 30 degrees relative to the horizontal. If the box is
pushed with a force of 9.8 N directed along the surface of the
plane, and the box experiences a frictional force of 3.4 N
directed down the surface of the plane, what is the net work
done on the box during the 2.3 meter displacement?

**Solution:**

This problem asks us to find the net work done on a box due
to a number of forces. In order to accomplish this, we will
find the work done on the box by each of the forces
independently and then use Equation 110-14 to fine the net
work, 𝑊���.

The figure to the right shows all
of the forces acting the box and
their relative directions, what we
will later call a free body
diagram.

For the pushing force, the force is in the direction of
displacement (up the incline), so

𝑊���� = 𝐹[⃗]���� ∙𝑑[⃗] = (9.9 𝑁)(2.3 𝑚) cos 0° = 22.8 𝐽


The friction force is directed opposite of the displacement
(180°) so

𝑊����� = 𝐹[⃗]����� ∙𝑑[⃗] = (3.4 𝑁)(2.3 𝑚) cos 180° = −7.8 𝐽

The work due to the gravitational force is a bit more
complicated because we have to worry about the angle.
Since the displacement is up the incline (30° above the
horizontal) and the gravitational force is directed
downward, the angle between the two vectors is 120°
(90° + 30°)’ therefore

𝑊� = 𝐹[⃗]� ∙𝑑[⃗] = (1.3 𝑘𝑔)(9.8 𝑁/𝑘𝑔)(2.3 𝑚) cos 120°

= −14.7 𝐽

The normal force does no work, since it is directed 90° to
the direction of displacement (cos 90° = 0).

Therefore, the net work on the box is given by

𝑊��� = 𝑊���� + 𝑊����� + 𝑊� + 𝑊������,
or

𝑊��� = 22.8 𝐽−7.8 𝐽−14.7 𝐽−0 = 0.3 𝐽.

In the next unit, we will show how this net work on an
object can be used to calculate a change in kinetic energy.


-----

#### 110-5. Conservative and non-conservative forces

**Consider: When work is performed, is mechanical energy conserved?**

If you throw a ball straight up and catch it at its peak, can you recover the kinetic energy it lost as it rose? You certainly can
– if you just release the ball, the kinetic energy it has as it reaches its initial launch point will be very close to the initial
kinetic energy it had when it left your hand.
What about when a book sliding across a table comes to rest due to friction – can you recover the kinetic energy that was
lost as the book slowed down? This would be much harder to do since the kinetic energy (mechanical energy) is converted to
internal energy (not mechanical energy). In fact, even the most sophisticated apparatus would not be able to recover all of the
mechanical energy. (This is due to the second law of thermodynamics, which is beyond the scope of this course).
In each case, we can ask if the mechanical energy, kinetic energy and potential energy, is conserved. If the work due to a
force conserves mechanical energy it is called a conservative force. Conservative forces essentially transfer energy between
kinetic and potential forms, which allow you to recoup the energy as kinetic energy later.
On the other hand, if the work due to a force causes a loss in mechanical energy we call it a non-conservative force. The
most common non-conservative forces are those that act like friction – kinetic slowing due to friction, air resistance and
water resistance.
Luckily, there is a test for whether a force is conservative or not. When you find the work due to a conservative force,

�

𝑊= �𝐹[⃗] ⋅𝑑𝑥⃗, (110-15)

�

if the work is independent of the path taken from a to b, then the force is conservative. If the work depends on the path from
a to b, then then force is non-conservative.
To summarize

**_A conservative force is one that maintains all mechanical energy in the system. The_**
work due to a conservative force is independent of path taken in computing the work.

**_A non-conservative force is one that causes mechanical energy to enter or leave the_**
system. The work due to a non-conservative force is dependent on the path taken in
computer the work.

The work due to a conservative force transfers energy between potential and kinetic energies, and can be related by

𝑊������������ = −∆𝑈, (110-16)

where 𝑊������������ is the work done by the system due to a conservative force and ∆𝑈is a change in potential energy.
As an example, imagine lifting a 5-kg ball, initially at rest, slowly up 1.2 meters and then slowly down 0.6 meters where
it comes to rest. The net effect is that the ball has risen 0.6 meters without a change in kinetic energy. The gravitational
potential energy of the ball has increased

∆𝑈� = 𝑚𝑔∆ℎ= (5 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )(0.6 𝑚) = 29.4 𝐽. (110-17)

Let’s now think about this in terms of the work required to lift the ball 1.2 meters and then lower the ball 0.6 meters and find
the total work performed. First, the force of gravity is constant, so we can use Equation 110-12 to find the work required to
lift the ball 1.2 meters using

𝑊������� = 𝐹[⃗] ∙𝑑[⃗] = (5 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )(1.2 𝑚) cos 180° = −58.8 𝐽. (110-18)

Please note that the angle is 180° because the force of gravity is directed downward and we are lifting the ball upward. We
can also use the same equation to find the work required to lower the ball 0.6 m:

𝑊�������� = 𝐹[⃗] ∙𝑑[⃗] = (5 𝑘𝑔)(9.8 𝑁𝑘𝑔⁄ )(0.6 𝑚) cos 0° = 29.4 𝐽. (110-19)


-----

The total work is then -58.8 J + 29.4 J = -29.4 J. Then, when use the fact that 𝑊= −∆𝑈, the change in potential energy is
29.4 J. Since this is the same value we found in 110-17, we have shown that the gravitational force is independent of path
and is therefore a conservative force!
Compare the example above with friction. Imagine you try to slide a heavy box across a carpeted floor. If you push the
box 5 meters across the carpet, you use considerably less energy than if you slide the box 10 meters and then back 5 meters to
the same location. This is because at every step along the way, friction is removing energy from the system and transferring
it to thermal energy. Friction is an example of a **_non-conservative force, because the amount of energy transferred is_**
dependent on the path of the motion.

#### 110-6. Calculating path independence with path integrals (optional)

**Consider: Is there a precise way to determine if a force is conservative**
or non-conservative?

In the last section, we used hand-waving arguments to determine that the gravitational force is conservative and that the
friction force is non-conservative. In doing this, we explored how the work due to the force compared as we varied the path
over which we calculated the work. In general, this can done using path integrals. In a path integral, we use specific
relationships between dimensions (the path we are following) to parametrize the integral. The easiest parametrization is to
follow lines that move parallel to the x-, y-, and/or z-axis. Computing the work along different paths in this fashion will
always determine whether a force is conservative or not.
Completing calculations such as those describe above are beyond the scope of this course. However, a relatively
simple example using path integrals is shown below for those that might be interested.


Example 110 - 10 **Conservative or non-conservative?**

Is the force

𝐹[⃗](𝑥, 𝑦) = 2𝑥[�]𝚤̂ + 4𝑥𝑦𝚥̂.

conservative or non-conservative between the points (0,0,0)
and (2,3,0)?

**Solution:**

This problem asks us to determine if a given force is
conservative or non-conservative in a specific region of space.
In order to do this, we will follow two distinct paths between
the starting and ending points. If the work along the two
paths is the same, the force is conservative, if the work is
different, the force is non-conservative.
Here are the two paths we will use:

1) First move along x-axis (where 𝑦= 0) from 𝑥= 0 to

𝑥= 2, and then move parallel to y-axis (with 𝑥= 2)
from 𝑦= 0 to 𝑦= 3.

2) First move along y-axis (where 𝑥= 0) from 𝑦= 0 to

𝑦= 3, and then move parallel to x-axis (with 𝑦= 3)
from 𝑥= 0 to 𝑥= 3.

Note, as we move parallel to a given axis, 𝑑𝑟⃗ reduces to a
differential along that axis, for example, when moving along
the x-axis, 𝑑𝑟⃗= 𝑑𝑥𝚤̂ + 𝑑𝑦𝚥̂ + 𝑑𝑧𝑘[�] = 𝑑𝑥𝑖 since dy and dz are
zero.


Path1: First move along x-axis (with y=0) from 𝑥= 0 to
𝑥= 2:


�

𝑊�,� = �(2𝑥[�]𝚤̂ + 4𝑥0𝚥̂) ∙𝑑𝑥𝚤̂

�


�

= �2𝑥[�]𝑑𝑥

�


= 5.33


Next, we move along the y-axis at 𝑥= 2

� �

𝑊�,� = �[2(2[�])𝚤̂ + 4(2)𝑦𝚥̂] ∙𝑑𝑦𝚥̂ = �8𝑦𝑑𝑦

� �


= 36.


Therefore the total work over this path is 41.33.

Path 2: First move along the y-axis (with 𝑥= 0) from
𝑦= 0 to 𝑦= 3:


�

𝑊�,� = �[2(0[�])𝚤̂ + 4(0)𝑦𝚥̂] ∙𝑑𝑦𝚥̂

�


�

= �0𝑑𝑦

�


= 0


Next, we move along the x-axis at 𝑦= 3


�

𝑊�,� = �[2𝑥[�]𝚤̂ + 4𝑥(3)𝚥̂] ∙𝑑𝑥𝚤̂

�


�

= �2𝑥[�]𝑑𝑥

�


= 5.33,


which gives a total work of 5.33. Since the work along
the two paths is different, we have a **_non-conservative_**
**_force!_**


-----

-----

