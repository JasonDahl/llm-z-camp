### – Kinematics
## 120


_The kinematic relationships give us ways to find position, velocity and/or acceleration of objects assuming that we know_
_something about one of these values. Although these relationships are very general and can be used for all problems,_
_constant acceleration is so common that we present the overall equations for this situation specifically._


##### The Bare Essentials

- The kinematic relationships give us a general way to relate

position, velocity and acceleration



- Given the velocity as a function of time, the position function

is found using an antiderivatives and the acceleration function
is found using a derivative.


����������

��� ����
�⎯⎯⎯⎯⎯⎯�𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛


𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛


����������

��� ����
�⎯⎯⎯⎯⎯⎯�𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦


�������� ��������
��� ���� ��� ����

𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛 �⎯⎯⎯⎯⎯�𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦 �⎯⎯⎯⎯⎯�𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛

- Given the position as a function of time, the velocity function

and acceleration function for motion are found using
derivatives.


**Kinematic Relationships**

**(starting with velocity)**

�

𝑥⃗(𝑡) −𝑥⃗� = �𝑣⃗(𝑡)𝑑𝑡

�

𝑎⃗(𝑡) = [𝑑]

𝑑𝑡 [𝑣⃗(𝑡)]

**Description – These equations show the relationships between**

position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for a system where
we initially know the velocity as a function of time.


**Kinematic Relationships**

**(starting with position)**

𝑣⃗(𝑡) = [𝑑]

𝑑𝑡 [𝑥⃗(𝑡)]


𝑎⃗(𝑡) = [𝑑] [𝑑][�]

𝑑𝑡 [𝑣⃗(𝑡) =] 𝑑𝑡[�] [𝑥⃗(𝑡)]

**Description – These equations show the relationships between**

position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for a system where
we initially know the position as a function of time.



- For constant acceleration, we can write a set of equations that

directly relate the kinematic variables.


**Constant Acceleration Kinematics Equations**

**(1-D)**

𝑎= 𝑎

𝑣(𝑡) = 𝑣� + 𝑎𝑡



- Given the acceleration as a function of time, the velocity and

position functions are found using antiderivatives


**Kinematic Relationships**
**(starting with acceleration)**

�

𝑣⃗(𝑡) −𝑣⃗� = �𝑎⃗(𝑡) 𝑑𝑡

�

�

𝑥⃗(𝑡) −𝑥⃗� = �𝑣⃗(𝑡)𝑑𝑡

�

**Description – These equations show the relationships between**

position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for a system where
we initially know the acceleration as a function of time.


𝑥(𝑡) = 𝑥� + 𝑣�𝑡+ [�]�[𝑎𝑡][�]

𝑣[�](𝑡) = 𝑣�� + 2𝑎[𝑥(𝑡) −𝑥�]

**Description – These equation relate the velocity, 𝑣(𝑡), and**

position, 𝑥(𝑡) of a particle at a given time 𝑡 under constant
acceleration, 𝑎. 𝑥� and 𝑣� represent the initial position and
speed of the particle, respectively.
**Note: It is very important that you use these equations only when**

there is constant acceleration.


-----

#### 120.1 – Position, velocity and acceleration

**Consider: How are position, velocity and acceleration related?**

EWTON’S SECOND LAW GIVES US A general way to find the acceleration of a body due to the forces that act
upon it. We can then use this acceleration to determine the velocity and position of the object as a function of time.
This is true even when the acceleration of the object is a function of time itself. Our goal in this unit is to give the

# N

direct relationships between the kinematic variables of position, velocity and acceleration, and then to practice predicting the
later motion of objects. In addition, we should be able to predict the acceleration, and therefore net force on an object, if we
know something about how its position and velocity change with respect to time.
Earlier in the course, we defined the velocity of an object as the rate of change of position,

v�⃗= [𝑑𝑟⃗] (120-1)

𝑑𝑡[,]

and the acceleration as the rate of change of velocity

a�⃗= [𝑑𝑣⃗] (120-2)

𝑑𝑡 [.]


We can also combine these relationships to show that the acceleration of the object is the second derivative of the position
with respect to time,

a�⃗= [𝑑][�][𝑥⃗] (120-3)

𝑑𝑡[�][.]

Together, these represent the kinematic derivatives that allow us to find the velocity and acceleration given position and/or
velocity as a function of time. The real power of these relationships is seen in specific contexts as we’ll see in examples later
in this unit.
We can write these relationships succinctly as


���������� ����������

��� ���� ��� ����

𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛 �⎯⎯⎯⎯⎯⎯�𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦 �⎯⎯⎯⎯⎯⎯�𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛,

where “wrt” means with respect to.
Just as derivatives allow us to move from position to velocity to acceleration, we can use antiderivatives to move in the
reverse direction. Assuming that we start with acceleration, we can then find the velocity as

�

𝑣⃗(𝑡) −𝑣⃗� = �𝑎⃗(𝑡) 𝑑𝑡, (120-4)

�

where we have assumed that the velocity starts at time 𝑡= 0. It is possible to have a problem where the integral does not
begin at time 𝑡= 0; however, this can be dealt with by either changing the lower limit of integration, or transforming the
function so that the initial time is zero.
Once we know the position as a function of time (or if we are given it directly), we can then find the position as

� **Connection: Jerk**

𝑥⃗(𝑡) −𝑥⃗� = �𝑣⃗(𝑡) 𝑑𝑡, (120-5)

� There is a relatively common forth kinematic variable that we


where, once again, the initial 𝑡= 0 is given a standard which
can be converted for specific problems if needed. These
relationships starting with acceleration can be succinctly
summarized as we did above for the derivative relationships:

�������� ��������
��� ���� ��� ����

𝑎𝑐𝑐𝑒𝑙𝑒𝑟𝑎𝑡𝑖𝑜𝑛 �⎯⎯⎯⎯⎯�𝑣𝑒𝑙𝑜𝑐𝑖𝑡𝑦 �⎯⎯⎯⎯⎯�𝑝𝑜𝑠𝑖𝑡𝑖𝑜𝑛.

Unit 121 will delve into the graphical relationships


-----

between the kinematic variables. For now, I mention that, graphically, the derivative represents the slope of the tangent line
of a function at a specific point and the integral gives you the area under the curve. Stay tuned for more on this next unit.
We can also be very explicit about the relationships depending on which variable we know at the beginning of a problem

**Starting with position:**


**Kinematic Relationships**

**(starting with position)**

𝑣⃗(𝑡) = [𝑑]

𝑑𝑡 [𝑥⃗(𝑡)]


𝑎⃗(𝑡) = [𝑑] [𝑑][�]

𝑑𝑡 [𝑣⃗(𝑡) =] 𝑑𝑡[�] [𝑥⃗(𝑡)]

**Description – These equations show the relationships**

between position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for
a system where we initially know the position as a
function of time.


**Starting with acceleration:**

**Starting with velocity:**


**Kinematic Relationships**
**(starting with acceleration)**

�

𝑣⃗(𝑡) −𝑣⃗� = �𝑎⃗(𝑡) 𝑑𝑡

�

�

𝑥⃗(𝑡) −𝑥⃗� = �𝑣⃗(𝑡)𝑑𝑡

�

**Description – These equations show the relationships**

between position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for
a system where we initially know the acceleration as a
function of time.


**Kinematic Relationships**

**(starting with velocity)**

�

𝑥⃗(𝑡) −𝑥⃗� = �𝑣⃗(𝑡)𝑑𝑡

�

𝑎⃗(𝑡) = [𝑑]

𝑑𝑡 [𝑣⃗(𝑡)]

**Description – These equations show the relationships**

between position, 𝑥⃗, velocity, 𝑣⃗, and acceleration, 𝑎⃗, for
a system where we initially know the velocity as a
function of time.


-----

#### 120.2 – One dimensional kinematics

**Consider: How do we consider motion along a straight line?**

We first consider a couple of examples of the kinematics relationships in one dimension. In this case, the kinematics
relationships look exactly like Equations 120-1 through 120-5, just without the vector symbols. One-dimensional kinematics
can always be used for motion along one axis; however, if you are given a coordinate system where the linear motion is not
along an axis, you may need to transform coordinates to bring the motion along one axis.


Example 120 - 1 **Rockets in a straight line**

The position of a rocket moving in a straight line as a function
of time is given by

𝑥(𝑡) = 143𝑡+ 22𝑡 [�],

where 𝑥 is given in 𝑚 and 𝑡 is seconds.

(a) What are the units of the numbers 143 and 22?
(b) What are the velocity and acceleration as a function

of time for this rocket?
(c) What is the speed of the rocket at 𝑡= 2𝑠?
(d) What is the average speed of the rocket between 𝑡=

0𝑠 and 𝑡= 2𝑠?

**Solution:**

This problem asks us to use the kinematic relationships to
determine certain velocities and accelerations.

(a) We know that each term in the equation must have units of
𝑘𝑚. Since 143 is multiplied by time once to give 𝑚, its units
must be 𝑚/𝑠. Similarly, 22 is multiplied by time twice to
give 𝑘𝑚, so its units must be 𝑚/𝑠[�]. (Note: these units
resemble those of velocity and acceleration, respectively.)

(b) The velocity as a function of time is given by the
derivative of the position function

𝑣= [𝑑]

𝑑𝑡 [(143𝑡+ 22𝑡][�][) = 143 + 44𝑡,]

where 𝑣 is in _m/s. The acceleration as a function of time is_
given by the derivative of the velocity function,


𝑣��� = [𝑥(2𝑠) −𝑥(0)](2s −0) = [374𝑚−0]2𝑠 = 187 𝑚𝑠⁄ .

Please note that this average speed between two times is
different than the speed at the later time. Since the speed
is linear as a function of time in this case, it turns out that
the average speed between 𝑡= 0𝑠 and 𝑡= 2𝑠 is equal to
its speed at t=1s; however, this is not a general result, it is
one that happens to be true for constant acceleration (see
120.4 below).

Be careful when discussing speeds at a time (sometimes
called instantaneous speed) and the average speed
between two times.  They give you very different
information!


(c) The speed of a rocket at a specific time is found by
using that time in the velocity equation (since this is 1dimensional motion). For 𝑡= 2𝑠, we find

𝑣(1𝑠) = 143𝑚+ 44 𝑚𝑠⁄ (2𝑠) = 231 𝑚𝑠⁄ .

(d) For an average speed, we must compare the position
at two times divided by the time interval between those
two positions. This come about by essentially undoing
the definition of the derivative


𝑣= [𝑑𝑥]

𝑑𝑡 [= lim]��→�


𝑥(𝑡+ �𝑡) −𝑥(𝑡)

,
�𝑡


such that we do not take the limit:

𝑣��� = [𝑥(𝑡+ �𝑡) −𝑥(𝑡)]�𝑡 .

Therefore, the average speed between 𝑡= 0𝑠 and 𝑡= 2𝑠
is


𝑎= [𝑑]

𝑑𝑡 [(143 + 44𝑡) = 44,]

where 𝑎 is in 𝑚/𝑠[�].


Example 120 - 2 **Viscous drag and kinematics**

When an object is acted on by viscous drag (such as when
moving through a liquid), the velocity of the object decreases
as a function of time. Imagine that one such velocity is

𝑣(𝑡) = (5.2 𝑚𝑠⁄ )𝑒[��.��] .


Assuming the object starts at 𝑥= 0 at 𝑡= 0, what is the
position as a function of time and acceleration as a
function of time of this object?


-----

**Solution:**

This problem asks us to use the kinematic relationships
starting with velocity to find the position and acceleration as a
function of time.

The position as a function of time is given by the integral of
the velocity equation


�

𝑥(𝑡) −𝑥(0) = �𝑣(𝑡)𝑑𝑡

�


�

= ��(5.2 𝑚𝑠⁄ )𝑒[��.���]�𝑑𝑡.

�


Taking the integral (and noting the initial position is zero), we
find


𝑥(𝑡) = (−20𝑚)(𝑒[��.���] −𝑒[�]).

Factoring out a negative one from the parentheses (which
reverses the order of the difference) and simplifying, we
get

𝑥(𝑡) = 20𝑚(1 −𝑒[��.���]).

In order to find the acceleration of the object, we take the
derivative with respect to time

𝑎(𝑡) = [𝑑𝑣] [𝑑] ⁄ )𝑒[��.���]�,

𝑑𝑡 [=] 𝑑𝑡 [�(5.2 𝑚𝑠]


𝑥(𝑡) −0 =


�

(5.2 𝑚𝑠⁄ )𝑒[��.���]

�
−0.26 𝑠[��]

�


.


Please note that the units of -0.26 must be 𝑠[��] since the
argument of the exponential function must be unitless. We
must be careful with this function, because when plugging in
𝑡= 0 for the exponential function, we do not get zero. In this
case, we find


which gives us

𝑎(𝑡) = (−0.26 𝑠[��])(5.2 𝑚𝑠⁄ )𝑒[��.���],

or

𝑎(𝑡) = −(1.35𝑒[��.���]) 𝑚𝑠⁄ [�].

Note that since 𝑣 is positive for all 𝑡 and 𝑎 is negative for
all 𝑡, the object will slow down until coming to rest.


#### 120.3 – Vector Calculus

**Consider: Just how do you do derivatives and integrals of vectors?**

In order to complete kinematics problems in three dimensions, we must use Equations 120-1 and 120-2 as well as their
inverses, Equations 120-4 and 120-5. Each of these contain calculus on vector functions, which is something we have yet to
encounter in this course. However, completing such derivatives and integrals on vectors comes down to doing the derivatives
and integrals on each component separately. For derivatives, we find


𝑣⃗= [𝑑𝑟⃗] [𝑑]

𝑑𝑡 [=] 𝑑𝑡 [�]

On the integral side, we have

and


𝑥(𝑡)
𝑦(𝑡)
𝑧(𝑡)


𝑣�(𝑡)
𝑣�(𝑡)
𝑣�(𝑡)


�=


�
⎡[𝑑𝑥] 𝑑𝑡⎤
⎢𝑑𝑦 ⎥
⎢ �𝑑𝑡⎥
⎢ ⎥
⎣𝑑𝑧𝑑𝑡� ⎦


and   𝑎⃗= [𝑑𝑣⃗] [𝑑]

𝑑𝑡 [=] 𝑑𝑡 [�]


�=


⎡[𝑑𝑣][�]�𝑑𝑡⎤
⎢⎢𝑑𝑣��𝑑𝑡⎥⎥
⎢ ⎥
⎣𝑑𝑣��𝑑𝑡⎦


. (120-6)


�

𝑣⃗(𝑡) −𝑣⃗� = �𝑎⃗(𝑡)

�


� 𝑎�

𝑑𝑡= ��𝑎�

� 𝑎�


�


𝑑𝑡=


�

⎡�𝑎�𝑑𝑡⎤
⎢ � ⎥
⎢ � ⎥
⎢�𝑎�𝑑𝑡⎥, (120-7)
⎢ �� ⎥
⎢ ⎥
⎣�𝑎� �𝑑𝑡⎦


-----

�

𝑟⃗(𝑡) −𝑟⃗� = �𝑣⃗(𝑡)

�


�

𝑑𝑡= ��

�


𝑣�
𝑣�
𝑣�


�


𝑑𝑡=


�

⎡�𝑣�𝑑𝑡⎤
⎢ � ⎥
⎢ � ⎥
⎢�𝑣�𝑑𝑡⎥. (120-8)
⎢ �� ⎥
⎢ ⎥
⎣�𝑣� �𝑑𝑡⎦


Example 120 - 3 **Example Problem**

Find the derivative and integral of


𝑑
⎡ ⎤
𝑑𝑡 [(𝑡)]
⎢ ⎥

𝑑

⎢ ⎥
⎢ 𝑑𝑡 [(𝑒][��][)] ⎥
⎢ 𝑑 ⎥
⎣𝑑𝑡 [sin(2𝑡)⎦]


1
2𝑒[��]

2 cos(2𝑡)


�,


𝑓[⃗](𝑡) = �


𝑡
𝑒[��] �.

sin(2𝑡)


𝑑
𝑑𝑡 [𝑓⃗(𝑡) =]


= �


**Solution:**

In order to find the derivative and integral of a vector valued
function, we perform calculus on each component of the
function separately.

Therefore, the derivative of the function 𝑓[⃗](𝑡) is


and the integral is given by


�𝑓[⃗](𝑡)𝑑𝑡=


⎡ �𝑡𝑑𝑡 ⎤
⎢ ⎥
⎢ �𝑒[��] 𝑑𝑡 ⎥
⎢ ⎥
⎢ ⎥
⎣�sin(2𝑡)𝑑𝑡⎦


=


𝑡[�]
⎡ �+ 𝐶2 � ⎤
⎢ 𝑒[��] ⎥
⎢ �+ 𝐶2 � ⎥
⎢−cos(2𝑡) ⎥
⎣ �+ 𝐶2 �⎦


.


#### 120.4 – Kinematics in two and three dimensions

**Consider: What is different about motion in multiple dimensions?**

The vector nature of position, velocity and acceleration becomes most important when we consider multiple dimensions. In
one sense, multiple dimension kinematics comes down to performing the kinematics relationships multiple times. The
complication comes in when we are given the magnitude and direction of one of our kinematic vectors and need to convert
this into the components of one of our variables. Remembering from Unit 104: given a vector of magnitude |𝑎⃗| and an angle
measured from the x-axis towards the y-axis, 𝜃�→�, the components of that vector in two dimensions are

𝑎� = |𝑎⃗| cos 𝜃�→� 𝑎� = |𝑎⃗| sin 𝜃�→�. (120-9)

Similarly, if you know the components of a vector, you can find the magnitude and angle with

|𝑎⃗| = �𝑎�[�] + 𝑎�[�] 𝜃�→� = tan[��] �[𝑎][�]�. (120-10)

𝑎�

The components and angles for a three-dimensional vector are, unfortunately, more complicated. Please review Section 1043 if you need a refresher on how to deal with 3-D vectors.


Example 120 - 4 **Surfacing submarine**

The position of a submarine as a function of time while
executing an emergency surfacing procedure (a ‘blow’) is
given by

𝑟⃗(𝑡) =< 20 −0.15𝑡[�], 0, −85 + 3.5𝑡[�] >,

all given in SI units. What is the speed and acceleration of the


submarine just before bursting through the surface (at
𝑧= 0)?

**Solution:**

This problem asks us to use the three-dimensional
kinematics relationships to find velocity and acceleration
at a specific time.


-----

First, we can find the time at which the submarine reaches the
surface by solving the z-component of the position for z=0:

0 = −85 + 5𝑡[�] →   𝑡= 2.89 𝑠.

In order to find the speed and acceleration, we must first find
the functional forms of the velocity and acceleration as a
function of time. Taking derivatives, we find


We can then use the time just before the sub breaches the
surface to find the velocity and acceleration at this time


The speed just before the sub breaks the surface is then
given as the magnitude of the velocity at this time,

|𝑣⃗| = �(−0.30)[�] + (88)[�] = 88 𝑚/𝑠.

Now, the problem asks for the acceleration at this time.
We must remember that acceleration is always a vector,
so the acceleration is given by the vector above.
Regardless, it is easy to see that the magnitude of the
acceleration is also 61 m/s[2].


0
0
61


� [𝑚]

𝑠[�][.]


𝑣⃗(𝑡) = �


−0.30

0
88


� [𝑚]

𝑠 [    𝑎𝑛𝑑   𝑎⃗(𝑡) = �]


𝑣⃗(𝑡) = [𝑑]

𝑑𝑡 [�]


20 −0.15𝑡[�]

0
−85 + 3.5𝑡[�]


�= �


−0.30

0
10.5𝑡[�]


�,


and


𝑎⃗(𝑡) = [𝑑]

𝑑𝑡 [�]


−0.30

0
10.5𝑡[�]


�= �


0
0
21𝑡


�.


#### 120.4 – Motion with Constant Acceleration

**Consider: If we know acceleration is constant (not dependent on time),**
are there specific equations that can be used?

One of the most popular types of motion to explore in introductory physics is that of motion with a constant acceleration. We
discussed earlier in Unit 106 that near the surface of a large gravitating body, the gravitational force on an object can be
written as
𝐹� = 𝑚𝑔, (120-11)

where 𝐹� is the magnitude of the gravitational force, 𝑚 is the mass of the object and 𝑔 is the local gravitational field strength.
If the gravitational force is the only force acting on an object, we can then relate this to the acceleration of the object using
Newton’s 2[nd] law:
𝐹��� = 𝑚𝑔= 𝑚𝑎, (120-12)

If we assume that the masses on each side of this equation are the same, we can further simplify this to

𝑎= 𝑔, (120-13)

suggesting that in this special case, the magnitude of the acceleration of the object is equal to the gravitational field strength.
This is why g has traditionally been called the acceleration due to gravity. This is a bit of a misnomer because an object will
only undergo this physical acceleration if it is in a vacuum and is acted on by no other forces – a very special case indeed.
To be clear, there is no theoretical reason to believe that the mass in equation 120.11 (known as the gravitational mass) is
the same as the mass on the right side of equation 120.12 (known as the inertial mass). The equivalence of these two masses
has, however, been tested to approximately the 10[���] level and found to be the same. Another way of saying this is that our
two possible masses have been shown to be the same to at least fifteen decimal places. Tests of this equivalence principle
are ongoing and were a sizeable part of the author’s Ph.D. thesis.
In unit 121 we will solve problems in which gravity (in the vertical direction) is the only acceleration on a system. This
type of problem is known as an ideal projectile motion problem and is an important example of how kinematics can be
applied to near real-world problems. For the rest of this section, however, we will allow for there to be any acceleration in
any direction, so long as it is constant.
So, let us start in one dimension with a constant acceleration, 𝑎, and use the kinematic chain in order to find an
expression for the velocity as a function of time:

𝑣(𝑡) = �𝑎𝑑𝑡= 𝑎𝑡+ 𝐶. (120-14)

We can solve for the constant of integration, C, by looking at the initial condition, that is, we write down the velocity at
initial time of t=0,
𝑣(0) = 𝑎(0) + 𝐶 → 𝐶≡𝑣�. (120-15)


-----

Using this initial velocity, we can now write the velocity as a function of time (for constant acceleration) as

𝑣(𝑡) = 𝑎𝑡+ 𝑣�. (120-16)

Using the same process, we can find the position equation as a function of time:

𝑥(𝑡) = �𝑣(𝑡)𝑑𝑡. (120-17)

In this case, we can now plug in the position equation (equation 120.x) into this integral and solve, giving
𝑥(𝑡) = �(𝑎𝑡+ 𝑣�) 𝑑𝑡= [𝑎𝑡]2 [�] [+ 𝑣][�][𝑡+ 𝐷,] (120-18)

where I have used 𝐷 as the constant of integration to avoid confusion with the constant 𝐶 above. We can solve for the
constant 𝐷 by finding the initial position, 𝑥(0) and call this value 𝑥�,
𝑥(0) = [𝑎(0)]2 [�] + 𝑣�(0) + 𝐷 → 𝐷≡𝑥�. (120-19)

Just as we did for velocity, we can now insert this initial position to write the position as a function of time (for constant
acceleration) as
𝑥(𝑡) = [1] (120-20)

2 [𝑎𝑡][�] [+ 𝑣][�][𝑡+ 𝑥][�][,]

Together, equations 120.16 and 120.20 form two of the core equations for motion with constant acceleration. These
equations have one drawback, however – they both depend on time. We can find an equation for the velocity as a function
**_of position (for constant acceleration) by first solving for time in equation 120.16, giving us_**

𝑡= [𝑣(𝑡) −𝑣][�]. (120-21)

𝑎

We can then substitute this into equation 120.20 as


+ 𝑣� �[𝑣(𝑡) −𝑣]𝑎 [�]�+ 𝑥� → 𝑣(𝑡)[�] = 𝑣�� + 2𝑎[𝑥(𝑡) −𝑥�], (120-22)


𝑥(𝑡) = [1] �

2 [𝑎�𝑣(𝑡) −𝑣]𝑎 [�]


�


These important kinematics equations can now be summarized as in the box below:


**Constant Acceleration Kinematics Equations (1-D)**

𝑎= 𝑎

𝑣(𝑡) = 𝑣� + 𝑎𝑡


𝑥(𝑡) = 𝑥� + 𝑣�𝑡+ [�]�[𝑎𝑡][�]

𝑣[�](𝑡) = 𝑣�� + 2𝑎[𝑥(𝑡) −𝑥�]

**Description – These equation relate the velocity, 𝑣(𝑡), and**

position, 𝑥(𝑡) of a particle at a given time 𝑡 under constant
acceleration, 𝑎. 𝑥� and 𝑣� represent the initial position and
speed of the particle, respectively.
**Note: It is very important that you use the equations only when**

there is constant acceleration.


-----

As written in the box above, each of the constant acceleration kinematics equations are true for one-dimension. The first
three equations can be generalized to vector equations directly, giving us

𝑎⃗= 𝑎⃗,

𝑣⃗(𝑡) = 𝑣⃗� + 𝑎⃗𝑡,

𝑟⃗(𝑡) = 𝑟⃗� + 𝑣⃗�𝑡+ [�]�[𝑎⃗𝑡][�][.]

where 𝑟⃗ is used for the vector position. More explicitly, these vector equations are


𝑎�

𝑎⃗= �𝑎�

𝑎�


�,


𝑣�� + 𝑎�𝑡

𝑣⃗(𝑡) = �𝑣�� + 𝑎�𝑡

𝑣�� + 𝑎�𝑡


�,


𝑟⃗(𝑡) =


⎡[𝑥][�] [+ 𝑣][��][𝑡+][ �]�[𝑎][�][𝑡][�]⎤
⎢𝑦� + 𝑣��𝑡+ [�]�[𝑎][�][𝑡][�]⎥
⎢ ⎥
⎣ 𝑧� + 𝑣��𝑡+ [�]�[𝑎][�][𝑡][�] [⎦]


.


The final equation in the kinematics box is more difficult to write in vector form. This equation contains the square of both
the initial velocity and the velocity at time 𝑡. If you remember back to the unit on vectors, the square of a vector is, by
definition, the dot product of the vector with itself;

𝑣�� = 𝑣⃗� ⋅𝑣⃗�, (120-23)

for example. Therefore, the velocity as a function of time cannot be written in a compact three-dimensional vector form;
however, the equation can still be used in each dimension separately as long as you are careful to keep the components of
each direction together. Explicitly, the equation for each of the three dimensions is

𝑣��(𝑡) = 𝑣��� + 2𝑎�[𝑥(𝑡) −𝑥�],

𝑣��(𝑡) = 𝑣��� + 2𝑎�[𝑦(𝑡) −𝑦�],

𝑣��(𝑡) = 𝑣��� + 2𝑎�[𝑧(𝑡) −𝑧�].


Example 120 - 5 **Finding values by analogy**

A particle undergoes motion with a position vector given by

−2.5 −6.2𝑡+ 0.48𝑡[�]

𝑟(𝑡) = � 25 �.

32 + 2.6𝑡−4.9𝑡[�]

(a) Using analogies to the constant acceleration kinematics

equations, write down the initial position, initial velocity
and acceleration vectors for this particle.
(b) Explain how you can know by inspection if position and

velocity equations are those for constant acceleration.

**Solution:**

We can compare the position equation give to the position


equation for constant acceleration to find


𝑟⃗� = �


−2.5

25
32


�𝑚,   and   𝑣⃗� = �


−6.2

0 � [𝑚]

𝑠 [,]

2.6


Where the initial position is given by the constant terms
and the initial velocity is given by the terms linear in t.
For the acceleration, we must be careful because of the ½
in


𝑟⃗(𝑡) = 𝑟⃗� + 𝑣⃗�𝑡+ [�]�[𝑎⃗𝑡][�][.]

Therefore, the acceleration vector is given by


-----

0.48

0
−4.9


0.96

0
−9.8


� [𝑚]

𝑠[�][.]


𝑎⃗= 2 �


� [𝑚]

𝑠[�] [= �]


Of course, we could find each of these values by taking the
derivatives as we did earlier in the Unit. However, being able
to determine these values by inspection for constant
acceleration can help you complete problems faster.


(b) Any constant, linear, or quadratic equation for
position will be that for constant acceleration, since the
second derivative of each would be a constant value
(including zero).

For velocity, the equations must be constant or linear in
time to be constant acceleration. You can see both of
these by exploring equations 120-16 and 120-20.


Example 120 - 6 **3-d Accelerated motion**

A particle undergoes constant acceleration given by


⎡ [−2 + (0)𝑡+][ �]�[(2.2)𝑡][�] ⎤
⎢ 0 + (0)𝑡+ [�] ⎥

�[(−1.8)𝑡][�]

⎢ ⎥
⎣120 + (0)𝑡+ [�]�[(−1.6)𝑡][�][⎦]


𝑚.


2.2

𝑎⃗= �−1.8

−1.6


𝑟⃗(𝑡) =


� [𝑚]

𝑠


�


,


and has initial velocity and position given by 𝑣⃗� = < 0, 0, 0 >
𝑚/𝑠 and 𝑟� =< −2, 0, 120 > 𝑚, respectively. Determine the
position as a function of time for this object.

**Solution:**

This problem asks us to use the constant acceleration
kinematics equations to find the position equation given a
known acceleration. Similar to example 120-5, we can use
analogies to immediately write the solution as


This can be simplified to

−2 + 1.1𝑡[�]

𝑟⃗(𝑡) = � −0.9𝑡[�]

120 −0.8𝑡[�]


�𝑚.


Again, once we realize we have constant acceleration, we
do not need to perform the integrals to answer such
questions.


Example 120 - 6 **Motion in parts**

A car accelerates from rest along a straight line at 3.1 𝑚/𝑠[�]
for 2.2 seconds. After this time, the car then travels at a
constant speed for an additional 4.5 seconds. How far has the
car traveled during the entire 5.7 seconds?

**Solution:**

This problem is a constant acceleration kinematics problem in
two parts. First, there is an accelerated motion for 2.2 seconds
and then a constant velocity section for 4.5 seconds. All of
this motion happens along one axis, so we will consider this
motion in one-dimension.

For the first 2.2 seconds, we use the constant acceleration
equations to find

𝑣(𝑡) = 𝑣� + 𝑎𝑡= 0 + 3.1 𝑠[𝑚][�] [(2.2 𝑠) = 6.82 𝑚]𝑠 [,]


which simplifies to

𝑥(𝑡) = 38.2 𝑚.

Therefore, at the end of the two periods, the car has
traveled 38.2 m and is traveling at 6.82 m/s.


𝑥(𝑡) = 0 + 0(2.2 𝑠) + [�] [𝑚]

� [�3.1] 𝑠[�][�(2.2 𝑠)][�] [= 7.50 𝑚.]


First the second part of the motion, our final position and
velocity become the initial position and velocity for this
section. For this section of the motion, we know that the
velocity remains the same at 6.82 m/s, so we do not need
to do any calculation for the speed. We can then
calculate the final overall position using information for
this section of motion as

𝑥(𝑡) = 7.50 𝑚+ �6.82 [𝑚]

𝑠 [�(4.5𝑠) +][ �]�[(0)(4.5 𝑠)][�][,]


and


-----

