### – Derivatives
## Appendix A


_Appendix A serves as either a brief review or practical introduction to differential calculus. This unit is in no way meant_
_to replace rigorous study in the field; however, this will present the tools as needed to understand instantaneous_
_relationships throughout your physics course. The derivative of a function gives you the rate of change of a function at_
_one specific point. This idea is important when discussing the relationships between position, velocity and acceleration,_
_among others._


##### The Bare Essentials

- The derivative of a function of a single variable represents the

**_rate of change of the function at a given point._**
.

- On a graph, the derivative of a function is the slope of the

function at a given point.

- The mathematical definition of the derivative gives us a way

to find the desired rate of change of any function. Note: In
practice, using the definition can be very hard.



- When a constant multiplies a function, we can “pull it out” of

the derivative:

𝑑
𝑑𝑡 [�𝑛𝑓(𝑡)�= 𝑛𝑑𝑓(𝑡)]𝑑𝑡

- The sum rule tells us that if we have the sum of two functions,

the derivative of the sum is the sum of the derivatives of the
individual functions.


**Definition of the Derivative**


𝒇[�](𝒕) = [𝒅𝒇(𝒕)] = 𝐥𝐢𝐦

𝒅𝒕 𝒉→𝟎


𝒇(𝒕+ 𝒉) −𝒇(𝒕)

𝒉


**Description – For a function, 𝑓(𝑡), this equation defines the**

derivative of the function, 𝑓[�](𝑡) in terms of the limit as a
dummy variable, ℎ, goes to zero.
**Note 1: Two common notations for a derivative are 𝑓[�](𝑡) and**

𝑑𝑓(𝑡) 𝑑𝑡⁄ .
**Note 2: The definition is given as a derivative with respect to time,**

if, for example, the function depended on 𝑥, we would have
𝑓[�](𝑥), the derivative with respect to 𝑥.


**Derivative Sum Rule**

𝒅[𝒇(𝒕) + 𝒈(𝒕)]

= 𝒇[�](𝒕) + 𝒈[�](𝒕)
𝒅𝒕

**Description – This equation defines the sum rule for two functions**

of a single variable, 𝑓(𝑡) and 𝑔(𝑡), which are added together.



- The product rule gives us a way of finding the derivative of

two functions of a single variable multiplied together.



- Listed below are some important derivatives to know. Note

that 𝑛 represents any constant value and 𝑡 is the considered the
variable for these examples

𝑑
𝑑𝑡 [(𝑛) = 0]

𝑑
𝑑𝑡 [(𝑡][�][) = 𝑛𝑡][���]

𝑑
𝑑𝑡 [(sin 𝑛𝑡) = 𝑛cos 𝑛𝑡]

𝑑
𝑑𝑡 [(cos 𝑛𝑡) = −𝑛sin 𝑛𝑡]

𝑑
𝑑𝑡 [(𝑒][��][) = 𝑛𝑒][��]


**Product Rule**

𝒅[𝒇(𝒕)𝒈(𝒕)]

= 𝒇[�](𝒕)𝒈(𝒕) + 𝒇(𝒕)𝒈[�](𝒕)
𝒅𝒕

**Description – This equation defines the product rule for two**

functions of a single variable, 𝑓(𝑡) and 𝑔(𝑡), which are
multiplied together.



- We find higher order derivatives by taking consecutive

derivatives of a function.

��

**_First derivative: 𝑥[�](𝑡) =_**

��

�

**_Second derivative: 𝑥[��](𝑡) =_**

�� [𝑥][�][(𝑡)]

�

**_Third derivative: 𝑥[���](𝑡) =_**

�� [𝑥][��][(𝑡)][, etc. ]


-----

#### A.1 – Definition of the Derivative 

**Consider: How do we quantify the rate of change of a quantity?**

HE RATE OF CHANGE OF VARIABLES CAN be a very important quantity in science and engineering. In Physics,
the prototypical example is the relationship between position and velocity. Although this relationship is explored in
detail in Unit 105, we will now use this relationship to describe how differences are related to derivatives.

# T

Assume that a car is at position 𝑥= 5 𝑚 at 𝑡= 2 𝑠 and at 𝑥= 12 𝑚 when 𝑡= 7 𝑠. We can say that the car as moved

∆𝑥= 12 𝑚−5 𝑚= 7 𝑚 (A-1)
in
∆𝑡= 7 𝑠−2 𝑠= 5 𝑠. (A-2)

Therefore, the car has moved seven meters along the positive x-axis in five seconds. In order to get the average velocity, we
take the displacement of the car and divide it by the time, as

v�⃗��� = [∆x�⃗]∆t [= 7 𝑚𝚤̂]5 𝑠 [= 1.4 𝑚𝑠]⁄ 𝑥�. (A-3)

If you have not yet explored vector relationships in Physics, just realize
that the arrow over the 𝑣 and 𝑥 above denote that they are vector quantities
(quantities with magnitude and direction) and that 𝑥� tells us that the
direction is along the x-axis.
Equation A-3 says that, on average, the car was moving 1.4 meters for
every second that passes. This does not mean that the car was moving 1.4
m/s throughout the entire five second interval we are exploring – only that
its _average velocity over that time was 1.4 m/s. Figure A-1 shows the_
position of the car as a function of time with points P and Q representing
the car’s initial and final position (5 m and 12 m), respectively.
Graphically, the slope of the line connecting points P and Q represents the
average velocity of the car. That is to say the slope of this line represents
the average rate of change of the position with respect to time.
What if we want to know the speed of the car exactly at point P? The
average value as depicted in Figure A-1 doesn’t help us. However, what if
we knew the slope of the line representing the car’s motion at exactly point **Figure A-1. Position of the car as a function of**

P? Then, instead of **time.**
having the average
slope between two points, we would have the slope (rate of change) of
the position at point P. To be most specific, what we need to do is find
the tangent line to the parth at point P, and then the slope of this tangent
line would be the rate of change at that point. In our current example,
this would represent the **_instantaneous velocity of the car at point P._**
Figure A-2 shows such a tangent line at point P. Please note that the
slope of the tangent line is NOT equal to the slope of the line connecting
P and Q, meaning the speed at this point is NOT the same as the average
speed.
We know how to find slopes of straight lines – change along y-axis
divided by change along x-axis. In a very general sense, we can rewrite
the slope as the value of the function at point Q (which happens at time

**Figure A-2. Position of the car as a function of**
**time.** 𝑡�) minus the value of the function at point P (which happens at time

𝑡�), divided by the change in time (change along the x-axis):


slope = [𝑓�𝑡][�][�−𝑓(𝑡][�][)]. (A-4)

∆𝑡

In order to get to point Q, the car must start at point P and then move along the path for the time ∆𝑡. Therefore, we could
write the position at point Q as 𝑓�𝑡��= 𝑓�𝑡� + ∆𝑡�. Therefore, we can rewrite this slope equation as


-----

slope = [𝑓�𝑡][�] [+ ∆𝑡�−𝑓(𝑡][�][)]. (A-5)

∆𝑡

Again, look at Figures A-1 and A-2. If we were to slowly move the final position closer to the initial position, the average
velocity (slope in Figure A-1) would get closer and closer to the instantaneous velocity shown in Figure A-2. That is to say
that in the limit as ∆𝑡→0, the average slope will tend to the slope exactly at position P. In this limit, we call this rate of
change the derivative of the function 𝑓, which can be written

𝑑 𝑓�𝑡� + ∆𝑡�−𝑓(𝑡�). (A-6)
𝑑𝑡 [𝑓(𝑡) = 𝑓′(𝑡) = lim]∆�→� ∆𝑡

The notations
𝑑
(A-7)
𝑑𝑡 [𝑓(𝑡) = 𝑓][�][(𝑡),]

are both called the derivative of 𝒇(𝒕) with respect to time. The two notations are completely interchangeable. The choice of
notation is by user choice and often depends on how the notation fits with the remainder of the problem/derivation/solutions,
etc.
In this section, we found the derivative in relation to how position changes with time. The same idea could be used for
any set of axes, be they positions, velocities, forces, times, positions, etc. Therefore, in general, we tend to write the general
definition of the derivative in terms of a function which depends on 𝑡, and denote the differences between the initial and final
positions as ℎ. Therefore, a more general equation for the definition of the derivative is

𝑓(𝑡+ ℎ) −𝑓(𝑡)

𝑓[�](𝑡) = [𝑑𝑓(𝑡)] = lim (A-8)

𝑑𝑡 �→� ℎ


**Definition of the Derivative**


𝒇[�](𝒕) = [𝒅𝒇(𝒕)] = 𝐥𝐢𝐦

𝒅𝒕 𝒉→𝟎


𝒇(𝒕+ 𝒉) −𝒇(𝒕)

𝒉


**Description – For a function, 𝑓(𝑡), this equation defines the**

derivative of the function, 𝑓[�](𝑡) in terms of the limit as a
dummy variable, ℎ, goes to zero.
**Note 1: Two common notations for a derivative are 𝑓[�](𝑡) and**

𝑑𝑓(𝑡) 𝑑𝑡⁄ .
**Note 2: The definition is given as a derivative with respect to time,**

if, for example, the function depended on 𝑥, we would have
𝑓[�](𝑥), the derivative with respect to 𝑥.


#### A.2 – The derivative of a constant

**Consider: Since a constant doesn’t change, what is its derivative?**

As our first specific example of a derivative, consider a constant function

𝑓(𝑡) = 3, (A-9)

Since the value of this function does not change with our variable (t in this case), we would expect the rate of change
(derivative) to be zero. In order to see this specifically, we can use the definition of the derivative (equation A-8):

𝑓(𝑡+ ℎ) −𝑓(𝑡)

𝑓[�](𝑡) = lim . (A-10)

�→� ℎ

Remember that as a function, 𝑓(𝑡+ ℎ) says to take the form of the function and replace every 𝑡 with 𝑡+ ℎ. In our current
case, we have no 𝑡′𝑠 in the function, therefore 𝑓(𝑡+ ℎ) = 3. So, we can then write


-----

0
(A-11)
ℎ[.]


𝑓[�](𝑡) = lim

�→�


3 −3

= lim
ℎ �→�


The quantity 0 ℎ⁄ equals 0 for any infinitesimally sized value of h. Therefore, as ℎ approaches 0, the entire derivative
remains zero.

**The derivative of any constant function 𝒇(𝒕) = 𝒏 is zero,**

**regardless of the value of the constant:**

𝒇’(𝒏) = 𝟎.

We can also consider the derivative of a constant function by looking at
a graph and thinking about the slope (remember, the derivative is a slope
of a function at a given point). Figure A-3 shows a graph of 𝑓(𝑡) = 3.
Since the value of the function on the y-axis does not change throughout
the entire graph, ∆𝑦= 0 around any possible point; therefore the slope
of this line is zero everywhere – which is to say the derivative of this
function is zero everywhere. This is the same result we found from the
definition of the derivative above. **Figure A-3. Graph of a constant function 𝒇(𝒕).**

#### A.3 – Some important derivatives

**Consider: What are some derivatives we need for Physics I and II?**

In principle, you can use the definition of the derivative to find the derivative of any function. However, in practice, this can
become very tedious. Luckily, when the definition is used to determine the form of derivatives for entire classes of functions
– meaning functions that have the same general form – we can the apply these general forms to individual problems. In this
section, we will show how to use the definition of the derivative on a non-constant function and then give the general results
for functions which we will need for Physics I and Physics II.
In general for our classes, you should be able to recognize the general form of a function, determine the form of the
derivative and apply that derivative to the function. The examples at the end of this section will help you see how to
accomplish this task.
To apply the definition of the derivative, we will now consider the function 𝑓(𝑡) = 𝑡[�]. Applying this to the definition of
the derivative, we find

(𝑡+ ℎ)[�] −𝑡[�] (𝑡[�] + 3𝑡[�]ℎ+ 3ℎ[�]𝑡+ ℎ[�]) −𝑡[�]

𝑓[�](𝑡) = lim = lim . (A-12)

�→� ℎ �→� ℎ

Noting that 𝑡[�] cancels, we can simply this result as

3𝑡[�]ℎ+ 3ℎ[�]𝑡+ ℎ[�]

𝑓[�](𝑡) = lim = lim (A-13)

�→� ℎ �→� [3𝑡][�] [+ 3ℎ𝑡+ ℎ][�][.]

Notice that the second two terms in this equation both contain an h, so that when we take the limit ℎ→0, those entire terms
will go to zero, leaving

𝑓[�](𝑡) = 3𝑡[�]. (A-14)

Notice that the original exponent (3) became the leading factor of our derivative and that the value of the exponent in the
derivative is decreased by one from the original. If fact, this is a feature of all polynomial derivatives, which can be written
succinctly as
𝑑
(A-15)
𝑑𝑡 [(𝑡][�][) = 𝑛𝑡][���][,]

where 𝑛 is the original exponent. Please note that the exponent does not need to be an integer.


-----

Example A - 1 **Single Polynomial Derivative**

What is the derivative of the following function with respect
to time?

𝑥(𝑡) = 𝑡[�.��] ?

**Solution:**

This problem asks us to find the derivative of a polynomial
function with a non-integer exponent. In order to do this we
use the general form of the polynomial derivative, noting that
in this case 𝑛= 3.14. Therefore


𝑑𝑥(𝑡)

= 𝑛𝑡[���] = (3.14)𝑡[�.����],
𝑑𝑡

which gives us


𝑑𝑥(𝑡)

= 3.14𝑡 [�.��].
𝑑𝑡

The value of this derivative could then be found for any t.


There is one special case of polynomial derivatives we must be careful with. Linear terms such as 𝑡 (or 𝑥 or 𝑦, etc.), are
actually of the form 𝑡[�]. Taking the derivative of these linear functions then leaves us with 1(𝑡[�]) after we reduce the
exponent by one. Since any function raised to the zeroth power is by definition 1, the entire derivative becomes 1. Therefore

𝑑

(A-16)

𝑑𝑡 [(𝑡) = 𝑑𝑡]𝑑𝑡 [= 1,]

which works for any variable.
The same process as above could be used for other derivatives. For simplicity, we will not go through the derivation of
each derivative we need for Physics using the definition of the derivative, but rather, we will give the results and invite you to
go back and check how these come about if you are interested. The general forms of derivatives needed in Physics I are

**Derivatives of sine and cosine:**

𝑑
(A-17)
𝑑𝑡 [(sin 𝑛𝑡) = 𝑛cos 𝑛𝑡,]

and

𝑑
(A-18)
𝑑𝑡 [(cos 𝑛𝑡) = −𝑛sin 𝑛𝑡,]

where 𝑛 is a constant with units inverse to 𝑡, since the argument of a trigonometric function should be unitless. If 𝑡 is time,
the units of 𝑛 would be 𝑡[��]. The equations above could be written in terms of a position variable 𝑥 with units of meters. In
this case, 𝑛 would have units of meters[-1], or 𝑚[��].

**Derivatives of exponential functions:**

𝑑
(A-19)
𝑑𝑡 [(𝑒][��][) = 𝑛𝑒][��][,]

where, again, 𝑛 is a constant with units inverse to 𝑡 so that the argument of the exponential function is unitless.

#### A.4 – The value of a derivative at a specific point

**Consider: How do we deal with derivatives of more than one function?**

The derivatives described in section A.3 above may be valid over large ranges of the variable 𝑡. In order to find the value of a
derivative at a specific point, it is very important to find the functional form of the derivative first and then plug in the
**_value for 𝒕._**
As an example, let’s again consider the function 𝑓(𝑡) = 𝑡[�]. What are the values of the 𝑓(𝑡) and its derivative at 𝑡=
2.5? We can first find the value of the function by directly inserting the value as


-----

𝑓(2.5) = (2.5)[�] = 15.625. (A-20)

In order to find the value of the derivative of 𝑓(𝑡) we must go back to the original function first:

𝑓[�](𝑡) = 3𝑡[�] → 𝑓[�](2.5) = 3(2.5)[�] = 18.75. (A-21)

Please note: if we had attempted to take the derivative of 𝑓(𝑡) after plugging in the value, we would assume (incorrectly) that
the derivative is zero, since the derivative of 𝑓(2.5) = 15.625 (as a constant) would be zero.


Example A – 2: **The value of a derivative**

Find the value of the function

𝑓(𝑥) = 𝑒 [�/�]

and its derivative at 𝑥= 1.2.

**Solution:**

This problem asks us to find the numerical value of a function
and its derivative at a specific value. Noting that we already
have the functional form of the original function, we must
first find the form of its derivative. We can do this by noting
that the constant in the argument of our function is 𝑛= 1 2⁄ .


We can now use the value of x given to find

𝑓(1.2) = 𝑒[�.��]⁄ = 1.82,

and

⁄
𝑓[�](1.2) = [𝑒][�.��] = 0.91.

2


Therefore, using the derivative forms found in the last
section

⁄

𝑓[�](𝑥) = 𝑛𝑒[��] = [1]

2 [𝑒][��] [= 𝑒][��]2 [.]


#### A.5 – Some important properties

**Consider: What are some ways to manipulate derivatives?**

**Multiplicative constants:**

A constant multiplying a function for which we want to take the derivative can be “pulled out” of the derivative:

𝑑

(A-22)

𝑑𝑡 [[𝑎𝑓(𝑡)] = 𝑎�𝑑]𝑑𝑡 [𝑓(𝑡)�= 𝑎𝑑𝑓(𝑡)]𝑑𝑡 [,]


where 𝑎 is a constant.

**The Sum Rule:**

When two functions are added together, the derivative of the sum is the sum of the derivatives:

𝑑
(A-23)
𝑑𝑡 [[𝑓(𝑡) + 𝑔(𝑡)] = 𝑓][�][(𝑡) + 𝑔][�][(𝑡).]


**Derivative Sum Rule**

𝒅[𝒇(𝒕) + 𝒈(𝒕)]

= 𝒇[�](𝒕) + 𝒈[�](𝒕)
𝒅𝒕

**Description – This equation defines the sum rule for two**

functions of a single variable, 𝑓(𝑡) and 𝑔(𝑡), which are
added together.


-----

**The Product Rule:**

When two functions are multiplied together, the derivative of the product follows the product rule:

𝑑
𝑑𝑡 [[𝑓(𝑡)𝑔(𝑡)] = 𝑓][�][(𝑡)𝑔(𝑡) + 𝑓(𝑡)𝑔][�][(𝑡)]

.


(A-24)


**Product Rule**

𝒅[𝒇(𝒕)𝒈(𝒕)]

= 𝒇[�](𝒕)𝒈(𝒕) + 𝒇(𝒕)𝒈[�](𝒕)
𝒅𝒕

**Description – This equation defines the product rule for**

two functions of a single variable, 𝑓(𝑡) and 𝑔(𝑡), which
are multiplied together.


**Higher order derivatives:**

The derivatives we found in this Appendix so far are technically 1[st] derivatives, that is, they are derivatives of an original
function. The term higher order derivative is used when we are finding derivatives of derivatives. For example, to find the
**_second derivative of a function, you take the derivative of the first derivative. If you want the third derivative, you take the_**
derivative of the second derivative of a function. Finding higher order derivatives is relatively straightforward as long as you
follow this chain. So, for a second derivative, we would, in general, write

𝑑[�]𝑓

[𝑑] (A-25)
𝑑𝑡[�] [=] 𝑑𝑡 [�𝑑𝑓]𝑑𝑡 [�,]

where the symbol 𝑑[�]𝑓𝑑𝑡⁄ [�] is used to denote the second derivative. Similarly, 𝑑[�]𝑓𝑑𝑡⁄ [�] would represent the third derivative.
Higher order derivatives can also be noted using the prime notation: 𝑓′′(𝑡) would be the second derivative of 𝑓 with respect
to 𝑡 and 𝑓[���](𝑡) would be the third derivative with respect to 𝑡, and so on.


Example A - 3 **Polynomial Derivative with Sums**

Find the value of the function

𝑥(𝑡) = 4𝑡[�] + 2𝑡+ 1

and its first derivative at 𝑡= 1.2.

**Solution:**

This problem asks us to find the numerical value of a function
and its derivative at a specific time. In order to do this, we
must first find the derivative of the function with respect to
time noting that this function has both multiplicative constants
and a sum of functions.

We can find the first term in 𝑥(𝑡) by “pulling out” the 4 and
finding the derivative of 𝑡[�] as

𝑑 [𝑑]
𝑑𝑡 [4𝑡][�] [= 4] 𝑑𝑡 [𝑡][�] [= 4(2𝑡).]

Similarly, we can find the derivative of the second and third
terms as


𝑑 [𝑑]
𝑑𝑡 [(2𝑡) = 2] 𝑑𝑡 [(𝑡) = 2(1𝑡][�][) = 2(1),]

and

𝑑
𝑑𝑡 [(1) = 0,]

respectfully.

We can now use the Sum Rule to put each term back
together as


𝑥[�](𝑡) = 4(2𝑡) + 2(1) + 0 = 8𝑡+ 2.

We can now find the value of the function and its
derivative by plugging in the requested value for 𝑡 into
each respective equation. This gives us

𝑥(1.2) = 4(1.2)[�] + 2(1.2) + 1 = 9.16,

and

𝑥[�](1.2) = 8(1.2) + 2 = 11.6.


-----

Example A - 4 **The product rule**

Find the value of the derivative of

𝑧(𝑡) = (8𝑡[�])(5𝑒[��])

at 𝑡= 2.5.

**Solution:**

This problem asks us to find the numerical value of a
derivative where the function is composed of two separate
functions multiplied together. In order to do this, we will use
the chain rule.

First, we note that the 𝑧(𝑡) can be written as the product of
two functions

𝑓(𝑡) = 8𝑡[�]
and

𝑔(𝑡) = 5𝑒[��].


We can then note that the derivative of 𝑧(𝑡) will be found
using the product rule:

𝑧′(𝑡) = 𝑓[�](𝑡)𝑔(𝑡) + 𝑓(𝑡)𝑔[�](𝑡).

Therefore, we must first find the derivatives of 𝑓(𝑡) and
𝑔(𝑡) as

𝑓[�](𝑡) = 8(2𝑡) = 16𝑡
and

𝑔[�](𝑡) = 5(5𝑒[��]) = 25𝑒[��].

We can now put the entire derivative together:

𝑧[�](𝑡) = 16𝑡(5𝑒[��]) + 8𝑡[�](25𝑒[��]) = 40(5𝑡[�] + 2𝑡)(𝑒[��]).

Finally, using the value of 2.5 for t, we find

𝑧[�](𝑡) = 40�5(2.5[�]) + 2(2.5)�(𝑒[��.�]) = 3.89 𝑥10[�].


Example A - 5 **First, second and third derivatives**

Find the value of the first three derivatives of

𝑤(𝑡) = 3𝑡[�] + 𝑡[��]

at 𝑡= 1.

**Solution:**

This problem asks us to find the numerical value of
derivatives of a function. We start by finding the functional
form of the first three derivatives, using each derivative as the
seed for the next higher state:

𝑤[�](𝑡) = 3(3𝑡[�]) + (−1)𝑡[��] = 9𝑡[�] −𝑡[��],

𝑤[��](𝑡) = 9(2𝑡) −(−2)(𝑡[��]) = 18𝑡+ 2𝑡[��]

𝑤[���](𝑡) = 18 + 2(−3)(𝑡[��]) = 18 −6𝑡[��].


Please note that the derivatives with negative exponents
followed the same form as those for positive exponents;
for example, bringing down the original exponent and
then subtracting one in the exponent for the new value:

𝑑
𝑑𝑡 [(𝑡][��][) = −2(𝑡][����][) = −2𝑡][��][.]

We can now insert 𝑡= 1 in each of these derivatives to
find

𝑤[�](1) = 9(1[�]) −1[��] = 8,

𝑤[��](1) = 18(1) −(−2)(1[��]) = 20,

𝑤[���](1) = 18 −6(1[��]) = 12.

Therefore, the first derivative is 8, the second derivative
is 20 and the third derivative is 12.


-----

