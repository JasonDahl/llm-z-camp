### – When Fluids Move, Things Change
## 132


_We continue our discussion of fluids with the idea of ideal fluid flow. Ideal fluid flow is often a good approximation as long_
_as the fluid is incompressible (liquid), but not too thick – like water – and as long as the flow is steady. In order to fully_
_describe the flow of ideal fluids, we will discover two important conservation laws – the continuity equation and Bernoulli’s_
_equation._

#### The Bare Essentials

  - An ideal fluid is a fluid which

      - is incompressible,

      - exhibits steady, non-rotational flow,

      - ignores viscosity.
Important: Since an ideal fluid must be incompressible, this cannot include gasses!

  - The continuity equation tells us that the flow rate of an ideal fluid is constant:


**Continuity Equation**

𝑸= 𝒗𝑨= 𝒄𝒐𝒏𝒔𝒕𝒂𝒏𝒕

⇒ 𝒗𝟏𝑨𝟏 = 𝒗𝟐𝑨𝟐 (132-1)

**Description: The volume flow rate, Q, of an ideal fluid is equal to**

the velocity of the fluid multiplied by the cross-sectional area of
the flow. The continuity equation states that the volume flow rate
of an ideal fluid is constant, that is, the flow rate in one area of the
flow, must be the same as another area of the flow
**Note 1: This equation only holds for incompressible fluids.**
**Note 2: The units for volume flow rate is 𝑚[�]/𝑠.**



- **Bernoulli’s Equation is the conservation of energy for ideal fluid flow:**


**Bernoulli’s Equation**

𝑷𝟏 + [𝟏]𝟐 [𝝆𝒗]𝟐[𝟏] + 𝝆𝒈𝒛𝟏 = 𝑷𝟐 + [𝟏]𝟐 [𝝆𝒗]𝟐[𝟐] + 𝝆𝒈𝒛𝟐


Eq. 132-8


**Description: Bernoulli’s equation states that the sum of the pressure**

in a fluid, kinetic energy density and gravitational potential energy
density in a fluid is constant for the entire fluid flow. That is to
say, this combination must be the same at two points along the
flow, point 1 and point 2.
**Note: This only holds for ideal fluids.**



- It is often necessary to combine the continuity equation and Bernoulli’s equation when solving ideal fluid problems.


-----

#### 132-1: Ideal Fluids


**Consider: What simplifications do we have to make to understand the**
_basics of moving fluids?_

HE FLUID DYNAMICS OF REAL FLUIDS is very complicated. In fact, it is not a stretch to say that the scientists
do not fully understand fluid motion except for under relatively simple situations.  Once things start to get
complicated, very good approximations using numerical simulations (a field known as computational fluid dynamics)

# T

must be used. Even if there are closed form (equation-like) solutions, the path to these solutions become incredibly complex
very quickly. In unit 203, we will start to explore just a few of the complexities of real fluids, but for now we will make a
number of assumptions for an ideal fluid.
Our ideal fluids will essentially neglect friction and assume a very steady flow. Specifically, an ideal fluid exhibits the
following four characteristics:

1. The fluid is incompressible. Here we assume that no matter how large a pressure placed on the fluids, its density

does not change. That is, for a given mass of a fluid, its volume will remain constant if it is incompressible.
2. The fluid is non-viscous. Viscosity is a result of friction inside the fluid and with the fluid’s container. In a non
viscous flow, both internal and external friction are considered negligible
3. The fluid flow is irrotational. The fluid flow does not have angular momentum about any point.
4. The fluid flow is **laminar. In laminar flow, particles in a fluid move in smooth layers as opposed to turbulent**

(jumbled) motion. Laminar flow is not actually a requirement for an ideal fluid, but actually a property of ideal
fluids.

#### 132-2: The Continuity Equation

**Consider: How does changing the area of fluid flow change the flow**
_(i.e., why is the spray harder when I use my thumb on a garden hose?)_

Consider an ideal fluid moving through a confined space, such as a pipe. Since an ideal fluid is incompressible, we know
that the same volume of fluid must pass each point in the pipe in a given period of time – otherwise some of the fluid would
have had either appeared from nowhere, or completely disappeared. For a straight pipe with a constant diameter, this really
tells us nothing new. However, now consider what happens if we allow the pipe to taper down so that the diameter
decreases. The cross-sectional area of the pipe will get smaller, and since we still need to have the same volume pass each
point in a given time, the fluid must move faster. Many of you have experienced this by placing your thumb over the end of
a hose and noticing that the water flies out of the hose at a much greater speed than it was when the hose was open.
We can make the description of this process more specific by defining the volume flow rate, Q, as the rate at which a
given volume of fluid passes by a point in the pipe. Since Q is the rate of flow of a volume, its units must be m[3]/s. Above,
we noticed that as the cross-sectional area of a pipe decreased the speed of the fluid must increase – an inverse relationship.
Also, notice that the units of speed (m/s), multiplied by the cross-sectional area of the pipe (m[2]), also has the units of m[3]/s.
This gives us an intuitive way to define the volume flow rate, 𝑄= 𝑣𝐴. In addition, since we know from our initial discussion
in this section that the amount of fluid that passes a point in a given period of time must be constant, we can also say that the
volume flow rate in a confined flow must be constant, i.e. that it must be the same at any two points in the flow. This
relationship is known as the continuity equation.


**Continuity Equation**

𝑸= 𝒗𝑨= 𝒄𝒐𝒏𝒔𝒕𝒂𝒏𝒕

⇒ 𝒗𝟏𝑨𝟏 = 𝒗𝟐𝑨𝟐 (132-1)

**Description: The volume flow rate, Q, of an ideal fluid is equal to**

the velocity of the fluid multiplied by the cross-sectional area of
the flow. The continuity equation states that the volume flow rate
of an ideal fluid is constant, that is, the flow rate in one area of the
flow, must be the same as another area of the flow
**Note 1: This equation only holds for incompressible fluids.**
**Note 2: The units for volume flow rate is 𝑚[�]/𝑠.**


-----

**Figure 132-1. The characteristic pipe used to describe the continuity equation. Since the diameter of the**
**pipe changes and the volume flow rate must remain constant, the velocity of the fluid must also change.**


Example 132-1. Fire away!

If water from a garden hose typically emerges from the
spout at 1 m/s, how fast will the water flow if you cover
90% of the opening with your thumb?

**Solution:**

This is a direct application of the continuity principle.
The key words to determine this are that we have a
relationship between two areas (𝐴� = 𝐴 and 𝐴� =
0.1𝐴), and we are given one speed (𝑣� = 1 𝑚/𝑠).
Therefore, we start with the continuity equation and
substitute in our values:


#### 132-3: Bernoulli’s Equation

**Consider: What is the relationship between speed, pressure and height**
_for an ideal fluid?_

We have spent quite a bit of time in physics talking about the conservation of energy. There is no reason to believe that the
conservation of energy shouldn’t hold for fluids; however, since a fluid doesn’t have a well defined shape and the fluid can
flow, trying to define exactly what mass we are talking about for kinetic energy or potential energy equations can be difficult.
Bernoulli’s Equation is going to give us a relatively straightforward way to do energy conservation on a moving fluid.
Consider again our example above where you put your thumb over the opening of a garden hose, causing the water to
leave the hose at a much higher speed than it would have if your thumb were not in the way. In order to do this, you have to
exert a considerable amount of force on the water leaving the hose to keep your thumb in place. In other words, you are
doing work against water as it passes your thumb. In fact, if you are pushing against the water with a force F, as an amount
of water x passes your thumb, you do an amount of work given by


-----

𝑊= 𝐹[⃗] ⋅∆𝑥⃗= −𝐹∆𝑥. (132-2)

The last term of the above equation is negative because you are pushing into the hose while the water is leaving the hose, so
the angle between your force and the direction of the water flow is 180 degrees, leading to negative work. It is also important
to note that if you are experiencing negative work, then the water is experiencing positive work of the same magnitude 𝑊=
𝐹∆𝑥.
Ok, now that we know the work being done on the system to constrict flow at one point, let’s try to relate this to the
pressure in the water. We know that the force a fluid exerts is related to its pressure by 𝐹= 𝑃𝐴, where A is the area over
which the fluids acts. If we now relate this back to work done, we find

𝑊= 𝐹∆𝑥= 𝑃𝐴∆x = 𝑃𝑉, (132-3)

where we have used the fact that the cross-sectional area of a fluid extended over a distance ∆x defines a volume of fluid.
We are now ready to apply the conservation of energy to our fluid. In general, the conservation of energy with work due
to external forces can be written

𝑊�� = ∆𝐾+ ∆𝑉, (132-4)

where 𝑊�� is the work done on the fluid between points 2 and 1, ∆𝐾 is the change in kinetic energy of the water between the
two points and ∆𝑉 is the change in potential energy between the same two points.
Consider the situation shown in Figure 132-2 of water flowing through a pipe with varying pipe diameter and height. If
we apply equation 132-3 above to this very general situation (equation 132-4), we find
−(𝑃� −𝑃�)𝑉= [1]2 [𝑚𝑣][�]� − [1]2 [𝑚𝑣][�]� + 𝑚𝑔𝑧� −𝑚𝑔𝑧�. (132-5)

Each of the mass terms in this equation can be replaced with 𝑚= 𝜌𝑉, the density of the water multiplied by the volume,
giving us
−(𝑃� −𝑃�)𝑉= [1]2 [𝜌𝑉𝑣][�]� − [1]2 [𝜌𝑉𝑣][�]� + 𝜌𝑉𝑔𝑧� −𝜌𝑉𝑔𝑧�. (132-6)

Every term in this equation has a volume term, V, so if we divide both sides of the equation by the volume, we find
−(𝑃� −𝑃�) = [1]2 [𝜌𝑣][�]� − [1]2 [𝜌𝑣][�]� + 𝜌𝑔𝑧� −𝜌𝑔𝑧�, (132-7)

which can be rearranged to
𝑃� + [1]2 [𝜌𝑣][�]� + 𝜌𝑔𝑧� = 𝑃� + [1]2 [𝜌𝑣][�]� + 𝜌𝑔𝑧�. (132-8)

This equation is known as Bernoulli’s Equation and is a very powerful extension of the conservation of energy for ideal
fluids.


**Bernoulli’s Equation**

𝑷𝟏 + [𝟏]𝟐 [𝝆𝒗]𝟐[𝟏] + 𝝆𝒈𝒛𝟏 = 𝑷𝟐 + [𝟏]𝟐 [𝝆𝒗]𝟐[𝟐] + 𝝆𝒈𝒛𝟐


(132-8)


**Description: Bernoulli’s equation states that the sum of the pressure**

in a fluid, kinetic energy density and gravitational potential energy
density in a fluid is constant for the entire fluid flow. That is to
say, this combination must be the same at two points along the
flow, point 1 and point 2.
**Note: This only holds for ideal fluids.**


-----

##### x2 = v2 Δ t

 p
2

##### A2 z 2


##### A1


##### z 1


**Figure 132-2. Representation of an ideal fluid flowing through a pipe that changes height and diameter. In**
**order to solve problems of this type, both the continuity equation and Bernoulli’s equations must be used**
**together.**

It is very important to note that the continuity equation and Bernoulli’s equation often have to be used in tandem with
each other to solve problems. That is, often, the continuity equation must be used to find the fluid speed at a second point if
you know the speed at one point and how the cross-sectional areas change. Then, using information about the two points,
you can then use Bernoulli’s Equation to relate pressures, etc. This is just one of many possible examples of how the two
may be used together.


-----

Extension: How far?

Where will the two streams land relative to the bottom of
the cup?

**Solution:**

This is just a projectile motion question. The water will
leave the cup moving horizontally with the speeds found
in the first part of this example. In each case, we must
first find the time it takes for the water to reach the ground
using the constant acceleration kinematics equation in the
z-direction, and then find the distance traveled using the
constant acceleration kinematics equation in the xdirection.

In general:

𝑧� = 𝑧� + 𝑣�,�𝑡+ [1]2 [𝑎][�][𝑡][�][,]

𝑥� = 𝑥� + 𝑣�,�𝑡.

For each case, the initial speed in the z-direction is zero,
and we can take both the initial height to be zero and the
initial position in the x-direction to be zero.


−0.14 𝑚= − [1]

2 [(9.8 𝑚/𝑠][�][)𝑡][�] [⇒𝑡= 0.17 𝑠]

𝑥� = (0.90 𝑚/𝑠)(0.17 𝑠) = 0.15 𝑚.

The stream that started 4 cm below the top of the cup will
reach the ground 15 cm from the bottom of the cup and the
stream that started higher (1 cm below the top) will land
only 8 cm from the cup.

If you decide the try this yourself, make sure you offset the
holes a little bit (so they aren’t on top of each other),
because the streams will cross on their way down!!


**For the stream 1 cm below the top of the cup: the final**
height will be -17 cm (remember, the cup is 18 cm tall.

−0.17 𝑚= − [1]

2 [(9.8 𝑚/𝑠][�][)𝑡][�] [⇒𝑡= 0.18 𝑠]

𝑥� = (0.45 𝑚/𝑠)(0.18 𝑠) = 0.08 𝑚.

**For the stream 4 cm below the top of the cup: the final**
height will be -14 cm.


#### 132-4: When Fluids Move, Things Change

So, what changes when fluids move? Bernoulli’s Equation describes how the speed, pressure and height of a fluid are
related. First, let’s consider fluids moving at a constant height. Bernoulli’s Equation then says
𝑃� + [1]2 [𝜌𝑣][�]� = 𝑃� + [1]2 [𝜌𝑣][�]�. (132-9)

Inspecting this equation, you can see that in a region where the speed of the fluid is greater, the pressure must be less. This
has some stark consequences. First, airplane wings are designed so that air moves over the top of the wing faster than the air
moves over the bottom of the wing. Therefore, the pressure over the top of the wing is smaller than the pressure on the
bottom, leading to a net force upward known as lift. Although air is not a very ideal fluid, this general result for lift winds up
working in the current case.
Another important consequence of this result is important for boating safety. Consider two boats relatively close to each
other. As the water trying to flow between the two boats becomes confined, it must flow faster than the water flowing around
the outside of the boats (continuity equation). Since the water between the boats is flowing faster, the pressure in the water is
lower and the boats experience a net force _towards each other. This force (very similar to lift but horizontal) must be_
carefully considered when navigating in close waters.
Let’s now consider what happens in a pipe that maintains it diameter, but changes height, such as going up a hill. Since
the diameter of the pipe is not changing, the speed of the fluid will remain constant (continuity equation). In this case,
Bernoulli’s equation reduces to

𝑃� + 𝜌𝑔𝑧� = 𝑃� + 𝜌𝑔𝑧�, (132-10)

which says that the water at the higher position will have less pressure.  You may have experienced this effect where the
water in a shower on the second floor of a house has less pressure than a very similar shower on the first floor.
So, yes, things change when fluids start moving. In fact, we’ve only begun to touch the surface of fluid effects in this
chapter on ideal fluids. In the next chapter, we will see more effects of moving fluids when we relax the requirement that the
fluids be ideal.


-----

