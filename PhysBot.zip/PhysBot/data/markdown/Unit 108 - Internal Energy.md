### – Internal Energy
## 108


_All matter contains energy in the random motions and interactions of its atoms and molecules. This internal energy can_
_be harnessed by changing the temperature of an object or changing the way the bonds interact. In this unit, we will_
_study these internal energies and their relationship to temperature and the other forms of energy we have studied to_
_date._

##### Integration of Ideas

    - The ideas of energy (unit 103) and especially kinetic energy (unit 105) are very important for this unit.


##### The Bare Essentials

- Temperature is defined in terms of the average translational

kinetic energy of a group of molecules.



- The change in thermal energy of a substance is linked to its

change in temperature.


**Definition of Temperature**

𝑲𝑲𝒂𝒂𝒂𝒂𝒂𝒂 = [𝟑]
𝟐𝟐 [𝒌][𝒌][𝒃][𝒃][𝑻][𝑻]


**Description – The equation defines the temperature, 𝑇𝑇, of a**

substance in relation to the average kinetic energy, 𝐾𝑎𝐾 𝑎𝑎 𝑎𝑎 𝑎,
of the particles that make up the substance.
**Note 1: 𝑘𝑘𝑏𝑏 is the Boltzmann constant and has value**

𝑘𝑘𝑏𝑏 = 1.381𝑥10𝑥 [−23] 𝐽𝐽⁄𝐾 = 8.617𝑥10𝑥 [−5] 𝑒𝑒𝑒 𝑒⁄𝐾
**Note 2:** 𝑇𝑇 must be measure in Kelvin.

- The internal energy, 𝑈𝑈, of a substance describes all of the
microscopic energy stored in motion and bonds. The internal
energy is composed of thermal energy and latent energy.

- The total thermal energy of a substance is more complicated
than the definition of temperature; however, for gases, the
thermal energy can be written precisely.


**Change in Thermal Energy**

𝚫𝚫𝑼𝑻𝑼 𝑻𝑻 𝑻 = 𝒎𝒎𝒎𝒎𝚫𝚫𝑻𝑻

**Description – This equation relates the change in thermal**

energy, Δ𝑈𝑇𝑈 𝑇ℎ, of a system to its mass, 𝑚𝑚, specific heat,
𝑐𝑐, and change in temperature, Δ𝑇𝑇.
**Note: Although technically Δ𝑇𝑇 should be in Kelvin, since**

the Kelvin and Celsius scales have the same gradations,
either can be used here.



- Latent energy describes how energy is stored between
molecules in a system (non-bond interactions and bonds)


**Thermal Energy of Gases**

𝑼𝑻𝑼 𝑻𝑻 𝑻 = 𝑵𝑵 [𝒇]
𝟐𝟐 [𝒌][𝒌][𝒃][𝒃][𝑻][𝑻]

**Description – This equation defines the thermal energy of a**

system in terms of the number of particles in the system,
𝑁𝑁, the degrees of freedom for the system, 𝑓𝑓, and the
energy for each degree of freedom, (1 2⁄ )𝑘𝑘𝑏𝑏𝑇𝑇.
**Note: 𝑓𝑓** = 3 for an ideal monatomic gas and simple solids;

𝑓𝑓 = 5 for diatomic gases including rotation and 𝑓𝑓 = 7
for diatomic gases including rotation and vibration.


**Latent Energy**

𝚫𝚫𝑼𝑳𝑼 𝑳𝑳𝑳 = ±𝒎𝒎𝒎𝒎

**Description – This equation defines the energy transfer,**

Δ𝑈𝐿𝑈 𝐿𝐿𝐿, of a material with mass, 𝑚𝑚, during a phase
transition. 𝐿𝐿 is the latent heat
**Note 1: For melting and freezing, you must use the latent**

heat of fusion, 𝐿𝑓𝐿 𝑓, and for boiling and condensing, you
must use the latent heat of vaporization, 𝐿𝑣𝐿 𝑣.
**Note 2: Δ𝑈𝐿𝑈** 𝐿𝐿𝐿 is positive for melting/vaporizing and

negative freezing/condensing.



- We can now solve conservation of energy problems including
kinetic energy, potential energies and internal energies.


-----

#### 108.1 – Temperature

**Consider: How can we precisely define temperature?**

OULD YOU RATHER SIT IN A ROOM at 68° F or 90° F? I think most people would respond 68°; however, my
point in asking this question is to show that we use the idea of temperature so often in everyday life that you
wouldn’t even blink when asked this question. As further examples, many of you just know that water freezes at

# W

0° C (32° F) and boils at 100° C (212° F), and couldn’t even say when you learned this; when cooking, meats should reach at
least 165° F so that bacteria won’t cause your digestive system troubles; we worry about the temperature of the earth and
whether humans are causing irrevocable damage to the environment by increasing its average temperature. However, just as
with other scientific concepts which have everyday meaning, we need a very precise definition in physics. This scientific
definition of temperature may be surprising to many of you since it doesn’t immediately correlate to our everyday
experience:

     - **_Temperature is a measure of the average kinetic energy of the particles making up a substance._**


Now, if you think about this, it isn’t a far stretch to connect our everyday
picture of temperature to this scientific definition. When you are
immersed in a nice warm bath, if the water molecules have, on average,
more kinetic energy than molecules in cooler water, this means that the
water molecules are bouncing off of your skin cells more often and with
more vigor. We can then connect this measure of how strongly the
water molecules ricochet from your skin as a measure of temperature. It
turns out that your skin is not a very good measure of temperature (see
the connection box on this page); however, as a first example, the warm
bath works.
We can make this more precise by considering mercury thermometers, such as those shown in Figure 108.1. In each of these
thermometers, a small capillary tub is filled with mercury – a hazardous

**Figure 108-1. A sample of mercury** metal that is a liquid at room temperature. Since the temperature of an
**thermometers.** object is a measure of the average kinetic energy of the particles, many

substances expand when the temperature is increased – which is true of
the mercury in the thermometer. When the thermometer is placed in an environment at a certain temperature, the particles of
the environment interact with the tube containing the mercury. Energy can be transferred either into or out of the mercury
(conservation of energy) until the average kinetic energy of the

**Connection: Temperature and your Body**

particles is the same. Thus, the temperature of the mercury will
equilibrate with the temperature of the environment. This

The human body is amazingly bad at measuring temperature.

process is called **_heat transfer and we will explore this more_**

When you place your hand on a surface, what you perceive as

later in the unit. temperature is really the rate at which thermal energy is
We are now ready to connect the scientific idea of entering or leaving your hand. Try this: Find two surfaces in
temperature to an equation. We know that the temperature of an the same room; one metal and one non-metal (the pages of
object will be proportional to the average kinetic energy of the this book will work). Place one hand on the metal surface and
particles inside the object. It turns out that it is very hard to one on the other surface. How does it feel? At room
come up with a general expression for all phases of matter; temperature, the metal probably feels cooler since it more

readily accepts heat from your hand. However, both surfaces

however, for gases and simple solids under everyday

are at the same temperature since they are in the same room!

circumstances, the temperature and kinetic energy are directly

You will also notice the same effect when you jump into a

proportional,

pool. Initially, the water feels quite cold because of the
temperature difference between your skin and the water.

𝐾𝐾𝑎𝑎𝑎𝑎𝑎𝑎 ∝𝑇𝑇, (108-1) However, after a short period of time, it will not feel nearly as

cool, because the temperature of your skin has decreased –

and we only need an experimentally determined constant of not because the temperature of the water has increased.
proportionality, known as the Boltzmann constant, 𝑘𝑘𝑏𝑏. It’s
important to mention that the term for average kinetic energy
above is only the translational kinetic energy of the substance. For simple, monatomic gases and simple solids, this always
works since rotational motion does not come into play for those substances. However, more complicated gases, including
diatomic gases as oxygen, rotational and vibrational energy complicate the situation. The same is true for liquids, where
there is an appreciable interaction between particles in the system. However, keeping this limitation in mind, the simple
definition of temperature below works well, and can even use to get gross estimates of more complicated gases.


-----

The SI unit of temperature is the Kelvin (K). We will discuss temperature units in just a bit, but for now you need to
know that the Kelvin scale is an absolute scale, meaning that zero Kelvin would mean zero kinetic energy, and that room
temperature on the Kelvin scale is about 293 K.


**Definition of Temperature**

𝑲𝑲𝒂𝒂𝒂𝒂𝒂𝒂 = [𝟑]
𝟐𝟐 [𝒌][𝒌][𝒃][𝒃][𝑻][𝑻]


**Description – The equation defines the temperature, 𝑇𝑇, of a**

substance in relation to the average kinetic energy, 𝐾𝑎𝐾 𝑎𝑎 𝑎𝑎 𝑎,
of the particles that make up the substance.
**Note 1: 𝑘𝑘𝑏𝑏 is the Boltzmann constant and has value**

𝑘𝑘𝑏𝑏 = 1.381𝑥10𝑥 [−23] 𝐽𝐽⁄𝐾 = 8.617𝑥10𝑥 [−5] 𝑒𝑒𝑒 𝑒⁄𝐾
**Note 2:** 𝑇𝑇 must be measure in Kelvin.

The average kinetic energy in the definition of temperature is found using the root mean square value for the velocity:

𝑣𝑣𝑟𝑟𝑟𝑟𝑟𝑟 = �(𝑣⃗∙𝑣𝑣 ⃗)𝑣 𝑎𝑎𝑎 𝑎𝑎𝑎𝑎 𝑎𝑎𝑎𝑎𝑎𝑎 𝑎 = �(𝑣𝑣[2])𝑎𝑎𝑎 𝑎𝑎𝑎𝑎 𝑎𝑎𝑎𝑎 𝑎𝑎 𝑎. (108-2)

Why do we need to do this? Consider the gas particles in the room you are currently sitting in. The particles move randomly
(although with an average speed), such that for every particle currently moving to the right, there is most likely a particle
moving to the left with the same speed. Taking into account the vector nature of velocity, the average velocity of these two
particles would be zero. When you consider the fact that there are a huge number of gas particles in a standard room, it is not
hard to envision that the average velocity of the particles is close to zero. Finding the root mean square value is a valid way
of finding the average speed of the particles in order to find the kinetic energy.


Example 108 - 1 **Speed of air particles**

What is the average translational speed of an oxygen molecule
at room temperature (𝑇𝑇 = 293 𝐾𝐾)?

**Solution:**

In order to solve this problem, we must use the equation for
the definition of temperature and substitute in what we know
about kinetic energy:

𝐾𝑎𝐾 𝑎𝑎 𝑎𝑎𝑎 = [1] 2 = [3]

2 [𝑚][𝑚][𝑣][𝑎][𝑣] [𝑎][𝑎] [𝑎][𝑎] 2 [𝑘][𝑘][𝑏][𝑏][𝑇][𝑇][   →   𝑣][𝑎][𝑣] [𝑎][𝑎] [𝑎][𝑎][𝑎] [= ][�3𝑘]𝑚[𝑘][𝑏]𝑚 [𝑏][𝑇][.]


In order to solve this, we must look up the mass of an
oxygen molecule. Substituting in this information gives
us

⁄ )(293 𝐾𝐾)
𝑣𝑎𝑣 𝑎𝑎 𝑎𝑎𝑎 = �[3(1.381𝑥][10][𝑥] [−23][ 𝐽][𝐽] [𝐾] = 479 𝑚𝑚/𝑠𝑠.
5.3𝑥𝑥10[−26] 𝑘𝑘𝑘

This is a surprisingly large speed! However, it is true that
the molecules in air around you are moving quite fast and
even striking your skin at this speed.


It also turns out that the particles at a given temperature will have
a wide variation in speed, which is why the averaging is so important.
The kinetic theory of gases tells us that the distribution of speeds will
follow a Maxwell-Boltzmann distribution as shown in Figure 108-2.
This figure shows that some particles in the gas will have speeds that
are very close to zero and some will have speeds that are more than
twice the average. This means that in the air around you, some of
particles are moving upwards of 1000 m/s - more than 2200 miles per
hour!!


**Figure 108-2. Speed distributions for oxygen at**
**100 K, 293 K and 600 K.**


-----

**Temperature Scales**

The most common temperature scales currently used
worldwide are the Fahrenheit (°F) and Celsius (°C) scales. The
modern definition of both scales is based on the freezing point and
boiling point of water as shown in Table 108-1. As of 2015, the
United States and its territories are the only major country still
using the Fahrenheit scale.
Although I tend not to push historical facts related to physics
in this book, two points related to these scales are of interest:


**Table 108-1. Modern defining points for the Fahrenheit**
**and Celsius temperature scales.**

|and Celsius temperature scales.|Col2|
|---|---|
|Scale Freezing Point|Boiling point|
|Fahrenheit 32 °F|212 °F|
|Celsius 0 °C|100 °C|



     - _Daniel Fahrenheit originally introduced the scale in 1732, using the temperature that he could reproducibly_
cool brine and human core temperature as his defining points. Today, these seem rather odd definitions.

     - _Anders Celsius originally set 0 °C as the boiling point of water and 100 °C as the freezing point of water!_
Upon his death in 1744, the scale was reversed by Carl Linnaeus to support a thermometer he had developed
and fit with a similar scale develop by Jean-Pierre Christin.

The Fahrenheit and Celsius scales do not have the same gradation; in fact, a change on 1° on the Fahrenheit scale is the same
as a 5/9° change on the Celsius scale. Since we also know that the freezing point of water is offset by 32° on the two scales,
we can write conversion factors between our two common scales:

(108-3)

𝑇𝑇𝐶𝐶 = [5]

9 [(𝑇𝑇][𝐹𝐹] [−32)   and   𝑇𝑇][𝐹𝐹] [= ][9]5 [𝑇𝑇][𝐶𝐶] [+ 32,]


where 𝑇𝑇𝐶𝐶 is the temperature in degrees Celsius and 𝑇𝑇𝐹𝐹 is the temperature in degrees Fahrenheit.
Both the Fahrenheit and Celsius scales are actually inconsistent with our definition of temperature! If we are trying to
relate the average kinetic energy of particles to the temperature, it makes sense to set the zero point of the temperature scale
to where average kinetic energy would also go to zero – a temperature known as absolute zero. This simplest solution is to
take the scales already in use and shift their values so that the new zero is absolute zero – which is the origin of the Kelvin
temperature scale.
As mentioned above, the SI unit of temperature is the Kelvin (K), an absolute temperature scale having the same relative
gradations as the Celsius scale, but reset zero to the point where physicists determined all motion would stop in an ideal gas:
-273.15 °C. Therefore, the relationship between temperature in Kelvin and Celsius is

𝑇𝑇𝐾𝐾 = 𝑇𝑇𝐶𝐶 + 273.15, (108-4)

where 𝑇𝑇𝐾𝐾 is the temperature in Kelvin. Please note:

  - by convention, temperatures are noted as in “Kelvin” and not “degrees Kelvin,” as opposed to the Celsius and
Fahrenheit scales where the terms “degrees Celsius” and “degrees Fahrenheit” are completely acceptable.

  - in practice, we often use 273 (three sig figs) as the conversion factor between Kelvin and Celsius, ignoring the 0.15.


Example 108 - 2 **Converting temperatures**

What is 165°F in (a) Celsius and (b) Kelvin?

**Solution:**

This problem asks us to directly apply the conversion factors
between Fahrenheit, Celsius and Kelvin.

(a) Applying the conversion equation for Fahrenheit to
Celsius, we find


𝑇𝐶𝑇 𝐶 = [5]
9 [(165 −32) = 73.9 °𝐶][𝐶][.]

(b) Applying the conversion equation for Fahrenheit to
Celsius, we find

𝑇𝐾𝑇 𝐾 = 73.9 + 273.15 = 347 𝐾𝐾.


-----

#### 108.2 – Internal energy

**Consider: Do all objects have energy that can’t be seen?**

**_Internal energy refers to the microscopic energy inside a substance. I use the term microscopic because internal energy is_**
related to the motion and interactions of individual atoms and molecules and therefore is on a very small scale. Internal
energy comes in two forms:

  - **_thermal energy, which is the energy associated with random atomic and molecular motions, and_**

  - **_latent energy, which is the energy stored in molecular bonds._**

Below, we will discuss each of these forms of internal energy and then show how internal energy combined with the
conservation of energy allow us describe in detail how ice melts or a cup of coffee cools over time.

#### 108.3 – Thermal energy

**Consider: How can we quantify the motions of all the particles in a**
substance?

In section 108.3, we showed how the temperature of an object is related to the average translational kinetic energy of the
particles that make it up:

𝐾𝐾𝑎𝑎𝑎𝑎𝑎𝑎 = [3] (108-5)

2 [𝑘𝑘][𝑏𝑏][𝑇𝑇.]

Equation 108-5 holds true for ideal gases for which the particles can move in three dimensions and for simple solids where
the atoms can vibrate in three dimensions. In fact, the energy supplied by the translational motion of particles in each
dimension is given by (1 2⁄ )𝑘𝑘𝑏𝑏𝑇𝑇, so the total in all three dimensions is (3 2⁄ )𝑘𝑘𝑏𝑏𝑇𝑇. This is a statement of the equipartition
**_theorem, which states the each degree of freedom contributes the same amount of energy to system. A degree of freedom_**
could be an axis along which to translate, rotate or vibrate, or any systematic set of ways the particles could move.
We can use these ideas to quickly build up to an equation for the total thermal energy of a system. Let’s say we have a
system of 𝑁𝑁 atoms or molecules, each of which have 𝑓𝑓 degrees of freedom. If we say that each degree of freedom for each
particle delivers (1 2⁄ )𝑘𝑘𝑏𝑏𝑇𝑇 of thermal energy to the system, then the total thermal energy is given by

(108-6)

𝑈𝑇𝑇ℎ𝑈 = 𝑁𝑁 ∙𝑓𝑓 ⋅ [1]

2 [𝑘][𝑘][𝑏𝑏][𝑇][𝑇][.]

This suggests that larger systems and systems with more degrees of freedom will store more thermal energy, which makes
sense.


**Thermal Energy of Gases**

𝑼𝑻𝑼 𝑻𝑻 𝑻 = 𝑵𝑵 [𝒇]
𝟐𝟐 [𝒌][𝒌][𝒃][𝒃][𝑻][𝑻]

**Description – This equation defines the thermal energy of a**


system in terms of the number of particles in the system,
𝑁𝑁, the degrees of freedom for the system, 𝑓𝑓, and the
energy for each degree of freedom, (1 2⁄ )𝑘𝑘𝑏𝑏𝑇𝑇.
**Note: 𝑓𝑓** = 3 for an ideal monatomic gas and simple solids;

𝑓𝑓 = 5 for diatomic gases including rotation and 𝑓𝑓 = 7
for diatomic gases including rotation and vibration.

The number of degrees of freedom for substances besides gases and simple solids becomes very complicated and usually
depends on temperature in a very complicated fashion. We will not explore thermal energy to this depth.


-----

Example 108 - 3 **Thermal energy of oxygen**

How much thermal energy is contained in 1 kg of diatomic
oxygen at room temperature?  Note: At room temperature, we
do not need to include vibrational energy for oxygen.

**Solution:**

This problem is a direct application of the equation for
thermal energy of a gas. For this problem

1) We must convert the mass we are given to the number

of molecules, 𝑁𝑁.

2) We know that 𝑓𝑓 = 5 for this problem, since we have a

diatomic molecule but we are not including vibration.

3) Room temperature is 293 K

We can find the number of molecules in 1 kg of diatomic
oxygen by looking up the mass of diatomic oxygen:
5.3 𝑥𝑥 10[−26] 𝑘𝑘𝑘𝑘 per molecule. The number of molecules is
then


𝑚𝑚𝑚𝑚𝑚 𝑚𝑚 𝑚(𝑚𝑚) 1 𝑘𝑘𝑘
𝑁𝑁 = =
𝑚𝑚⁄𝑚𝑚𝑚𝑚𝑚 𝑚𝑚 𝑚𝑚 𝑚𝑚 𝑚𝑚𝑚𝑚 5.3𝑥𝑥10[−26]𝑘𝑘𝑘𝑘/𝑚𝑚𝑚𝑚𝑚 𝑚[,]

which gives us

𝑁𝑁 = 1.89 𝑥𝑥 10[25]𝑚𝑚𝑚𝑚𝑚 𝑚𝑚 𝑚𝑚 𝑚𝑚 𝑚𝑚𝑚𝑚 𝑚𝑚𝑚.

We can now use the equation for thermal energy,

𝑈𝑇𝑈 𝑇ℎ = 𝑁𝑁 [𝑓]
2 [𝑘][𝑘][𝑏][𝑏][𝑇][𝑇][,]

to find

𝑈𝑇𝑈 𝑇ℎ = (1.89𝑥𝑥10[25]) [5] ⁄ )(293𝐾𝐾),
2 [(1.381𝑥][10][𝑥] [−23][ 𝐽][𝐽] [𝐾]

𝑈𝑇𝑈 𝑇ℎ = 1.91 𝑥𝑥 10[5] 𝐽𝐽.


Often more important than the total amount of thermal energy in a system is how much the thermal energy changes and
what this does to the temperature of the system. Comparing what we have learned about temperature and thermal energy,
you might guess that a change in thermal energy is proportional to a change in temperature:

Δ𝑈𝑈𝑇𝑇ℎ ∝Δ𝑇𝑇. (108-7)

We must know two things about the substance in order to equate the thermal energy **Table 108-2. Some specific heats***
and temperature: how much of the substance there is in the system (its mass, 𝑚𝑚) and **Material** **Specific heat**
a constant of proportionality that defines the substance. The constant of 𝑱𝑱/(𝒌𝒌𝒌𝒌 ∙𝑲𝑲)
proportionality is called the specific heat, 𝑐𝑐. In reality, the specific heat is neither a Air 740
constant nor a type of heat, so it is very poorly named. Although we can’t do Aluminum 900
anything about the name (specific heat is ubiquitous in chemistry and physics), we Copper 385
will make sure to only look at systems where the specific heat is approximately Lead 128
constant over the range of temperatures we are interested in. Using the mass and

Water 4186

specific heat to equate thermal energy and temperature changes, we get

Ethanol (alcohol) 2400

Δ𝑈𝑈𝑇𝑇ℎ = 𝑚𝑚𝑚𝑚Δ𝑇𝑇. (108-8) Silver 235

Gold 129

As with many of the topics in introductory physics, the idea of specific heat is Human (37°C) 3500
considerably more complicated than we have introduced it here; however, the detail Ice (0°C) 2090
given to this point will allow us to solve many mechanical systems to the level we

Wood (approx.) 1500

require. Table 108-2 gives the specific heats for a number of common substances. - T = 20 °C unless otherwise noted


**Change in Thermal Energy**

𝚫𝚫𝑼𝑻𝑼 𝑻𝑻 𝑻 = 𝒎𝒎𝒎𝒎𝚫𝚫𝑻𝑻

**Description – This equation relates the change in thermal**

energy, Δ𝑈𝑇𝑈 𝑇ℎ, of a system to its mass, 𝑚𝑚, specific heat,
𝑐𝑐, and change in temperature, Δ𝑇𝑇.
**Note: Although technically Δ𝑇𝑇 should be in Kelvin, since**

the Kelvin and Celsius scales have the same gradations,
either can be used here.


-----

Example 108 - 4 **Cooling coffee**

How does the thermal energy of a cup of coffee change as it
cools from 96 °C to room temperature? A standard cup of
coffee is 6 fluid ounces (approximately 0.17 kg).

**Solution:**

This problem is a direct application of the change in thermal
energy equation. Since coffee is mostly water, we will use
the specific heat of water for this calculation. It is also
important to note that room temperature is 22 °C.

Starting with the equation for change in thermal energy,


Δ𝑈𝑇𝑈 𝑇ℎ = 𝑚𝑚𝑚Δ𝑇𝑚 𝑇,

we find

𝐽
Δ𝑈𝑇𝑈 𝑇ℎ = (0.17 𝑘𝑘𝑘𝑘) �4186
𝑘𝑘𝑘𝑘𝑘𝑘[�(22°C −96°C),]

Δ𝑈𝑇𝑈 𝑇ℎ = −52,700 𝐽𝐽

That is to say, the system lost 52,700 J of energy while
cooling. Although this may seem like quite a bit of
energy, keep in mind that this is for a small cup of coffee!


#### 108.3 – Latent energy

**Consider: How much energy does it take to boil water?**

Section 102-2 gave a brief introduction to the most important
phases of matter: solids, liquids and gases. The phase a material
will be in depends on the pressure and temperature in and around
the material, as can be seen in Figure 108-3. Such a **_phase_**
**_diagram, as they are called, allow us to predict the phase of the_**
material if we know the pressure and temperature. In general,
for a given pressure, a material will be a solid at low
temperature, a liquid at moderate temperatures and a gas a higher
temperatures. This is especially true for pressure that are
between the triple point pressure (𝑝𝑝𝑡𝑡𝑡𝑡) and the critical pressure
(𝑝𝑝𝑐𝑐𝑐𝑐). The triple point is a specific pressure and temperature at
which the three phases of solid, liquid and gas coexist. The
critical point is a pressure and temperature above which the
distinction between gas and liquid become hard to define, a state
known as a supercritical fluid..
For now, we are going to confine ourselves to solids, liquids

**Figure 108-3. Generalized phase diagram showing the**

and gases with pressures between the triple point pressure and

**relationship between pressure, temperature and phase.**

critical pressure (the middle section of Figure 108-3). Even
more, we will make the pressure constant for each system we
study so that the phase of a material is only dependent on its temperature. With these conditions (which do mimic many reallife situations), a material will move from solid to liquid to gas as temperature increases and gas to liquid to solid as
temperature decreases.
We all know that once a pot of water starts to boil, we must continue to put energy into the system to keep it boiling –
that is, you must keep the pot of water on the burner. Put another way, it takes energy to continue to change the phase of the
water. What’s more, if you were to check the temperature of the water while it is undergoing to the phase change, you would
note that the temperature remains constant as the water boils.
We will use the following terms when discussing phase changes in this course:

  - **_Melting – phase change from solid to liquid at the melting temperature_**

  - **_Freezing – phase change from liquid to solid at the melting temperature_**

  - **_Vaporization – phase change from liquid to gas at the boiling temperature_**

  - **_Condensation– phase change from gas to liquid at the boiling temperature_**


-----

**Figure 108-4. Relationships between the phases of matter**
**and their transitions.**


Figure 108-4 summarizes these phase changes and includes a
direct phase changes from solids to/from gases (deposition and
sublimation) as well as gases to/from plasmas (ionization and
recombination).
The energy that enters or leaves a system due to a phase
change is known as **_latent energy. Latent energy is associated_**
with creating or dissociating molecular bonds, which is to say that
latent energy changes the way in which atoms and molecules
interact with each other in a substance. As you might imagine,
the amount of energy needed to, say, boil a certain material will
depend on how much mass is present and some factor related to
the type of material (a proportionality constant). For latent
energy, we use the variable L, which stands for the latent heat of
fusion (for melting/freezing) or the latent heat of vaporization (for
vaporizing/condensing). Using this, we can write the energy
needed to change the phase of a material as

Δ𝑈𝑈𝐿𝐿𝐿𝐿 = mL. (108-9)

Table 108-3 gives latent heat values and boiling and freezing
temperatures for various substances.  Just as with specific heat,
latent heat, L, is poorly named since it is not heat, but rather a
value relating how much energy is required to change the phase
of a substance per mass.


**Latent Energy**

𝚫𝚫𝑼𝑳𝑼 𝑳𝑳𝑳 = ±𝒎𝒎𝒎𝒎

**Description – This equation defines the energy transfer,**

Δ𝑈𝐿𝑈 𝐿𝐿𝐿, of a material with mass, 𝑚𝑚, during a phase
transition. 𝐿𝐿 is the latent heat.
**Note 1: For melting and freezing, you must use the latent**

heat of fusion, 𝐿𝑓𝐿 𝑓, and for boiling and condensing, you
must use the latent heat of vaporization, 𝐿𝑣𝐿 𝑣.
**Note 2: Δ𝑈𝐿𝑈** 𝐿𝐿𝐿 is positive for melting/vaporizing and

negative freezing/condensing.


**°C** 𝑳𝑳𝒇𝒇 (𝑱𝑱/𝒌𝒌𝒌)𝒌 **°C** 𝑳𝑳𝒗𝒗 (𝑱𝑱⁄𝒌𝒌𝒌)𝒌

Copper 1084 2.05 𝑥𝑥 10[5] 2560 3.92 𝑥𝑥 10[5]
Ethanol -114 1.04 𝑥𝑥 10[5] 78 8.52 𝑥𝑥 10[5]
Gold 1064 6.45 𝑥𝑥 10[4] 2650 1.57 𝑥𝑥 10[6]
Helium -- -- -269 2.09 𝑥𝑥 10[4]
Lead 328 2.50 𝑥𝑥 10[4] 1740 8.66 𝑥𝑥 10[5]
Mercury -39 1.22 𝑥𝑥 10[4] 358 2.67 𝑥𝑥 10[5]
Nitrogen -210 2.57 𝑥𝑥 10[4] -196 1.96 𝑥𝑥 10[5]
Oxygen -218 1.38 𝑥𝑥 10[4] -183 2.12 𝑥𝑥 10[5]
Tungsten 3400 1.82 𝑥𝑥 10[5] 5880 4.81 𝑥𝑥 10[6]
Uranium 1133 8.28 𝑥𝑥 10[4] 3818 1.88 𝑥𝑥 10[6]
Water 0 3.33 𝑥𝑥 10[5] 100 2.26 𝑥𝑥 10[6]

|Table 108-3. Some latent heats|Col2|Col3|Col4|
|---|---|---|---|
|Material Melting Point °C|Heat of Fusion 𝑳𝑳 (𝑱𝑱/𝒌𝒌𝒌)𝒌 𝒇𝒇|Boiling Point °C|Heat of Vaporization 𝑳𝑳 (𝑱𝑱⁄𝒌𝒌𝒌)𝒌 𝒗𝒗|
|Copper 1084|2.05 𝑥𝑥 105|2560|3.92 𝑥𝑥 105|
|Ethanol -114|1.04 𝑥𝑥 105|78|8.52 𝑥𝑥 105|
|Gold 1064|6.45 𝑥𝑥 104|2650|1.57 𝑥𝑥 106|
|Helium --|--|-269|2.09 𝑥𝑥 104|
|Lead 328|2.50 𝑥𝑥 104|1740|8.66 𝑥𝑥 105|
|Mercury -39|1.22 𝑥𝑥 104|358|2.67 𝑥𝑥 105|
|Nitrogen -210|2.57 𝑥𝑥 104|-196|1.96 𝑥𝑥 105|
|Oxygen -218|1.38 𝑥𝑥 104|-183|2.12 𝑥𝑥 105|
|Tungsten 3400|1.82 𝑥𝑥 105|5880|4.81 𝑥𝑥 106|
|Uranium 1133|8.28 𝑥𝑥 104|3818|1.88 𝑥𝑥 106|
|Water 0|3.33 𝑥𝑥 105|100|2.26 𝑥𝑥 106|


-----

Example 108 - 5 **Boiling water**

How much energy does it take to boil 2.3 kg of water?

**Solution:**

This problem is a direct application of the latent energy
equation. We have all the required information, so we can
start with the basic equation

Δ𝑈𝐿𝑈 𝐿𝐿𝐿 = 𝑚𝑚𝑚𝑚


and find

Δ𝑈𝐿𝑈 𝐿𝐿𝐿 = (2.3 𝑘𝑘𝑘𝑘)(2.26𝑥𝑥10[6] 𝐽𝐽⁄𝑘𝑘𝑘) = 5.20𝑥𝑥10[6]𝐽𝐽.

Note that this is 100 times the energy that was released
when coffee cooled to room temperature in Example 1084. Phase changes use/release immense amount of energy,
which is why melting ice works so effectively at cooling
down a drink.


#### 108.3 – Conservation of energy with internal energy

**Consider: How does a small piece of ice cool a drink so well?**

Thermal and latent energy can be used as part of a conservation of energy problem in two important ways:

1. If there are no changes in (macroscopic) kinetic and potential energies, thermal and latent energy can be used
directly to determine changes in temperature and phase changes.

2. Thermal and latent energy can be used to determine temperature and phase changes when kinetic and potential
energy “disappear”. This may occur, for example, when friction is involved in a system.

The examples below show how to effectively use the conservation of energy in these two cases.


Example 108 - 6 **Ice water**

Imagine that 10 grams of ice is placed into an 8-ounce (0.23
kg) glass of water at 293 K. If we assume the system of ice
and water to be isolated, what will be the final temperature
when the ice melts?

**Solution:**

This problem will utilize the conservation of energy equation
two times – first while the ice melts and then as the water that
was ice warms up. In both cases, there are not changes in
(macroscopic) kinetic energy or potential energy, so the only
energy terms we need to work with are the latent and thermal
energies.

In order to melt the ice, the water will give some of its
thermal energy to the ice in the form of latent energy. The
conservation of energy for this part of the problem can be
written

Δ𝐸𝐸 = 0 = Δ𝑈𝐿𝑈 𝐿𝐿𝐿,1 + Δ𝑈𝑇𝑈 𝑇ℎ,2,

where I have used the subscript 1 to represent material that is
initially ice and subscript 2 to represent material that is
initially water.

Substituting in equations for latent energy and thermal
energy, we find


0 = 𝑚1𝑚 𝐿𝐿 + 𝑚𝑚2𝑐𝑐(𝑇𝑏𝑇 𝑏 −𝑇𝑎𝑇 𝑎).

Solving for the final temperature gives us

(10𝑥𝑥10[−3]𝑘𝑘𝑘 𝑘)(3.33 𝑥𝑥 10[5] 𝐽𝐽⁄𝑘𝑘𝑘 )
𝑇𝑏𝑇 𝑏 = 𝑇𝑎𝑇 𝑎 − [𝑚]𝑚[1][𝑚]𝑚2[𝐿]𝑐𝑐 [= 293 −] (0.23 𝑘𝑘𝑘 𝑘) �4186 𝐽,

𝑘𝑘𝑘 𝑘 ∙𝐾𝐾[�]


which simplifies to

𝑇𝑏𝑇 𝑏 = 289.54 𝐾𝐾.

We now have water at 0 °C (273.15 K) mixed with water
at 289.54 K. Again, the conservation of energy gives us

Δ𝐸𝐸 = 0 = Δ𝑈𝑇𝑈 𝑇ℎ,1 + Δ𝑈𝑇𝑈 𝑇ℎ,2
or

Δ𝐸𝐸 = 0 = 𝑚1𝑚 𝑐𝑐(𝑇𝑐𝑇 𝑐 −273.15 𝐾𝐾) + 𝑚𝑚2𝑐𝑐(𝑇𝑐𝑇 𝑐 −289.54 𝐾𝐾).

Solving this equation for 𝑇𝑐𝑇 𝑐 (the final temperature of the
mixture) gives us

𝑇𝑐𝑇 𝑐 = 288.9 𝐾𝐾.

Note that the ice changing to water (process 1) changed
the temperature more than process 2.


-----

Alternate Solution :

The ice water problem can also be solved in one step by
utilizing all of the changes in energy at once:

Δ𝐸𝐸 = 0 = Δ𝑈𝐿𝑈 𝐿𝐿𝐿,1 + Δ𝑈𝑇𝑈 𝑇ℎ,1 + Δ𝑈𝑇𝑈 𝑇ℎ,2.

In order to do this, we must realize, however, that Δ𝑇2𝑇 will
include the initial and final temperatures of the entire system
and Δ𝑇1𝑇 will use the final temperature of the system and
273.15 K (𝑇𝑖𝑇 𝑖𝑖 𝑖𝑖 𝑖-the temperature of the water from the ice after
melting). Given these restrictions, our equation becomes

0 = 𝑚1𝑚 𝐿𝐿 + 𝑚1𝑚 𝑐𝑐�𝑇𝑓𝑇 𝑓 −𝑇𝑖𝑇 𝑖𝑖 𝑖𝑖 𝑖�+ 𝑚𝑚2𝑐𝑐�𝑇𝑓𝑇 𝑓 −𝑇𝑖𝑇 𝑖�.


The only unknown in this equation is 𝑇𝑓𝑇 𝑓, so we can
directly solve:


⁄
𝑇𝑓𝑇 𝑓 = [𝑚][1][𝑚] [𝑇][𝐼][𝑇] [𝐼][𝐼][𝐼][𝐼] [𝐼] [+ 𝑚][𝑚][2][𝑇][𝑖][𝑇] [𝑖] [−𝑚][1][𝑚] [𝐿][𝐿] [𝑐]
𝑚1𝑚 + 𝑚𝑚2


.


Inserting all of our known values gives us 𝑇𝑓𝑇 𝑓 = 288.9 𝐾𝐾,
as before. This alternate solution is quicker and more
elegant; however, when you are first working with
thermal and latent heats, it makes sense to take care of
each process separately as we did in the first solution.


Example 108 - 7 **Falling water**

Imagine you pour water from a jug into a pail on the floor, 2.3 gives us
meters below. When the system settles down, but how much
will the temperature of the water changed if we assume the 0 = (0 −𝑚𝑚𝑚𝑚ℎ) + 𝑚𝑚𝑚Δ𝑇𝑚 𝑇,
water to be isolated from its environment?

where I have set the zero point of height at the pail (the

**Solution:** lowest point). Solving for the change in temperature

gives us

This problem is an application of the conservation of energy
including both mechanical energy and internal energy. The Δ𝑇𝑇 = [𝑔][𝑔][ℎ]

𝑐𝑐 [,]

water starts off with gravitational potential energy since it is
elevated. As the water fall, the potential energy is converted which, surprisingly, is independent of mass. Using the
to kinetic energy. Finally, when the water settles down in the numbers from the problem gives us a final change in
pail, the kinetic energy is converted to internal energy. It temperature of
might be tempting to treat all of these energies individually;
however, we can simplify the process by noting that there is (9.81 𝑁𝑁⁄𝑘𝑘𝑘)(2.3𝑚𝑚)
no change in kinetic energy between the initial condition Δ𝑇𝑇 = = 0.005 𝐾𝐾

4186 𝐽𝐽⁄𝑘𝑘𝑘𝑘𝑘

(water at rest which elevated) and final condition (water at
rest in pail). Therefore, we only need to contend with changes This is a very small change in temperature, which you
in gravitational potential energy and thermal energy: might expect from experience. Also, in a real-world

situation, the water is also not isolated, so some of the

Δ𝐸𝐸 = 0 = Δ𝑈𝑔𝑈 𝑔 + Δ𝑈𝑇𝑈 𝑇ℎ energy would be given to the pail, and the measured

change in temperature of the water would be even lower.

Substituting what we know about these types of energy

Example 108 - 8 **Frictional heating**

Imagine that a 1.9-kg block of copper, with an initial speed of the block and that the other half goes into heating the
11.0 m/s is brought to rest by friction with the surface on surface. Using the conservation of energy:
which it moves. Approximately by how much would the
copper increase in temperature due to the friction?

𝐸𝐸 = 0 = [1]
2 [Δ𝐾][𝐾] [+ Δ𝑈][𝑇][𝑈] [𝑇][ℎ] [= �0 −1]4 [𝑚][𝑚][𝑣][𝑣][2][�+ 𝑚][𝑚][𝑚][Δ𝑇][𝑚] [𝑇][.]

**Solution:**

Solving for Δ𝑇𝑇, we find

Similar to example 108-7, this problem includes both
macroscopic and internal energies. Since the friction (11.0 𝑚𝑚⁄ )𝑠 [2]
interaction is shared by the block and the surface, I will Δ𝑇𝑇 = [𝑣][𝑣][2]

4𝑐𝑐 [=] 4(385 𝐽𝐽⁄𝑘𝑘𝑘𝑘𝑘) [= 0.079 𝐾][𝐾][.]

assume only half of the energy released by friction goes into


-----

