### – Newton’s Laws
## 119


_Newton’s laws of motion give us another way to analyze physical systems. By using Newton’s laws, we can directly_
_relate how the net force on a set of objects is related to acceleration. Then, using kinematic relationships studied in the_
_next two units, we will be able to directly relate the acceleration of objects to their change in velocity and position._


##### The Bare Essentials

- Isaac Newton proposed three ‘laws’ for classical mechanics

that hold for inertial, non-relativistic systems.

- **_Newton’s 1[st] law states that the velocity of an object does not_**

change if it is not interacting with other objects

“An object in motion tends to stay in motion
unless acted on by an outside force”

- **_Newton’s 2[nd] law relates the net force on an object to its_**

change in momentum, and often its acceleration.



- Note: Newton’s laws and free-body diagrams are done with
respect to individual objects. This is quite different than the
conservation of momentum and energy where the equations
were for the entire system!

- The gravitational force on an object is given by mass of the
object multiplied by the local gravitational field strength.


**Newton’s Second Law**

𝐅[⃗]𝐧𝐞𝐭 = [𝒅𝒑��⃗]𝒅𝒕

**Description – The equation relates the net force on an**

object, F[�⃗]���, to the rate of change of the object’s
momentum, 𝑑𝑝⃗𝑑𝑡⁄ .
**Note: When the mass of an object moving at non-relativistic**

speeds is constant, 𝑑𝑝⃗𝑑𝑡⁄ reduces to 𝑚𝑎⃗.


**Gravitational Force**

[��⃗]𝑭𝒈 = 𝒎𝒈��⃗

**Description: This equation describes the gravitational force**

on an object, 𝐹�, as the product of the object’s mass, 𝑚,
and the local gravitational field, 𝑔⃗.
**Note: Near the surface of the earth, the gravitational field**

strength is often given as 9.80 𝑚/𝑠[�] or 9.80 𝑁/𝑘𝑔



- **_Newton’s 3[rd] law states that since an interaction is between_**

two objects, the force on one of the interacting objects is equal
in magnitude and opposite in direction to the force on the
other interacting object.

“For every action, there is an equal and
opposite reaction”

- In order to visualize the force on individual object, it is

advised that you always draw a free-body diagram of each
object in the system and label each diagram with all of the
forces that act on the body.


-----

#### 119.1 – From conservation laws to Newton’s “laws”

**Consider: Are there other ways to solve physics problems besides the**
conservation of energy and momentum?

HE LAWS OF CONSERVATION OF ENERGY AND conservation of momentum that
we have studied up to this point give us powerful tools to solve physics problems. As
mentioned before, these two principles are not only applicable for classical physics, but

# T

can be applied to the very small (quantum systems) and the very fast (relativistic systems).
Interestingly, there is some question as to the conservation of energy on the very, very large
scale – we’re not sure that energy conservation works for the universe as a whole. Regardless,
the principles of energy and momentum are so pervasive that it is impossible to overstate their
important in all of science.
There are another set of “laws” that can be used to solve physics problems – Newton’s laws
of motion. Although often called laws, they are not conservation laws like energy and
momentum, but rather a set of rules that work extremely well in the classical limit. As
summarized in Unit 103, the three laws are

**_Newton’s 1[st] Law: In an inertial reference frame, an object remains at rest or continues_** **Figure 119-1. Newton’s**

_to move at constant velocity (speed and direction) unless acted on by an_ **laws from the original**
_outside force._ **Principia.**

**Newton’s 2[nd] Law: The vector sum of forces on an object is equal to the rate of change of momentum of**

_the object. In the case where the mass of the object remains the same, the vector sum of forces is_
_equal to the mass of the object multiplied by the acceleration of the object._

**_Newton’s 3[rd] Law: When two objects interact, the force exerted on the first object by the second object is_**

_equal in magnitude and opposite in direction to the force on the second object by the first object._

In Unit 119, we explore the basics of these three laws. Units 120 through 122 will explore the particulars of position,
velocity and acceleration. Then, units 123 through 129 build up a repertoire of techniques that can be used to solve problems
using Newton’s three laws. We will see along the way that almost all of the problems we solved using energy and
momentum can also be solved using forces and Newton’s laws. The power of knowing each technique is that one problem
may be much easier to solve using Newton’s laws rather than energy considerations, but another problem may be more suited
to the energy and momentum principles.

#### 119.2 – Inertial reference frames and the law of inertia

**Consider: Why do objects in motion tend to stay in motion?**

Imagine an object which is not undergoing any interactions. For this object, it is possible to find a reference frame in which
the object does not accelerate. Such a reference frame is called an inertial reference frame. It is actually possible to find an
infinite number of such frames and although the object would not accelerate in any of those frames, the velocity of the object
could be different in each. Consider this example:

_You are traveling down the road at 55 mph relative to the ground. A car, traveling the_
_same direction, passes you traveling at 75 mph relative to the ground. You would say_
_that the car is moving 20 mph faster than you are, which is to say that the car is moving_
_20 mph relative to you._

Both you and the ground represent inertial coordinate systems for the other car. In the coordinate system attached to the
ground, the other car is moving at 75 mph. In the coordinate system attached to you, the car is moving 20 mph. The other
car is not accelerating in either frame, although the speed of the other car is different in each frame. To be very precise, this
example does not help to define inertial reference frames because the other car is undergoing a number of interactions as a
rolls down the road. However, the visuals relayed by the cars of this example should give you a feel for why inertial
reference frames are helpful.
Now that we have a feel for inertial reference frames, we can once again state Newton’s first law:


-----

**_In an inertial reference frame, an object remains at rest or continues to move at_**
**_constant velocity (speed and direction) unless acted on by an outside force._**

Newton’s first law is also sometimes called the law of inertia.  Inertia is the ability of any object to resist a change in its
motion, and since the 1[st] law is entirely about an object’s lack of change of motion in the absence of forces, calling it the law
of inertia fits well. We will see in Newton’s 2[nd] law that an object’s ability to resist changes in motion is directly
proportional to its mass, so an object’s mass is direct measure of its inertia. This definition of mass can be used to bring even
more meaning to the definition of momentum of a particle:

𝑝⃗= 𝛾𝑚𝑣⃗, (119-1)

which is now the (complex) product of an object’s inertia and velocity.

#### 119.3 – Newton’s second law

**Consider: How do forces relate to an object’s change in motion?**

When an object undergoes one or more interactions, the net (vector) force on the object is the vector sum of the forces due to
each interactions, as

𝐹[⃗]��� = 𝐹[⃗]� + 𝐹[⃗]� + 𝐹[⃗]� + ⋯, (119-2)

where 𝐹[⃗]�, 𝐹[⃗]�, and so on are the forces due to the object’s interactions. Here, remember that each individual force is the push
or pull that results from a single interaction. The net force, or vector sum of the forces, is directly related to the change in
motion of the object. In fact, the net vector force on an object is equal to the rate of change of the object’s momentum.

(119-3)

𝐹[⃗]��� = [𝑑𝑝⃗]𝑑𝑡 [.]

Equation 119-3 is Newton’s 2[nd] law. In the classical limit and if the mass of the object is constant, Newton’s 2[nd] law can
be further reduced using the definition of momentum as


(119-4)

𝐹[⃗]��� = [𝑑𝑝⃗]𝑑𝑡 [= 𝑑(𝑚𝑣⃗)]𝑑𝑡 = 𝑚 [𝑑𝑣⃗]𝑑𝑡 [= 𝑚𝑎⃗.]

where we have used the fact that the rate of change of velocity (time derivative of velocity) is acceleration. Equation 119-4 is
the more commonly known equation for Newton’s 2[nd] law; however, Equation 119-3, defining the net force in terms of the
rate of change of momentum, more closely relates force to the fundamental momentum principle.


**Newton’s Second Law**

𝐅[⃗]𝐧𝐞𝐭 = [𝒅𝒑��⃗]𝒅𝒕

**Description – The equation relates the net force on an**

object, F[�⃗]���, to the rate of change of the object’s
momentum, 𝑑𝑝⃗𝑑𝑡⁄ .
**Note: When the mass of an object moving at non-relativistic**

speeds is constant, 𝑑𝑝⃗𝑑𝑡⁄ reduces to 𝑚𝑎⃗.


Imagine an object which undergoes a number of interactions and therefore has a number of forces acting on it. Each
force individually would lead to a change in momentum of the object, but is masked because there are numerous forces. We
can represent this mathematically as


-----

(119-4)

𝐹[⃗]��� = 𝐹[⃗]� + 𝐹[⃗]� + 𝐹[⃗]� + ⋯= [𝑑𝑝⃗]𝑑𝑡[�] [+ 𝑑𝑝⃗]𝑑𝑡[�] [+ 𝑑𝑝⃗]𝑑𝑡[�] [+ ⋯.]

Relating this equation back to Unit 114, each of 𝑑𝑝⃗�, 𝑑𝑝⃗�, etc., represent the impulses on the object due to each individual
force. Although this relationship will not change the ways in which we find the net force and motion of objects, it can help
with the interpretation of why the net force causes a change in motion.
As we continue to move from using conservation laws to forces to solve problems, it is important to keep the following
in mind:

**_For conservation laws: we combine the entire system into one equation for all objects_**
**_in the system_**

**_For Newton’s 2[nd] law: we write a 2[nd] law equation for each_** **_object_** **_in the system. As_**
**_such, we will have the same number of (vector) equations as we have objects of interest_**
**_in the system._**


Example 119 - 1 **Net force from two forces**

An object is acted on by two forces:

𝐹[⃗]� = (10𝑡𝚤̂ −3𝚥̂) 𝑁;
𝐹[⃗]� = �−2𝚤̂ + 11𝑡[�]𝚥̂ + 4𝑘[�]� 𝑁.

(a) What is the net force acting on this object at time 𝑡= 3 𝑠?
(b) If the object has a mass of 20 kg, what is the acceleration
of the object at this time?

**Solution:**

This problem asks us to find the net force on an object due to
two individual forces and then to determine the acceleration
of the object due to those forces.

(a) The first step is to use the definition of net force to find


1
𝑎⃗=
20 𝑘𝑔 [�]


�𝑁= �


As you can see, this is the net force as a function of time.
The net force at time 𝑡= 3 𝑠 is found by substituting in
the time, giving us

28

𝐹��� = �96�𝑁.

4

(b) Since the mass is given as a constant 20 kg, we can
write Newton’s 2[nd] law as

F[�⃗]��� = [𝑑𝑝⃗]𝑑𝑡 [= 𝑚𝑎⃗    →    𝑎⃗= F�⃗]𝑚[���][.]


Therefore,


28
96

4


1.4
4.8
0.2


� [𝑚]

𝑠[�][.]


10𝑡

𝐹��� = 𝐹[⃗]� + 𝐹[⃗]� = � −3

0


10𝑡−2

�𝑁= �11𝑡[�] −3

4


Note that we will often be able to use F[�⃗]��� = 𝑚𝑎⃗, but be
careful that the mass is constant to use the equation!


�𝑁+ �


−2
11𝑡[�]

4


�𝑁.


Example 119 - 2 **Momentum and forces**

A 2.8-kg rock is found to move with a momentum given by


First, we can find the net force on the rock, by taking the
derivative of the momentum with respect to time as


20

𝑝⃗= � 10

200 −27.4𝑡


�𝑘𝑔∙𝑚𝑠.⁄


F[�⃗]��� = [𝑑𝑝⃗]𝑑𝑡 [=] 𝑑𝑡[𝑑] [�]


20
10
200 −27.4𝑡


� [𝑘𝑔∙𝑚] = �

𝑠


0
0
−27.4


�𝑁.


What is the net force acting on the rock and acceleration of
the rock due to this net force?

**Solution:**

This problem asks us to use the definition of Newton’s 2[nd] law
to find the net force on an object given its known momentum
(as a function of time). In addition, we will find the
acceleration from the information given.


Assuming the mass of the rock is constant, we can then
find the acceleration using


1

𝑎⃗= [F�⃗][���]

𝑚 [=] 2.8 𝑘𝑔 [�]


0
0
−27.4


�𝑁= �


0
0
−9.8


� [𝑚]

𝑠[�][,]


which appears to be the acceleration due to gravity.


-----

#### 119.4 – Free body diagrams

**Consider: How can we visualize the forces on an object?**

When dealing with forces, it is often advisable to make diagram for each object of interest in the
system with every force on each object noted. Such a diagram is called a **_free-body diagram,_**
because we draw each object separate (free) and diagram out each force on the diagram. Free-body
diagrams are also sometimes called force diagrams.
Figure 119-2 shows the free-body diagram of a ball in free fall, i.e. under only the influence of
the gravitational force, 𝐹[⃗]�. Some things to note about this diagram

1) The object (ball) is represented in a way that it can be identified.
2) The only force acting _on the ball (gravity) is identified and drawn as a vector in the_

direction which it acts.
3) No other extraneous information is in the diagram itself.


**Figure 119-2. Free-**
**body diagram of a**
**ball in free-fall.**


When more than one force acts on an object, each force is drawn on the same diagram. Be
sure to include all forces that act on the object, but not any forces caused by the object. Figure 1193 shows the free-body diagram for a box sitting on a table such that it undergoes two interactions –
a normal interaction with the table and a gravitational interaction with the earth. Note that the force
on the box due to each of these interactions is noted in the free-body diagram.
When drawing free-body diagrams, try to follow these rules:

Drawing Free-Body Diagrams

**Figure 119-3. Free-**
**body diagram of a**

1) Draw a representative diagram for the object

**box sitting on a**

2) Identify all forces that act directly on the object. In physics I, most forces (except gravity)

**table.**

will be due to direct contact with the object.
3) Draw and label an arrow for each force with the direction of the arrow representing the direction of the force. Try to

have the tail of each arrow at the place where the force acts on the object.

Drawing free-body diagrams correctly can make all the difference for solving force problems. We will see that when writing
out Newton’s 2[nd] law equations for an object, if you have a correctly formatted free-body diagram, it is simply a matter of
converting the forces in the diagram to the equation. In this way, the visual representation of a problem can directly translate
to the mathematical representation.

#### 119.5 – The gravitational force (near the surface of the earth)

**Consider: What is the difference between mass and weight?**

In Section 3 of Unit 106, we found that the gravitational field near a large massive object is


(119-5)

𝑔⃗= − [𝐺𝑚]� [𝑟̂][��][,]

𝑟��

and we noted that near the surface of the earth, the value of the gravitational field is 9.80 N/kg down. It turns out that the
gravitational force on an object of mass, m, is the product of the object’s mass and the gravitational field in which it is
situation. That is
𝐹[⃗]� = 𝑚𝑔⃗ (119-5)

The gravitational force on an object is also called its weight. Note that since weight is a force, it has SI units of Newtons (N),
or U.S. customary units of points (lbs.).

1 𝑁= 1 𝑘𝑔∙𝑚𝑠⁄ [�] 1 𝑁≈2.2 𝑙𝑏𝑠. (119-6)


-----

It is very important to note the difference between mass and weight. Mass is an intrinsic property of an object, that is, it
is determined only by the makeup of the object. Weight, on the other hand, depends not only on the mass of the object, but
where the object is located in a gravitational field.
Let’s compare an astronaut at the surface of the earth and at the surface of the moon. In Unit 106, we noted that the
gravitational field strength at the surface of the moon is roughly 1/6[th] the strength of the gravitational field at the surface of
the earth. So, for a 70 kg astronaut, we find

Body Mass (𝑚) Weight (𝐹� = 𝑚𝑔)
Earth 70 kg 686 N
Moon 70 kg 114 N

To summarize:

**_Mass is an intrinsic property of a material and is independent of where the object is in_**
**_the universe. Weight, on the other hand, is the gravitational force acting on an object_**
**_and depends on both the mass of the object and the local gravitational field._**


**Gravitational Force**

[��⃗]𝑭𝒈 = 𝒎𝒈��⃗

**Description: This equation describes the gravitational force**

on an object, 𝐹�, as the product of the object’s mass, 𝑚,
and the local gravitational field, 𝑔⃗.
**Note: Near the surface of the earth, the gravitational field**

strength is often given as 9.80 𝑚/𝑠[�] or 9.80 𝑁/𝑘𝑔


For completeness, the gravitational force can be derived from the gravitational potential energy we from Unit 106,
𝑈� = − [𝐺𝑚]𝑟��[�][𝑚][�]. (119-7)

We can find the gravitational force using the gradient of this potential energy (Equation 110-5):

𝐹[⃗] = −∇[��⃗]𝑈.

(119-8)
.

Since the gravitational potential energy is written in terms of the radius of a sphere, we must technically take this gradient in
spherical-polar coordinates. However, since the radius is the only variable in our potential energy equation, the derivatives
with respect to the angular variables (𝜃 and 𝜙) will be zero. Therefore, we can write
𝐹[⃗]� = −∇[��⃗]𝑈� = − 𝜕𝑟[𝜕] [�−𝐺𝑚]𝑟��[�][𝑚][�]�𝑟̂ = − [𝐺𝑚]𝑟��[�]�[𝑚][�] 𝑟̂. (119-9)

Equation 119-8 is called Newton’s Universal Law of Gravity, and can be used to determine the gravitational force between
any two massive bodies, whether that be a person standing at the earth’s surface, or a planet orbiting a star. We will return to
this general equation in Unit 128. For now, we can rewrite equation 119-8 as

𝐹[⃗]� = −�[𝐺𝑚]� [�][�𝑚][�][𝑟̂,] (119-10)

𝑟��

and use the definition of the gravitational field (Equation 119-5) to simplify this to

𝐹[⃗]� = 𝑚𝑔⃗, (119-11)

which is the relationship for the gravitational force near the surface of the earth we were looking for.


-----

Example 119 - 3 **Being careful with weight.**

A U.S. penny has a mass of 3.1 grams. What is the weight of
this penny at the surface of the earth?

**Solution:**

This is a direct application for the relationship between the
mass of an object and its weight (the gravitational force on the
object).

For this problem, I will take vertically up as the positive
direction for the z-axis. Since we know the mass is 3.1 grams
(0.0031 kg), we can directly find the weight as


0
0
−9.8


� [𝑚]

𝑠[�] [= �]


0
0
−0.030


𝐹[⃗]� = 𝑚𝑔⃗= 0.0031𝑘𝑔� 0 � 𝑠[�] [= �] 0 � 𝑁 .

−9.8 −0.030

A few things to note:

1) The weight, as force, is a vector. We can often

denote this by saying the weight is 0.030 N
_down._
2) The magnitude of the gravitational field strength

(𝑔) is positive. The negative in the above
equation comes from the direction of the
gravitational field.


Example 119 - 4 **Moon rock**

A moon rock brought back to earth during an Apollo mission
has a mass of 0.61 kg. What are the mass and weight of this
rock when it was on the moon and now that it is on earth?

**Solution:**

This problem asks us to compare the mass and weight of an
object on the earth and the moon. In order to do this, we will
use the definition of weight given in the unit.

First, it is important to realize that as an intrinsic property, the
mass of the moon rock is the same everywhere – so it is
certainly the same at the surface of the moon and the surface
of the earth.

As for the weight, we can use the definition,

𝐹[⃗]� = 𝑚𝑔⃗,


where I have used the gravitational field strength for the
moon given early in this unit.

Again, note the vector nature of weight. As we become
more familiar with such problems, it will become easy to
forget that weight is a vector – which can lead to
mistakes.


to find it for the rock at both surfaces. Therefore, for the
earth we find


0
0 � 𝑁
−6.0


𝐹[⃗]� = 0.61𝑘𝑔�


0
0
−9.8


� [𝑚]

𝑠[�] [= �]


and for the moon we find


0
0 � 𝑁,
−0.98


𝐹[⃗]� = 0.61𝑘𝑔�


0
0
−1.6


� [𝑚]

𝑠[�] [= �]


#### 119.6 – Newton’s third law

**Consider: Why is it that for every force there is an equal and opposite**
force?

Growing up, you have probably heard the phrase “for every action there is an equal and opposite reaction.” This is a
statement of Newton’s 3[rd] law; however, we have to be very careful about how we apply this law.  First, Newton’s 3[rd] law is
concerned with forces, so we could reword the colloquial saying above as ‘every force has an equal and opposite force.”
Now, we have to be careful, because if every force has an exact opposite partner, how is possible that any object ever
accelerates? That is, if every force has an opposite pair, shouldn’t those pairs, coupled with Newton’s 2[nd] law, tell us that the
net force on an object is always zero?
The subtlety that resolves this situation is that the equal and opposite forces spoken of in Newton’s 3[rd] law must act on
**_different objects. Remember that a single force on an object is the result of the object’s interaction with another object. For_**
example, the gravitational force acting on you right now is the result of the interaction between you and the earth. The third
**_law pair, as they are called of the gravitational force of the earth on you, must lie at the other end of that interaction – the_**
gravitational force of you on the earth. This is how we can have equal and opposite forces, but yet have some form of net
acceleration.
There is a simple turn of phrase you can use to ensure that you are finding the correct third law partner to a force:


-----

For two interacting objects (object 1 and object 2):


**_Given a force on object 1 caused by object 2 in a given direction,_**

**_the 3[rd] law pair is_**
**_A force of the same type on object 2 by object 1 in the opposite direction._**


Above, I used the example of the gravitational force of the earth on you. The 3[rd] law statement for this situation would be

_For the gravitational force on you by the earth directed towards the center of the earth,_

_the third law pair is_
_A gravitational force on the earth by you directed towards the center of you._

Note that this statement has the same type of force and the object causing the force and acted on by the force are reversed, as
are the directions. Now, consider a box sitting on a flat table (see Figure 119-3). There are two forces acting on the box, the
gravitational force of the earth on the box (downward) and the normal force of the table on the box (upward). **_Note: The_**
**_normal force is not the 3[rd] law pair of the gravitational force. As we just saw above, the 3[rd] law pair of the gravitational_**
force on the box by the earth is a gravitational force of the box on the earth.
What about the normal force? Using our sentence pairs, we have

_For the normal force on the box by the table directed up,_

_the third law pair is_
_A normal force of the box on the table directed down._

The box pushes down on the table just as much as the table pushes up on the box.
A few notes about third law pairs

1) Third law pairs will never be in the same free body diagram since they act on different objects.
2) If you have a problem with multiple interacting objects, it’s often good to note third law pairs in some way

(subscripts). For example, if box 1 pushes on box 2 with a force of magnitude F21, the in the other free body
diagram you may want to call the force of box 2 on box 1 F12. This is tantamount to eliminating one unknown, since
you know those forces have the same magnitude and opposite direction.


Example 119 - 5 **A hanging mass**

For the 100 N mass below, identify the forces acting on the
box and state the third law pair for each force.

**Solution:**

This problem asks us to determine forces on a box as well as
the third law pair for each force. In order to do this, we first
show the free body diagram for the mass as


where 𝑇 is the tension force of the string on the box and
𝑚𝑔 is the gravitational force of the earth on the box (note
that we do not require calling this force, 𝐹�, it is just
important to be consistent).

To find the third law pair for each of these forces, we put
together our sentences:

There is a tension force of the string on the box upward,

the third law pair is
**A tension force of the box on the string downward.**

There is a gravitational force of the earth on the box

downward, the third law pair is
**A gravitational force of the box on the earth upward.**

Again, note that the third law pairs do not show up in our
free body diagram because they act on _different_ bodies
than the one if the diagram.


-----

