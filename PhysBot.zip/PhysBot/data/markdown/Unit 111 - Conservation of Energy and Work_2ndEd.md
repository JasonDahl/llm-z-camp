### – Conservation of Energy and Work
## 111


_Units 105 through 110 introduced a number of types of energy and how the conservation of energy can be used to describe_
_transfers between those types of energy in an isolated system. In this unit, we extend the conservation of energy to include_
_transfers of energy into and out of a system by mechanical work and heat. This leads to the most general form for the_
_conservation of energy, also known as the first law of thermodynamics._


##### The Bare Essentials

- The conservation of energy can become very complicated when

work due to external forces, heat, and all possible potential
energies and thermal energy are accounted for. This form of
the conservation of energy is also known as the first law of
**_thermodynamics._**



- Historically, there are two important special cases of the

conservation of mechanical energy equation:

 - The work-kinetic energy theorem states that the net
work done on a particle (or an object that cannot
deform) is equal to the object’s total change in kinetic
energy.

𝑊��� = ∆𝐾

The net work in the work-kinetic energy theorem
contains work due to both conservative and nonconservative forces.

- We can now solve conservation of energy problems

including
  - Kinetic energy
  - Gravitational potential energy
  - Elastic potential energy
  - Thermal energy
  - Rotational energy
  - Work
  - Heat


**Conservation of Energy**
**(1[st] law of Thermodynamics)**

𝚫𝑬= 𝑸+ 𝑾

**Description – This equation relates the change in energy of**

a system (∆𝐸) to energy transferred to the system by
heat (𝑄) and energy transferred through work done on
the system (𝑊).
**Note: Both 𝑄 and 𝑊 represent energy transfers into the**

system. If either are transferring energy out of the
system, they will be negative.



- **_Mecahnical energy (∆𝐸�, often listed as simply ∆𝐸) refers to_**

the sum of potenial and kinetic energies. The conservation of
mechanical energy states that the change in mechanical energy
of a system is equal to the mechanical work done on the
system.


**Conservation of Mechanical Energy**

𝚫𝑬𝒎 = 𝑾

**Description – This equation relates the change in**

mechanical energy of a system (∆𝐸�) to energy
transferred by work done on the system (𝑊).
**Note: 𝑊 represent energy transfer into the system. If**

mechanical energy is transferring out of the system, 𝑊
will be negative.


-----

#### 111.1 – The first law of thermodynamics

**Consider: How can we include external interactions in the**
conservation of energy?

E HAVE NOW DISCUSSED ALL of the forms of energy we are going to concern ourselves with in Physics I. In
units 103 – 109 we solved conservation of energy equations where all of the energy remains contained in the system.
We now extend this idea to allow a system of objects to interact with the environment – all of the space outside of

# W

the system we care about.
The first modification we can make the conservation of energy relates to unit 108. When energy is transferred out of a
system due to a difference in temperature between the system and the environment, this transfer is called heat. For heat, we
used the symbol Q, and we will define positive heat as heat (energy) entering a system from the environment. Although we
are now defining heat in terms of the system and environment, we have already discussed how to calculate it – heat is the
energy added do to temperature differences, which is mathematically equivalent to a change in thermal energy,

𝑄= ∆𝑈�� = 𝑚𝑐∆𝑇. (111-1)

Including heat into the conservation of energy, we find

∆𝐸= 𝑄. (111-2)

In addition to heat, energy can transfer into or leave a system due to work. There is a slight distinction that needs to be
made here – up until now we have defined mechanical work in terms of the energy transferred into or out of system due to a
force active over a distance. We have to expand the definition of work to include all types of energy transfer into or out of a
system that are not due to a temperature difference. This expanded definition of work is called **_thermodynamic work and_**
includes mechanical in addition to other, non-temperature dependent transfers. Unless specifically noted, in this course you
_can treat work as mechanical work.  If we now define the work done on a system (i.e. energy entering the system) as positive,_
we can again extend the definition of conservation of energy to

∆𝐸= 𝑄+ 𝑊. (111-3)

Equation 111-3 is a very general statement of the conservation of energy. This statement of energy conservation is also called
the fist law of thermodynamics since it includes of the energy and energy transferred required to consider the thermodynamics
of a system.


**Conservation of Energy**
**(1[st] law of Thermodynamics)**

𝚫𝑬= 𝑸+ 𝑾

**Description – This equation relates the change in all**

mechanical energy in a system (∆𝐸) to energy
transferred to the system by heat (𝑄) and energy
transferred through work done on the system (𝑊).
**Note: Both 𝑄 and 𝑊 represent energy transfers into the**

system. If either are transferring energy out of the
system, they will be negative.


The remainder of this unit will explore applications and specific situations of the first law of thermodynamics. Remember,
however, that this is the most general statement we can make for the conservation of energy, so if in doubt, return to this
definition and simplify it due to the conditions of your known system.
Most of classical physics is based on the first law of thermodynamics. In fact, in conjunction with the principle of
momentum studied in the next few units, we can solve almost every classical physics problem – at least in principle. In reality,
many problems are so complex that a complete, analytic solution cannot be readily achieved. In this way, professional
physicists go through similar process to all of you – deciding what are the most important terms in the equation.


-----

#### 111.2 – The conservation of mechanical energy

**Consider: How does a system react to external forces?**

In many cases, the energy involved in heat transfer are very small compared to the mechanical energies in a system. In
this case, we are only concerned with mechanical energy: kinetic energy, potential energies and mechanical work. Neglecting
heat transfer, the first law of thermodynamics then becomes the conservation of mechanical energy:

∆𝐸� = 𝑊, (111-4)

where 𝑊 represents the work on the system by interactions between the system and its environment, and ∆𝐸� is the change in
mechanical energy of the system (note, ∆𝐸� is often written as just ∆𝐸 when it is clear we only have mechanical energies to
deal with.


**Conservation of Mechanical Energy**

𝚫𝑬𝒎 = 𝑾

**Description – This equation relates the change in**

mechanical energy of a system (∆𝐸�) to energy
transferred by work done on the system (𝑊).
**Note: 𝑊 represent energy transfer into the system. If**

mechanical energy is transferring out of the system, 𝑊
will be negative.


The classic example of this system is when friction causes energy to leave a system, and we do not care about the change in
temperature resulting from the friction interaction. Consider the following two examples.


Example 111 - 1 **Work done by friction**

A 2.3-kg box slows from 7.6 m/s to 1.3 m/s over a distance of
5.4 m. What is a) the work due to friction on the box and b)
the magnitude of the average force of friction on the box?

**Solution:**

This is a conservation of energy problem with external work
due to friction. There is no potential energy or thermal energy
involved, so we need only be concerned with kinetic energy.
Since out system is that of the box and the earth, we have

∆𝐸= ∆𝐾� + ∆𝐾� = 𝑊�,

Where ∆𝐾� and ∆𝐾� are the change in kinetic energy of the box
and the earth, respectively. Since the mass of the earth is
enormous in relation to the box, we can also neglect the change
in kinetic energy of the earth.


a) Therefore, we have

∆𝐾� = [1]2 [𝑚𝑣][�]� − [1]2 [𝑚𝑣][�]� = 𝑊� = [1]2 [𝑚(𝑣][�]� −𝑣��).


We can then substitute our known values in order to find
the work due to friction as

𝑊� = [1]2 [(2.3 𝑘𝑔)[(1.3 𝑚𝑠]⁄ )[�] −(7.6 𝑚𝑠⁄ )[�]] = −64 𝐽.

b) Since friction and the displacement are along the same
axis, we can find the average force using


𝑊� = 𝐹���𝑑  →  𝐹��� = [𝑊]𝑑[�] [=] 5.4 𝑚[64 𝐽] [= 12 𝑁.]


Example 111 - 2 **Work done by friction on an incline**

A 5.6 kg cart slows from 4.5 m/s to a stop while traveling 0.75
m up an inclined plane. During this motion, the cart increases
its height by 0.45 m. Determine the work due to friction on
the cart during this period.


**Solution:**

This is a conservation of energy problem including work.
Our system is the cart and the earth, and we must consider


-----

kinetic energy and gravitational potential energy. Therefore,
the conservation of energy can be written

∆𝐸= ∆𝐾� + ∆𝐾� + 𝑈� = 𝑊�.

Since the earth is much more massive than the cart, we can
both ignore the change in kinetic energy of the earth and use
the gravitational potential energy near a large body for 𝑈�.
Therefore, the conservation of energy equation becomes

∆𝐸= [1]2 [𝑚𝑣][�]� − [1]2 [𝑚𝑣][�]� + 𝑚𝑔h� −𝑚𝑔ℎ� = 𝑊.


we can take the initial height of the cart to be zero, so that
ℎ� = 0. Therefore, we have

𝑊= 𝑚𝑔ℎ� − �� [𝑚𝑣][�]�.

Using our known values, we find


𝑊= (5.6 𝑘𝑔) �9.8 [𝑁]

𝑘𝑔[�(0.56 𝑚) −1]2 [(5.6 𝑘𝑔) �4.5 𝑚]𝑠 [�]

or


�


We know that the cart will come to a rest, so 𝑣� = 0, and


𝑊= −26 𝐽.


#### 111.3 – The conservation of energy and heat

**Consider: How does heat affect a system when no work is present?**

Another possible use of the conservation of energy is to consider what happens to a system when heat is allowed to flow across
a system’s boundary but no work is performed on the system. In this case, the conservation of energy reduces to

∆𝐸= 𝑄, (111-5)

The classic situation leading to this process is an object with a known mass dropped into a “heat bath,” which is an external
environment that is so large that it can be assumed to stay at the same temperature even as it transfers energy into our system
at a different temperature.


Example 111 - 3 **Example Problem**

Imagine a 11.4-kg piece of silver at 293 K is placed into a very
large bucket of water at 306 K. a) What is the maximum
amount of energy the silver can absorb from the water and b)
if this energy were given to the mass as mechanical work, how
fast would the silver be moving after receiving the energy
assuming it started at rest?

**Solution:**

This is a conservation of energy problem where there is a
change in thermal energy of a piece of silver and heat
transferred from a very large heat bath (which will not change
temperature). There is no work or change in kinetic or potential
energy to be concerned with in this problem. Therefore

∆𝐸= ∆𝑈�� = 𝑄.

a) Subsituting in for thermal energy, we get

𝑚𝑐∆𝑇= 𝑚𝑐�𝑇� −𝑇��= 𝑄.

From Unit 108, we find that the specific heat of silver is 235
J/(kgK). Using this and our other known values, we find

𝑄= (11.4 𝑘𝑔)(235 𝐽𝑘𝑔∙𝐾⁄ )(306 𝐾−293 𝐾),


78 m/s is equal to 174 miles per hour. Keep in mind that
this is the energy needed to change the piece of silver just
13° C (13 K). Also, it turns out that this equivalent speed
is independent of mass – meaning the energy to raise any
block of silver 13° C has the energy equivalent to get it
moving to this speed. To see this, we can substitute the
mass from part a) into the equation for part b) as,

𝑣� = √2𝑐∆𝑇.


which gives us

𝑄= 34 800 𝐽.

b) If all of this energy went into kinetic energy of the silver
(with zero initial kinetic energy), we would have

𝑄= K� = [1]2 [𝑚𝑣][�]�.


Solving for the final speed we get

𝑣� = [�2𝑄]𝑚 [= �2(34 800 𝐾)]11.4 𝑘𝑔 = 78 𝑚𝑠⁄ .


-----

The ways in which the first law of thermodynamics and the conservation of mechanical energy can be used are uncountable.
Since these equations use terms for kinetic and potential energies of any interacting objects, there is no limit to the types of
problems that can be solved using this technique. Below, are just a couple more examples that bring types of energy and energy
transfers in ways that we haven’t used them yet.
To put the whole thing in perspective – here is a possible first law of thermodynamics equation for just two objects that
interact in ways we’ve discussed in Physics I that might also include friction and heat:

∆E = ∆K� + ∆𝐾� + ∆𝑈� + ∆𝑈� + ∆𝑈��,� + ∆𝑈��,� + ∆𝐾�� + ∆𝐾�� = 𝑊� + 𝑄. (111-6)

In reality, as we have seen, we can often neglect some of these terms because they are small compared to the others. However,
we lose some of the most interesting physics is doing this. In Physics II, we will explore earthquakes and their mechanical
energy. At first glance, it makes sense to neglect the change in kinetic energy of the earth during such a local event. Well, the
2004 Indonesian earthquake (which caused a massive, deadly tsunami), changed the earth’s kinetic energy enough to change
the length of a day by a measureable amount – granted a very small amount, but something we can measure. These small
effects may not always show up in Physics I, but they are the active research areas of physics today.

#### 111.4 – Applications of the Conservation of Mechanical Energy

**Consider: What is the work-kinetic energy theorem?**

In this course we have introduced the conservation of energy in its most general form by building up all of the possible
pieces and shown how they can be modeled as a single equation containing kinetic energy, potential energies, thermal energies,
heat and work. Although this model fits better as a conceptual framework relative to a traditional, historical introduction to
physics, we have left out a couple of ‘theorems’ that you may come across in your future studies. Keep in mind that these are
applications of the conservation of energy, and can be used in specific instances. You can always return to the general
Conservation of Energy equation if you are feeling quite comfortable with it.

The work-kinetic energy theorem

In Unit 110, we discussed how to find the net work, 𝑊��� on an object as the sum of the work due to each individual force
that acts on the object. The **_work-kinetic energy theorem (sometimes called simply the work-energy theorem) relates the_**
_change in kinetic energy of an object to the net work done on the object by external forces. Please note, that this can be the_
work done by either conservative or non-conservative forces. Therefore, when we write the conservation of energy equation
in this way, we will not have any potential energy terms (they will be included in the work), leading to

∆𝐾= 𝑊���, (111-7)

where ∆𝐾 is the change in kinetic energy of an objet and 𝑊��� must be the work done on the object by all of the forces acting
on it.
The work-kinetic energy theorem is one way to look at the conservation of energy for a particle (or object that will not
deform). Whereas the full treatment of the conservation of energy considers potential energies that are related to the system
and to a give particle, the work-kinetic energy relates the work due to all forces (conservative and non-conservative) to their
affects directly on the particle, regardless of what happens to the rest of the external system. This can be a very powerful
technique for looking at changes in motion of an object.


Example 111 - 6 𝚫𝑲 from net work

In example 110-9, we explored how to find the net work on a
box being pushed up an inclined plane with friction. What is
the final speed of the box after its displacement if it starts at at
a very slow speed (almost zero)?

**Solution:**

This questions is a direct application of the work-kinetic energy
theorem. We found the net work on the box in example 110-9
to be 0.3 J.


Therefore, the change in kinetic energy is also

∆𝐾= 𝑊��� = 0.3 𝐽.

We can now use the classical definition of kinetic energy
to get the change in speed

∆𝐾= [1] � − [1] � = 𝑊.

2 [𝑚𝑣][�] 2 [𝑚𝑣][�]


-----

Example 111 - 7 **Work-kinetic energy theorem**

A 42-N force directed 23° above the horizontal, acts to move a
2.0-kg block of ice across a flat, horizontal surface a
displacement of 5.3 m. If the block has an initial speed of 8.2
m/s, what is the final speed of the block in the absence of
friction?

**Solution:**

We can solve this using the work-energy theorem with a single
force leading to the net work.

First, we must find the work on the system due to the (constant)
42-N force as

𝑊��� = 𝐹[⃗] ∙𝑑[⃗] = �𝐹[⃗]��𝑑[⃗]�cos 𝜃,
or

𝑊��� = (42 𝑁)(5.3 𝑚)(cos 34°) = 205 𝐽


Using this work, we can now apply the work-kinetic
energy theorem

𝑊��� = ∆𝐾= [1]2 [𝑚𝑣][�]� − [1]2 [𝑚𝑣][�]�.


Solving for the final speed, we get

𝑣� = [�]𝑣�� + [2𝑊]𝑚 [= �(8.2 𝑚𝑠]⁄ )[�] + [2(205 𝐽)]2.0 𝑘𝑔 [,]


which gives us


𝑣� = 16.5 𝑚𝑠⁄ .


-----

