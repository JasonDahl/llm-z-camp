### – Energy in Rotation
## 109


_Unit 109 introduces rotational motion and the kinetic energy of rotation. In order to accomplish this, we will discuss_
_how to measure angles and the rate of change of angles, as well as the moment of intertia – the angular compliment to_
_mass._


##### The Bare Essentials

- The arc length traced out by a point rotating 𝜃𝜃 radians around

a circle of radius 𝑟𝑟 has a well-defined relationship.



- The rotational kinetic energy of a rigid body depends on its

moment of inertia and its angular speed


**Arc length**


𝒔𝒔 = 𝒓𝒓𝒓 𝒓

**Description – This equation defines the arc length, 𝑠𝑠, of a point**

particle rotating an angle, 𝜃𝜃, around a circle of radius 𝑟𝑟.
**Note: 𝜃𝜃** **_must be in radians._**

- For a rotating rigid body, the angular speed of a point on that
body is related to the linear speed of the same point by its
distance to the axis of rotation.


**Rotational Kinetic Energy**

𝑲𝑲𝒓𝒓𝒓𝒓𝒓 𝒓 = [𝟏]𝟐𝟐 [𝑰][𝑰][𝝎][𝝎][𝟐][𝟐]

**Description – This equation defines the rotational kinetic energy**

of a body using the moment of inertia, 𝐼𝐼, and angular speed, 𝜔𝜔,
of the body.
**Note 1: This equation can only be used for particles or rigid**

bodies.
**Note 2: This equation should only be used in the classical limit.**


**Angular speed**

𝝎𝝎 = [𝒗]
𝒓𝒓


**Description – This equation defines the angular speed, 𝜔𝜔, of a**

rotating rigid object in terms of the linear speed, 𝑣𝑣, of a point a
distance, 𝑟𝑟, from the axis of rotation.
**Note 1: 𝜔𝜔** = 𝑑𝑑𝑑 𝑑⁄𝑑𝑑𝑑
**Note 2: The SI units of angular speed is radian/second (rad/sec).**

- The moment of inertia of an object describes its rotational
inertia – its ability to resist changes in rotation.



- If an object is rolling without slipping, the linear speed of its
center of mass is related to its angular speed by 𝑣𝑣𝑙𝑙𝑙𝑙𝑙𝑙 = 𝜔𝜔𝜔𝜔,
where r is the radius of the object.

- An object that is rolling without slipping contains both linear
and rotational kinetic energy.


object as the sum of its translational kinetic energy and its
rotational kinetic energy.

- We can now solve conservation of energy problems including

  - Kinetic energy
  - Gravitational potential energy
  - Elastic potential energy
  - Thermal energy
  - Rotational energy


**Rolling Without Slipping**

𝑲𝑲𝒕𝒕𝒕𝒕𝒕 𝒕 = 𝑲𝑲𝒍𝒍𝒍𝒍𝒍 𝒍 + 𝑲𝑲𝒓𝒓𝒓𝒓𝒓 𝒓 = [𝟏]𝟐𝟐 [𝒎][𝒎][𝒗][𝒗]𝟐[𝒄][𝒄][𝒄] + [𝟏]𝟐𝟐 [𝑰][𝑰][𝝎][𝟐][𝝎] [𝟐]

**Description – This equation defines the total kinetic energy of a**


**Moment of Inertia**

𝑰𝑰 = �𝒓[𝟐]𝒓 [𝟐]𝒅𝒅𝒅 𝒅

**Description – This equation allows us to calculate the moment of**

inertial of an object based on its geometry.
**Note 1: The integral represents a sum of all tiny pieces of mass,**

𝑑𝑑𝑑 𝑑, a distance, 𝑟𝑟, from the axis of rotation.
**Note 2: The SI units for 𝐼𝐼 is 𝑘𝑘𝑘** 𝑘 ∙𝑚𝑚[2]


-----

#### 109.1 – Radians and Degrees

**Consider: How do we measure angles?**

MAGINE THAT YOU SPIN A BALL on a vertical axis such as the one
shown in Figure 109-1, where we have defined the vertical axis as the z-axis.
How could we describe the motion of particles on the surface of this ball.

# I

First, consider a point that starts on the surface of the ball on the positive x-axis.
If the ball is rotating counterclockwise as viewed from above, then that particle
will move around the dotted circle shown in the figure, moving from its starting
point on the positive x-axis through the positive y-axis and continue on all the
way back to the positive x-axis. When it has completed one trip around, we say
that the ball has gone through one **_revolution. When the particle has moved_**
from the positive x-axis to the positive y-axis, it has completed one-fourth of its
trip, so this would be one-quarter revolution, etc.
The angle that our particle has moved as it rotates around is a measure of
the fraction or multiple of its revolution. The most common unit used in the **Figure 109-1. Defining axes for a**
United States for angles is the degree, which is defined as 1/360 of a revolution. **spinning ball.**
The degree is an ancient unit and where this definition comes from is unknown.
In this awkward set of units, one revolution is 360 degrees (noted as 360°), and a right angle is 90°. Of course, we have been
using degrees throughout this book when discussing angles of vectors; however, we are now defining the unit relative to a
rotating object.
To be precise, when our particle has rotated a certain angle, 𝜃𝜃, as it rotates, it traces
our an arc-length, 𝑠𝑠, as shown in Figure 109-2.  When the particle has completed one
revolution, the arc length would be equal to the circumference of the circle that it
traced,
𝐶𝐶= 2𝜋𝜋𝜋𝜋, (109-1)

where C is the circumference, and r is the radius of the circle traced out by the particle.
Now, if you wanted to describe the arc length of a half-circle, what we could do is
divide both sides of the circumference equation by two giving us

**Figure 109-2. Definition of the** 1 (109-2)
**arc length, s.** 2 [𝐶𝐶= 𝜋𝜋𝜋𝜋,]

but what we have really done is allow the particle to only rotate through half the angle
that it does for the full circumferences. Therefore, what equation 109-1 is really saying is
that the arc length traced out (subtended) by a rotating particle is related to the radius of
the circle it is tracing and the angle through which it moves.
In addition to degrees, there is a second unit of angle, the **_radian that helps us use_**
this definition of arc length directly. One radian is defined as the angle at which the arc
length is equal to the radius as shown in Figure 109-3. It turns out that it takes an arc
length that is 2𝜋𝜋 of any radius to fully go around a circle. This is the 2𝜋𝜋 in 𝐶𝐶= 2𝜋𝜋𝜋𝜋!
Using this definition of the radius, we can write down any arc length relative to the
radius and the arc-length subtended as

𝑠𝑠= 𝑟𝑟𝑟𝑟. (109-3)

**Figure 109-3. Definition of the**
**radian.**

Again, I cannot stress enough that to use equation 109-3, the angle, 𝜃𝜃, must be in radian!!
Knowing that there are 360° and 2𝜋𝜋 radians in a circle, we can set up a direct conversion factor:

𝜋
𝜃𝜃𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟𝑟 = (109-4)
180 [𝜃𝜃][𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑𝑑][.]


-----

**Arc length**


𝒔𝒔 = 𝒓𝒓𝒓𝒓

**Description – This equation defines the arc length, 𝑠𝑠, of a**

point particle rotating an angle, 𝜃𝜃, around a circle of
radius 𝑟𝑟.
**Note: 𝜃𝜃** **_must be in radians._**

Consider the units in our equation for arc length (equation 109-3 and the arc length box above). Both the radius, 𝑟𝑟, and
arc length, 𝑠𝑠, should have units of length. This means that in order to balance the units in this equation, the angle, 𝜃𝜃, should
be unitless! In fact, this is the case. Both degrees and radians are called pseudo-units and they are really placeholders – they
don’t change the balance of units in any equation or problem. Therefore, it is very important that you keep track of angular
units and in fact

**you should always use radians for any angle that is not the argument of a trig function.**

If an angle is the argument of a trig function (30° in **Table 109-1. Conversion equations for important rotational**
sin 30° for example), be very careful that your **measures.**
calculator is set the correct units, but feel free to **Catagory** **Description**
use whichever set of units makes sense for the 𝜋
problem. The issue with radians versus degrees **Degrees to radians** 𝜃𝑟𝜃 𝑟𝑟𝑟𝑟 𝑟𝑟 𝑟𝑟 𝑟𝑟𝑟𝑟𝑟 = 180 [𝜃][𝑑][𝜃] [𝑑][𝑑] [𝑑][𝑑] [𝑑][𝑑][𝑑][𝑑][𝑑][𝑑] [𝑑][𝑑][𝑑]
really only exists for bare angles such as in the arc

**Radians to revolutions** # 𝑅𝑅𝑅𝑅𝑅 𝑅𝑅𝑅𝑅𝑅𝑅𝑅𝑅 𝑅𝑅 𝑅𝑅𝑅𝑅𝑅𝑅 𝑅 = [𝜃][𝑟][𝜃] [𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟][𝑟]

length formula. You _will get the wrong answer if_ 2𝜋
you don’t use radians in this case. The conversion
factors between revolutions, radians and degrees **Degrees to revolutions** # 𝑅𝑅𝑅𝑅𝑅 𝑅𝑅𝑅𝑅𝑅𝑅𝑅𝑅 𝑅𝑅 𝑅𝑅𝑅𝑅𝑅𝑅 𝑅 = [𝜃][𝑑][𝜃] [𝑑][𝑑][𝑑][𝑑] [𝑑][𝑑][𝑑][𝑑][𝑑][𝑑] [𝑑][𝑑]

360

are summarized in Table 109-1.


Example 109 - 1 **Angle and arc length**

What arc length corresponds to a rotation of 𝜋𝜋⁄ radians at a 3
radius of 3.3 cm?

**Solution:**

This is a direct application of the relationship between angle,
radius and arc length.


In order to solve this, we use with the equation for arc
length,

𝑠𝑠 = 𝑟𝑟𝑟 𝑟 = (3.3 𝑐𝑐𝑐 𝑐)(𝜋𝜋⁄ ) = 1.1𝜋3 𝜋 𝑐𝑐𝑐 𝑐.

Although this is the most accurate way to report the arc
length, we could also approximate pi, giving us 3.5 cm.


Example 109 - 2 **Converting angular units**

A boy is sitting on the very edge of a merry-go-round, which
has a radius of 11.2 m. If the boy completes 2.5 revolutions,
determine

(a) the angle in radians that the boy has traveled,
(b) the angle in degrees the boy has traveled,
(c) the arc length the boy has traveled.

**Solution:**

This problem asks us to use our knowledge of rotational
variables to convert between angular systems as well as
calculate an arc length.

(a) The conversion factor between revolutions and radians is


given in Table 109-1, so we find

𝜃𝑟𝜃 𝑟𝑟𝑟𝑟 𝑟 = 2𝜋𝜋(#𝑟𝑟𝑟 𝑟𝑟𝑟) = 2𝜋𝜋(2.5 𝑟𝑟𝑟 𝑟𝑟 𝑟) = 5𝜋𝜋 𝑟𝑟𝑟 𝑟𝑟 𝑟.

(b) We can now either convert from either revolutions or
radians to degrees:

𝜃𝑑𝜃 𝑑𝑑 𝑑𝑑 𝑑 = [180]
𝜋𝜋 [𝜃][𝑟][𝜃] [𝑟][𝑟][𝑟][𝑟] [𝑟] [= 180]𝜋𝜋 [(5𝜋][𝜋][ 𝑟][𝑟][𝑟] [𝑟][𝑟] [𝑟][) = 900°.]

(c) The arc length is found using Equation 109-3:

𝑠𝑠 = 𝑟𝑟𝑟 𝑟 = (11.2 𝑚𝑚)(5𝜋𝜋 𝑟𝑟𝑟 𝑟𝑟 𝑟) = 176 𝑚𝑚.

Note: radians must be used to have the result in meters!


-----

#### 109.2 – Angular velocity and speed

**Consider: How do we measure speed for rotating objects?**

Imagine you have a mass at the end of a string and you are rotating the mass around in a
circle. At any point, the velocity of the mass is perpendicular to the string, which is to
say that the velocity vector is perpendicular to the radius vector, as shown in Figure
109-4. In the figure, the velocity vector of two points is shown, separated by an angle,
𝜃𝜃, with respect to each other.
Here’s a thought experiment: Think of two points on a disk; one point at radius 𝑟𝑟1 =
𝑟𝑟 and one point at a radius of 𝑟𝑟2 = 2𝑟𝑟 from the center of the disk. As the disk rotates,
both points must go through the same angle, 2𝜋𝜋 radians, in the same amount of time to
complete one revolution. I will define the angular speed, 𝝎𝝎, of the point as the angle
traveled divided by the time it takes to travel that angle

(109-5)

𝜔𝜔= [Δ𝜃]

Δ𝑡𝑡 [,]


**Figure 109-4. Velocity of a**
**rotating object.**


where Δ𝜃𝜃 is the angle traveled in time Δ𝑡𝑡. From this, you can see that if both of our particles traveled 2𝜋𝜋 radians in the same
time (since the disk is solid), then both points must have the same angular speed (in radians per second since we have radians
in the numerator and seconds in the denominator).
Contrast this with the linear speed of each point. In order to go once around the circle, each point must complete one
circumference in the same time. Therefore, the linear speed of each point is

(109-6)

𝑣𝑣1 = [2𝜋][𝜋][𝑟][1][𝑟]

Δ𝑡𝑡 [= ][2𝜋]Δ𝑡[𝜋][𝜋] 𝑡 [     and   𝑣𝑣][2][ = ][2𝜋]Δ𝑡[𝜋][𝑟]𝑡[2][𝑟] [= ][4𝜋]Δ𝑡[𝜋][𝜋] 𝑡 [.]

As you can see, the linear speed of each point is different! The point farther away from the center of the disk has a higher
speed because it has to move a greater distance in the same period of time.
This quick example illustrates the importance of angular speed. Every point on a solid body, also known as a rigid body
must have the same angular speed, otherwise the body would deform. This is not true of linear speed. We can show the
relationship between angular speed and linear speed by first looking at the relationship between arc length and radius,

𝑠𝑠= 𝑟𝑟𝑟𝑟, (109-7)

and then taking the derivative with respect to time, assuming the radius does not change

(109-8)

𝑣𝑣 = [𝑑][𝑑][𝑑]

𝑑𝑑𝑑 𝑑 [= 𝑟][𝑟] [𝑑]𝑑[𝑑][𝑑]𝑑𝑑 𝑑 [= 𝑟][𝑟][𝑟] [𝑟][   →   𝑣][𝑣] [= 𝑟][𝑟][𝑟] [𝑟][.]

This description of angular speed is summarized in the box below.


**Angular speed**

𝝎𝝎 = [𝒗]
𝒓𝒓


**Description – This equation defines the angular speed, 𝜔𝜔,**

of a rotating rigid object in terms of the linear speed, 𝑣𝑣,
of a point a distance, 𝑟𝑟, from the axis of rotation.
**Note: 𝜔𝜔** = 𝑑𝑑𝑑 𝑑⁄𝑑𝑑𝑑

Just as linear velocity is a combination of an objects speed and direction, angular velocity is combines and object’s angular
speed and direction. However, if an object is rotating, the rotation defines a plane. In order to define the direction of
rotation, we will use a vector that is perpendicular to the plane of the rotation, such that if you look along the vector arrow
(towards the point at the front of the arrows from the back of the arrow), the object rotates clockwise. For an object rotating
in a horizontal plane, these vectors are shown in Figure 109-5.


-----

Another way to determine the direction of the
angular velocity vector is to use one of the right hand
**_rules. If you curl the fingers of your right hand in the_**
direction of the rotation with your thumb outstretched,
your thumb will point in the direction of the angular
velocity vector. The direction of such vectors will be
quite important when we revisit them in Unit 117 on
angular momentum.


**Figure 109-5. Angular velocity vectors for rotations in a horizontal**
**plane.**


Example 109 - 3 **Circling helicopter**

While investigating the scene of a marine incident, an H-60
circles counterclockwise (as seen from above) at a speed of 20
m/s. The radius of the circle traced out by the path of the
helicopter is 35 m. What is the H-60’s angular velocity?

**Solution:**

This asks us to use our knowledge of angular speed and
direction to find an angular velocity.


To find the angular speed, we use equation 109-8,

𝜔𝜔 = [𝑣]
𝑟𝑟 [= 20 𝑚]35 𝑚[𝑚][/𝑠]𝑚 [= 0.57 𝑟][𝑟][𝑟] [𝑟][𝑟] [𝑟][/𝑠][𝑠][.]

We can use Figure 109-5 to find the direction. If the H60 is counterclockwise as seen from above, the figure
suggests that the direction of the angular velocity is up
(picture on the right side of the figure).


#### 109.3 – Moment of inertia

**Consider: Why does shape matter when it comes to rotations?**

Since any particle undergoing rotation motion is, by definition, moving, it must possess kinetic energy. Let’s first start by
writing the kinetic energy equation using angular speed:

(109-9)

𝐾𝐾= [1]

2 [𝑚𝑚𝑣𝑣][2][ = ][1]2 [𝑚𝑚(𝜔𝜔𝜔𝜔)][2][ = ][1]2 [(𝑚𝑚𝑟𝑟][2][)𝜔𝜔][2][,]

where m is the mass of the particle, r is the distance of the particle from the axis of rotation and 𝜔𝜔 is the angular speed related
to the linear speed as in the last section. Equation 109-9 gives us a rotational analogy to the linear kinetic energy equation.
Now, remember that the discussion so far is focused on a single, small particle. I’m going to define the moment of inertia, I,
of the particle, as the part of the kinetic energy equation that plays the role of inertia (mass) in the linear kinetic energy
equation. In equation 109-9, the 𝑚𝑚𝑟𝑟[2]in parentheses in the last term plays this role since it is the term between the ½ and the
speed term. Therefore

(109-10)

𝐾𝐾𝑟𝑟𝑟𝑟𝑟𝑟,𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝 = [1]

2 [𝐼𝐼][𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝][𝜔𝜔][2][.]

The subscripts on equation 109-10 are there to remind you that this is the kinetic energy of rotation for a single particle.
Any real, rigid body is made up of many, many small particles which may be at different radii from the axis of rotation.
We can go from an equation for the rotational kinetic energy of a particle to that of a full body by summing the moments of
inertia of each particle such as

𝐼𝐼= 𝐼𝐼1 + 𝐼𝐼2 + 𝐼𝐼3 + ⋯= 𝑚𝑚1𝑟𝑟12 + 𝑚𝑚2𝑟𝑟22 + 𝑚𝑚3𝑟𝑟32 + ⋯. (109-11)

Assuming that each individual particle is very small and that this sum will be made over a large number of particles, we can
turn this sum into an integral by allowing 𝑟𝑟[2] to be the integrand and the mass to be the variable over wich we are integrating,
given us

𝐼𝐼= �𝑟𝑟[2]𝑑𝑑𝑑𝑑. (109-12)


As with all integrals, keep in mind that it is really a sum. For example, if you a body is made up of three objects, all of
which you already know the moment of inertia for, you can simply add those three moments. However, in a case where you
do not know the moments, you can, in principle, calculate it using equation 109-12.


-----

**Moment of Inertia**

𝑰𝑰 = �𝒓𝒓[𝟐][𝟐]𝒅𝒅𝒅 𝒅

**Description – This equation allows us to calculate the**

moment of inertial of an object based on its geometry.
**Note 1: The integral represents a sum of all tiny pieces of**


mass, 𝑑𝑑𝑑 𝑑, a distance, 𝑟𝑟, from the axis of rotation.
**Note 2: The SI units for 𝐼𝐼 is 𝑘𝑘𝑘𝑘** ∙𝑚𝑚[2]

The moment of inertia is also called **_rotational inertia. Just as mass is a_**
measure of a body’s resistance to change in motion (inertia), the moment of inertia
measures a body’s resistance to change in rotational motion. You have most likely
seen this with tight rope walkers, as shown in figure 109-6. Many tight rope
walkers will hold a very long pole in the center. Since some of the mass is very
far away from the axis of rotation (the tight rope walker), it has a high moment of
inertia. Therefore, the entire system, including the walker will resist changes in
rotation, making it easier for the walker to correct for any motion away from
his/her stability points.
Although the ability to calculate the moment of inertia of an extended body is
important, there are a number of common shapes for which it is important to have
easy access to 𝐼𝐼, Table 109-2 gives the moment of inertial of a number of common **Figure 109-6. Tight rope walker Samuel**
shapes. **Dixon using a long pole for stability.**


**Table 109-2. Inertia of some common solids.**

**Shape** **Figure** **I**

**Particle** 𝐼𝐼= 𝑀𝑀𝑟𝑟[2]

**Rod of length L**
**held at end** 𝐼𝐼= [1]

3 [𝑀𝑀𝐿𝐿][2]

**Rod of length L**
**held in the center** 𝐼𝐼= [1]

12 [𝑀𝑀𝐿𝐿][2]


-----

Example 109 - 4 **A sphere’s inertia**

Find the moment of inertia of a solid sphere with a mass of
1.75 kg and a radius of 1.50 m.

**Solution:**

This is a direct application of the equation for moment of
inertia of an extended object.


𝐼𝐼 = [2]

5 [(1.75 𝑘][𝑘][𝑘][𝑘][)(1.50 𝑚][𝑚][)][2][ = 1.58 𝑘][𝑘][𝑘][𝑘] [∙𝑚][𝑚][2][.]


From Table 109-2, we see that the moment of inertia of a
solid sphere is


Therefore,


𝐼𝐼 = [2]
5 [𝑀][𝑀][𝑅][𝑅][2][.]


Example 109 - 5 **Dvd**

What is the moment of inertia of a dvd disk
with a mass of 16 g, and inner radius of 10 mm
and an outer radius of 59 mm? (Note: this
missing mass in the hole of a dvd would be
about 0.5 g).

**Solution:**

This is a complex (meaning more than one step) moment of
inertia problem. A dvd can be considered a solid disk with
radius given by the outer radius, with a solid disk given by its
inner radius removed to form the hole.
The moment of inertia of a disk is

𝐼𝐼 = [1]

2 [𝑀][𝑀][𝑅][𝑅][2][,]


𝐼𝐼 = [1]
2 [(0.016 𝑘][𝑘][𝑘] [𝑘][)(0.059 𝑚][𝑚][)][2][ −1]2 [(0.0005 𝑘][𝑘][𝑘] [𝑘][)(0.010 𝑚][𝑚][)][2][.]

Which gives us

𝐼𝐼 = 2.78 𝑥𝑥 10[−5] 𝑘𝑘𝑘 𝑘 ∙𝑚𝑚[2]

Keep in mind that since the moment of inertia for an
extended body is the sum of the moments for each
particle in the body, we can add or subtract pieces as we
just did.


therefore the moment of inertia for the dvd player would
be


or


𝐼𝐼 = [1] 2 − [1] 2,
2 [𝑀][𝑑][𝑀] [𝑑][𝑑] [𝑑][𝑑] [𝑑][𝑑] [𝑑][𝑅][𝑜][𝑅] [𝑜][𝑜] [𝑜][𝑜][𝑜][𝑜][𝑜][𝑜] 2 [𝑀][ℎ𝑜][𝑀] [𝑜][𝑜] [𝑜][𝑜] [𝑜][𝑅][𝑖][𝑅] [𝑖][𝑖] [𝑖][𝑖][𝑖][𝑖][𝑖][𝑖]


#### 109.4 – Rotational kinetic energy

**Consider: How much energy does it take to rotate and object?**

In the last section, we showed that the rotational kinetic energy of a particle is given by

(109-13)

𝐾𝐾𝑟𝑟𝑟𝑟𝑟𝑟,𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝 = [1]

2 [𝐼𝐼][𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝𝑝][𝜔𝜔][2][,]

and then went on to show how to find the moment of inertia of an entire object as the sum of inertias for each particle. It
follows that the rotational kinetic energy of a body is given by the sum of the rotational kinetic energies of each particle;
however, since 𝜔𝜔 is the same for all particles on a rigid body, the total rotational kinetic energy can be written

(109-14)

𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1]

2 [𝐼][𝐼][𝜔][𝜔][2][.]


**Rotational Kinetic Energy**

𝑲𝑲𝒓𝒓𝒓 𝒓𝒓 𝒓 = [𝟏]
𝟐𝟐 [𝑰][𝝎][𝑰] [𝟐][𝝎] [𝟐]

**Description – This equation defines the rotational kinetic**

energy of a body using the moment of inertia, 𝐼𝐼, and
angular speed, 𝜔𝜔, of the body.
**Note: This equation can only be used for particle and rigid**

bodies.


-----

Example 109 - 6 **Spinning hoop**

A hoop rotates about an axis through its center and
perpendicular to the plane of the hoop. If the mass of the
hoop is 2.5 kg, the radius is 0.45 m and it rotates with an
angular speed of 8.2 rad/s, what is the rotational kinetic
energy of the hoop?

**Solution:**

This problem asks us to use the equation for rotational kinetic
energy. In order to do this, we will need to determine the
moment of inertia of a hoop.
We start with the equation for the rotational kinetic
energy of an extended object,

𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1]

2 [𝐼][𝐼][𝜔][𝜔][2][.]


From Table 109-2, we can see that the moment of inertia
of a hoop is

𝐼𝐼 = 𝑀𝑀𝑅𝑅[2];

therefore the rotational kinetic energy can be written

𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1]
2 [(𝑀][𝑀][𝑅][𝑅][2][)𝜔][𝜔][2][.]

Since we know each of these values, we can directly
compute the kinetic energy as

𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1] ⁄ ) = 17 𝐽𝐽.

2 [(2.5 𝑘][𝑘][𝑘][𝑘][)(0.45 𝑚][𝑚][)][2][(8.2 𝑟][𝑟][𝑟] [𝑟][𝑟] [𝑟] [𝑠]


#### 109.4 – Rotating and translating

**Consider: How do we account for rotating and moving?**

When you are riding down the street on a bicycle, the wheels are not only rotating, but they are also moving in a straight line.
Each of these motions contains kinetic energy and the total kinetic energy of each wheel is given by the sum of the linear
kinetic energy and rotational kinetic energy

𝐾𝐾= 𝐾𝐾𝑙𝑙𝑙𝑙𝑙𝑙 + 𝐾𝐾𝑟𝑟𝑟𝑟𝑟𝑟, (109-15)

where 𝐾𝐾𝑙𝑙𝑙𝑙𝑙𝑙 is the linear kinetic energy and 𝐾𝐾𝑟𝑟𝑟𝑟𝑟𝑟 is the rotational kinetic energy. In a general sense, each of these kinetic
energies must be found separately using their respective equations. However, in the case of **_rolling without slipping, the_**
rolling object (wheel in the bicycle example above) rolls along such that for every rotation of the wheel, the wheel itself
moves forward a distance equal to its circumference. As a visual, picture a wheel in which we have smeared the edge with
ink. As the wheel rolls, it will leave a trail of ink on the ground as it rolls, and for each revolution of the wheel, the line of
ink on the ground will be equal to the circumference of the wheel itself. In this case the linear speed of the object, 𝑣𝑣𝑙𝑙𝑙𝑙𝑙𝑙 is
related to its angular speed, 𝜔𝜔 by
𝑣𝑣𝑙𝑙𝑙𝑙𝑙𝑙 = 𝜔𝜔𝜔𝜔, (109-16)

and the total kinetic energy can be written

2

2 2 (109-17)

𝐾𝑡𝐾 𝑡𝑡𝑡𝑡 𝑡 = 𝐾𝑙𝐾 𝑙𝑙 𝑙𝑙 𝑙 + 𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1] + [1] + [1]

2 [𝑚][𝑚][𝑣][𝑙][𝑣] [𝑙][𝑙] [𝑙][𝑙] 2 [𝐼][𝐼][𝜔][𝜔][2][ = 1]2 [𝑚][𝑚][𝑣][𝑙][𝑣] [𝑙][𝑙] [𝑙][𝑙] 2 [𝐼][𝐼] [𝑣]𝑟[𝑙][𝑣] 𝑟[𝑙][𝑙][2][𝑙][𝑙][ .]


**Rolling Without Slipping**

𝑲𝑲𝒕𝒕𝒕 𝒕𝒕 𝒕 = 𝑲𝑲𝒍𝒍𝒍 𝒍𝒍𝒍 + 𝑲𝑲𝒓𝒓𝒓 𝒓𝒓 𝒓 = [𝟏] 𝟐 + [𝟏]
𝟐𝟐 [𝒎][𝒎][𝒗][𝒗][𝒍][𝒍][𝒍] [𝒍][𝒍] 𝟐𝟐 [𝑰][𝝎][𝑰] [𝟐][𝝎] [𝟐]

**Description – This equation defines the total kinetic energy**

of an object as the sum of its translational kinetic energy
and its rotational kinetic energy.


-----

Example 109 - 7 **Example Problem**

A 6.4-kg bowling ball with a radius of 11 cm rolls towards
you without slipping with a linear speed of 2.3 m/s. (a) What
is the angular velocity of the ball? (b) What is the total
kinetic energy of the ball?

**Solution:**

(a) The angular speed of the ball can be determined from the
relationship between angular and linear speed,

⁄
𝜔𝜔 = [𝑣] ⁄ .
𝑟𝑟 [= 2.3 𝑚]0.11 𝑚[𝑚] [𝑠]𝑚 [= 21 𝑟][𝑟][𝑟] [𝑟][𝑟] [𝑟] [𝑠]

The direction of the angular velocity is found using the righthand-rule. Since the ball is moving towards you, holding
your hand out and curling your fingers up towards you shows
your thumb point to the right – the direction of 𝜔𝜔 is to the
right.


(b) The total kinetic energy of the ball is

𝐾𝑡𝐾 𝑡𝑡𝑡𝑡 𝑡 = 𝐾𝑙𝐾 𝑙𝑙 𝑙𝑙𝑙 + 𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = [1] [1]
2 [𝑚][𝑚][𝑣][𝑣][2][ +] 2 [𝐼][𝐼][𝜔][𝜔][2][.]

The moment of inertia of a solid ball is (2/5)mr[2].
Therefore, the total kinetic energy is

𝐾𝑡𝐾 𝑡𝑡𝑡𝑡 𝑡 = [1] [1] [7]
2 [𝑚][𝑚][𝑣][𝑣][2][ +] 2 [�][2]5 [𝑚][𝑚][𝑟][𝑟][2][�𝜔][𝜔][2][ =] 10 [𝑚][𝑚][𝑣][𝑣][2][,]

since we know that 𝑣𝑣[2] = 𝑟𝑟[2]𝜔𝜔[2]. Substituting in our
known values give a final result of

𝐾𝑡𝐾 𝑡𝑡𝑡𝑡 𝑡 = [7] ⁄ )[2] = 24 𝐽𝐽.
10 [(6.4 𝑘][𝑘][𝑘][𝑘][)(2.3 𝑚][𝑚] [𝑠]


#### 109.5 – Conservation of energy with rotational energy

**Consider: How do we include rotations in the conservation of energy?**

We are now prepared to use rotational kinetic energy as part of our conservation of energy equations. Please see the
examples below.


-----

Example 109 - 9 **Example Problem**

A solid disk compresses a spring horizontally, with spring
constant of 76 N/m, a displacement 0.56 cm from its
equilibrium position. If the disk rolls without slipping after
the spring is released, how fast will it roll on a flat surface?
The mass of the disk is 19 g.

**Solution:**

This is a conservation of energy problem including elastic
potential energy of a spring and kinetic energy (both linear
and rotational) of the disk. Since this is no change in height
of any of the objects in our system, gravitational potential
energy can be ignored. Therefore, the conservation of energy
can be written.

Δ𝐸𝐸 = Δ𝑈𝑠𝑈 𝑠 + Δ𝐾𝑙𝐾 𝑙𝑙 𝑙𝑙 𝑙 + Δ𝐾𝑟𝐾 𝑟𝑟𝑟𝑟 𝑟 = 0.

In this initial situation (compressed spring), there is no kinetic
energy and in the final situation there is no elastic potential
energy since the spring returns to its natural length. We can
then write the conservation of energy equation as

− [1] 2 + [1] 2 + [1] 2 = 0.

2 [𝑘][𝑘][𝑥][𝑖][𝑥] 2 [𝑚][𝑚][𝑣][𝑓][𝑣] 2 [𝐼][𝐼][𝜔][𝑓][𝜔]


A solid disk has 𝐼𝐼 = (1 2⁄ )𝑚𝑚𝑟𝑟[2], which leads to

− [1] 2 + [1] 2 + [1] 2 = 0.
2 [𝑘][𝑘][𝑥][𝑖][𝑥] 2 [𝑚][𝑚][𝑣][𝑓][𝑣] 2 [�][1]2 [𝑚][𝑚][𝑟][𝑟][2][�𝜔][𝑓][𝜔]

Since the disk is rolling without slipping, we can also use
the fact that 𝑣𝑣[2] = 𝜔𝜔[2]𝑟𝑟[2] to simplify the final term, leading
to

− [1] 2 + [1] 2 + [1] 2 = 0.
2 [𝑘][𝑘][𝑥][𝑖][𝑥] 2 [𝑚][𝑚][𝑣][𝑓][𝑣] 4 [𝑚][𝑚][𝑣][𝑓][𝑣]

We can now solve for the final speed and use the values
given in the problem:

⁄
𝑣𝑓𝑣 𝑓 = [�2𝑘]3𝑚𝑚 [𝑥][𝑖][𝑥] [𝑖] [= ][�2(76 𝑁]3(0.019 𝑘[𝑁] [𝑚]𝑘𝑘[𝑚][)]𝑘) [(0.0056 𝑚][𝑚][),]

or

𝑣𝑓𝑣 𝑓 = 0.29 𝑚𝑚⁄𝑠𝑠.

Note, as always, that we started with the most general
form of the conservation of energy and use terms related
to the information given in the problem.


-----

